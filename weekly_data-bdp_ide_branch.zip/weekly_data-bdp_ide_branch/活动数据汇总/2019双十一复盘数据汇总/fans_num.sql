select
	shop_id,
	count(distinct case when end_date > '2019-10-18' then pin end) 累计粉丝数, ----本周周期开始
	count(distinct case when end_date > '2019-11-15' then pin end) 本周末粉丝数, ----本周周期结束
	count(distinct case when start_date <= '2019-10-17' then pin end) 上周末粉丝数, ----本周周期开始前一天
	count(distinct case when start_date >= '2019-10-18' then pin end) 新增粉丝数 ----本周周期开始
from
	fdm.fdm_follow_vender_sns_follow_vender_chain ----粉丝拉链表
where
	start_date <= '2019-11-15'
	and end_date > '2019-10-17'
	and shop_id in('1000015268', '1000014803', '1000006804', '1000013402', '1000003685', '1000040122', '1000017162', '1000100813', '1000077335', '1000014142', '1000008814', '1000014286', '1000040105', '1000075642', '1000014486', '1000074823', '1000014602', '1000014550', '1000079565', '1000010481', '1000100813')
group by
	shop_id
select
	coalesce(t1.dept_name, t2.dept_name) 部门名称,
	coalesce(t1.brand_code, t2.brand_code) 品牌id,
	coalesce(t1.barndname_full, t2.barndname_full) 品牌,
	sum(case when t1.year_dt = 2019 then 自营PV end) 今年自营PV,
	sum(case when t1.year_dt = 2019 then 自营UV end) 今年自营UV,
	sum(case when t1.year_dt = 2019 then POPPV end) 今年POPPV,
	sum(case when t1.year_dt = 2019 then POPUV end) 今年POPUV,
	sum(case when t1.year_dt = 2019 then 自营有效子单数 end) 今年自营有效子单数,
	sum(case when t1.year_dt = 2019 then 自营gmv end) 今年自营gmv,
	sum(case when t1.year_dt = 2019 then POP有效子单数 end) 今年POP有效子单数,
	sum(case when t1.year_dt = 2019 then POPgmv end) 今年POPgmv,
	sum(case when t1.year_dt = 2018 then 自营PV end) 去年自营PV,
	sum(case when t1.year_dt = 2018 then 自营UV end) 去年自营UV,
	sum(case when t1.year_dt = 2018 then POPPV end) 去年POPPV,
	sum(case when t1.year_dt = 2018 then POPUV end) 去年POPUV,
	sum(case when t1.year_dt = 2018 then 自营有效子单数 end) 去年自营有效子单数,
	sum(case when t1.year_dt = 2018 then 自营gmv end) 去年自营gmv,
	sum(case when t1.year_dt = 2018 then POP有效子单数 end) 去年POP有效子单数,
	sum(case when t1.year_dt = 2018 then POPgmv end) 去年POPgmv
from
	(
		select /*+ mapjoin(a)*/
			a.dept_name,
			a.brand_code,
			a.barndname_full,
			b.year_dt,
			count(distinct case when model = '自营' then b.sale_ord_id end) 自营有效子单数,
			sum(case when model = '自营' then b.cw_gmv else 0 end) 自营gmv,
			count(distinct case when model = 'POP' then b.sale_ord_id end) POP有效子单数,
			sum(case when model = 'POP' then b.cw_gmv else 0 end) POPgmv
		from
			(
				select
					item_sku_id,
					case dept_id_3
						when '3842' then '饼干蛋糕组'
						when '989' then '饼干蛋糕组'
						when '3840' then '坚果组'
						when '4159' then '坚果组'
						when '4161' then '糖巧组'
						when '4162' then '糖巧组'
					end dept_name,
					case data_type
						when '1' then '自营'
						when '3' then 'POP'
					end model,
					brand_code,
					barndname_full
				from
					gdm.gdm_m03_active_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and
					(
						(
							dept_id_3 in('3842', '989')
							and brand_code in('3681', '5673', '5869', '7858', '8055', '8165', '10361', '10440', '10485', '10590', '11187', '11237', '12679', '13004', '13885', '14597', '14633', '14962', '16062', '16599', '17315', '17332', '17659', '18169', '18768', '20050', '20244', '21051', '21649', '21651', '22553', '25573', '28939', '32686', '32702', '36999', '40943', '41772', '44612', '63503', '64477', '77835', '78378', '102806', '145053', '151523', '163954', '196237', '197246', '244659', '386919', '400077', '431656')
						)
						or
						(
							dept_id_3 in('3840', '4159')
							and brand_code in('3979', '7241', '8092', '8558', '10745', '11540', '11726', '11727', '17919', '19144', '19145', '25550', '26083', '27649', '27776', '32294', '66594', '69131', '78743', '94390', '144349', '149866', '172808', '219371', '236440', '236923', '249090', '271882', '280910', '284708', '291846', '386766')
						)
						or
						(
							dept_id_3 in('4161', '4162')
							and brand_code in('5926', '18768', '151468')
						)
					)
			)
			a
		join
			(
				select
					year(dt) year_dt,
					item_sku_id,
					sale_ord_id,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2018-10-18'
							and dt <= '2018-11-11'
						)
						or
						(
							dt >= '2019-10-18'
							and dt <= '2019-11-11'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		group by
			a.dept_name,
			a.brand_code,
			a.barndname_full,
			b.year_dt
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			a.dept_name,
			a.brand_code,
			a.barndname_full,
			b.year_dt,
			sum(case when model = '自营' then b.pv else 0 end) 自营PV,
			count(distinct case when model = '自营' then b.browser_uniq_id end) 自营UV,
			sum(case when model = 'POP' then b.pv else 0 end) POPPV,
			count(distinct case when model = 'POP' then b.browser_uniq_id end) POPUV
		from(
				select
					item_sku_id,
					case dept_id_3
						when '3842' then '饼干蛋糕组'
						when '989' then '饼干蛋糕组'
						when '3840' then '坚果组'
						when '4159' then '坚果组'
						when '4161' then '糖巧组'
						when '4162' then '糖巧组'
					end dept_name,
					case data_type
						when '1' then '自营'
						when '3' then 'POP'
					end model,
					brand_code,
					barndname_full
				from
					gdm.gdm_m03_active_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and
					(
						(
							dept_id_3 in('3842', '989')
							and brand_code in('3681', '5673', '5869', '7858', '8055', '8165', '10361', '10440', '10485', '10590', '11187', '11237', '12679', '13004', '13885', '14597', '14633', '14962', '16062', '16599', '17315', '17332', '17659', '18169', '18768', '20050', '20244', '21051', '21649', '21651', '22553', '25573', '28939', '32686', '32702', '36999', '40943', '41772', '44612', '63503', '64477', '77835', '78378', '102806', '145053', '151523', '163954', '196237', '197246', '244659', '386919', '400077', '431656')
						)
						or
						(
							dept_id_3 in('3840', '4159')
							and brand_code in('3979', '7241', '8092', '8558', '10745', '11540', '11726', '11727', '17919', '19144', '19145', '25550', '26083', '27649', '27776', '32294', '66594', '69131', '78743', '94390', '144349', '149866', '172808', '219371', '236440', '236923', '249090', '271882', '280910', '284708', '291846', '386766')
						)
						or
						(
							dept_id_3 in('4161', '4162')
							and brand_code in('5926', '18768', '151468')
						)
					)
			)
			a
		join
			(
				select
					year(dt) year_dt,
					sku_id,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2018-10-18'
							and dt <= '2018-11-11'
						)
						or
						(
							dt >= '2019-10-18'
							and dt <= '2019-11-11'
						)
					)
				group by
					sku_id,
					year(dt),
					browser_uniq_id
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			a.dept_name,
			a.brand_code,
			a.barndname_full,
			b.year_dt
	)
	t2
on
	t1.year_dt = t2.year_dt
	and t1.dept_name = t2.dept_name
	and t1.brand_code = t2.brand_code
group by
	coalesce(t1.dept_name, t2.dept_name),
	coalesce(t1.brand_code, t2.brand_code),
	coalesce(t1.barndname_full, t2.barndname_full)
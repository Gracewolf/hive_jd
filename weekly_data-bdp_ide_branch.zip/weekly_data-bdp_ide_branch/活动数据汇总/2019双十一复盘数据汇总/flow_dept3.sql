----周报分渠道流量模板
select
	coalesce(t1.dept_id_3, t2.dept_id_3) 部门id,
	coalesce(t1.dept_name_3, t2.dept_name_3) 部门名称,
	sum(case when t1.year_dt = 2019 then t1.有效用户数 end) 今年有效用户数,
	sum(case when t1.year_dt = 2019 then t1.有效子单数 end) 今年有效子单数,
	sum(case when t1.year_dt = 2019 then t1.有效父单数 end) 今年有效父单数,
	sum(case when t1.year_dt = 2019 then t1.gmv end) 今年gmv,
	sum(case when t1.year_dt = 2019 then t2.pv end) 今年pv,
	sum(case when t1.year_dt = 2019 then t2.uv end) 今年uv,
	sum(case when t1.year_dt = 2018 then t1.有效用户数 end) 去年有效用户数,
	sum(case when t1.year_dt = 2018 then t1.有效子单数 end) 去年有效子单数,
	sum(case when t1.year_dt = 2018 then t1.有效父单数 end) 去年有效父单数,
	sum(case when t1.year_dt = 2018 then t1.gmv end) 去年gmv,
	sum(case when t1.year_dt = 2018 then t2.pv end) 去年pv,
	sum(case when t1.year_dt = 2018 then t2.uv end) 去年uv
from
	(
		select /*+ mapjoin(a)*/
			a.dept_id_3,
			a.dept_name_3,
			b.year_dt,
			count(distinct b.pin) 有效用户数,
			count(distinct b.sale_ord_id) 有效子单数,
			count(distinct b.parent_sale_ord_id) 有效父单数,
			sum(b.cw_gmv) gmv
		from
			(
				select
					item_sku_id,
					dept_id_3,
					dept_name_3
				from
					gdm.gdm_m03_active_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					item_sku_id,
					sale_ord_id,
					parent_sale_ord_id,
					lower(trim(user_log_acct)) pin,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2018-10-18'
							and dt <= '2018-11-15'
						)
						or
						(
							dt >= '2019-10-18'
							and dt <= '2019-11-15'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		group by
			a.dept_id_3,
			a.dept_name_3,
			b.year_dt
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			b.year_dt,
			a.dept_id_3,
			a.dept_name_3,
			sum(b.pv) pv,
			count(distinct b.browser_uniq_id) uv
		from
			(
				select
					item_sku_id,
					dept_id_3,
					dept_name_3,
					data_type
				from
					gdm.gdm_m03_active_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					sku_id,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2018-10-18'
							and dt <= '2018-11-15'
						)
						or
						(
							dt >= '2019-10-18'
							and dt <= '2019-11-15'
						)
					)
				group by
					sku_id,
					year(dt),
					browser_uniq_id
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			b.year_dt,
			a.dept_id_3,
			a.dept_name_3
	)
	t2
on
	t1.year_dt = t2.year_dt
	and t1.dept_id_3 = t2.dept_id_3
group by
	coalesce(t1.dept_id_3, t2.dept_id_3),
	coalesce(t1.dept_name_3, t2.dept_name_3)
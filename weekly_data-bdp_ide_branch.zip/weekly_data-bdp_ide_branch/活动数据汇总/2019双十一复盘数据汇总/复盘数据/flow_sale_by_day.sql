select
	t1.*,
	t2.PV,
	t2.自营PV,
	t2.POPPV
from
	(
		select /*+mapjoin(a)*/
			c.dt,
			sum(case when a.data_type = '1' and b.item_id is not null then 0 else c.cw_gmv end) GMV,
			sum(case when a.data_type = '3' then c.cw_gmv else 0 end) POPGMV,
			sum(case when a.data_type = '1' and b.item_id is null then c.cw_gmv else 0 end) 自营GMV
		from
			(
				select
					item_sku_id,
					item_id,
					data_type
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
			)
			a
		left join
			(
				select
					item_id
				from
					gdm.gdm_m03_item_spec_attr_da
				where
					dt = sysdate( - 1)
					and attr_name in('factoryShip')
					and attr_val in('1')
			)
			b
		on
			a.item_id = b.item_id
		join
			(
				select
					item_sku_id,
					dt,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2018-10-18'
							and dt <='2018-11-15'
						)
						or
						(
							dt >= '2019-10-18'
							and dt <= '2019-11-15'
						)
					)
					and valid_flag = '1'
					and
					(
						(
							tp = '1'
							and substr(ord_flag, 40, 1) <> '1'
						) ----自营剔分销
						or
						(
							tp = '2'
							and
							(
								item_second_cate_cd <> '4980'
								and item_third_cate_cd <> '4992'
							)
						) ----POP剔赠品
					)
			)
			c
		on
			a.item_sku_id = c.item_sku_id
		group by
			c.dt
	)
	t1
join
	(
		select /*+mapjoin(a)*/
			b.dt,
			sum(sku_pv) PV,
			sum(case when a.data_type = '1' then sku_pv else 0 end) 自营PV,
			sum(case when a.data_type = '3' then sku_pv else 0 end) POPPV
		from
			(
				select
					item_sku_id,
					data_type
				from
					gdm.gdm_m03_active_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
			)
			a
		join
			(
				select
					sku_id,
					sku_pv,
					dt
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2018-10-18'
							and dt <='2018-11-15'
						)
						or
						(
							dt >= '2019-10-18'
							and dt <= '2019-11-15'
						)
					)
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			b.dt
	)
	t2
on
	t1.dt = t2.dt;

select
	t1.*,
	t2.PV,
	t2.自营PV,
	t2.POPPV,
	t2.UV,
	t2.自营UV,
	t2.POPUV
from
	(
		select /*+mapjoin(a)*/
			c.year_dt,
			sum(case when a.data_type = '1' and b.item_id is not null then 0 else c.cw_gmv end) GMV,
			sum(case when a.data_type = '3' then c.cw_gmv else 0 end) POPGMV,
			sum(case when a.data_type = '1' and b.item_id is null then c.cw_gmv else 0 end) 自营GMV
		from
			(
				select
					item_sku_id,
					item_id,
					data_type
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
			)
			a
		left join
			(
				select
					item_id
				from
					gdm.gdm_m03_item_spec_attr_da
				where
					dt = sysdate( - 1)
					and attr_name in('factoryShip')
					and attr_val in('1')
			)
			b
		on
			a.item_id = b.item_id
		join
			(
				select
					item_sku_id,
					year(dt) year_dt,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2018-11-01'
							and dt <='2018-11-11'
						)
						or
						(
							dt >= '2019-11-01'
							and dt <= '2019-11-11'
						)
					)
					and valid_flag = '1'
					and
					(
						(
							tp = '1'
							and substr(ord_flag, 40, 1) <> '1'
						) ----自营剔分销
						or
						(
							tp = '2'
							and
							(
								item_second_cate_cd <> '4980'
								and item_third_cate_cd <> '4992'
							)
						) ----POP剔赠品
					)
			)
			c
		on
			a.item_sku_id = c.item_sku_id
		group by
			c.year_dt
	)
	t1
join
	(
		select /*+mapjoin(a)*/
			b.year_dt,
			sum(sku_pv) PV,
			sum(case when a.data_type = '1' then sku_pv else 0 end) 自营PV,
			sum(case when a.data_type = '3' then sku_pv else 0 end) POPPV,
			count(distinct browser_uniq_id) UV,
			count(distinct case when data_type = '1' then browser_uniq_id end) 自营UV,
			count(distinct case when data_type = '3' then browser_uniq_id end) POPUV
		from
			(
				select
					item_sku_id,
					data_type
				from
					gdm.gdm_m03_active_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					sku_id,
					sku_pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2018-11-01'
							and dt <='2018-11-11'
						)
						or
						(
							dt >= '2019-11-01'
							and dt <= '2019-11-11'
						)
					)
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			b.year_dt
	)
	t2
on
	t1.year_dt = t2.year_dt
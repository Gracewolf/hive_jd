----wk_dept2
select
	'0' 部门id,
	'食品饮料（经分）' 部门,
	count(distinct case when x.year_dt = 2019 then x.user_log_acct end) 今年总用户数,
	count(distinct case when x.year_dt = 2019 and par_ord_num >= 2 then x.user_log_acct end) 今年复购用户数,
	count(distinct case when x.year_dt = 2019 and y.year_dt = x.year_dt and fst_all_yn = 1 then x.user_log_acct end) 今年站外新用户数,
	count(distinct case when x.year_dt = 2019 and y.year_dt = x.year_dt and fst_all_yn = 0 then x.user_log_acct end) 今年站内新用户数,
	sum(case when x.year_dt = 2019 then par_ord_num end) 今年父单数,
	count(distinct case when x.year_dt = 2018 then x.user_log_acct end) 去年总用户数,
	count(distinct case when x.year_dt = 2018 and par_ord_num >= 2 then x.user_log_acct end) 去年复购用户数,
	count(distinct case when x.year_dt = 2018 and y.year_dt = x.year_dt and fst_all_yn = 1 then x.user_log_acct end) 去年站外新用户数,
	count(distinct case when x.year_dt = 2018 and y.year_dt = x.year_dt and fst_all_yn = 0 then x.user_log_acct end) 去年站内新用户数,
	sum(case when x.year_dt = 2018 then par_ord_num end) 去年父单数
from
	(
		select /*+ MAPJOIN(a)*/
			b.year_dt,
			b.user_log_acct,
			count(distinct parent_sale_ord_id) par_ord_num
		from
			(
				select
					item_sku_id,
					dept_id_2,
					dept_name_2
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and item_first_cate_cd = '1320'
			)
			a
		join
			(
				select
					lower(trim(user_log_acct)) user_log_acct,
					item_sku_id,
					year(sale_ord_dt) year_dt,
					parent_sale_ord_id,
					check_account_tm,
					sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
				from
					gdm.gdm_m04_ord_det_sum
				where
					dt >= '2018-10-18'
					and
					(
						(
							sale_ord_dt >= '2018-10-18'
							and sale_ord_dt <= '2018-11-15'
						)
						or
						(
							sale_ord_dt >= '2019-10-18'
							and sale_ord_dt <= '2019-11-15'
						)
					)
					and sale_ord_valid_flag = '1'
					and item_third_cate_cd not in('6980') --剔除礼品卡
					and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
					and
					(
						substr(ord_flag, 31, 1) <> '2' --非行政内采
						or
						(
							substr(ord_flag, 31, 1) = '2'
							and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
						)
					)
					and
					(
						substring(ord_flag, 46, 1) not in('1', '2', '3', '7')
						or substring(ord_flag, 60, 3) not in('013')
					)
					and sale_ord_type_cd <> '68' --剔除拍卖
					and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
					and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
					and user_log_acct not like"ept%"
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		where
			b.ord_amount < 100000
			or
			(
				b.ord_amount >= 100000
				and coalesce(b.check_account_tm, '') <> ''
			)
		group by
			b.year_dt,
			b.user_log_acct
	)
	x
left join
	(
		select
			x.user_log_acct,
			x.fst_all_yn,
			x.spite_flag,
			case
				when fst_ord_dt >= '2018-10-18' and fst_ord_dt <= '2018-11-15' then 2018
				when fst_ord_dt >= '2019-10-18' and fst_ord_dt <= '2019-11-15' then 2019
			end year_dt
		from
			(
				select
					lower(trim(unif_user_log_acct)) user_log_acct,
					max(case when fst_all_yn = '1' then 1 else 0 end) fst_all_yn,
					max(case when spite_user_flag = '1' then 1 else 0 end) spite_flag,
					min(fst_ord_dt) fst_ord_dt
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 1)
					and tp = 'cate'
					and item_first_cate_cd = '1320'
				group by
					lower(trim(unif_user_log_acct))
			)
			x
	)
	y
on
	x.user_log_acct = y.user_log_acct
where
	y.spite_flag <> 1
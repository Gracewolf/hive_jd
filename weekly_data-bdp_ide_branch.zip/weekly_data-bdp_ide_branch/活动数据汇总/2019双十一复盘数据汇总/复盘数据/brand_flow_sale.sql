select
	coalesce(t1.brand_code, t2.brand_code) 品牌id,
	coalesce(t1.barndname_full, t2.barndname_full) 品牌,
	t1.今年自营GMV,
	t1.去年自营GMV,
	t1.今年POPGMV,
	t1.去年POPGMV,
	t2.今年自营PV,
	t2.去年自营PV,
	t2.今年POPPV,
	t2.去年POPPV
from
	(
		select /*+mapjoin(a)*/
			a.brand_code,
			a.barndname_full,
			sum(case when c.year_dt = 2019 and data_type = '1' then cw_gmv end) 今年自营GMV,
			sum(case when c.year_dt = 2018 and data_type = '1' then cw_gmv end) 去年自营GMV,
			sum(case when c.year_dt = 2019 and data_type = '3' then cw_gmv end) 今年POPGMV,
			sum(case when c.year_dt = 2018 and data_type = '3' then cw_gmv end) 去年POPGMV
		from
			(
				select
					item_sku_id,
					item_id,
					data_type,
					brand_code,
					barndname_full
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
					and brand_code in('12690', '19306', '27776', '7095', '149866', '9429', '14633', '11540', '7623', '3979', '11742', '55567', '15840', '17332', '3492', '63953', '5673', '10504', '37837')
			)
			a
		left join
			(
				select
					item_id
				from
					gdm.gdm_m03_item_spec_attr_da
				where
					dt = sysdate( - 1)
					and attr_name in('factoryShip')
					and attr_val in('1')
			)
			b
		on
			a.item_id = b.item_id
		join
			(
				select
					item_sku_id,
					year(dt) year_dt,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2018-11-01'
							and dt <='2018-11-11'
						)
						or
						(
							dt >= '2019-11-01'
							and dt <= '2019-11-11'
						)
					)
					and valid_flag = '1'
					and
					(
						(
							tp = '1'
							and substr(ord_flag, 40, 1) <> '1'
						) ----自营剔分销
						or
						(
							tp = '2'
							and
							(
								item_second_cate_cd <> '4980'
								and item_third_cate_cd <> '4992'
							)
						) ----POP剔赠品
					)
			)
			c
		on
			a.item_sku_id = c.item_sku_id
		where
			a.data_type <> '1'
			or
			(
				a.data_type = '1'
				and b.item_id is null ----自营厂直
			)
		group by
			a.brand_code,
			a.barndname_full
	)
	t1
full outer join
	(
		select /*+mapjoin(a)*/
			a.brand_code,
			a.barndname_full,
			sum(case when b.year_dt = 2019 and data_type = '1' then sku_pv end) 今年自营PV,
			sum(case when b.year_dt = 2018 and data_type = '1' then sku_pv end) 去年自营PV,
			sum(case when b.year_dt = 2019 and data_type = '3' then sku_pv end) 今年POPPV,
			sum(case when b.year_dt = 2018 and data_type = '3' then sku_pv end) 去年POPPV
		from
			(
				select
					item_sku_id,
					data_type,
					brand_code,
					barndname_full
				from
					gdm.gdm_m03_active_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
					and brand_code in('12690', '19306', '27776', '7095', '149866', '9429', '14633', '11540', '7623', '3979', '11742', '55567', '15840', '17332', '3492', '63953', '5673', '10504', '37837')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					sku_id,
					sku_pv
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2018-11-01'
							and dt <='2018-11-11'
						)
						or
						(
							dt >= '2019-11-01'
							and dt <= '2019-11-11'
						)
					)
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			a.brand_code,
			a.barndname_full
	)
	t2
on
	t1.brand_code = t2.brand_code
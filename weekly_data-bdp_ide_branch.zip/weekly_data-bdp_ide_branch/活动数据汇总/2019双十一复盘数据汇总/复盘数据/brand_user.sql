select
	b.year_dt,
	a.brand_code,
	a.barndname_full,
	count(distinct case when data_type = '1' then b.user_log_acct end) 自营整体用户,
	count(distinct case when data_type = '1' and fst_all_yn = 0 then b.user_log_acct end) 自营站内新,
	count(distinct case when data_type = '1' and fst_all_yn = 1 then b.user_log_acct end) 自营站外新,
	count(distinct case when data_type = '3' then b.user_log_acct end) POP整体用户,
	count(distinct case when data_type = '3' and fst_all_yn = 0 then b.user_log_acct end) POP站内新,
	count(distinct case when data_type = '3' and fst_all_yn = 1 then b.user_log_acct end) POP站外新
from
	(
		select
			item_sku_id,
			data_type,
			brand_code,
			barndname_full
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and dept_id_2 in('47', '1699')
			and brand_code in('12690', '19306', '27776', '7095', '149866', '9429', '14633', '11540', '7623', '3979', '11742', '55567', '15840', '17332', '3492', '63953', '5673', '10504', '37837')
	)
	a
join
	(
----有效订单模板
		select
			b.*
		from
			(
				select
					user_log_acct,
					item_sku_id,
					sale_ord_dt,
					year(sale_ord_dt) year_dt,
					parent_sale_ord_id,
					sale_ord_id,
					case
						when after_prefr_amount_1 is not null and after_prefr_amount_1 <> '' then after_prefr_amount_1
						else after_prefr_amount
					end after_prefr_amount_1,
					check_account_tm,
					sale_qtty,
					sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
				from
					gdm.gdm_m04_ord_det_sum
				where
					dt >= '2018-01-01'
					and
					(
						(
							sale_ord_dt >= '2018-11-01'
							and sale_ord_dt <='2018-11-11'
						)
						or
						(
							sale_ord_dt >= '2019-11-01'
							and sale_ord_dt <= '2019-11-11'
						)
					)
					and sale_ord_valid_flag = '1'
					and item_third_cate_cd not in('6980') --剔除礼品卡
					and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
					and
					(
						substr(ord_flag, 31, 1) <> '2' --非行政内采
						or
						(
							substr(ord_flag, 31, 1) = '2'
							and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
						)
					)
					and
					(
						substr(ord_flag, 46, 1) not in('1', '2', '3', '7')
						or substr(ord_flag, 60, 3) not in('013')
					)
					and sale_ord_type_cd <> '68' --剔除拍卖
					and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
					and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
					and user_log_acct not like"ept%"
			)
			b
		where
			b.ord_amount < 100000
			or
			(
				b.ord_amount >= 100000
				and coalesce(b.check_account_tm, '') <> ''
			)
	)
	b
on
	a.item_sku_id = b.item_sku_id
left join
	(
		select
			case x.main_brand_cd
				when '131496' then '12690'
				when '227429' then '17332'
				else main_brand_cd
			end brand_code,
			x.user_log_acct,
			x.fst_all_yn,
			year(x.fst_ord_dt) year_dt
		from
			(
				select
					main_brand_cd,
					unif_user_log_acct user_log_acct,
					max(
						case
							when fst_all_yn = 1
							then 1
							else 0
						end) fst_all_yn,
					min(fst_ord_dt) fst_ord_dt
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 1)
					and tp = 'brand'
					and main_brand_cd in('3492', '3979', '5673', '7095', '7623', '9429', '10504', '11540', '11742', '131496', '14633', '15840', '227429', '19306', '27776', '37837', '55567', '63953', '149866')
				group by
					main_brand_cd,
					unif_user_log_acct
			)
			x
		where
			(
				(
					fst_ord_dt >= '2018-11-01'
					and fst_ord_dt <='2018-11-11'
				)
				or
				(
					fst_ord_dt >= '2019-11-01'
					and fst_ord_dt <= '2019-11-11'
				)
			)
	)
	c
on
	a.brand_code = c.brand_code
	and b.user_log_acct = c.user_log_acct
	and b.year_dt = c.year_dt
group by
	b.year_dt,
	a.brand_code,
	a.barndname_full
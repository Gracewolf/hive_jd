select
	t1.dept_id_3,
	t1.dept_name_3,
	t1.今年GMV,
	t1.去年GMV,
	t2.今年PV,
	t2.去年PV
from
	(
		select /*+mapjoin(a)*/
			a.dept_id_3,
			a.dept_name_3,
			sum(case when c.year_dt = 2019 then cw_gmv end) 今年GMV,
			sum(case when c.year_dt = 2018 then cw_gmv end) 去年GMV
		from
			(
				select
					item_sku_id,
					item_id,
					data_type,
					dept_id_3,
					dept_name_3
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
			)
			a
		left join
			(
				select
					item_id
				from
					gdm.gdm_m03_item_spec_attr_da
				where
					dt = sysdate( - 1)
					and attr_name in('factoryShip')
					and attr_val in('1')
			)
			b
		on
			a.item_id = b.item_id
		join
			(
				select
					item_sku_id,
					year(dt) year_dt,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2018-11-01'
							and dt <='2018-11-11'
						)
						or
						(
							dt >= '2019-11-01'
							and dt <= '2019-11-11'
						)
					)
					and valid_flag = '1'
					and
					(
						(
							tp = '1'
							and substr(ord_flag, 40, 1) <> '1'
						) ----自营剔分销
						or
						(
							tp = '2'
							and
							(
								item_second_cate_cd <> '4980'
								and item_third_cate_cd <> '4992'
							)
						) ----POP剔赠品
					)
			)
			c
		on
			a.item_sku_id = c.item_sku_id
		where
			a.data_type <> '1'
			or
			(
				a.data_type = '1'
				and b.item_id is null ----自营厂直
			)
		group by
			a.dept_id_3,
			a.dept_name_3
	)
	t1
join
	(
		select /*+mapjoin(a)*/
			a.dept_id_3,
			a.dept_name_3,
			sum(case when b.year_dt = 2019 then sku_pv end) 今年PV,
			sum(case when b.year_dt = 2018 then sku_pv end) 去年PV
		from
			(
				select
					item_sku_id,
					dept_id_3,
					dept_name_3
				from
					gdm.gdm_m03_active_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
			)
			a
		join
			(
				select
					year(dt) year_dt,
					sku_id,
					sku_pv
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2018-11-01'
							and dt <='2018-11-11'
						)
						or
						(
							dt >= '2019-11-01'
							and dt <= '2019-11-11'
						)
					)
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			a.dept_id_3,
			a.dept_name_3
	)
	t2
on
	t1.dept_id_3 = t2.dept_id_3
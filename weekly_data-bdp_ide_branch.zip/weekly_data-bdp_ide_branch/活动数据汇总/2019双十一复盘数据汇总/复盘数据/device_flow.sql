----周报分渠道流量模板
select
	coalesce(t1.device, t2.device) 渠道,
	sum(case when t1.year_dt = 2019 then t1.有效子单数 end) 今年有效子单数,
	sum(case when t1.year_dt = 2019 then t1.gmv end) 今年gmv,
	sum(case when t1.year_dt = 2019 then t2.pv end) 今年pv,
	sum(case when t1.year_dt = 2019 then t2.uv end) 今年uv,
	sum(case when t1.year_dt = 2018 then t1.有效子单数 end) 去年有效子单数,
	sum(case when t1.year_dt = 2018 then t1.gmv end) 去年gmv,
	sum(case when t1.year_dt = 2018 then t2.pv end) 去年pv,
	sum(case when t1.year_dt = 2018 then t2.uv end) 去年uv
from
	(
		select /*+ mapjoin(a)*/
			b.year_dt,
			b.device,
			count(distinct b.sale_ord_id) 有效子单数,
			sum(b.cw_gmv) gmv
		from
			(
				select
					item_sku_id,
					dept_id_2,
					dept_name_2
				from
					gdm.gdm_m03_active_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					item_sku_id,
					sale_ord_id,
					parent_sale_ord_id,
					lower(trim(user_log_acct)) pin,
					ord_flag,
					item_second_cate_cd,
					item_third_cate_cd,
					cw_gmv,
					case
						when terminal_flag in('12', '22', '42', '62') then 'APP'
						when terminal_flag in('13', '23', '43', '63') then 'M端'
						when terminal_flag in('11', '21', '41', '61') then 'PC'
						when terminal_flag in('33', '31', '30') then '微信'
						when terminal_flag in('32') then '手Q'
						else '未知'
					end device
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2018-11-01'
							and dt <= '2018-11-11'
						)
						or
						(
							dt >= '2019-11-01'
							and dt <= '2019-11-11'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		group by
			b.year_dt,
			b.device
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			b.year_dt,
			b.device,
			sum(b.pv) pv,
			count(distinct b.browser_uniq_id) uv
		from
			(
				select
					item_sku_id,
					dept_id_2,
					dept_name_2
				from
					gdm.gdm_m03_active_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					sku_id,
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end device,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2018-11-01'
							and dt <= '2018-11-11'
						)
						or
						(
							dt >= '2019-11-01'
							and dt <= '2019-11-11'
						)
					)
				group by
					sku_id,
					year(dt),
					browser_uniq_id,
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			b.year_dt,
			b.device
	)
	t2
on
	t1.year_dt = t2.year_dt
	and t1.device = t2.device
group by
	coalesce(t1.device, t2.device)
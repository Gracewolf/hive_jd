----APP流量来源模板
select
	/*+ mapjoin(a)*/
	src_url_first_cate_id 一级来源id,
	src_url_first_cate_name 一级来源,
	src_url_second_cate_id 二级来源id,
	src_url_second_cate_name 二级来源,
	src_url_third_cate_id 三级来源id,
	src_url_third_cate_name 三级来源,
	sum(case when year_dt = 2019 then item_pv end) 今年PV,
	sum(case when year_dt = 2019 then cart_num end) 今年加购,
	sum(case when year_dt = 2019 then intr_valid_ord_num end) 今年引入订单数,
	sum(case when year_dt = 2019 then intr_valid_aft_amount end) 今年优惠后订单金额,
	sum(case when year_dt = 2018 then item_pv end) 去年PV,
	sum(case when year_dt = 2018 then cart_num end) 去年加购,
	sum(case when year_dt = 2018 then intr_valid_ord_num end) 去年引入订单数,
	sum(case when year_dt = 2018 then intr_valid_aft_amount end) 去年优惠后订单金额
from
	(
		select
			item_sku_id,
			dept_id_2,
			dept_name_2
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and dept_id_2 in('47', '1699')
	)
	a
join
	(
		select
			year(dt) year_dt,
			sku_id,
			src_url_first_cate_id,
			src_url_first_cate_name,
			src_url_second_cate_id,
			src_url_second_cate_name,
			src_url_third_cate_id,
			src_url_third_cate_name,
			item_pv,
			cart_num,
			intr_valid_ord_num,
			intr_valid_aft_amount
		from
			adm.adm_s14_item_last_src_d
		where
			(
				(
					dt >= '2018-06-01'
					and dt <= '2018-06-20'
				)
				or
				(
					dt >= '2019-06-01'
					and dt <= '2019-06-20'
				)
			)
			and bs = '311210'
			and lvl = '6'
	)
	b
on
	a.item_sku_id = b.sku_id
group by
	src_url_first_cate_id,
	src_url_first_cate_name,
	src_url_second_cate_id,
	src_url_second_cate_name,
	src_url_third_cate_id,
	src_url_third_cate_name
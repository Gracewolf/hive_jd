select
	部门id,
	部门,
	阶段,
	总用户订单量,
	站内新订单量,
	站外新订单量,
	总用户订单量 - 站内新订单量 - 站外新订单量 老用户订单量,
	总用户金额,
	站内新金额,
	站外新金额,
	总用户金额 - 站内新金额 - 站外新金额 老用户金额
from
	(
		select
			x.dept_id_3 部门id,
			x.dept_name_3 部门,
			x.yyyy_mm 阶段,
			sum(x.ord_num) 总用户订单量,
			sum(case when fst_all_yn = 1 then x.ord_num end) 站外新订单量,
			sum(case when fst_all_yn = 0 then x.ord_num end) 站内新订单量,
			sum(x.after_prefr_amount) 总用户金额,
			sum(case when fst_all_yn = 1 then x.after_prefr_amount end) 站外新金额,
			sum(case when fst_all_yn = 0 then x.after_prefr_amount end) 站内新金额
		from
			(
				select /*+ MAPJOIN(a)*/
					dept_id_3,
					dept_name_3,
					coalesce(d.user_log_acct, b.user_log_acct) user_log_acct,
					yyyy_mm,
					sum(after_prefr_amount) after_prefr_amount,
					count(distinct sale_ord_id) ord_num
				from
					(
						select
							item_sku_id,
							dept_id_2,
							dept_name_2,
							dept_id_3,
							dept_name_3
						from
							gdm.gdm_m03_sold_item_sku_da
						where
							dt = sysdate( - 1)
							and data_type in('1', '3')
							and dept_id_2 = '47'
					)
					a
				join
					(
						select
							lower(trim(user_log_acct)) user_log_acct,
							item_sku_id,
							substr(sale_ord_dt, 1, 7) yyyy_mm,
							sale_ord_id,
							parent_sale_ord_id,
							after_prefr_amount,
							check_account_tm,
							sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
						from
							app.v_gdm_m04_ord_det_sum_rb
						where
							dt >= '2018-05-11'
							and
							(
								(
									sale_ord_dt >= '2018-05-11'
									and sale_ord_dt <= '2018-05-22'
								)
								or
								(
									sale_ord_dt >= '2019-05-01'
									and sale_ord_dt <= '2019-05-12'
								)
								or
								(
									sale_ord_dt >= '2018-06-01'
									and sale_ord_dt <= '2018-06-18'
								)
								or
								(
									sale_ord_dt >= '2019-06-01'
									and sale_ord_dt <= '2019-06-18'
								)
							)
							and sale_ord_valid_flag = '1'
							and item_third_cate_cd not in('6980') --剔除礼品卡
							and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
							and
							(
								substr(ord_flag, 31, 1) <> '2' --非行政内采
								or
								(
									substr(ord_flag, 31, 1) = '2'
									and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
								)
							)
							and
							(
								substring(ord_flag, 46, 1) not in('1', '2', '3', '7')
								or substring(ord_flag, 60, 3) not in('013')
							)
							and sale_ord_type_cd <> '68' --剔除拍卖
							and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
							and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
							and user_log_acct not like"ept%"
							and free_goods_flag = 0
					)
					b
				on
					a.item_sku_id = b.item_sku_id
				left join
					(
						select
							lower(trim(unif_user_log_acct)) user_log_acct,
							lower(trim(user_acct_name)) pin
						from
							gdm.gdm_m01_userinfo_basic_da
						where
							dt = sysdate( - 1)
					) ----归一化用户pin
					d
				on
					b.user_log_acct = d.pin
				where
					b.ord_amount < 100000
					or
					(
						b.ord_amount >= 100000
						and coalesce(b.check_account_tm, '') <> ''
					)
				group by
					dept_id_3,
					dept_name_3,
					coalesce(d.user_log_acct, b.user_log_acct),
					yyyy_mm
			)
			x
		left join
			(
				select
					dept_id_3,
					x.user_log_acct,
					x.fst_all_yn,
					substr(fst_ord_dt, 1, 7) yyyy_mm
				from
					(
						select
							dept_id_3,
							lower(trim(unif_user_log_acct)) user_log_acct,
							max(case when fst_all_yn = '1' then 1 else 0 end) fst_all_yn,
							min(fst_ord_dt) fst_ord_dt
						from
							app.v_adm_s01_user_new_or_old_flag_detail_xfp
						where
							dt = sysdate( - 1)
							and tp = 'dept'
							and dept_id_2 = '47'
						group by
							dept_id_3,
							lower(trim(unif_user_log_acct))
					)
					x
				where
					(
						(
							fst_ord_dt >= '2018-05-11'
							and fst_ord_dt <= '2018-05-22'
						)
						or
						(
							fst_ord_dt >= '2019-05-01'
							and fst_ord_dt <= '2019-05-12'
						)
						or
						(
							fst_ord_dt >= '2018-06-01'
							and fst_ord_dt <= '2018-06-18'
						)
						or
						(
							fst_ord_dt >= '2019-06-01'
							and fst_ord_dt <= '2019-06-18'
						)
					)
			)
			y
		on
			x.user_log_acct = y.user_log_acct
			and x.yyyy_mm = y.yyyy_mm
			and x.dept_id_3 = y.dept_id_3
		left join
			(
				select * from dev_xfp.spite_user_list_xfp
			)
			c
		on
			x.user_log_acct = c.user_log_acct
		where
			c.user_log_acct is null
		group by
			x.dept_id_3,
			x.dept_name_3,
			x.yyyy_mm
	)
	ff
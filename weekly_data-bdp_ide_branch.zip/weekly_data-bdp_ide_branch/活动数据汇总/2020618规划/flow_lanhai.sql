set hive.exec.parallel = true;
select
	coalesce(t1.model, t2.model) model,
	sum(case when coalesce(t1.year_dt, t2.year_dt) = 2019 then org_gmv else 0.0 end) 今年org_gmv,
	sum(case when coalesce(t1.year_dt, t2.year_dt) = 2019 then org_pv else 0 end) 今年org_pv,
	sum(case when coalesce(t1.year_dt, t2.year_dt) = 2018 then org_gmv else 0.0 end) 去年org_gmv,
	sum(case when coalesce(t1.year_dt, t2.year_dt) = 2018 then org_pv else 0 end) 去年org_pv,
	sum(case when coalesce(t1.year_dt, t2.year_dt) = 2019 then import_gmv else 0.0 end) 今年import_gmv,
	sum(case when coalesce(t1.year_dt, t2.year_dt) = 2019 then import_pv else 0 end) 今年import_pv,
	sum(case when coalesce(t1.year_dt, t2.year_dt) = 2018 then import_gmv else 0.0 end) 去年import_gmv,
	sum(case when coalesce(t1.year_dt, t2.year_dt) = 2018 then import_pv else 0 end) 去年import_pv,
	sum(case when coalesce(t1.year_dt, t2.year_dt) = 2019 then src_gmv else 0.0 end) 今年src_gmv,
	sum(case when coalesce(t1.year_dt, t2.year_dt) = 2019 then src_pv else 0 end) 今年src_pv,
	sum(case when coalesce(t1.year_dt, t2.year_dt) = 2018 then src_gmv else 0.0 end) 去年src_gmv,
	sum(case when coalesce(t1.year_dt, t2.year_dt) = 2018 then src_pv else 0 end) 去年src_pv
from
	(
		select
			year_dt,
			model,
			sum(cw_gmv * organ_flag) org_gmv,
			sum(cw_gmv * src_flag) src_gmv,
			sum(cw_gmv * import_flag) import_gmv
		from
			(
				select
					item_sku_id,
					case data_type
						when '1' then '自营'
						when '3' then 'POP'
					end model,
					case when sku_name like'%有机%' then 1 else 0 end organ_flag,
					case when sku_name like'%原产地%' then 1 else 0 end src_flag,
					case when item_second_cate_cd = '5019' or dept_id_3 in('4044', '4046') then 1 else 0 end import_flag,
					item_id
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
			)
			a
		left join
			(
				select
					item_id
				from
					gdm.gdm_m03_item_spec_attr_da
				where
					dt = sysdate( - 1)
					and attr_name in('factoryShip')
					and attr_val in('1')
			)
			c
		on
			a.item_id = c.item_id
		join
			(
				select
					year(dt) year_dt,
					item_sku_id,
					sale_ord_id,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2018-05-15'
							and dt <= '2018-06-30'
						)
						or
						(
							dt >= '2019-05-15'
							and dt <= '2019-06-30'
						)
					)
					and valid_flag = '1'
					and
					(
						(
							tp = '1'
							and substr(ord_flag, 40, 1) <> '1'
						) ----自营剔分销
						or
						(
							tp = '2'
							and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
						) ----POP剔赠品
					)
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		where
			c.item_id is null
		group by
			year_dt,
			model
	)
	t1
full outer join
	(
		select
			year_dt,
			model,
			sum(sku_pv * organ_flag) org_pv,
			sum(sku_pv * src_flag) src_pv,
			sum(sku_pv * import_flag) import_pv
		from
			(
				select
					item_sku_id,
					case data_type
						when '1' then '自营'
						when '3' then 'POP'
					end model,
					case when sku_name like'%有机%' then 1 else 0 end organ_flag,
					case when sku_name like'%原产地%' then 1 else 0 end src_flag,
					case when item_second_cate_cd = '5019' or dept_id_3 in('4044', '4046') then 1 else 0 end import_flag,
					item_id
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					sku_id,
					sku_pv
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2018-05-15'
							and dt <= '2018-06-30'
						)
						or
						(
							dt >= '2019-05-15'
							and dt <= '2019-06-30'
						)
					)
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			year_dt,
			model
	)
	t2
on
	t1.year_dt = t2.year_dt
	and t1.model = t2.model
group by
	coalesce(t1.model, t2.model)
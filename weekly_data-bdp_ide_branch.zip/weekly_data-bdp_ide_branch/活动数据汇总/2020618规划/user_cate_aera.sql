set hive.exec.parallel = true;
select
	部门id,
	部门,
	今年总用户数,
	今年总用户有效金额,
	今年站内新用户数,
	今年站内新有效金额,
	今年站外新用户数,
	今年站外新有效金额,
	今年总用户数 - 今年站内新用户数 - 今年站外新用户数 今年老用户数,
	今年总用户有效金额 - 今年站内新有效金额 - 今年站外新有效金额 今年老用户有效金额,
	今年复购用户数,
	去年总用户数,
	去年总用户有效金额,
	去年站内新用户数,
	去年站内新有效金额,
	去年站外新用户数,
	去年站外新有效金额,
	去年总用户数 - 去年站内新用户数 - 去年站外新用户数 去年老用户数,
	去年总用户有效金额 - 去年站内新有效金额 - 去年站外新有效金额 去年老用户有效金额,
	去年复购用户数
from
	(
		select
			'0' 部门id,
			coalesce(region_name, '未知') 部门,
			count(distinct case when x.year_dt = 2019 then x.user_log_acct end) 今年总用户数,
			sum(case when x.year_dt = 2019 then x.after_prefr_amount end) 今年总用户有效金额,
			count(distinct case when x.year_dt = 2019 and fst_all_yn = 1 then x.user_log_acct end) 今年站外新用户数,
			sum(case when x.year_dt = 2019 and fst_all_yn = 1 then x.after_prefr_amount end) 今年站外新有效金额,
			count(distinct case when x.year_dt = 2019 and fst_all_yn = 0 then x.user_log_acct end) 今年站内新用户数,
			sum(case when x.year_dt = 2019 and fst_all_yn = 0 then x.after_prefr_amount end) 今年站内新有效金额,
			count(distinct case when x.year_dt = 2019 and ord_num >= 2 then x.user_log_acct end) 今年复购用户数,
			count(distinct case when x.year_dt = 2018 then x.user_log_acct end) 去年总用户数,
			sum(case when x.year_dt = 2018 then x.after_prefr_amount end) 去年总用户有效金额,
			count(distinct case when x.year_dt = 2018 and fst_all_yn = 1 then x.user_log_acct end) 去年站外新用户数,
			sum(case when x.year_dt = 2018 and fst_all_yn = 1 then x.after_prefr_amount end) 去年站外新有效金额,
			count(distinct case when x.year_dt = 2018 and fst_all_yn = 0 then x.user_log_acct end) 去年站内新用户数,
			sum(case when x.year_dt = 2018 and fst_all_yn = 0 then x.after_prefr_amount end) 去年站内新有效金额,
			count(distinct case when x.year_dt = 2018 and ord_num >= 2 then x.user_log_acct end) 去年复购用户数
		from
			(
				select /*+ MAPJOIN(a)*/
					coalesce(d.user_log_acct, b.user_log_acct) user_log_acct,
					region_name,
					year_dt,
					sum(after_prefr_amount) after_prefr_amount,
					count(distinct parent_sale_ord_id) ord_num
				from
					(
						select
							item_sku_id
						from
							gdm.gdm_m03_sold_item_sku_da
						where
							dt = sysdate( - 1)
							and data_type in('1', '3')
							and item_first_cate_cd = '1320'
					)
					a
				join
					(
						select
							lower(trim(user_log_acct)) user_log_acct,
							item_sku_id,
							year(sale_ord_dt) year_dt,
							parent_sale_ord_id,
							after_prefr_amount,
							check_account_tm,
							rev_addr_city_id,
							sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
						from
							app.v_gdm_m04_ord_det_sum_dkx
						where
							dt >= '2018-05-15'
							and
							(
								(
									sale_ord_dt >= '2018-05-15'
									and sale_ord_dt <= '2018-06-30'
								)
								or
								(
									sale_ord_dt >= '2019-05-15'
									and sale_ord_dt <= '2019-06-30'
								)
							)
							and sale_ord_valid_flag = '1'
							and item_third_cate_cd not in('6980') --剔除礼品卡
							and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
							and
							(
								substr(ord_flag, 31, 1) <> '2' --非行政内采
								or
								(
									substr(ord_flag, 31, 1) = '2'
									and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
								)
							)
							and
							(
								substring(ord_flag, 46, 1) not in('1', '2', '3', '7')
								or substring(ord_flag, 60, 3) not in('013')
							)
							and sale_ord_type_cd <> '68' --剔除拍卖
							and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
							and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
							and user_log_acct not like"ept%"
							and free_goods_flag = 0
					)
					b
				on
					a.item_sku_id = b.item_sku_id
				left join
					(
						select
							lower(trim(unif_user_log_acct)) user_log_acct,
							lower(trim(user_acct_name)) pin
						from
							gdm.gdm_m01_userinfo_basic_da
						where
							dt = sysdate( - 1)
					) ----归一化用户pin
					d
				on
					b.user_log_acct = d.pin
				left join
				    (
				        select
				            dim_city_id,
				            region_name
				        from
				            (
				                select * from dim.dim_cmo_user_jxkh_county_new
				            )
				            a
				        join
				            (
				                select * from dim.dim_province_subd_region
				            )
				            b
				        on
				            a.dim_province_id = b.dim_province_id
				        group by
				            dim_city_id,
				            region_name
				    )
				    e
				on
					b.rev_addr_city_id = e.dim_city_id
				where
					b.ord_amount < 100000
					or
					(
						b.ord_amount >= 100000
						and coalesce(b.check_account_tm, '') <> ''
					)
				group by
					coalesce(d.user_log_acct, b.user_log_acct),
					region_name,
					year_dt
			)
			x
		left join
			(
				select
					x.user_log_acct,
					x.fst_all_yn,
					year(fst_ord_dt) year_dt
				from
					(
						select
							lower(trim(unif_user_log_acct)) user_log_acct,
							max(case when fst_all_yn = '1' then 1 else 0 end) fst_all_yn,
							min(fst_ord_dt) fst_ord_dt
						from
							app.v_adm_s01_user_new_or_old_flag_detail_xfp
						where
							dt = sysdate( - 1)
							and tp = 'cate'
							and item_first_cate_cd = '1320'
						group by
							lower(trim(unif_user_log_acct))
					)
					x
				where
					(
						(
							fst_ord_dt >= '2018-05-15'
							and fst_ord_dt <= '2018-06-30'
						)
						or
						(
							fst_ord_dt >= '2019-05-15'
							and fst_ord_dt <= '2019-06-30'
						)
					)
			)
			y
		on
			x.user_log_acct = y.user_log_acct
			and x.year_dt = y.year_dt
		left join
			(
				select user_log_acct from dev_xfp.spite_user_list_xfp
			)
			c
		on
			x.user_log_acct = c.user_log_acct
		where
			c.user_log_acct is null
		group by
			coalesce(region_name, '未知')
	)
	ff
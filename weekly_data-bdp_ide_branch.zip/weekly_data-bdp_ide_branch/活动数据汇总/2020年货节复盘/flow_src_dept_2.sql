----APP流量来源模板
select
	/*+ mapjoin(a)*/
	period 阶段,
	src_url_first_cate_id 一级来源id,
	src_url_first_cate_name 一级来源,
	src_url_second_cate_id 二级来源id,
	src_url_second_cate_name 二级来源,
	src_url_third_cate_id 三级来源id,
	src_url_third_cate_name 三级来源,
	sum(case when year_dt = '2020' then item_pv end) 今年PV,
	sum(case when year_dt = '2020' then cart_num end) 今年加购,
	sum(case when year_dt = '2020' then intr_valid_ord_num end) 今年引入订单数,
	sum(case when year_dt = '2020' then intr_valid_aft_amount end) 今年优惠后订单金额,
	sum(case when year_dt = '2019' then item_pv end) 去年PV,
	sum(case when year_dt = '2019' then cart_num end) 去年加购,
	sum(case when year_dt = '2019' then intr_valid_ord_num end) 去年引入订单数,
	sum(case when year_dt = '2019' then intr_valid_aft_amount end) 去年优惠后订单金额
from
	(
		select
			item_sku_id,
			dept_id_2,
			dept_name_2
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and dept_id_2 in('47', '1699')
	)
	a
join
	(
		select
			case
				when dt <= '2019-02-11' then '2019'
				else '2020'
			end year_dt,
			case
				when dt <= '2019-02-04' then 'p1'
				when dt <= '2019-02-11' then 'p2'
				when dt <= '2020-01-24' then 'p1'
				when dt <= '2020-01-31' then 'p2'
			end period,
			sku_id,
			src_url_first_cate_id,
			src_url_first_cate_name,
			src_url_second_cate_id,
			src_url_second_cate_name,
			src_url_third_cate_id,
			src_url_third_cate_name,
			item_pv,
			cart_num,
			intr_valid_ord_num,
			intr_valid_aft_amount
		from
			adm.adm_s14_item_last_src_d
		where
			(
				(
					dt >= '2018-12-24'
					and dt <= '2019-02-11'
				)
				or
				(
					dt >= '2019-12-13'
					and dt <= '2020-01-31'
				)
			)
			and bs = '311210'
			and lvl = '6'
	)
	b
on
	a.item_sku_id = b.sku_id
group by
	period,
	src_url_first_cate_id,
	src_url_first_cate_name,
	src_url_second_cate_id,
	src_url_second_cate_name,
	src_url_third_cate_id,
	src_url_third_cate_name
select
	lihe_flag,
	dept_name,
	model,
	year_dt,
	count(distinct user_log_acct) cn,
	count(distinct sale_ord_id) ord_num,
	sum(cw_gmv) gmv,
	sum(sale_qtty) qtty
from
	(
		select
			item_sku_id,
			case when sku_name like'%礼盒%' then '礼盒' else '非礼盒' end lihe_flag,
			substr(dept_name_3, 1, 2) dept_name,
			case data_type
				when '1' then '自营'
				when '3' then 'POP'
			end model
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = '2020-02-01'
			and data_type in('1', '3')
			and dept_id_2 = '47'
	)
	a
join
	(
		select
			item_sku_id,
			case
				when dt <= '2019-02-11' then '2019'
				else '2020'
			end year_dt,
			lower(trim(user_log_acct)) user_log_acct,
			cw_gmv,
			sale_ord_id,
			sale_qtty
		from
			app.v_app_cmo_cw_ord_det_sum_rb
		where
			(
				(
					dt >= '2018-12-24'
					and dt <= '2019-02-11'
				)
				or
				(
					dt >= '2019-12-13'
					and dt <= '2020-01-31'
				)
			)
			and valid_flag = '1'
	)
	b
on
	a.item_sku_id = b.item_sku_id
group by
	lihe_flag,
	dept_name,
	model,
	year_dt

----周报分渠道流量模板
select
	coalesce(t1.dept_name, t2.dept_name) 部门名称,
	coalesce(t1.device, t2.device) 端口,
	sum(case when t1.year_dt = 2019 then PV end) 今年PV,
	sum(case when t1.year_dt = 2019 then UV end) 今年UV,
	sum(case when t1.year_dt = 2019 then 自营PV end) 今年自营PV,
	sum(case when t1.year_dt = 2019 then 自营UV end) 今年自营UV,
	sum(case when t1.year_dt = 2019 then POPPV end) 今年POPPV,
	sum(case when t1.year_dt = 2019 then POPUV end) 今年POPUV,
	sum(case when t1.year_dt = 2019 then 有效子单数 end) 今年有效子单数,
	sum(case when t1.year_dt = 2019 then gmv end) 今年gmv,
	sum(case when t1.year_dt = 2019 then 自营有效子单数 end) 今年自营有效子单数,
	sum(case when t1.year_dt = 2019 then 自营gmv end) 今年自营gmv,
	sum(case when t1.year_dt = 2019 then POP有效子单数 end) 今年POP有效子单数,
	sum(case when t1.year_dt = 2019 then POPgmv end) 今年POPgmv,
	sum(case when t1.year_dt = 2018 then PV end) 去年PV,
	sum(case when t1.year_dt = 2018 then UV end) 去年UV,
	sum(case when t1.year_dt = 2018 then 自营PV end) 去年自营PV,
	sum(case when t1.year_dt = 2018 then 自营UV end) 去年自营UV,
	sum(case when t1.year_dt = 2018 then POPPV end) 去年POPPV,
	sum(case when t1.year_dt = 2018 then POPUV end) 去年POPUV,
	sum(case when t1.year_dt = 2018 then 有效子单数 end) 去年有效子单数,
	sum(case when t1.year_dt = 2018 then gmv end) 去年gmv,
	sum(case when t1.year_dt = 2018 then 自营有效子单数 end) 去年自营有效子单数,
	sum(case when t1.year_dt = 2018 then 自营gmv end) 去年自营gmv,
	sum(case when t1.year_dt = 2018 then POP有效子单数 end) 去年POP有效子单数,
	sum(case when t1.year_dt = 2018 then POPgmv end) 去年POPgmv
from
	(
		select /*+ mapjoin(a)*/
			a.dept_name,
			b.year_dt,
			b.device,
			count(distinct b.sale_ord_id) 有效子单数,
			sum(b.cw_gmv) gmv,
			count(distinct case when model = '自营' then b.sale_ord_id end) 自营有效子单数,
			sum(case when model = '自营' then b.cw_gmv else 0 end) 自营gmv,
			count(distinct case when model = 'POP' then b.sale_ord_id end) POP有效子单数,
			sum(case when model = 'POP' then b.cw_gmv else 0 end) POPgmv
		from
			(
				select
					item_sku_id,
					case dept_id_3
						when '3842' then '饼干蛋糕组'
						when '989' then '饼干蛋糕组'
						when '3840' then '坚果组'
						when '4159' then '坚果组'
					end dept_name,
					case dept_id_3
						when '3842' then '自营'
						when '989' then 'POP'
						when '3840' then '自营'
						when '4159' then 'POP'
					end model
				from
					gdm.gdm_m03_active_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and dept_id_3 in('3842', '989', '3840', '4159')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					item_sku_id,
					sale_ord_id,
					parent_sale_ord_id,
					lower(trim(user_log_acct)) pin,
					cw_gmv,
					case
						when terminal_flag in('12', '22', '42', '62') then 'APP'
						when terminal_flag in('13', '23', '43', '63') then 'M端'
						when terminal_flag in('11', '21', '41', '61') then 'PC'
						when terminal_flag in('33', '31', '30') then '微信'
						when terminal_flag in('32') then '手Q'
						else '未知'
					end device
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2018-01-16'
							and dt <= '2018-02-16'
						)
						or
						(
							dt >= '2019-01-05'
							and dt <= '2019-02-05'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		group by
			a.dept_name,
			b.year_dt,
			b.device
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			a.dept_name,
			b.year_dt,
			b.device,
			sum(b.pv) PV,
			count(distinct b.browser_uniq_id) UV,
			sum(case when model = '自营' then b.pv else 0 end) 自营PV,
			count(distinct case when model = '自营' then b.browser_uniq_id end) 自营UV,
			sum(case when model = 'POP' then b.pv else 0 end) POPPV,
			count(distinct case when model = 'POP' then b.browser_uniq_id end) POPUV
		from
			(
				select
					item_sku_id,
					case dept_id_3
						when '3842' then '饼干蛋糕组'
						when '989' then '饼干蛋糕组'
						when '3840' then '坚果组'
						when '4159' then '坚果组'
					end dept_name,
					case dept_id_3
						when '3842' then '自营'
						when '989' then 'POP'
						when '3840' then '自营'
						when '4159' then 'POP'
					end model
				from
					gdm.gdm_m03_active_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and dept_id_3 in('3842', '989', '3840', '4159')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					sku_id,
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end device,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2018-01-16'
							and dt <= '2018-02-16'
						)
						or
						(
							dt >= '2019-01-05'
							and dt <= '2019-02-05'
						)
					)
				group by
					sku_id,
					year(dt),
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end,
					browser_uniq_id
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			a.dept_name,
			b.year_dt,
			b.device
	)
	t2
on
	t1.year_dt = t2.year_dt
	and t1.dept_name = t2.dept_name
	and t1.device = t2.device
group by
	coalesce(t1.dept_name, t2.dept_name),
	coalesce(t1.device, t2.device)
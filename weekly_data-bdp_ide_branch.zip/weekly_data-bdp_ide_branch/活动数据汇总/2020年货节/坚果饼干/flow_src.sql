----APP流量来源模板
select
	/*+ mapjoin(a)*/
	dept_name 部门,
	src_url_first_cate_id 一级来源id,
	src_url_first_cate_name 一级来源,
	src_url_second_cate_id 二级来源id,
	src_url_second_cate_name 二级来源,
	src_url_third_cate_id 三级来源id,
	src_url_third_cate_name 三级来源,
	sum(case when year_dt = '2019' then item_pv end) 今年PV,
	sum(case when year_dt = '2019' then cart_num end) 今年加购,
	sum(case when year_dt = '2019' then intr_valid_ord_num end) 今年引入订单数,
	sum(case when year_dt = '2019' then intr_valid_aft_amount end) 今年优惠后订单金额,
	sum(case when year_dt = '2018' then item_pv end) 去年PV,
	sum(case when year_dt = '2018' then cart_num end) 去年加购,
	sum(case when year_dt = '2018' then intr_valid_ord_num end) 去年引入订单数,
	sum(case when year_dt = '2018' then intr_valid_aft_amount end) 去年优惠后订单金额
from
	(
		select
			item_sku_id,
			case dept_id_3
				when '3842' then '饼干蛋糕组'
				when '989' then '饼干蛋糕组'
				when '3840' then '坚果组'
				when '4159' then '坚果组'
			end dept_name
		from
			gdm.gdm_m03_active_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and dept_id_2 = '47'
			and dept_id_3 in('3842', '989', '3840', '4159')
	)
	a
join
	(
		select
			year(dt) year_dt,
			sku_id,
			src_url_first_cate_id,
			src_url_first_cate_name,
			src_url_second_cate_id,
			src_url_second_cate_name,
			src_url_third_cate_id,
			src_url_third_cate_name,
			item_pv,
			cart_num,
			intr_valid_ord_num,
			intr_valid_aft_amount
		from
			app.v_adm_s14_item_last_src_d_spyl
		where
			(
				(
					dt >= '2018-01-16'
					and dt <= '2018-02-16'
				)
				or
				(
					dt >= '2019-01-05'
					and dt <= '2019-02-05'
				)
			)
			and bs = '311210'
			and lvl = '6'
	)
	b
on
	a.item_sku_id = b.sku_id
group by
	dept_name,
	src_url_first_cate_id,
	src_url_first_cate_name,
	src_url_second_cate_id,
	src_url_second_cate_name,
	src_url_third_cate_id,
	src_url_third_cate_name

union all

select
	/*+ mapjoin(a)*/
	'食品饮料' 部门,
	src_url_first_cate_id 一级来源id,
	src_url_first_cate_name 一级来源,
	src_url_second_cate_id 二级来源id,
	src_url_second_cate_name 二级来源,
	src_url_third_cate_id 三级来源id,
	src_url_third_cate_name 三级来源,
	sum(case when year_dt = '2019' then item_pv end) 今年PV,
	sum(case when year_dt = '2019' then cart_num end) 今年加购,
	sum(case when year_dt = '2019' then intr_valid_ord_num end) 今年引入订单数,
	sum(case when year_dt = '2019' then intr_valid_aft_amount end) 今年优惠后订单金额,
	sum(case when year_dt = '2018' then item_pv end) 去年PV,
	sum(case when year_dt = '2018' then cart_num end) 去年加购,
	sum(case when year_dt = '2018' then intr_valid_ord_num end) 去年引入订单数,
	sum(case when year_dt = '2018' then intr_valid_aft_amount end) 去年优惠后订单金额
from
	(
		select
			item_sku_id
		from
			gdm.gdm_m03_active_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and dept_id_2 = '47'
	)
	a
join
	(
		select
			year(dt) year_dt,
			sku_id,
			src_url_first_cate_id,
			src_url_first_cate_name,
			src_url_second_cate_id,
			src_url_second_cate_name,
			src_url_third_cate_id,
			src_url_third_cate_name,
			item_pv,
			cart_num,
			intr_valid_ord_num,
			intr_valid_aft_amount
		from
			app.v_adm_s14_item_last_src_d_spyl
		where
			(
				(
					dt >= '2018-01-16'
					and dt <= '2018-02-16'
				)
				or
				(
					dt >= '2019-01-05'
					and dt <= '2019-02-05'
				)
			)
			and bs = '311210'
			and lvl = '6'
	)
	b
on
	a.item_sku_id = b.sku_id
group by
	src_url_first_cate_id,
	src_url_first_cate_name,
	src_url_second_cate_id,
	src_url_second_cate_name,
	src_url_third_cate_id,
	src_url_third_cate_name
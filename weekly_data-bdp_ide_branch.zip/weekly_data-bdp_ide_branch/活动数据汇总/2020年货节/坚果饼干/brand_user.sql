select
	a.dept_name,
	a.model,
	a.brand_code,
	a.barndname_full,
	count(distinct case when b.year_dt = 2019 then b.user_log_acct end) 今年总用户数,
	count(case when b.year_dt = 2019 then sale_ord_id end) 今年子单量,
	sum(case when b.year_dt = 2019 then after_prefr_amount end) 今年优惠后金额,
	count(distinct case when b.year_dt = 2019 and fst_all_yn = 1 then b.user_log_acct end) 今年站外新用户数,
	count(case when b.year_dt = 2019 and fst_all_yn = 1 then sale_ord_id end) 今年站外新子单量,
	sum(case when b.year_dt = 2019 and fst_all_yn = 1 then after_prefr_amount end) 今年站外新优惠后金额,
	count(distinct case when b.year_dt = 2019 and fst_all_yn = 0 then b.user_log_acct end) 今年站内新用户数,
	count(case when b.year_dt = 2019 and fst_all_yn = 0 then sale_ord_id end) 今年站内新子单量,
	sum(case when b.year_dt = 2019 and fst_all_yn = 0 then after_prefr_amount end) 今年站内新优惠后金额,
	count(distinct case when b.year_dt = 2018 then b.user_log_acct end) 去年总用户数,
	count(case when b.year_dt = 2018 then sale_ord_id end) 去年子单量,
	sum(case when b.year_dt = 2018 then after_prefr_amount end) 去年优惠后金额,
	count(distinct case when b.year_dt = 2018 and fst_all_yn = 1 then b.user_log_acct end) 去年站外新用户数,
	count(case when b.year_dt = 2018 and fst_all_yn = 1 then sale_ord_id end) 去年站外新子单量,
	sum(case when b.year_dt = 2018 and fst_all_yn = 1 then after_prefr_amount end) 去年站外新优惠后金额,
	count(distinct case when b.year_dt = 2018 and fst_all_yn = 0 then b.user_log_acct end) 去年站内新用户数,
	count(case when b.year_dt = 2018 and fst_all_yn = 0 then sale_ord_id end) 去年站内新子单量,
	sum(case when b.year_dt = 2018 and fst_all_yn = 0 then after_prefr_amount end) 去年站内新优惠后金额
from
	(
		select
			item_sku_id,
			case dept_id_3
				when '3842' then '饼干蛋糕组'
				when '989' then '饼干蛋糕组'
				when '3840' then '坚果组'
				when '4159' then '坚果组'
			end dept_name,
			case data_type
				when '1' then '自营'
				when '3' then 'POP'
			end model,
			brand_code,
			barndname_full
		from
			gdm.gdm_m03_active_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and dept_id_2 = '47'
			and
			(
				(
					dept_id_3 in('3842', '989')
					and brand_code in('3681', '5673', '5869', '7858', '8055', '8165', '10361', '10440', '10485', '10590', '11187', '11237', '12679', '13004', '13885', '14597', '14633', '14962', '16062', '16599', '17315', '17332', '17659', '18169', '18768', '20050', '20244', '21051', '21649', '21651', '22553', '25573', '28939', '32686', '32702', '36999', '40943', '41772', '44612', '63503', '64477', '77835', '78378', '102806', '145053', '151523', '163954', '196237', '197246', '244659', '386919', '400077', '431656')
				)
				or
				(
					dept_id_3 in('3840', '4159')
					and brand_code in('3979', '7241', '8092', '8558', '10745', '11540', '11726', '11727', '17919', '19144', '19145', '25550', '26083', '27649', '27776', '32294', '66594', '69131', '78743', '94390', '144349', '149866', '172808', '219371', '236440', '236923', '249090', '271882', '280910', '284708', '291846', '386766')
				)
			)
	)
	a
join
	(
----有效订单模板
		select
			b.*
		from
			(
				select
					user_log_acct,
					item_sku_id,
					year(sale_ord_dt) year_dt,
					parent_sale_ord_id,
					sale_ord_id,
					after_prefr_amount,
					check_account_tm,
					sale_qtty,
					sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
				from
					gdm.gdm_m04_ord_det_sum
				where
					dt >= '2018-01-16'
					and
					(
						(
							sale_ord_dt >= '2018-01-16'
							and sale_ord_dt <= '2018-02-16'
						)
						or
						(
							sale_ord_dt >= '2019-01-05'
							and sale_ord_dt <= '2019-02-05'
						)
					)
					and sale_ord_valid_flag = '1'
					and item_third_cate_cd not in('6980') --剔除礼品卡
					and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
					and
					(
						substr(ord_flag, 31, 1) <> '2' --非行政内采
						or
						(
							substr(ord_flag, 31, 1) = '2'
							and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
						)
					)
					and
					(
						substr(ord_flag, 46, 1) not in('1', '2', '3', '7')
						or substr(ord_flag, 60, 3) not in('013')
					)
					and sale_ord_type_cd <> '68' --剔除拍卖
					and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
					and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
					and user_log_acct not like"ept%"
			)
			b
		where
			b.ord_amount < 100000
			or
			(
				b.ord_amount >= 100000
				and coalesce(b.check_account_tm, '') <> ''
			)
	)
	b
on
	a.item_sku_id = b.item_sku_id
left join
	(
		select
			x.dept_name,
			x.user_log_acct,
			x.fst_all_yn,
			year(x.fst_ord_dt) year_dt
		from
			(
				select
					case dept_id_3
						when '3842' then '饼干蛋糕组'
						when '989' then '饼干蛋糕组'
						when '3840' then '坚果组'
						when '4159' then '坚果组'
					end dept_name,
					lower(trim(unif_user_log_acct)) user_log_acct,
					max(
						case
							when fst_all_yn = 1
							then 1
							else 0
						end) fst_all_yn,
					min(fst_ord_dt) fst_ord_dt
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 1)
					and tp = 'dept'
					and dept_id_2 = '47'
					and dept_id_3 in('3842', '989', '3840', '4159')
				group by
					case dept_id_3
						when '3842' then '饼干蛋糕组'
						when '989' then '饼干蛋糕组'
						when '3840' then '坚果组'
						when '4159' then '坚果组'
					end,
					lower(trim(unif_user_log_acct))
			)
			x
		where
			(
				(
					fst_ord_dt >= '2018-01-16'
					and fst_ord_dt <= '2018-02-16'
				)
				or
				(
					fst_ord_dt >= '2019-01-05'
					and fst_ord_dt <= '2019-02-05'
				)
			)
	)
	c
on
	a.dept_name = c.dept_name
	and b.user_log_acct = c.user_log_acct
	and b.year_dt = c.year_dt
group by
	a.dept_name,
	a.model,
	a.brand_code,
	a.barndname_full
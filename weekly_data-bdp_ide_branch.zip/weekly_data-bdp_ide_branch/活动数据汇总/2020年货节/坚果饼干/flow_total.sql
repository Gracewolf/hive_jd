----周报分渠道流量模板
select
	coalesce(t1.dt, t2.dt) 日期,
	coalesce(t1.dept_name, t2.dept_name) 部门名称,
	sum(t1.有效子单数) 今年有效子单数,
	sum(t1.gmv) 今年gmv,
	sum(t2.pv) 今年pv,
	sum(t2.uv) 今年uv
from
	(
		select /*+ mapjoin(a)*/
			a.dept_name,
			b.dt,
			count(distinct b.sale_ord_id) 有效子单数,
			sum(b.cw_gmv) gmv
		from
			(
				select
					item_sku_id,
					case dept_id_3
						when '3842' then '饼干蛋糕组'
						when '989' then '饼干蛋糕组'
						when '3840' then '坚果组'
						when '4159' then '坚果组'
					end dept_name
				from
					gdm.gdm_m03_active_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and dept_id_3 in('3842', '989', '3840', '4159')
			)
			a
		join
			(
				select
					dt,
					item_sku_id,
					sale_ord_id,
					parent_sale_ord_id,
					lower(trim(user_log_acct)) pin,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2018-01-16'
							and dt <= '2018-02-16'
						)
						or
						(
							dt >= '2019-01-05'
							and dt <= '2019-02-05'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		group by
			a.dept_name,
			b.dt
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			b.dt,
			a.dept_name,
			sum(b.pv) pv,
			count(distinct b.browser_uniq_id) uv
		from
			(
				select
					item_sku_id,
					case dept_id_3
						when '3842' then '饼干蛋糕组'
						when '989' then '饼干蛋糕组'
						when '3840' then '坚果组'
						when '4159' then '坚果组'
					end dept_name
				from
					gdm.gdm_m03_active_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and dept_id_3 in('3842', '989', '3840', '4159')
			)
			a
		join
			(
				select
					dt,
					sku_id,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2018-01-16'
							and dt <= '2018-02-16'
						)
						or
						(
							dt >= '2019-01-05'
							and dt <= '2019-02-05'
						)
					)
				group by
					sku_id,
					dt,
					browser_uniq_id
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			b.dt,
			a.dept_name
	)
	t2
on
	t1.dt = t2.dt
	and t1.dept_name = t2.dept_name
group by
	coalesce(t1.dt, t2.dt),
	coalesce(t1.dept_name, t2.dept_name)
	
----三级部门用户
----用户模板
select
	x.dept_id_3 部门id,
	x.dept_name_3 部门,
	count(distinct case when x.year_dt = 2019 then x.user_log_acct end) 今年总用户数,
	count(distinct case when x.year_dt = 2019 and par_ord_num >= 2 then x.user_log_acct end) 今年复购用户数,
	sum(case when x.year_dt = 2019 then ord_num end) 今年子单量,
	sum(case when x.year_dt = 2019 then par_ord_num end) 今年父单量,
	sum(case when x.year_dt = 2019 then aft_pre_amount end) 今年优惠后金额,
	count(distinct case when x.year_dt = 2019 and fst_all_yn = 1 then x.user_log_acct end) 今年站外新用户数,
	sum(case when x.year_dt = 2019 and fst_all_yn = 1 then ord_num end) 今年站外新子单量,
	sum(case when x.year_dt = 2019 and fst_all_yn = 1 then par_ord_num end) 今年站外新父单量,
	sum(case when x.year_dt = 2019 and fst_all_yn = 1 then aft_pre_amount end) 今年站外新优惠后金额,
	count(distinct case when x.year_dt = 2019 and fst_all_yn = 0 then x.user_log_acct end) 今年站内新用户数,
	sum(case when x.year_dt = 2019 and fst_all_yn = 0 then ord_num end) 今年站内新子单量,
	sum(case when x.year_dt = 2019 and fst_all_yn = 0 then par_ord_num end) 今年站内新父单量,
	sum(case when x.year_dt = 2019 and fst_all_yn = 0 then aft_pre_amount end) 今年站内新优惠后金额,
	count(distinct case when x.year_dt = 2018 then x.user_log_acct end) 去年总用户数,
	count(distinct case when x.year_dt = 2018 and par_ord_num >= 2 then x.user_log_acct end) 去年复购用户数,
	sum(case when x.year_dt = 2018 then ord_num end) 去年子单量,
	sum(case when x.year_dt = 2018 then par_ord_num end) 去年父单量,
	sum(case when x.year_dt = 2018 then aft_pre_amount end) 去年优惠后金额,
	count(distinct case when x.year_dt = 2018 and fst_all_yn = 1 then x.user_log_acct end) 去年站外新用户数,
	sum(case when x.year_dt = 2018 and fst_all_yn = 1 then ord_num end) 去年站外新子单量,
	sum(case when x.year_dt = 2018 and fst_all_yn = 1 then par_ord_num end) 去年站外新父单量,
	sum(case when x.year_dt = 2018 and fst_all_yn = 1 then aft_pre_amount end) 去年站外新优惠后金额,
	count(distinct case when x.year_dt = 2018 and fst_all_yn = 0 then x.user_log_acct end) 去年站内新用户数,
	sum(case when x.year_dt = 2018 and fst_all_yn = 0 then ord_num end) 去年站内新子单量,
	sum(case when x.year_dt = 2018 and fst_all_yn = 0 then par_ord_num end) 去年站内新父单量,
	sum(case when x.year_dt = 2018 and fst_all_yn = 0 then aft_pre_amount end) 去年站内新优惠后金额
from
	(
		select /*+ MAPJOIN(a)*/
			b.year_dt,
			a.dept_id_3,
			a.dept_name_3,
			b.user_log_acct,
			count(distinct sale_ord_id) ord_num,
			count(distinct parent_sale_ord_id) par_ord_num,
			sum(after_prefr_amount_1) aft_pre_amount
		from
			(
				select
					item_sku_id,
					dept_id_3,
					dept_name_3
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and dept_id_3 in('3842', '989', '3840', '4159')
			)
			a
		join
			(
				select
					lower(trim(user_log_acct)) user_log_acct,
					item_sku_id,
					year(sale_ord_dt) year_dt,
					parent_sale_ord_id,
					sale_ord_id,
					after_prefr_amount_1,
					check_account_tm,
					sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
				from
					gdm.gdm_m04_ord_det_sum
				where
					dt >= '2018-01-16'
					and
					(
						(
							sale_ord_dt >= '2018-01-16'
							and sale_ord_dt <= '2018-02-16'
						)
						or
						(
							sale_ord_dt >= '2019-01-05'
							and sale_ord_dt <= '2019-02-05'
						)
					)
					and sale_ord_valid_flag = '1'
					and item_third_cate_cd not in('6980') --剔除礼品卡
					and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
					and
					(
						substr(ord_flag, 31, 1) <> '2' --非行政内采
						or
						(
							substr(ord_flag, 31, 1) = '2'
							and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
						)
					)
					and
					(
						substring(ord_flag, 46, 1) not in('1', '2', '3', '7')
						or substring(ord_flag, 60, 3) not in('013')
					)
					and sale_ord_type_cd <> '68' --剔除拍卖
					and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
					and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
					and user_log_acct not like"ept%"
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		where
			b.ord_amount < 100000
			or
			(
				b.ord_amount >= 100000
				and coalesce(b.check_account_tm, '') <> ''
			)
		group by
			b.year_dt,
			a.dept_id_3,
			a.dept_name_3,
			b.user_log_acct
	)
	x
left join
	(
		select
			x.dept_id_3,
			x.user_log_acct,
			x.fst_all_yn,
			year(x.fst_ord_dt) year_dt
		from
			(
				select
					dept_id_3,
					lower(trim(unif_user_log_acct)) user_log_acct,
					max(
						case
							when fst_all_yn = 1
							then 1
							else 0
						end) fst_all_yn,
					min(fst_ord_dt) fst_ord_dt
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 1)
					and tp = 'dept'
					and dept_id_2 = '47'
					and dept_id_3 in('3842', '989', '3840', '4159')
				group by
					dept_id_3,
					lower(trim(unif_user_log_acct))
			)
			x
		where
			(
				(
					fst_ord_dt >= '2018-01-16'
					and fst_ord_dt <= '2018-02-16'
				)
				or
				(
					fst_ord_dt >= '2019-01-05'
					and fst_ord_dt <= '2019-02-05'
				)
			)
	)
	y
on
	x.user_log_acct = y.user_log_acct
	and x.dept_id_3 = y.dept_id_3
	and x.year_dt = y.year_dt
group by
	x.dept_id_3,
	x.dept_name_3

union all

select
	'0' 部门id,
	x.dept_name 部门,
	count(distinct case when x.year_dt = 2019 then x.user_log_acct end) 今年总用户数,
	count(distinct case when x.year_dt = 2019 and par_ord_num >= 2 then x.user_log_acct end) 今年复购用户数,
	sum(case when x.year_dt = 2019 then ord_num end) 今年子单量,
	sum(case when x.year_dt = 2019 then par_ord_num end) 今年父单量,
	sum(case when x.year_dt = 2019 then aft_pre_amount end) 今年优惠后金额,
	count(distinct case when x.year_dt = 2019 and fst_all_yn = 1 then x.user_log_acct end) 今年站外新用户数,
	sum(case when x.year_dt = 2019 and fst_all_yn = 1 then ord_num end) 今年站外新子单量,
	sum(case when x.year_dt = 2019 and fst_all_yn = 1 then par_ord_num end) 今年站外新父单量,
	sum(case when x.year_dt = 2019 and fst_all_yn = 1 then aft_pre_amount end) 今年站外新优惠后金额,
	count(distinct case when x.year_dt = 2019 and fst_all_yn = 0 then x.user_log_acct end) 今年站内新用户数,
	sum(case when x.year_dt = 2019 and fst_all_yn = 0 then ord_num end) 今年站内新子单量,
	sum(case when x.year_dt = 2019 and fst_all_yn = 0 then par_ord_num end) 今年站内新父单量,
	sum(case when x.year_dt = 2019 and fst_all_yn = 0 then aft_pre_amount end) 今年站内新优惠后金额,
	count(distinct case when x.year_dt = 2018 then x.user_log_acct end) 去年总用户数,
	count(distinct case when x.year_dt = 2018 and par_ord_num >= 2 then x.user_log_acct end) 去年复购用户数,
	sum(case when x.year_dt = 2018 then ord_num end) 去年子单量,
	sum(case when x.year_dt = 2018 then par_ord_num end) 去年父单量,
	sum(case when x.year_dt = 2018 then aft_pre_amount end) 去年优惠后金额,
	count(distinct case when x.year_dt = 2018 and fst_all_yn = 1 then x.user_log_acct end) 去年站外新用户数,
	sum(case when x.year_dt = 2018 and fst_all_yn = 1 then ord_num end) 去年站外新子单量,
	sum(case when x.year_dt = 2018 and fst_all_yn = 1 then par_ord_num end) 去年站外新父单量,
	sum(case when x.year_dt = 2018 and fst_all_yn = 1 then aft_pre_amount end) 去年站外新优惠后金额,
	count(distinct case when x.year_dt = 2018 and fst_all_yn = 0 then x.user_log_acct end) 去年站内新用户数,
	sum(case when x.year_dt = 2018 and fst_all_yn = 0 then ord_num end) 去年站内新子单量,
	sum(case when x.year_dt = 2018 and fst_all_yn = 0 then par_ord_num end) 去年站内新父单量,
	sum(case when x.year_dt = 2018 and fst_all_yn = 0 then aft_pre_amount end) 去年站内新优惠后金额
from
	(
		select /*+ MAPJOIN(a)*/
			b.year_dt,
			a.dept_name,
			b.user_log_acct,
			count(distinct sale_ord_id) ord_num,
			count(distinct parent_sale_ord_id) par_ord_num,
			sum(after_prefr_amount_1) aft_pre_amount
		from
			(
				select
					item_sku_id,
					case dept_id_3
						when '3842' then '饼干蛋糕组'
						when '989' then '饼干蛋糕组'
						when '3840' then '坚果组'
						when '4159' then '坚果组'
					end dept_name
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and dept_id_3 in('3842', '989', '3840', '4159')
			)
			a
		join
			(
				select
					lower(trim(user_log_acct)) user_log_acct,
					item_sku_id,
					year(sale_ord_dt) year_dt,
					parent_sale_ord_id,
					sale_ord_id,
					after_prefr_amount_1,
					check_account_tm,
					sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
				from
					gdm.gdm_m04_ord_det_sum
				where
					dt >= '2018-01-16'
					and
					(
						(
							sale_ord_dt >= '2018-01-16'
							and sale_ord_dt <= '2018-02-16'
						)
						or
						(
							sale_ord_dt >= '2019-01-05'
							and sale_ord_dt <= '2019-02-05'
						)
					)
					and sale_ord_valid_flag = '1'
					and item_third_cate_cd not in('6980') --剔除礼品卡
					and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
					and
					(
						substr(ord_flag, 31, 1) <> '2' --非行政内采
						or
						(
							substr(ord_flag, 31, 1) = '2'
							and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
						)
					)
					and
					(
						substring(ord_flag, 46, 1) not in('1', '2', '3', '7')
						or substring(ord_flag, 60, 3) not in('013')
					)
					and sale_ord_type_cd <> '68' --剔除拍卖
					and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
					and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
					and user_log_acct not like"ept%"
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		where
			b.ord_amount < 100000
			or
			(
				b.ord_amount >= 100000
				and coalesce(b.check_account_tm, '') <> ''
			)
		group by
			b.year_dt,
			a.dept_name,
			b.user_log_acct
	)
	x
left join
	(
		select
			x.dept_name,
			x.user_log_acct,
			x.fst_all_yn,
			year(x.fst_ord_dt) year_dt
		from
			(
				select
					case dept_id_3
						when '3842' then '饼干蛋糕组'
						when '989' then '饼干蛋糕组'
						when '3840' then '坚果组'
						when '4159' then '坚果组'
					end dept_name,
					lower(trim(unif_user_log_acct)) user_log_acct,
					max(
						case
							when fst_all_yn = 1
							then 1
							else 0
						end) fst_all_yn,
					min(fst_ord_dt) fst_ord_dt
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 1)
					and tp = 'dept'
					and dept_id_2 = '47'
					and dept_id_3 in('3842', '989', '3840', '4159')
				group by
					case dept_id_3
						when '3842' then '饼干蛋糕组'
						when '989' then '饼干蛋糕组'
						when '3840' then '坚果组'
						when '4159' then '坚果组'
					end,
					lower(trim(unif_user_log_acct))
			)
			x
		where
			(
				(
					fst_ord_dt >= '2018-01-16'
					and fst_ord_dt <= '2018-02-16'
				)
				or
				(
					fst_ord_dt >= '2019-01-05'
					and fst_ord_dt <= '2019-02-05'
				)
			)
	)
	y
on
	x.user_log_acct = y.user_log_acct
	and x.dept_name = y.dept_name
	and x.year_dt = y.year_dt
group by
	x.dept_name
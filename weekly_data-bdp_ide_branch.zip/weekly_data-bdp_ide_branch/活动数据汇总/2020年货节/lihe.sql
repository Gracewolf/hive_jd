select
	model,
	year_dt,
	sum(cw_gmv) gmv,
	sum(sale_qtty) sale_qtty,
	count(distinct sale_ord_id) ord_num,
	count(distinct user_log_acct) user_num,
	sum(case when skucate = '礼盒装' then cw_gmv end) lihe_gmv,
	sum(case when skucate = '礼盒装' then sale_qtty end) lihe_sale_qtty,
	count(distinct case when skucate = '礼盒装' then sale_ord_id end) lihe_ord_num,
	count(distinct case when skucate = '礼盒装' then user_log_acct end) lihe_user_num,
	sum(case when skucate = '非礼盒装' then cw_gmv end) not_lihe_gmv,
	sum(case when skucate = '非礼盒装' then sale_qtty end) not_lihe_sale_qtty,
	count(distinct case when skucate = '非礼盒装' then sale_ord_id end) not_lihe_ord_num,
	count(distinct case when skucate = '非礼盒装' then user_log_acct end) not_lihe_user_num
from
	(
		select
			item_sku_id,
			case
				when sku_name like'%礼盒%' then '礼盒装'
				else '非礼盒装'
			end skucate,
			case data_type
				when '1' then '自营'
				when '3' then 'POP'
			end model
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and dept_id_2 in('47', '1699')
	)
	a
join
	(
		select
			item_sku_id,
			case
				when year(dt) = 2016 then 2017
				else year(dt)
			end year_dt,
			sale_ord_id,
			sale_qtty,
			user_log_acct,
			cw_gmv
		from
			app.v_app_cmo_cw_ord_det_sum_rb
		where
			(
			   (
					dt >= '2016-12-28'
					and dt <= '2017-01-28'
			   )
			   or
			   (
					dt >= '2018-01-16'
					and dt <= '2018-02-16'
			   )
			   or
			   (
					dt >= '2019-01-05'
					and dt <= '2019-02-05'
			   )
			)
			and valid_flag = '1'
			and
			(
				(
					tp = '1'
					and substr(ord_flag, 40, 1) <> '1'
				) ----自营剔分销
				or
				(
					tp = '2'
					and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
				) ----POP剔赠品
			)
	)
	b
on
	a.item_sku_id = b.item_sku_id
group by
	model,
	year_dt
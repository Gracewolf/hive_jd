set hive.exec.parallel = true;
select /*+mapjoin(a)*/
	b.year_dt,
	'整体' beizhu,
	count(distinct browser_uniq_id) UV
from
	(
		select
			item_sku_id,
			data_type
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and dept_id_2 in('47', '1699')
	)
	a
join
	(
		select
			sku_id,
			year(dt) year_dt,
			browser_uniq_id
		from
			adm.adm_s14_online_log_smart_item_d
		where
		   (
				dt >= '2018-01-16'
				and dt <= '2018-02-16'
		   )
		   or
		   (
				dt >= '2019-01-05'
				and dt <= '2019-02-05'
		   )
	)
	b
on
	a.item_sku_id = b.sku_id
group by
	b.year_dt

union all

select /*+mapjoin(a)*/
	b.year_dt,
	a.data_type beizhu,
	count(distinct browser_uniq_id) UV
from
	(
		select
			item_sku_id,
			data_type
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and dept_id_2 in('47', '1699')
	)
	a
join
	(
		select
			sku_id,
			year(dt) year_dt,
			browser_uniq_id
		from
			adm.adm_s14_online_log_smart_item_d
		where
		   (
				dt >= '2018-01-16'
				and dt <= '2018-02-16'
		   )
		   or
		   (
				dt >= '2019-01-05'
				and dt <= '2019-02-05'
		   )
	)
	b
on
	a.item_sku_id = b.sku_id
group by
	b.year_dt,
	a.data_type
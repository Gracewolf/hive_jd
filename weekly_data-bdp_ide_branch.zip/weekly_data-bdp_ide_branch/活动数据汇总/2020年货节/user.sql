set hive.exec.parallel = true;
select
	'食品饮料整体' 部门,
	count(distinct case when a.year_dt = 2019 then a.user_log_acct end) 整体用户数,
	count(distinct case when a.year_dt = 2019 and a.ord_num >= 2 then a.user_log_acct end) 复购用户数,
	count(distinct case when a.year_dt = 2019 and b.fst_all_yn = 1 then a.user_log_acct end) 站外新用户数,
	count(distinct case when a.year_dt = 2019 and b.fst_all_yn = 0 then a.user_log_acct end) 站内新用户数,
	count(distinct case when a.year_dt = 2018 then a.user_log_acct end) 去年整体用户数,
	count(distinct case when a.year_dt = 2018 and a.ord_num >= 2 then a.user_log_acct end) 去年复购用户数,
	count(distinct case when a.year_dt = 2018 and b.fst_all_yn = 1 then a.user_log_acct end) 去年站外新用户数,
	count(distinct case when a.year_dt = 2018 and b.fst_all_yn = 0 then a.user_log_acct end) 去年站内新用户数
from
	(
		select
			user_log_acct,
			year_dt,
			count(distinct parent_sale_ord_id) ord_num
		from
			dev_xfp.nz_nianhuojie_user_pool
		where
			item_first_cate_cd = '1320'
		group by
			year_dt,
			user_log_acct
	)
	a
left join
	(
		select
			x.user_log_acct,
			x.fst_all_yn,
			year(fst_ord_dt) year_dt
		from
			(
				select
					unif_user_log_acct user_log_acct,
					max(
						case
							when fst_all_yn = 1
							then 1
							else 0
						end) fst_all_yn,
					min(fst_ord_dt) fst_ord_dt
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 1)
					and tp = 'cate'
					and item_first_cate_cd = '1320'
				group by
					unif_user_log_acct
			)
			x
		where
		   (
				fst_ord_dt >= '2018-01-16'
				and fst_ord_dt <= '2018-02-16'
		   )
		   or
		   (
				fst_ord_dt >= '2019-01-05'
				and fst_ord_dt <= '2019-02-05'
		   )
	)
	b
on
	a.user_log_acct = b.user_log_acct
	and a.year_dt = b.year_dt

union all

select
	model 部门,
	count(distinct case when a.year_dt = 2019 then a.user_log_acct end) 整体用户数,
	count(distinct case when a.year_dt = 2019 and a.ord_num >= 2 then a.user_log_acct end) 复购用户数,
	count(distinct case when a.year_dt = 2019 and b.fst_all_yn = 1 then a.user_log_acct end) 站外新用户数,
	count(distinct case when a.year_dt = 2019 and b.fst_all_yn = 0 then a.user_log_acct end) 站内新用户数,
	count(distinct case when a.year_dt = 2018 then a.user_log_acct end) 去年整体用户数,
	count(distinct case when a.year_dt = 2018 and a.ord_num >= 2 then a.user_log_acct end) 去年复购用户数,
	count(distinct case when a.year_dt = 2018 and b.fst_all_yn = 1 then a.user_log_acct end) 去年站外新用户数,
	count(distinct case when a.year_dt = 2018 and b.fst_all_yn = 0 then a.user_log_acct end) 去年站内新用户数
from
	(
		select
			user_log_acct,
			year_dt,
			case data_type
				when '1' then '食品饮料自营'
				when '3' then '食品饮料POP'
			end model,
			count(distinct parent_sale_ord_id) ord_num
		from
			dev_xfp.nz_nianhuojie_user_pool
		where
			item_first_cate_cd = '1320'
		group by
			year_dt,
			user_log_acct,
			case data_type
				when '1' then '食品饮料自营'
				when '3' then '食品饮料POP'
			end
	)
	a
left join
	(
		select
			x.user_log_acct,
			x.fst_all_yn,
			year(fst_ord_dt) year_dt
		from
			(
				select
					unif_user_log_acct user_log_acct,
					max(
						case
							when fst_all_yn = 1
							then 1
							else 0
						end) fst_all_yn,
					min(fst_ord_dt) fst_ord_dt
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 1)
					and tp = 'cate'
					and item_first_cate_cd = '1320'
				group by
					unif_user_log_acct
			)
			x
		where
		   (
				fst_ord_dt >= '2018-01-16'
				and fst_ord_dt <= '2018-02-16'
		   )
		   or
		   (
				fst_ord_dt >= '2019-01-05'
				and fst_ord_dt <= '2019-02-05'
		   )
	)
	b
on
	a.user_log_acct = b.user_log_acct
	and a.year_dt = b.year_dt
group by
	a.model

union all

select
	a.dept_name_2 部门,
	count(distinct case when a.year_dt = 2019 then a.user_log_acct end) 整体用户数,
	count(distinct case when a.year_dt = 2019 and a.ord_num >= 2 then a.user_log_acct end) 复购用户数,
	count(distinct case when a.year_dt = 2019 and b.fst_all_yn = 1 then a.user_log_acct end) 站外新用户数,
	count(distinct case when a.year_dt = 2019 and b.fst_all_yn = 0 then a.user_log_acct end) 站内新用户数,
	count(distinct case when a.year_dt = 2018 then a.user_log_acct end) 去年整体用户数,
	count(distinct case when a.year_dt = 2018 and a.ord_num >= 2 then a.user_log_acct end) 去年复购用户数,
	count(distinct case when a.year_dt = 2018 and b.fst_all_yn = 1 then a.user_log_acct end) 去年站外新用户数,
	count(distinct case when a.year_dt = 2018 and b.fst_all_yn = 0 then a.user_log_acct end) 去年站内新用户数
from
	(
		select
			user_log_acct,
			year_dt,
			dept_name_2,
			count(distinct parent_sale_ord_id) ord_num
		from
			dev_xfp.nz_nianhuojie_user_pool
		group by
			year_dt,
			dept_name_2,
			user_log_acct
	)
	a
left join
	(
		select
			dept_id_2,
			dept_name_2,
			x.user_log_acct,
			x.fst_all_yn,
			year(fst_ord_dt) year_dt
		from
			(
				select
					dept_id_2,
					dept_name_2,
					unif_user_log_acct user_log_acct,
					max(
						case
							when fst_all_yn = 1
							then 1
							else 0
						end) fst_all_yn,
					min(fst_ord_dt) fst_ord_dt
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 1)
					and tp = 'dept'
					and dept_id_2 in('47', '1699')
				group by
					dept_name_2,
					dept_id_2,
					unif_user_log_acct
			)
			x
		where
		   (
				fst_ord_dt >= '2018-01-16'
				and fst_ord_dt <= '2018-02-16'
		   )
		   or
		   (
				fst_ord_dt >= '2019-01-05'
				and fst_ord_dt <= '2019-02-05'
		   )
	)
	b
on
	a.user_log_acct = b.user_log_acct
	and a.dept_name_2 = b.dept_name_2
	and a.year_dt = b.year_dt
group by
	a.dept_name_2

union all

select
	a.dept_name_3 部门,
	count(distinct case when a.year_dt = 2019 then a.user_log_acct end) 整体用户数,
	count(distinct case when a.year_dt = 2019 and a.ord_num >= 2 then a.user_log_acct end) 复购用户数,
	count(distinct case when a.year_dt = 2019 and b.fst_all_yn = 1 then a.user_log_acct end) 站外新用户数,
	count(distinct case when a.year_dt = 2019 and b.fst_all_yn = 0 then a.user_log_acct end) 站内新用户数,
	count(distinct case when a.year_dt = 2018 then a.user_log_acct end) 去年整体用户数,
	count(distinct case when a.year_dt = 2018 and a.ord_num >= 2 then a.user_log_acct end) 去年复购用户数,
	count(distinct case when a.year_dt = 2018 and b.fst_all_yn = 1 then a.user_log_acct end) 去年站外新用户数,
	count(distinct case when a.year_dt = 2018 and b.fst_all_yn = 0 then a.user_log_acct end) 去年站内新用户数
from
	(
		select
			user_log_acct,
			year_dt,
			dept_name_3,
			count(distinct parent_sale_ord_id) ord_num
		from
			dev_xfp.nz_nianhuojie_user_pool
		where
			dept_name_2 = '干货食品部'
		group by
			year_dt,
			dept_name_3,
			user_log_acct
	)
	a
left join
	(
		select
			dept_id_3,
			dept_name_3,
			x.user_log_acct,
			x.fst_all_yn,
			year(fst_ord_dt) year_dt
		from
			(
				select
					dept_id_3,
					dept_name_3,
					unif_user_log_acct user_log_acct,
					max(
						case
							when fst_all_yn = 1
							then 1
							else 0
						end) fst_all_yn,
					min(fst_ord_dt) fst_ord_dt
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 1)
					and tp = 'dept'
					and dept_id_2 = '47'
				group by
					dept_name_3,
					dept_id_3,
					unif_user_log_acct
			)
			x
		where
		   (
				fst_ord_dt >= '2018-01-16'
				and fst_ord_dt <= '2018-02-16'
		   )
		   or
		   (
				fst_ord_dt >= '2019-01-05'
				and fst_ord_dt <= '2019-02-05'
		   )
	)
	b
on
	a.user_log_acct = b.user_log_acct
	and a.dept_name_3 = b.dept_name_3
	and a.year_dt = b.year_dt
group by
	a.dept_name_3
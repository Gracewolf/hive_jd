set hive.exec.parallel = true;
select
	coalesce(a.year_dt, b.year_dt) 日期,
	coalesce(a.dept_id_3, b.dept_id_3) 三级部门id,
	coalesce(a.dept_name_3, b.dept_name_3) 三级部门,
	coalesce(a.device, b.device) 端口,
	GMV,
	子单数,
	pv,
	uv
from
	(
		select /*+mapjoin(a)*/
			year_dt,
			dept_id_3,
			dept_name_3,
			device,
			sum(cw_gmv) GMV,
			count(distinct sale_ord_id) 子单数
		from
			(
				select
					item_sku_id,
					item_id,
					dept_id_3,
					dept_name_3
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and dept_id_3 in('3836', '966', '3816')
			)
			a
		left join
			(
				select
					item_id
				from
					gdm.gdm_m03_item_spec_attr_da
				where
					dt = sysdate( - 1)
					and attr_name in('factoryShip')
					and attr_val in('1')
			)
			c
		on
			a.item_id = c.item_id
		join
			(
				select
					case when dt <= '2018-02-16' then 2017
						else 2018 end year_dt,
					item_sku_id,
					sale_ord_id,
					case
						when terminal_flag in('12', '22', '42', '62') then 'APP'
						when terminal_flag in('13', '23', '43', '63') then 'M端'
						when terminal_flag in('11', '21', '41', '61') then 'PC'
						when terminal_flag in('33', '31', '30') then '微信'
						when terminal_flag in('32') then '手Q'
						else '未知'
					end device,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2017-12-29'
							and dt <= '2018-02-16'
						)
						or
						(
							dt >= '2018-12-18'
							and dt <= '2019-02-05'
						)
					)
					and valid_flag = '1'
					and
					(
						(
							tp = '1'
							and substr(ord_flag, 40, 1) <> '1'
						) ----自营剔分销
						or
						(
							tp = '2'
							and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
						) ----POP剔赠品
					)
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		where
			c.item_id is null
		group by
			year_dt,
			device,
			dept_id_3,
			dept_name_3
	)
	a
join
	(
		select /*+mapjoin(a)*/
			year_dt,
			dept_id_3,
			dept_name_3,
			device,
			sum(sku_pv) pv,
			count(distinct browser_uniq_id) uv
		from
			(
				select
					item_sku_id,
					item_id,
					dept_id_3,
					dept_name_3
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and dept_id_3 in('3836', '966', '3816')
			)
			a
		join
			(
				select
					sku_id,
					case when dt <= '2018-02-16' then 2017
						else 2018 end year_dt,
					sku_pv,
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end device,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2017-12-29'
							and dt <= '2018-02-16'
						)
						or
						(
							dt >= '2018-12-18'
							and dt <= '2019-02-05'
						)
					)
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			year_dt,
			dept_id_3,
			dept_name_3,
			device
	)
	b
on
	a.year_dt = b.year_dt
	and a.dept_id_3 = b.dept_id_3
	and a.dept_name_3 = b.dept_name_3
	and a.device = b.device
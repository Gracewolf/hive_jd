select
	coalesce(a.dt, b.dt) 日期,
	coalesce(a.dept_id_3, b.dept_id_3) 三级部门id,
	coalesce(a.dept_name_3, b.dept_name_3) 三级部门,
	GMV,
	pv
from
	(
		select /*+mapjoin(a)*/
			dt,
			dept_id_3,
			dept_name_3,
			sum(cw_gmv) GMV
		from
			(
				select
					item_sku_id,
					item_id,
					dept_id_3,
					dept_name_3
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and dept_id_3 in('3836', '966', '3816')
			)
			a
		left join
			(
				select
					item_id
				from
					gdm.gdm_m03_item_spec_attr_da
				where
					dt = sysdate( - 1)
					and attr_name in('factoryShip')
					and attr_val in('1')
			)
			c
		on
			a.item_id = c.item_id
		join
			(
				select
					dt,
					item_sku_id,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2017-12-01'
							and dt <= '2018-02-28'
						)
						or
						(
							dt >= '2018-12-01'
							and dt <= '2019-02-28'
						)
					)
					and valid_flag = '1'
					and
					(
						(
							tp = '1'
							and substr(ord_flag, 40, 1) <> '1'
						) ----自营剔分销
						or
						(
							tp = '2'
							and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
						) ----POP剔赠品
					)
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		where
			c.item_id is null
		group by
			dt,
			dept_id_3,
			dept_name_3
	)
	a
join
	(
		select /*+mapjoin(a)*/
			dt,
			dept_id_3,
			dept_name_3,
			sum(sku_pv) pv
		from
			(
				select
					item_sku_id,
					dept_id_3,
					dept_name_3
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and dept_id_3 in('3836', '966', '3816')
			)
			a
		join
			(
				select
					sku_id,
					dt,
					sku_pv
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2017-12-01'
							and dt <= '2018-02-28'
						)
						or
						(
							dt >= '2018-12-01'
							and dt <= '2019-02-28'
						)
					)
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			dt,
			dept_id_3,
			dept_name_3
	)
	b
on
	a.dt = b.dt
	and a.dept_id_3 = b.dept_id_3
	and a.dept_name_3 = b.dept_name_3
select
	coalesce(t1.model, t2.model) 模式,
	coalesce(t1.item_third_cate_name, t2.item_third_cate_name) 类目,
	coalesce(t1.brand_code, t2.brand_code) 品牌id,
	coalesce(t1.barndname_full, t2.barndname_full) 品牌,
	sum(case when t1.year_dt = 2018 then t1.子单数 end) 今年子单数,
	sum(case when t1.year_dt = 2018 then t1.gmv end) 今年gmv,
	sum(case when t1.year_dt = 2018 then t2.pv end) 今年pv,
	sum(case when t1.year_dt = 2018 then t2.uv end) 今年uv,
	sum(case when t1.year_dt = 2017 then t1.子单数 end) 去年子单数,
	sum(case when t1.year_dt = 2017 then t1.gmv end) 去年gmv,
	sum(case when t1.year_dt = 2017 then t2.pv end) 去年pv,
	sum(case when t1.year_dt = 2017 then t2.uv end) 去年uv
from
	(
		select /*+ mapjoin(a)*/
			a.model,
			a.item_third_cate_name,
			a.brand_code,
			a.barndname_full,
			b.year_dt,
			count(distinct b.sale_ord_id) 子单数,
			sum(b.cw_gmv) gmv
		from
			(
				select
					item_sku_id,
					item_third_cate_name,
					brand_code,
					regexp_replace(regexp_replace(trim(barndname_full), ',', '，'), '"', '') barndname_full,
					case data_type
						when '1' then '自营'
						when '3' then 'POP'
					end model
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and item_first_cate_cd = '1320'
					and item_second_cate_cd = '12202'
					and item_third_cate_cd in('12203', '12208')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					item_sku_id,
					sale_ord_id,
					parent_sale_ord_id,
					lower(trim(user_log_acct)) pin,
					ord_flag,
					item_second_cate_cd,
					item_third_cate_cd,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2018-09-27'
							and dt <= '2018-10-13'
						)
						or
						(
							dt >= '2017-09-27'
							and dt <= '2017-10-13'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		-- where
			-- (
				-- a.data_type = '1'
				-- and substr(b.ord_flag, 40, 1) <> '1'
			-- ) ----自营剔分销
			-- or
			-- (
				-- a.data_type = '3'
				-- and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
			-- ) ----POP剔赠品
		group by
			a.model,
			a.item_third_cate_name,
			a.brand_code,
			a.barndname_full,
			b.year_dt
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			a.model,
			a.item_third_cate_name,
			a.brand_code,
			a.barndname_full,
			b.year_dt,
			sum(b.pv) pv,
			count(distinct b.browser_uniq_id) uv
		from
			(
				select
					item_sku_id,
					item_third_cate_name,
					brand_code,
					regexp_replace(regexp_replace(trim(barndname_full), ',', '，'), '"', '') barndname_full,
					case data_type
						when '1' then '自营'
						when '3' then 'POP'
					end model
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and item_first_cate_cd = '1320'
					and item_second_cate_cd = '12202'
					and item_third_cate_cd in('12203', '12208')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					sku_id,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2018-09-27'
							and dt <= '2018-10-13'
						)
						or
						(
							dt >= '2017-09-27'
							and dt <= '2017-10-13'
						)
					)
				group by
					sku_id,
					year(dt),
					browser_uniq_id
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			a.model,
			a.item_third_cate_name,
			a.brand_code,
			a.barndname_full,
			b.year_dt
	)
	t2
on
	t1.year_dt = t2.year_dt
	and t1.item_third_cate_name = t2.item_third_cate_name
	and t1.model = t2.model
	and t1.brand_code = t2.brand_code
group by
	coalesce(t1.model, t2.model),
	coalesce(t1.item_third_cate_name, t2.item_third_cate_name),
	coalesce(t1.brand_code, t2.brand_code),
	coalesce(t1.barndname_full, t2.barndname_full)
----用户模板
select
	x.item_third_cate_name 类目,
	x.model 模式,
	count(distinct case when x.year_dt = 2018 then x.user_log_acct end) 2018总用户数,
	count(distinct case when x.year_dt = 2018 and par_ord_num >= 2 then x.user_log_acct end) 2018复购用户数,
	sum(case when x.year_dt = 2018 then ord_num end) 2018子单量,
	sum(case when x.year_dt = 2018 then par_ord_num end) 2018父单量,
	sum(case when x.year_dt = 2018 then aft_pre_amount end) 2018优惠后金额,
	count(distinct case when x.year_dt = 2018 and fst_all_yn = 1 then x.user_log_acct end) 2018站外新用户数,
	sum(case when x.year_dt = 2018 and fst_all_yn = 1 then ord_num end) 2018站外新子单量,
	sum(case when x.year_dt = 2018 and fst_all_yn = 1 then par_ord_num end) 2018站外新父单量,
	sum(case when x.year_dt = 2018 and fst_all_yn = 1 then aft_pre_amount end) 2018站外新优惠后金额,
	count(distinct case when x.year_dt = 2018 and fst_all_yn = 0 then x.user_log_acct end) 2018站内新用户数,
	sum(case when x.year_dt = 2018 and fst_all_yn = 0 then ord_num end) 2018站内新子单量,
	sum(case when x.year_dt = 2018 and fst_all_yn = 0 then par_ord_num end) 2018站内新父单量,
	sum(case when x.year_dt = 2018 and fst_all_yn = 0 then aft_pre_amount end) 2018站内新优惠后金额,
	count(distinct case when x.year_dt = 2017 then x.user_log_acct end) 2017总用户数,
	count(distinct case when x.year_dt = 2017 and par_ord_num >= 2 then x.user_log_acct end) 2017复购用户数,
	sum(case when x.year_dt = 2017 then ord_num end) 2017子单量,
	sum(case when x.year_dt = 2017 then par_ord_num end) 2017父单量,
	sum(case when x.year_dt = 2017 then aft_pre_amount end) 2017优惠后金额,
	count(distinct case when x.year_dt = 2017 and fst_all_yn = 1 then x.user_log_acct end) 2017站外新用户数,
	sum(case when x.year_dt = 2017 and fst_all_yn = 1 then ord_num end) 2017站外新子单量,
	sum(case when x.year_dt = 2017 and fst_all_yn = 1 then par_ord_num end) 2017站外新父单量,
	sum(case when x.year_dt = 2017 and fst_all_yn = 1 then aft_pre_amount end) 2017站外新优惠后金额,
	count(distinct case when x.year_dt = 2017 and fst_all_yn = 0 then x.user_log_acct end) 2017站内新用户数,
	sum(case when x.year_dt = 2017 and fst_all_yn = 0 then ord_num end) 2017站内新子单量,
	sum(case when x.year_dt = 2017 and fst_all_yn = 0 then par_ord_num end) 2017站内新父单量,
	sum(case when x.year_dt = 2017 and fst_all_yn = 0 then aft_pre_amount end) 2017站内新优惠后金额
from
	(
		select /*+ MAPJOIN(a)*/
			b.year_dt,
			b.user_log_acct,
			a.model,
			a.item_third_cate_cd,
			a.item_third_cate_name,
			count(distinct sale_ord_id) ord_num,
			count(distinct parent_sale_ord_id) par_ord_num,
			sum(after_prefr_amount_1) aft_pre_amount
		from
			(
				select
					item_sku_id,
					item_third_cate_cd,
					item_third_cate_name,
					case data_type
						when '1' then '自营'
						when '3' then 'POP'
					end model
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and item_first_cate_cd = '1320'
					and item_second_cate_cd = '12202'
					and item_third_cate_cd in('12203', '12208')
			)
			a
		join
			(
				select
					user_log_acct,
					item_sku_id,
					year(sale_ord_dt) year_dt,
					parent_sale_ord_id,
					sale_ord_id,
					after_prefr_amount_1,
					check_account_tm,
					sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
				from
					gdm.gdm_m04_ord_det_sum
				where
					dt >= '2017-09-27'
					and
					(
						(
							sale_ord_dt >= '2018-09-27'
							and sale_ord_dt <= '2018-10-13'
						)
						or
						(
							sale_ord_dt >= '2017-09-27'
							and sale_ord_dt <= '2017-10-13'
						)
					)
					and sale_ord_valid_flag = '1'
					and item_third_cate_cd not in('6980') --剔除礼品卡
					and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
					and
					(
						substr(ord_flag, 31, 1) <> '2' --非行政内采
						or
						(
							substr(ord_flag, 31, 1) = '2'
							and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
						)
					)
					and
					(
						substring(ord_flag, 46, 1) not in('1', '2', '3', '7')
						or substring(ord_flag, 60, 3) not in('013')
					)
					and sale_ord_type_cd <> '68' --剔除拍卖
					and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
					and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
					and user_log_acct not like"ept%"
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		where
			b.ord_amount < 100000
			or
			(
				b.ord_amount >= 100000
				and coalesce(b.check_account_tm, '') <> ''
			)
		group by
			b.year_dt,
			b.user_log_acct,
			a.model,
			a.item_third_cate_cd,
			a.item_third_cate_name
	)
	x
left join
	(
		select
			x.*,
			year(fst_ord_dt) year_dt
		from
			(
				select
					user_log_acct,
					3st_item_first_cate_cd,
					case 1st_self_or_pop
						when '商品是自营' then '自营'
						when '商品是POP' then 'POP'
					end model,
					min(1st_sale_ord_dt) fst_ord_dt,
					max(case when 1st_all_yn = 1 then 1 else 0 end) fst_all_yn
				from
					gdm.gdm_m01_user_third_cate_da
				where
					dt = sysdate( - 1)
					and 3st_item_first_cate_cd in('12203', '12208')
				group by
					user_log_acct,
					3st_item_first_cate_cd,
					case 1st_self_or_pop
						when '商品是自营' then '自营'
						when '商品是POP' then 'POP'
					end
			)
			x
		where
			(
				(
					fst_ord_dt >= '2018-09-27'
					and fst_ord_dt <= '2018-10-13'
				)
				or
				(
					fst_ord_dt >= '2017-09-27'
					and fst_ord_dt <= '2017-10-13'
				)
			)
	)
	y
on
	x.user_log_acct = y.user_log_acct
	and x.item_third_cate_cd = y.3st_item_first_cate_cd
	and x.year_dt = y.year_dt
	and x.model = y.model
group by
	x.item_third_cate_name,
	x.model

union

select
	x.item_second_cate_name 类目,
	x.model 模式,
	count(distinct case when x.year_dt = 2018 then x.user_log_acct end) 2018总用户数,
	count(distinct case when x.year_dt = 2018 and par_ord_num >= 2 then x.user_log_acct end) 2018复购用户数,
	sum(case when x.year_dt = 2018 then ord_num end) 2018子单量,
	sum(case when x.year_dt = 2018 then par_ord_num end) 2018父单量,
	sum(case when x.year_dt = 2018 then aft_pre_amount end) 2018优惠后金额,
	count(distinct case when x.year_dt = 2018 and fst_all_yn = 1 then x.user_log_acct end) 2018站外新用户数,
	sum(case when x.year_dt = 2018 and fst_all_yn = 1 then ord_num end) 2018站外新子单量,
	sum(case when x.year_dt = 2018 and fst_all_yn = 1 then par_ord_num end) 2018站外新父单量,
	sum(case when x.year_dt = 2018 and fst_all_yn = 1 then aft_pre_amount end) 2018站外新优惠后金额,
	count(distinct case when x.year_dt = 2018 and fst_all_yn = 0 then x.user_log_acct end) 2018站内新用户数,
	sum(case when x.year_dt = 2018 and fst_all_yn = 0 then ord_num end) 2018站内新子单量,
	sum(case when x.year_dt = 2018 and fst_all_yn = 0 then par_ord_num end) 2018站内新父单量,
	sum(case when x.year_dt = 2018 and fst_all_yn = 0 then aft_pre_amount end) 2018站内新优惠后金额,
	count(distinct case when x.year_dt = 2017 then x.user_log_acct end) 2017总用户数,
	count(distinct case when x.year_dt = 2017 and par_ord_num >= 2 then x.user_log_acct end) 2017复购用户数,
	sum(case when x.year_dt = 2017 then ord_num end) 2017子单量,
	sum(case when x.year_dt = 2017 then par_ord_num end) 2017父单量,
	sum(case when x.year_dt = 2017 then aft_pre_amount end) 2017优惠后金额,
	count(distinct case when x.year_dt = 2017 and fst_all_yn = 1 then x.user_log_acct end) 2017站外新用户数,
	sum(case when x.year_dt = 2017 and fst_all_yn = 1 then ord_num end) 2017站外新子单量,
	sum(case when x.year_dt = 2017 and fst_all_yn = 1 then par_ord_num end) 2017站外新父单量,
	sum(case when x.year_dt = 2017 and fst_all_yn = 1 then aft_pre_amount end) 2017站外新优惠后金额,
	count(distinct case when x.year_dt = 2017 and fst_all_yn = 0 then x.user_log_acct end) 2017站内新用户数,
	sum(case when x.year_dt = 2017 and fst_all_yn = 0 then ord_num end) 2017站内新子单量,
	sum(case when x.year_dt = 2017 and fst_all_yn = 0 then par_ord_num end) 2017站内新父单量,
	sum(case when x.year_dt = 2017 and fst_all_yn = 0 then aft_pre_amount end) 2017站内新优惠后金额
from
	(
		select /*+ MAPJOIN(a)*/
			b.year_dt,
			b.user_log_acct,
			a.item_second_cate_cd,
			a.item_second_cate_name,
			a.model,
			count(distinct sale_ord_id) ord_num,
			count(distinct parent_sale_ord_id) par_ord_num,
			sum(after_prefr_amount_1) aft_pre_amount
		from
			(
				select
					item_sku_id,
					item_second_cate_cd,
					item_second_cate_name,
					case data_type
						when '1' then '自营'
						when '3' then 'POP'
					end model
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and item_first_cate_cd = '1320'
					and item_second_cate_cd = '12202'
			)
			a
		join
			(
				select
					user_log_acct,
					item_sku_id,
					year(sale_ord_dt) year_dt,
					parent_sale_ord_id,
					sale_ord_id,
					after_prefr_amount_1,
					check_account_tm,
					sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
				from
					gdm.gdm_m04_ord_det_sum
				where
					dt >= '2017-09-27'
					and
					(
						(
							sale_ord_dt >= '2018-09-27'
							and sale_ord_dt <= '2018-10-13'
						)
						or
						(
							sale_ord_dt >= '2017-09-27'
							and sale_ord_dt <= '2017-10-13'
						)
					)
					and sale_ord_valid_flag = '1'
					and item_third_cate_cd not in('6980') --剔除礼品卡
					and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
					and
					(
						substr(ord_flag, 31, 1) <> '2' --非行政内采
						or
						(
							substr(ord_flag, 31, 1) = '2'
							and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
						)
					)
					and
					(
						substring(ord_flag, 46, 1) not in('1', '2', '3', '7')
						or substring(ord_flag, 60, 3) not in('013')
					)
					and sale_ord_type_cd <> '68' --剔除拍卖
					and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
					and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
					and user_log_acct not like"ept%"
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		where
			b.ord_amount < 100000
			or
			(
				b.ord_amount >= 100000
				and coalesce(b.check_account_tm, '') <> ''
			)
		group by
			b.year_dt,
			b.user_log_acct,
			a.item_second_cate_cd,
			a.item_second_cate_name,
			a.model
	)
	x
left join
	(
		select
			x.*,
			year(fst_ord_dt) year_dt
		from
			(
				select
					user_log_acct,
					2st_item_first_cate_cd,
					case 1st_self_or_pop
						when '商品是自营' then '自营'
						when '商品是POP' then 'POP'
					end model,
					min(1st_sale_ord_dt) fst_ord_dt,
					max(case when 1st_all_yn = 1 then 1 else 0 end) fst_all_yn
				from
					gdm.gdm_m01_user_third_cate_da
				where
					dt = sysdate( - 1)
					and 2st_item_first_cate_cd = '12202'
				group by
					user_log_acct,
					2st_item_first_cate_cd,
					case 1st_self_or_pop
						when '商品是自营' then '自营'
						when '商品是POP' then 'POP'
					end
			)
			x
		where
			(
				(
					fst_ord_dt >= '2018-09-27'
					and fst_ord_dt <= '2018-10-13'
				)
				or
				(
					fst_ord_dt >= '2017-09-27'
					and fst_ord_dt <= '2017-10-13'
				)
			)
	)
	y
on
	x.user_log_acct = y.user_log_acct
	and x.item_second_cate_cd = y.2st_item_first_cate_cd
	and x.year_dt = y.year_dt
	and x.model = y.model
group by
	x.item_second_cate_name,
	x.model
----周报分渠道流量模板
select
	coalesce(t1.item_second_cate_name, t2.item_second_cate_name) 类目,
	sum(case when t1.year_dt = 2018 then t1.子单数 end) 今年子单数,
	sum(case when t1.year_dt = 2018 then t1.gmv end) 今年gmv,
	sum(case when t1.year_dt = 2018 then t2.pv end) 今年pv,
	sum(case when t1.year_dt = 2018 then t2.uv end) 今年uv,
	sum(case when t1.year_dt = 2017 then t1.子单数 end) 去年子单数,
	sum(case when t1.year_dt = 2017 then t1.gmv end) 去年gmv,
	sum(case when t1.year_dt = 2017 then t2.pv end) 去年pv,
	sum(case when t1.year_dt = 2017 then t2.uv end) 去年uv,
	sum(case when t1.year_dt = 2018 then t1.自营子单数 end) 今年自营子单数,
	sum(case when t1.year_dt = 2018 then t1.自营gmv end) 今年自营gmv,
	sum(case when t1.year_dt = 2018 then t2.自营pv end) 今年自营pv,
	sum(case when t1.year_dt = 2018 then t2.自营uv end) 今年自营uv,
	sum(case when t1.year_dt = 2017 then t1.自营子单数 end) 去年自营子单数,
	sum(case when t1.year_dt = 2017 then t1.自营gmv end) 去年自营gmv,
	sum(case when t1.year_dt = 2017 then t2.自营pv end) 去年自营pv,
	sum(case when t1.year_dt = 2017 then t2.自营uv end) 去年自营uv,
	sum(case when t1.year_dt = 2018 then t1.POP子单数 end) 今年POP子单数,
	sum(case when t1.year_dt = 2018 then t1.POPgmv end) 今年POPgmv,
	sum(case when t1.year_dt = 2018 then t2.POPpv end) 今年POPpv,
	sum(case when t1.year_dt = 2018 then t2.POPuv end) 今年POPuv,
	sum(case when t1.year_dt = 2017 then t1.POP子单数 end) 去年POP子单数,
	sum(case when t1.year_dt = 2017 then t1.POPgmv end) 去年POPgmv,
	sum(case when t1.year_dt = 2017 then t2.POPpv end) 去年POPpv,
	sum(case when t1.year_dt = 2017 then t2.POPuv end) 去年POPuv
from
	(
		select /*+ mapjoin(a)*/
			a.item_second_cate_name,
			b.year_dt,
			count(distinct b.sale_ord_id) 子单数,
			sum(b.cw_gmv) gmv,
			count(distinct case when data_type = '1' then b.sale_ord_id end) 自营子单数,
			sum(case when data_type = '1' then b.cw_gmv end) 自营gmv,
			count(distinct case when data_type = '3' then b.sale_ord_id end) POP子单数,
			sum(case when data_type = '3' then b.cw_gmv end) POPgmv
		from
			(
				select
					item_sku_id,
					item_second_cate_name,
					data_type
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and item_first_cate_cd = '1320'
					and item_second_cate_cd = '12202'
			)
			a
		join
			(
				select
					year(dt) year_dt,
					item_sku_id,
					sale_ord_id,
					parent_sale_ord_id,
					lower(trim(user_log_acct)) pin,
					ord_flag,
					item_second_cate_cd,
					item_third_cate_cd,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2018-09-27'
							and dt <= '2018-10-13'
						)
						or
						(
							dt >= '2017-09-27'
							and dt <= '2017-10-13'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		-- where
			-- (
				-- a.data_type = '1'
				-- and substr(b.ord_flag, 40, 1) <> '1'
			-- ) ----自营剔分销
			-- or
			-- (
				-- a.data_type = '3'
				-- and (item_second_cate_cd <> '4980' or item_second_cate_cd <> '4992')
			-- ) ----POP剔赠品
		group by
			a.item_second_cate_name,
			b.year_dt
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			a.item_second_cate_name,
			b.year_dt,
			sum(b.pv) pv,
			count(distinct b.browser_uniq_id) uv,
			sum(case when data_type = '1' then b.pv end) 自营pv,
			count(distinct case when data_type = '1' then b.browser_uniq_id end) 自营uv,
			sum(case when data_type = '3' then b.pv end) POPpv,
			count(distinct case when data_type = '3' then b.browser_uniq_id end) POPuv
		from
			(
				select
					item_sku_id,
					item_second_cate_name,
					data_type
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and item_first_cate_cd = '1320'
					and item_second_cate_cd = '12202'
			)
			a
		join
			(
				select
					year(dt) year_dt,
					sku_id,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2018-09-27'
							and dt <= '2018-10-13'
						)
						or
						(
							dt >= '2017-09-27'
							and dt <= '2017-10-13'
						)
					)
				group by
					sku_id,
					year(dt),
					browser_uniq_id
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			a.item_second_cate_name,
			b.year_dt
	)
	t2
on
	t1.year_dt = t2.year_dt
	and t1.item_second_cate_name = t2.item_second_cate_name
group by
	coalesce(t1.item_second_cate_name, t2.item_second_cate_name)

union

select
	coalesce(t1.item_third_cate_name, t2.item_third_cate_name) 类目,
	sum(case when t1.year_dt = 2018 then t1.子单数 end) 今年子单数,
	sum(case when t1.year_dt = 2018 then t1.gmv end) 今年gmv,
	sum(case when t1.year_dt = 2018 then t2.pv end) 今年pv,
	sum(case when t1.year_dt = 2018 then t2.uv end) 今年uv,
	sum(case when t1.year_dt = 2017 then t1.子单数 end) 去年子单数,
	sum(case when t1.year_dt = 2017 then t1.gmv end) 去年gmv,
	sum(case when t1.year_dt = 2017 then t2.pv end) 去年pv,
	sum(case when t1.year_dt = 2017 then t2.uv end) 去年uv,
	sum(case when t1.year_dt = 2018 then t1.自营子单数 end) 今年自营子单数,
	sum(case when t1.year_dt = 2018 then t1.自营gmv end) 今年自营gmv,
	sum(case when t1.year_dt = 2018 then t2.自营pv end) 今年自营pv,
	sum(case when t1.year_dt = 2018 then t2.自营uv end) 今年自营uv,
	sum(case when t1.year_dt = 2017 then t1.自营子单数 end) 去年自营子单数,
	sum(case when t1.year_dt = 2017 then t1.自营gmv end) 去年自营gmv,
	sum(case when t1.year_dt = 2017 then t2.自营pv end) 去年自营pv,
	sum(case when t1.year_dt = 2017 then t2.自营uv end) 去年自营uv,
	sum(case when t1.year_dt = 2018 then t1.POP子单数 end) 今年POP子单数,
	sum(case when t1.year_dt = 2018 then t1.POPgmv end) 今年POPgmv,
	sum(case when t1.year_dt = 2018 then t2.POPpv end) 今年POPpv,
	sum(case when t1.year_dt = 2018 then t2.POPuv end) 今年POPuv,
	sum(case when t1.year_dt = 2017 then t1.POP子单数 end) 去年POP子单数,
	sum(case when t1.year_dt = 2017 then t1.POPgmv end) 去年POPgmv,
	sum(case when t1.year_dt = 2017 then t2.POPpv end) 去年POPpv,
	sum(case when t1.year_dt = 2017 then t2.POPuv end) 去年POPuv
from
	(
		select /*+ mapjoin(a)*/
			a.item_third_cate_name,
			b.year_dt,
			count(distinct b.sale_ord_id) 子单数,
			sum(b.cw_gmv) gmv,
			count(distinct case when data_type = '1' then b.sale_ord_id end) 自营子单数,
			sum(case when data_type = '1' then b.cw_gmv end) 自营gmv,
			count(distinct case when data_type = '3' then b.sale_ord_id end) POP子单数,
			sum(case when data_type = '3' then b.cw_gmv end) POPgmv
		from
			(
				select
					item_sku_id,
					item_third_cate_name,
					data_type
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and item_first_cate_cd = '1320'
					and item_second_cate_cd = '12202'
					and item_third_cate_cd in('12203', '12208')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					item_sku_id,
					sale_ord_id,
					parent_sale_ord_id,
					lower(trim(user_log_acct)) pin,
					ord_flag,
					item_second_cate_cd,
					item_third_cate_cd,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2018-09-27'
							and dt <= '2018-10-13'
						)
						or
						(
							dt >= '2017-09-27'
							and dt <= '2017-10-13'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		-- where
			-- (
				-- a.data_type = '1'
				-- and substr(b.ord_flag, 40, 1) <> '1'
			-- ) ----自营剔分销
			-- or
			-- (
				-- a.data_type = '3'
				-- and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
			-- ) ----POP剔赠品
		group by
			a.item_third_cate_name,
			b.year_dt
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			a.item_third_cate_name,
			b.year_dt,
			sum(b.pv) pv,
			count(distinct b.browser_uniq_id) uv,
			sum(case when data_type = '1' then b.pv end) 自营pv,
			count(distinct case when data_type = '1' then b.browser_uniq_id end) 自营uv,
			sum(case when data_type = '3' then b.pv end) POPpv,
			count(distinct case when data_type = '3' then b.browser_uniq_id end) POPuv
		from
			(
				select
					item_sku_id,
					item_third_cate_name,
					data_type
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and item_first_cate_cd = '1320'
					and item_second_cate_cd = '12202'
					and item_third_cate_cd in('12203', '12208')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					sku_id,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2018-09-27'
							and dt <= '2018-10-13'
						)
						or
						(
							dt >= '2017-09-27'
							and dt <= '2017-10-13'
						)
					)
				group by
					sku_id,
					year(dt),
					browser_uniq_id
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			a.item_third_cate_name,
			b.year_dt
	)
	t2
on
	t1.year_dt = t2.year_dt
	and t1.item_third_cate_name = t2.item_third_cate_name
group by
	coalesce(t1.item_third_cate_name, t2.item_third_cate_name)
select
	dt 日期,
	sum(gmv) gmv,
	sum(case t1.data_type when '1' then gmv else 0.0 end) self_gmv,
	sum(case t1.data_type when '3' then gmv else 0.0 end) pop_gmv
from
	(
		select
			dt,
			data_type,
			sum(cw_gmv) gmv
		from
			(
				select
					data_type,
					item_id,
					item_sku_id,
					case when item_third_cate_name like '%赠品%' or item_second_cate_name like '%赠品%'
						or item_third_cate_name like '%特殊商品%' or item_second_cate_name like '%特殊商品%' then 1 else 0 end present_flag
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
			)
			a
		left join
			(
				select
					item_id
				from
					gdm.gdm_m03_item_spec_attr_da
				where
					dt = sysdate( - 1)
					and attr_name in('factoryShip')
					and attr_val in('1')
			)
			c
		on
			a.item_id = c.item_id
		join
			(
				select
					dt,
					substr(ord_flag, 40, 1) fenxiao_flag,
					item_second_cate_cd,
					item_third_cate_cd,
					item_sku_id,
					sale_ord_id,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2019-08-21'
							and dt <= '2019-09-13'
						)
						or
						(
							dt >= '2018-09-01'
							and dt <= '2018-09-24'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		where
			c.item_id is not null
			or
			(
				(
					data_type = '1'
					and fenxiao_flag = '1'
				) ----自营剔分销
				or
				(
					data_type = '3'
					and
					(
						item_second_cate_cd like '4980'
						or item_third_cate_cd = '4992'
						or present_flag = 1
					)
				) ----POP剔赠品
			)
		group by
			dt,
			data_type
	)
	t1
group by
	dt
select
	regexp_replace(regexp_replace(trim(key_word), '"', ''), ',', '，') 关键词,
	sum(case when wk = 1 then 搜索次数 end) 第一周搜索次数,
	sum(case when wk = 2 then 搜索次数 end) 第二周搜索次数,
	sum(case when wk = 3 then 搜索次数 end) 第三周搜索次数,
	sum(case when wk = 4 then 搜索次数 end) 第四周搜索次数
from
	(
		select
			dt,
			case
				when dt <= '2019-08-25' then 1
				when dt <= '2019-09-01' then 2
				when dt <= '2019-09-08' then 3
				else 4
			end wk,
			key_word,
			search_times 搜索次数,
			click_num 搜索结果页点击量,
			uv 访客数,
			click_num_sku 搜索结果页商品点击量,
			user_num_cate 引入订单用户数,
			valid_user_num_cate 有效引入订单用户数,
			par_ord_num_cate 父单量,
			ord_num_cate 子单量,
			valid_ord_num_cate 有效子单量,
			gmv_cate 优惠后金额
		from
			(
				select
					*
				from
					app.v_adm_m14_key_word_sum_d LATERAL VIEW explode(split(high_value, ',')) adTable as high_value_third_cate
				where
					dt >= '2019-08-19'
					and dt <= '2019-09-15'
			)
			a
		join
			(
				select
					dim_item_gen_first_cate_name,
					dim_item_gen_first_cate_id,
					dim_item_gen_second_cate_id,
					dim_item_gen_second_cate_name,
					dim_item_gen_third_cate_id
				from
					dim.dim_item_gen_third_cate_orc
				where
					valid_flag = '1'
					and dim_item_gen_first_cate_id in('1320')
			)
			b
		on
			a.high_value_third_cate = b.dim_item_gen_third_cate_id
		group by
			dt,
			dim_item_gen_first_cate_id,
			dim_item_gen_first_cate_name,
			key_word,
			search_times,
			click_num,
			uv,
			click_num_sku,
			user_num_cate,
			valid_user_num_cate,
			par_ord_num_cate,
			ord_num_cate,
			valid_ord_num_cate,
			gmv_cate
	)
	c
group by
	regexp_replace(regexp_replace(trim(key_word), '"', ''), ',', '，')
order by
	第四周搜索次数 desc
limit 200
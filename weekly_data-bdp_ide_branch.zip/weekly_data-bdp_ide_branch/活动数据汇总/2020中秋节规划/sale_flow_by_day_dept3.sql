set hive.exec.parallel = true;
select
	coalesce(t1.dt, t2.dt) dt,
	coalesce(t1.dept_id_3, t2.dept_id_3) dept_id_3,
	coalesce(t1.dept_name_3, t2.dept_name_3) dept_name_3,
	sum(gmv) gmv,
	sum(pv) pv
from
	(
		select
			dt,
			dept_id_3,
			dept_name_3,
			sum(cw_gmv) gmv
		from
			(
				select
					data_type,
					dept_id_3,
					dept_name_3,
					item_id,
					item_sku_id
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
			)
			a
		left join
			(
				select
					item_id
				from
					gdm.gdm_m03_item_spec_attr_da
				where
					dt = sysdate( - 1)
					and attr_name in('factoryShip')
					and attr_val in('1')
			)
			c
		on
			a.item_id = c.item_id
		join
			(
				select
					year(dt) dt,
					item_sku_id,
					sale_ord_id,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2019-08-21'
							and dt <= '2019-09-13'
						)
						or
						(
							dt >= '2018-09-01'
							and dt <= '2018-09-24'
						)
					)
					and valid_flag = '1'
					and
					(
						(
							tp = '1'
							and substr(ord_flag, 40, 1) <> '1'
						) ----自营剔分销
						or
						(
							tp = '2'
							and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
						) ----POP剔赠品
					)
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		where
			c.item_id is null
		group by
			dt,
			dept_id_3,
			dept_name_3
	)
	t1
full outer join
	(
		select
			dt,
			dept_id_3,
			dept_name_3,
			sum(sku_pv) pv
		from
			(
				select
					data_type,
					dept_id_3,
					dept_name_3,
					item_id,
					item_sku_id
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
			)
			a
		join
			(
				select
					year(dt) dt,
					sku_id,
					sku_pv
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2019-08-21'
							and dt <= '2019-09-13'
						)
						or
						(
							dt >= '2018-09-01'
							and dt <= '2018-09-24'
						)
					)
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			dt,
			dept_id_3,
			dept_name_3
	)
	t2
on
	t1.dt = t2.dt
	and t1.dept_id_3 = t2.dept_id_3
	and t1.dept_name_3 = t2.dept_name_3
group by
	coalesce(t1.dt, t2.dt),
	coalesce(t1.dept_id_3, t2.dept_id_3),
	coalesce(t1.dept_name_3, t2.dept_name_3)
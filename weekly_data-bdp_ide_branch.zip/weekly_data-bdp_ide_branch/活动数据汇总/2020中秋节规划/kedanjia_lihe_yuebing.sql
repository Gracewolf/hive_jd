select
	a.model,
	lihe_flag,
	b.dt,
	sum(cw_gmv) gmv,
	sum(sale_qtty) qtty,
	count(distinct parent_sale_ord_id) 订单数
from
	(
		select
			item_sku_id,
			case data_type
				when '1' then '自营'
				else 'POP'
			end model,
			case when sku_name like '%礼盒%' then '礼盒' else '非礼盒' end lihe_flag
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and dept_id_2 in('47', '1699')
			and item_first_cate_cd = '1320'
			and item_third_cate_cd = '2642'
	)
	a
join
	(
		select
			year(dt) dt,
			item_sku_id,
			parent_sale_ord_id,
			sale_qtty,
			cw_gmv
		from
			app.v_app_cmo_cw_ord_det_sum_rb
		where
			(
				(
					dt >= '2019-08-21'
					and dt <= '2019-09-13'
				)
				or
				(
					dt >= '2018-09-01'
					and dt <= '2018-09-24'
				)
			)
			and valid_flag = '1'
	)
	b
on
	a.item_sku_id = b.item_sku_id
group by
	a.model,
	lihe_flag,
	b.dt
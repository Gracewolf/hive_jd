set hive.exec.parallel = true;
set hive.exec.parallel.thread.number = 16;
create table dev_xfp.nz_618_20_big_table as
select
	flow.dt_dt,
	flow.dept_id_2 dept_id,
	flow.dept_name_2 dept_name,
	pv,
	pv / pv_last - 1 pv_ratio,
	uv,
	uv / uv_last - 1 uv_ratio,
	ord_num / pv pv_cov,
	ord_num / pv - ord_num_last / pv_last pv_cov_gap,
	ord_num / uv uv_cov,
	ord_num / uv - ord_num_last / uv_last uv_cov_gap,
	valid_amount / uv uv_value,
	valid_amount / uv / (valid_amount_last / uv_last) - 1 uv_value_ratio,
	ord_num,
	ord_num / ord_num_last - 1 ord_num_ratio,
	valid_amount,
	valid_amount / valid_amount_last - 1 valid_amount_ratio,
	gmv,
	gmv / gmv_last - 1 gmv_ratio,
	cn,
	cn / cn_last - 1 cn_ratio,
	inner_new_user,
	inner_new_user / inner_new_user_last - 1 inner_ratio,
	outer_new_user,
	outer_new_user / outer_new_user_last - 1 outer_ratio
from
	(
		select
			dept_id_2,
			dept_name_2,
			dt_dt,
			sum(case when year_dt = '2020' then sku_pv else 0 end) pv,
			sum(case when year_dt = '2019' then sku_pv else 0 end) pv_last,
			count(distinct case when year_dt = '2020' then browser_uniq_id end) uv,
			count(distinct case when year_dt = '2019' then browser_uniq_id end) uv_last
		from
			(
				select
					item_sku_id,
					dept_id_2,
					dept_name_2
				from
					gdm.gdm_m03_mkt_item_sku_da
				where
					dt = sysdate( - 1)
					and dept_id_2 in('47', '1699')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					substr(dt, 6, 5) dt_dt,
					sku_id,
					sku_pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2019-05-21'
							and dt <= '2019-06-21'
						)
						or
						(
							dt >= '2020-05-21'
							and dt <= '2020-06-21'
						)
					)
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			dept_id_2,
			dept_name_2,
			dt_dt
	)
	flow
join
	(
		select
			dept_id_2,
			dept_name_2,
			dt_dt,
			sum(case when year_dt = '2020' then cw_gmv else 0 end) gmv,
			sum(case when year_dt = '2019' then cw_gmv else 0 end) gmv_last
		from
			(
				select
					item_sku_id,
					dept_id_2,
					dept_name_2
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					substr(dt, 6, 5) dt_dt,
					item_sku_id,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2019-05-21'
							and dt <= '2019-06-21'
						)
						or
						(
							dt >= '2020-05-21'
							and dt <= '2020-06-21'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		group by
			dept_id_2,
			dept_name_2,
			dt_dt
	)
	sale
on
	flow.dt_dt = sale.dt_dt
	and flow.dept_id_2 = sale.dept_id_2
	and flow.dept_name_2 = sale.dept_name_2
join
	(
		select
			x.dept_id_2,
			x.dept_name_2,
			x.dt_dt,
			count(distinct case when x.year_dt = '2020' then x.user_log_acct end) cn,
			sum(case when x.year_dt = '2020' then x.after_prefr_amount_1 end) valid_amount,
			count(distinct case when x.year_dt = '2020' and fst_all_yn = 1 then x.user_log_acct end) outer_new_user,
			count(distinct case when x.year_dt = '2020' and fst_all_yn = 0 then x.user_log_acct end) inner_new_user,
			count(distinct case when x.year_dt = '2020' then x.sale_ord_id end) ord_num,
			count(distinct case when x.year_dt = '2019' then x.user_log_acct end) cn_last,
			sum(case when x.year_dt = '2019' then x.after_prefr_amount_1 end) valid_amount_last,
			count(distinct case when x.year_dt = '2019' and fst_all_yn = 1 then x.user_log_acct end) outer_new_user_last,
			count(distinct case when x.year_dt = '2019' and fst_all_yn = 0 then x.user_log_acct end) inner_new_user_last,
			count(distinct case when x.year_dt = '2019' then x.sale_ord_id end) ord_num_last
		from
			(
				select /*+ MAPJOIN(a)*/
					coalesce(d.user_log_acct, b.user_log_acct) user_log_acct,
					dept_id_2,
					dept_name_2,
					year_dt,
					dt_dt,
					after_prefr_amount_1,
					sale_ord_id
				from
					(
						select
							item_sku_id,
							dept_id_2,
							dept_name_2
						from
							gdm.gdm_m03_sold_item_sku_da
						where
							dt = sysdate( - 1)
							and data_type in('1', '3')
							and dept_id_2 in('47', '1699')
					)
					a
				join
					(
						select
							lower(trim(user_log_acct)) user_log_acct,
							item_sku_id,
							year(sale_ord_dt) year_dt,
							substr(sale_ord_dt, 6, 5) dt_dt,
							parent_sale_ord_id,
							sale_ord_id,
							after_prefr_amount_1,
							check_account_tm,
							rev_addr_city_id,
							sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
						from
							app.v_gdm_m04_ord_det_sum_rb
						where
							dt >= '2019-05-21'
							and
							(
								(
									sale_ord_dt >= '2019-05-21'
									and sale_ord_dt <= '2019-06-21'
								)
								or
								(
									sale_ord_dt >= '2020-05-21'
									and sale_ord_dt <= '2020-06-21'
								)
							)
							and sale_ord_valid_flag = '1'
							and item_third_cate_cd not in('6980') --剔除礼品卡
							and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
							and
							(
								substr(ord_flag, 31, 1) <> '2' --非行政内采
								or
								(
									substr(ord_flag, 31, 1) = '2'
									and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
								)
							)
							and
							(
								substring(ord_flag, 46, 1) not in('1', '2', '3', '7')
								or substring(ord_flag, 60, 3) not in('013')
							)
							and sale_ord_type_cd <> '68' --剔除拍卖
							and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
							and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
							and user_log_acct not like"ept%"
							and free_goods_flag = 0
					)
					b
				on
					a.item_sku_id = b.item_sku_id
				left join
					(
						select
							lower(trim(unif_user_log_acct)) user_log_acct,
							lower(trim(user_acct_name)) pin
						from
							gdm.gdm_m01_userinfo_basic_da
						where
							dt = sysdate( - 1)
					) ----归一化用户pin
					d
				on
					b.user_log_acct = d.pin
				where
					b.ord_amount < 100000
					or
					(
						b.ord_amount >= 100000
						and coalesce(b.check_account_tm, '') <> ''
					)
			)
			x
		left join
			(
				select
					x.user_log_acct,
					x.fst_all_yn,
					dept_id_2,
					year(fst_ord_dt) year_dt,
					substr(fst_ord_dt, 6, 5) dt_dt
				from
					(
						select
							dept_id_2,
							lower(trim(unif_user_log_acct)) user_log_acct,
							max(case when fst_all_yn = '1' then 1 else 0 end) fst_all_yn,
							min(fst_ord_dt) fst_ord_dt
						from
							app.v_adm_s01_user_new_or_old_flag_detail_xfp
						where
							dt = sysdate( - 1)
							and tp = 'dept'
							and dept_id_2 in('47', '1699')
						group by
							dept_id_2,
							lower(trim(unif_user_log_acct))
					)
					x
				where
					(
						(
							fst_ord_dt >= '2019-05-21'
							and fst_ord_dt <= '2019-06-21'
						)
						or
						(
							fst_ord_dt >= '2020-05-21'
							and fst_ord_dt <= '2020-06-21'
						)
					)
			)
			y
		on
			x.user_log_acct = y.user_log_acct
			and x.year_dt = y.year_dt
			and x.dt_dt = y.dt_dt
			and x.dept_id_2 = y.dept_id_2
		left join
			(
				select user_log_acct from dev_xfp.spite_user_list_xfp
			)
			c
		on
			x.user_log_acct = c.user_log_acct
		where
			c.user_log_acct is null
		group by
			x.dept_id_2,
			x.dept_name_2,
			x.dt_dt
	)
	cc
on
	flow.dt_dt = cc.dt_dt
	and flow.dept_id_2 = cc.dept_id_2
	and flow.dept_name_2 = cc.dept_name_2

union all

select
	flow.dt_dt,
	flow.dept_id_3 dept_id,
	flow.dept_name_3 dept_name,
	pv,
	pv / pv_last - 1 pv_ratio,
	uv,
	uv / uv_last - 1 uv_ratio,
	ord_num / pv pv_cov,
	ord_num / pv - ord_num_last / pv_last pv_cov_gap,
	ord_num / uv uv_cov,
	ord_num / uv - ord_num_last / uv_last uv_cov_gap,
	valid_amount / uv uv_value,
	valid_amount / uv / (valid_amount_last / uv_last) - 1 uv_value_ratio,
	ord_num,
	ord_num / ord_num_last - 1 ord_num_ratio,
	valid_amount,
	valid_amount / valid_amount_last - 1 valid_amount_ratio,
	gmv,
	gmv / gmv_last - 1 gmv_ratio,
	cn,
	cn / cn_last - 1 cn_ratio,
	inner_new_user,
	inner_new_user / inner_new_user_last - 1 inner_ratio,
	outer_new_user,
	outer_new_user / outer_new_user_last - 1 outer_ratio
from
	(
		select
			dept_id_3,
			dept_name_3,
			dt_dt,
			sum(case when year_dt = '2020' then sku_pv else 0 end) pv,
			sum(case when year_dt = '2019' then sku_pv else 0 end) pv_last,
			count(distinct case when year_dt = '2020' then browser_uniq_id end) uv,
			count(distinct case when year_dt = '2019' then browser_uniq_id end) uv_last
		from
			(
				select
					item_sku_id,
					dept_id_3,
					dept_name_3
				from
					gdm.gdm_m03_mkt_item_sku_da
				where
					dt = sysdate( - 1)
					and dept_id_2 in('47', '1699')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					substr(dt, 6, 5) dt_dt,
					sku_id,
					sku_pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2019-05-21'
							and dt <= '2019-06-21'
						)
						or
						(
							dt >= '2020-05-21'
							and dt <= '2020-06-21'
						)
					)
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			dept_id_3,
			dept_name_3,
			dt_dt
	)
	flow
join
	(
		select
			dept_id_3,
			dept_name_3,
			dt_dt,
			sum(case when year_dt = '2020' then cw_gmv else 0 end) gmv,
			sum(case when year_dt = '2019' then cw_gmv else 0 end) gmv_last
		from
			(
				select
					item_sku_id,
					dept_id_3,
					dept_name_3
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					substr(dt, 6, 5) dt_dt,
					item_sku_id,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2019-05-21'
							and dt <= '2019-06-21'
						)
						or
						(
							dt >= '2020-05-21'
							and dt <= '2020-06-21'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		group by
			dept_id_3,
			dept_name_3,
			dt_dt
	)
	sale
on
	flow.dt_dt = sale.dt_dt
	and flow.dept_id_3 = sale.dept_id_3
	and flow.dept_name_3 = sale.dept_name_3
join
	(
		select
			x.dept_id_3,
			x.dept_name_3,
			x.dt_dt,
			count(distinct case when x.year_dt = '2020' then x.user_log_acct end) cn,
			sum(case when x.year_dt = '2020' then x.after_prefr_amount_1 end) valid_amount,
			count(distinct case when x.year_dt = '2020' and fst_all_yn = 1 then x.user_log_acct end) outer_new_user,
			count(distinct case when x.year_dt = '2020' and fst_all_yn = 0 then x.user_log_acct end) inner_new_user,
			count(distinct case when x.year_dt = '2020' then x.sale_ord_id end) ord_num,
			count(distinct case when x.year_dt = '2019' then x.user_log_acct end) cn_last,
			sum(case when x.year_dt = '2019' then x.after_prefr_amount_1 end) valid_amount_last,
			count(distinct case when x.year_dt = '2019' and fst_all_yn = 1 then x.user_log_acct end) outer_new_user_last,
			count(distinct case when x.year_dt = '2019' and fst_all_yn = 0 then x.user_log_acct end) inner_new_user_last,
			count(distinct case when x.year_dt = '2019' then x.sale_ord_id end) ord_num_last
		from
			(
				select /*+ MAPJOIN(a)*/
					coalesce(d.user_log_acct, b.user_log_acct) user_log_acct,
					dept_id_3,
					dept_name_3,
					year_dt,
					dt_dt,
					after_prefr_amount_1,
					sale_ord_id
				from
					(
						select
							item_sku_id,
							dept_id_3,
							dept_name_3
						from
							gdm.gdm_m03_sold_item_sku_da
						where
							dt = sysdate( - 1)
							and data_type in('1', '3')
							and dept_id_2 in('47', '1699')
					)
					a
				join
					(
						select
							lower(trim(user_log_acct)) user_log_acct,
							item_sku_id,
							year(sale_ord_dt) year_dt,
							substr(sale_ord_dt, 6, 5) dt_dt,
							parent_sale_ord_id,
							sale_ord_id,
							after_prefr_amount_1,
							check_account_tm,
							rev_addr_city_id,
							sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
						from
							app.v_gdm_m04_ord_det_sum_rb
						where
							dt >= '2019-05-21'
							and
							(
								(
									sale_ord_dt >= '2019-05-21'
									and sale_ord_dt <= '2019-06-21'
								)
								or
								(
									sale_ord_dt >= '2020-05-21'
									and sale_ord_dt <= '2020-06-21'
								)
							)
							and sale_ord_valid_flag = '1'
							and item_third_cate_cd not in('6980') --剔除礼品卡
							and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
							and
							(
								substr(ord_flag, 31, 1) <> '2' --非行政内采
								or
								(
									substr(ord_flag, 31, 1) = '2'
									and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
								)
							)
							and
							(
								substring(ord_flag, 46, 1) not in('1', '2', '3', '7')
								or substring(ord_flag, 60, 3) not in('013')
							)
							and sale_ord_type_cd <> '68' --剔除拍卖
							and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
							and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
							and user_log_acct not like"ept%"
							and free_goods_flag = 0
					)
					b
				on
					a.item_sku_id = b.item_sku_id
				left join
					(
						select
							lower(trim(unif_user_log_acct)) user_log_acct,
							lower(trim(user_acct_name)) pin
						from
							gdm.gdm_m01_userinfo_basic_da
						where
							dt = sysdate( - 1)
					) ----归一化用户pin
					d
				on
					b.user_log_acct = d.pin
				where
					b.ord_amount < 100000
					or
					(
						b.ord_amount >= 100000
						and coalesce(b.check_account_tm, '') <> ''
					)
			)
			x
		left join
			(
				select
					x.user_log_acct,
					x.fst_all_yn,
					dept_id_3,
					year(fst_ord_dt) year_dt,
					substr(fst_ord_dt, 6, 5) dt_dt
				from
					(
						select
							dept_id_3,
							lower(trim(unif_user_log_acct)) user_log_acct,
							max(case when fst_all_yn = '1' then 1 else 0 end) fst_all_yn,
							min(fst_ord_dt) fst_ord_dt
						from
							app.v_adm_s01_user_new_or_old_flag_detail_xfp
						where
							dt = sysdate( - 1)
							and tp = 'dept'
							and dept_id_2 in('47', '1699')
						group by
							dept_id_3,
							lower(trim(unif_user_log_acct))
					)
					x
				where
					(
						(
							fst_ord_dt >= '2019-05-21'
							and fst_ord_dt <= '2019-06-21'
						)
						or
						(
							fst_ord_dt >= '2020-05-21'
							and fst_ord_dt <= '2020-06-21'
						)
					)
			)
			y
		on
			x.user_log_acct = y.user_log_acct
			and x.year_dt = y.year_dt
			and x.dt_dt = y.dt_dt
			and x.dept_id_3 = y.dept_id_3
		left join
			(
				select user_log_acct from dev_xfp.spite_user_list_xfp
			)
			c
		on
			x.user_log_acct = c.user_log_acct
		where
			c.user_log_acct is null
		group by
			x.dept_id_3,
			x.dept_name_3,
			x.dt_dt
	)
	cc
on
	flow.dt_dt = cc.dt_dt
	and flow.dept_id_3 = cc.dept_id_3
	and flow.dept_name_3 = cc.dept_name_3
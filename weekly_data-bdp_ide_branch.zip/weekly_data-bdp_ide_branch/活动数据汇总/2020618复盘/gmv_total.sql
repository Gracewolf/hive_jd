select
	dt,
	data_type,
	sum(cw_gmv) gmv
from
	(
		select
			data_type,
			item_id,
			item_sku_id
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and dept_id_2 in('47', '1699')
	)
	a
join
	(
		select
			year(dt) dt,
			item_sku_id,
			sale_ord_id,
			cw_gmv
		from
			app.v_app_cmo_cw_ord_det_sum_rb
		where
			(
				(
					dt >= '2020-05-21'
					and dt <= '2020-06-21'
				)
				or
				(
					dt >= '2019-05-21'
					and dt <= '2019-06-21'
				)
			)
			and valid_flag = '1'
	)
	b
on
	a.item_sku_id = b.item_sku_id
group by
	dt,
	data_type;

select
	dt,
	data_type,
	sum(cw_gmv) gmv
from
	(
		select
			data_type,
			item_id,
			item_sku_id
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and dept_id_2 in('47', '1699')
	)
	a
join
	(
		select
			year(dt) dt,
			item_sku_id,
			sale_ord_id,
			cw_gmv
		from
			app.v_app_cmo_cw_ord_det_sum_rb
		where
			(
				(
					dt >= '2020-05-21'
					and dt <= '2020-06-21'
				)
				or
				(
					dt >= '2019-05-21'
					and dt <= '2019-06-21'
				)
			)
			and valid_flag = '1'
			and substr(ord_flag, 313, 1) in('1', '2')
	)
	b
on
	a.item_sku_id = b.item_sku_id
group by
	dt,
	data_type
set hive.exec.parallel = true;
select
	coalesce(t1.dt, t2.dt) 日期,
	organ_gmv,
	self_organ_gmv,
	pop_organ_gmv,
	src_gmv,
	self_src_gmv,
	pop_src_gmv,
	import_gmv,
	self_import_gmv,
	pop_import_gmv,
	organ_pv,
	self_organ_pv,
	pop_organ_pv,
	src_pv,
	self_src_pv,
	pop_src_pv,
	import_pv,
	self_import_pv,
	pop_import_pv,
	organ_uv,
	self_organ_uv,
	pop_organ_uv,
	src_uv,
	self_src_uv,
	pop_src_uv,
	import_uv,
	self_import_uv,
	pop_import_uv
from
	(
		select
			dt,
			sum(cw_gmv * organ_flag) organ_gmv,
			sum(case data_type when '1' then cw_gmv * organ_flag else 0.0 end) self_organ_gmv,
			sum(case data_type when '3' then cw_gmv * organ_flag else 0.0 end) pop_organ_gmv,
			sum(cw_gmv * src_flag) src_gmv,
			sum(case data_type when '1' then cw_gmv * src_flag else 0.0 end) self_src_gmv,
			sum(case data_type when '3' then cw_gmv * src_flag else 0.0 end) pop_src_gmv,
			sum(cw_gmv * import_flag) import_gmv,
			sum(case data_type when '1' then cw_gmv * import_flag else 0.0 end) self_import_gmv,
			sum(case data_type when '3' then cw_gmv * import_flag else 0.0 end) pop_import_gmv
		from
			(
				select
					item_sku_id,
					item_id,
					data_type,
					case when sku_name like'%有机%' then 1 else 0 end organ_flag,
					case when sku_name like'%原产地%' then 1 else 0 end src_flag,
					case when item_second_cate_cd = '5019' or dept_id_3 in('4044', '4046') then 1 else 0 end import_flag
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
			)
			a
		left join
			(
				select
					item_id
				from
					gdm.gdm_m03_item_spec_attr_da
				where
					dt = sysdate( - 1)
					and attr_name in('factoryShip')
					and attr_val in('1')
			)
			c
		on
			a.item_id = c.item_id
		join
			(
				select
					year(dt) dt,
					item_sku_id,
					sale_ord_id,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2020-05-21'
							and dt <= '2020-06-21'
						)
						or
						(
							dt >= '2019-05-21'
							and dt <= '2019-06-21'
						)
					)
					and valid_flag = '1'
					and
					(
						(
							tp = '1'
							and substr(ord_flag, 40, 1) <> '1'
						) ----自营剔分销
						or
						(
							tp = '2'
							and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
						) ----POP剔赠品
					)
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		where
			c.item_id is null
		group by
			dt
	)
	t1
full outer join
	(
		select
			dt,
			sum(sku_pv * organ_flag) organ_pv,
			sum(case data_type when '1' then sku_pv * organ_flag else 0.0 end) self_organ_pv,
			sum(case data_type when '3' then sku_pv * organ_flag else 0.0 end) pop_organ_pv,
			sum(sku_pv * src_flag) src_pv,
			sum(case data_type when '1' then sku_pv * src_flag else 0.0 end) self_src_pv,
			sum(case data_type when '3' then sku_pv * src_flag else 0.0 end) pop_src_pv,
			sum(sku_pv * import_flag) import_pv,
			sum(case data_type when '1' then sku_pv * import_flag else 0.0 end) self_import_pv,
			sum(case data_type when '3' then sku_pv * import_flag else 0.0 end) pop_import_pv,
			count(distinct case when organ_flag = 1 then browser_uniq_id end) organ_uv,
			count(distinct case when data_type = '1' and organ_flag = 1 then browser_uniq_id end) self_organ_uv,
			count(distinct case when data_type = '3' and organ_flag = 1 then browser_uniq_id end) pop_organ_uv,
			count(distinct case when src_flag = 1 then browser_uniq_id end) src_uv,
			count(distinct case when data_type = '1' and src_flag = 1 then browser_uniq_id end) self_src_uv,
			count(distinct case when data_type = '3' and src_flag = 1 then browser_uniq_id end) pop_src_uv,
			count(distinct case when import_flag = 1 then browser_uniq_id end) import_uv,
			count(distinct case when data_type = '1' and import_flag = 1 then browser_uniq_id end) self_import_uv,
			count(distinct case when data_type = '3' and import_flag = 1 then browser_uniq_id end) pop_import_uv
		from
			(
				select
					item_sku_id,
					item_id,
					data_type,
					case when sku_name like'%有机%' then 1 else 0 end organ_flag,
					case when sku_name like'%原产地%' then 1 else 0 end src_flag,
					case when item_second_cate_cd = '5019' or dept_id_3 in('4044', '4046') then 1 else 0 end import_flag
				from
					gdm.gdm_m03_mkt_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
			)
			a
		join
			(
				select
					year(dt) dt,
					sku_id,
					browser_uniq_id,
					sku_pv
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2020-05-21'
							and dt <= '2020-06-21'
						)
						or
						(
							dt >= '2019-05-21'
							and dt <= '2019-06-21'
						)
					)
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			dt
	)
	t2
on
	t1.dt = t2.dt
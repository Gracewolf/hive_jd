set hive.exec.parallel = true;
select
	coalesce(t1.device, t2.device) 端口,
	sum(case when coalesce(t1.year_dt, t2.year_dt) = '2020' then gmv else 0.0 end) 今年gmv,
	sum(case when coalesce(t1.year_dt, t2.year_dt) = '2020' then ord_num else 0 end) 今年ord_num,
	sum(case when coalesce(t1.year_dt, t2.year_dt) = '2020' then pv else 0 end) 今年pv,
	sum(case when coalesce(t1.year_dt, t2.year_dt) = '2020' then uv else 0 end) 今年uv,
	sum(case when coalesce(t1.year_dt, t2.year_dt) = '2019' then gmv else 0.0 end) 去年gmv,
	sum(case when coalesce(t1.year_dt, t2.year_dt) = '2019' then ord_num else 0 end) 去年ord_num,
	sum(case when coalesce(t1.year_dt, t2.year_dt) = '2019' then pv else 0 end) 去年pv,
	sum(case when coalesce(t1.year_dt, t2.year_dt) = '2019' then uv else 0 end) 去年uv
from
	(
		select
			year_dt,
			device,
			sum(cw_gmv) gmv,
			count(distinct sale_ord_id) ord_num
		from
			(
				select
					item_id,
					dept_id_2,
					dept_name_2,
					item_sku_id
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
			)
			a
		left join
			(
				select
					item_id
				from
					gdm.gdm_m03_item_spec_attr_da
				where
					dt = sysdate( - 1)
					and attr_name in('factoryShip')
					and attr_val in('1')
			)
			c
		on
			a.item_id = c.item_id
		join
			(
				select
					year(dt) year_dt,
					case
						when terminal_flag in('12', '22', '42', '62') then 'APP'
						when terminal_flag in('13', '23', '43', '63') then 'M端'
						when terminal_flag in('11', '21', '41', '61') then 'PC'
						when terminal_flag in('33', '31', '30') then '微信'
						when terminal_flag in('32') then '手Q'
						else '未知'
					end device,
					item_sku_id,
					sale_ord_id,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2020-05-21'
							and dt <= '2020-06-21'
						)
						or
						(
							dt >= '2019-05-21'
							and dt <= '2019-06-21'
						)
					)
					and valid_flag = '1'
					and
					(
						(
							tp = '1'
							and substr(ord_flag, 40, 1) <> '1'
						) ----自营剔分销
						or
						(
							tp = '2'
							and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
						) ----POP剔赠品
					)
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		where
			c.item_id is null
		group by
			year_dt,
			device
	)
	t1
full outer join
	(
		select
			year_dt,
			device,
			sum(sku_pv) pv,
			count(distinct browser_uniq_id) uv
		from
			(
				select
					item_id,
					dept_id_2,
					dept_name_2,
					item_sku_id
				from
					gdm.gdm_m03_mkt_item_sku_da
				where
					dt = sysdate( - 1)
					and dept_id_2 in('47', '1699')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end device,
					sku_id,
					browser_uniq_id,
					sku_pv
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2020-05-21'
							and dt <= '2020-06-21'
						)
						or
						(
							dt >= '2019-05-21'
							and dt <= '2019-06-21'
						)
					)
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			year_dt,
			device
	)
	t2
on
	t1.year_dt = t2.year_dt
	and t1.device = t2.device
group by
	coalesce(t1.device, t2.device)
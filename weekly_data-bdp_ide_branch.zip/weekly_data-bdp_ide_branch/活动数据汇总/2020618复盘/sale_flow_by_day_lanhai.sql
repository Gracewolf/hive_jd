set hive.exec.parallel = true;
select
	coalesce(t1.dt, t2.dt) dt,
	coalesce(t1.data_type, t2.data_type) data_type,
	sum(organ_gmv) organ_gmv,
	sum(src_gmv) src_gmv,
	sum(import_gmv) import_gmv,
	sum(organ_pv) organ_pv,
	sum(src_pv) src_pv,
	sum(import_pv) import_pv
from
	(
		select
			dt,
			data_type,
			sum(cw_gmv * organ_flag) organ_gmv,
			sum(cw_gmv * src_flag) src_gmv,
			sum(cw_gmv * import_flag) import_gmv
		from
			(
				select
					item_sku_id,
					item_id,
					data_type,
					case when sku_name like'%有机%' then 1 else 0 end organ_flag,
					case when sku_name like'%原产地%' then 1 else 0 end src_flag,
					case when item_second_cate_cd = '5019' or dept_id_3 in('4044', '4046') then 1 else 0 end import_flag
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
			)
			a
		left join
			(
				select
					item_id
				from
					gdm.gdm_m03_item_spec_attr_da
				where
					dt = sysdate( - 1)
					and attr_name in('factoryShip')
					and attr_val in('1')
			)
			c
		on
			a.item_id = c.item_id
		join
			(
				select
					dt,
					item_sku_id,
					sale_ord_id,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2020-05-21'
							and dt <= '2020-06-21'
						)
						or
						(
							dt >= '2019-05-21'
							and dt <= '2019-06-21'
						)
					)
					and valid_flag = '1'
					and
					(
						(
							tp = '1'
							and substr(ord_flag, 40, 1) <> '1'
						) ----自营剔分销
						or
						(
							tp = '2'
							and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
						) ----POP剔赠品
					)
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		where
			c.item_id is null
		group by
		    data_type,
			dt
	)
	t1
full outer join
	(
		select
			dt,
			data_type,
			sum(sku_pv * organ_flag) organ_pv,
			sum(sku_pv * src_flag) src_pv,
			sum(sku_pv * import_flag) import_pv
		from
			(
				select
					item_sku_id,
					data_type,
					case when sku_name like'%有机%' then 1 else 0 end organ_flag,
					case when sku_name like'%原产地%' then 1 else 0 end src_flag,
					case when item_second_cate_cd = '5019' or dept_id_3 in('4044', '4046') then 1 else 0 end import_flag
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
			)
			a
		join
			(
				select
					dt,
					sku_id,
					sku_pv
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2020-05-21'
							and dt <= '2020-06-21'
						)
						or
						(
							dt >= '2019-05-21'
							and dt <= '2019-06-21'
						)
					)
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
		    data_type,
			dt
	)
	t2
on
	t1.dt = t2.dt
	and t1.data_type = t2.data_type
group by
	coalesce(t1.dt, t2.dt),
	coalesce(t1.data_type, t2.data_type)
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;
  
set hive.exec.parallel = true;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
set hive.map.aggr = true;
set hive.groupby.mapaggr.checkinterval = 100000;
set hive.auto.convert.join = true;

----内部归一化
drop table if exists dev_dkx.mjt_jianguo_userpin_sale_already_huiliu;
create
  table dev_dkx.mjt_jianguo_userpin_sale_already_huiliu STORED AS ORC tblproperties
  (
    'orc.compress' = 'SNAPPY'
  ) as
select
	a.yyyy_mm month,
	sum(a.after_prefr_amount_1) GMV,
	count(distinct a.sale_ord_id) diangdan,
	count(distinct e.sale_ord_id) quandingdan, 
	count(distinct case when model = 'POP' then a.sale_ord_id end) POPdingdan,
	count(distinct case when model = '自营' then a.sale_ord_id end) ziyingdingdan,
	sum(b.pv) PV
from
	(
		select /*+ MAPJOIN(a)*/
			coalesce(d.unif_pin, b.pin) unif_pin,
			yyyy_mm,
			model,
			after_prefr_amount_1,
			sale_ord_id
		from
			(
				select
					item_sku_id,
					item_id,
					case data_type
				        when '1' then '自营'
				        when '3' then 'POP'
			        end model
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and item_first_cate_cd = '1320'
					and item_third_cate_cd in ('1591','1593')
			)
			a
		    join
			(
		    ----成交
				SELECT
                    item_sku_id,
                    lower(trim(user_log_acct)) pin,
                    substr(dt,1,7) yyyy_mm,
                    sale_ord_id,
                    parent_sale_ord_id,
                    after_prefr_amount_1,
                    sale_qtty
                FROM
                    app.v_adm_d04_trade_ord_det_sku_snapshot_xfp
                WHERE
                    (
                        (
                            dt >= '2020-03-01'
                            and dt <= '2021-02-28'
                        )  
                    )
                    AND intraday_ord_deal_flag = '1' ----成交标记
                    AND split_status_cd NOT IN('1') --排查拆单的父订单
                    AND valid_flag = '1' --有效状态
                    AND biz_flag_collect['int_pur_ord_flag'] <> 1 ----内采
                    AND biz_flag_collect['dist_ord_flag'] <> 1---分销
                    AND biz_flag_collect['corp_ord_flag'] <> 1-----企业订单
                    AND biz_flag_collect['xtl_ord_flag'] <> 1 ----新通路
                    AND virtual_ord_flag <> '1'---剔除虚拟订单
                    and biz_flag_collect['yhd_ord_flag'] <> 1 ----一号店
			)
			b
		    on
			    a.item_sku_id = b.item_sku_id
		    left join
			(
				select
					lower(trim(unif_user_log_acct)) unif_pin,
					lower(trim(user_acct_name)) pin
				from
					gdm.gdm_m01_userinfo_basic_da
				where
					dt = sysdate( - 1)
			) ----归一化用户pin
			d
		    on
			    b.pin = d.pin
		    group by
			    coalesce(d.unif_pin, b.pin),
				yyyy_mm,
			    model,
			    after_prefr_amount_1,
			    sale_ord_id
	)
	a
	join 
	(
	    select
            lower(trim(user_log_acct)) user_pin,
            sum(sku_pv) pv 
	    from
            adm.adm_s14_online_log_smart_item_d
        where
		(
		    dt >= '2020-03-01'
			and dt <= '2021-02-28'
		)
        group by 
            lower(trim(user_log_acct))
	)
    b
    on 
        a.unif_pin = b.user_pin	
	join 
    (
	    select 
		    a.user_pin
		from
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month3to8 group by user_pin
		)
        a
        join
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month1to2 group by user_pin
		)
        b
        on 
            a.user_pin = b.user_pin 
		left join
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month9to12 group by user_pin
		)
        c
        on 
            a.user_pin = c.user_pin 	
		where 
			c.user_pin is null
		group by
            a.user_pin		
	)
    d
    on
        a.unif_pin = b.user_pin
        and a.unif_pin = d.user_pin	
    join
    (
	    select
			lower(trim(user_log_acct_unif)) user_pin,
			substr(sale_ord_tm, 1, 7) yyyy_mm,
			batch_id,
			cps_name,
			cps_id,
			sale_ord_id,
			parent_sale_ord_id,
			sale_qtty,
			pay_amount,
			after_prefr_amount_1,
			sku_id
		from
			adm.adm_d07_cps_batch_ord_sku_det_sz
		where
			dt >= '2020-03-01'
			and dt <= '2021-02-28'
			and index_flag = '1'
	)
    e	
	on
	    a.unif_pin = e.user_pin
    left join
	(
		select
            lower(trim(unif_user_log_acct)) unif_pin,
            spite_user_flag
        from
            app.v_adm_s01_user_new_or_old_flag_detail_xfp
        where
            dt = sysdate(-2)
            and spite_user_flag = 1
        group by
            lower(trim(unif_user_log_acct)),
            spite_user_flag
	)
	c
    on
	    a.unif_pin = c.unif_pin
    where
	    c.unif_pin is null
	group BY
	    a.yyyy_mm;
"""
ht.exec_sql(
    schema_name = 'dev_dkx',
    sql=sql,
    table_name = 'mjt_jianguo_userpin_sale_already_huiliu',
    merge_flag = True)
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;
  
set hive.exec.parallel = true;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
set hive.map.aggr = true;
set hive.groupby.mapaggr.checkinterval = 100000;
set hive.auto.convert.join = true;

----内部归一化
drop table if exists dev_dkx.mjt_jianguo_userpin_huaxiang_already_huiliu;
create
  table dev_dkx.mjt_jianguo_userpin_huaxiang_already_huiliu STORED AS ORC tblproperties
  (
    'orc.compress' = 'SNAPPY'
  ) as
select
    '用户数' 备注,
	'全部用户' 指标,
	count(distinct (tt.unif_pin)) 用户数
from
(
    select
	    xx.unif_pin    
	from
    (	
	    select /*+ MAPJOIN(a)*/
		    coalesce(d.unif_pin, b.pin) unif_pin				
	    from
		    (
				                select
					                item_sku_id,
					                item_id
				                from
					                gdm.gdm_m03_sold_item_sku_da
				                where
					                dt = sysdate( - 1)
					                and data_type in('1', '3')
					                and item_first_cate_cd = '1320'
					                and item_third_cate_cd in ('1591','1593')
		    )
		    a
		    join
		    (
		    ----成交
				                SELECT
                                    item_sku_id,
                                    lower(trim(user_log_acct)) pin,
									user_log_acct,
                                    year(dt) year_dt,
                                    sale_ord_id,
									sale_ord_tm,
									rev_addr_city_id,
                                    parent_sale_ord_id,
                                    after_prefr_amount_1,
                                    sale_qtty
                                FROM
                                    app.v_adm_d04_trade_ord_det_sku_snapshot_xfp
                                WHERE
                                    (
                                        (
                                            dt >= '2020-03-01'
                                            and dt <= '2020-08-31'
                                        )  
                                    )
                                    AND intraday_ord_deal_flag = '1' ----成交标记
                                    AND split_status_cd NOT IN('1') --排查拆单的父订单
                                    AND valid_flag = '1' --有效状态
                                    AND biz_flag_collect['int_pur_ord_flag'] <> 1 ----内采
                                    AND biz_flag_collect['dist_ord_flag'] <> 1---分销
                                    AND biz_flag_collect['corp_ord_flag'] <> 1-----企业订单
                                    AND biz_flag_collect['xtl_ord_flag'] <> 1 ----新通路
                                    AND virtual_ord_flag <> '1'---剔除虚拟订单
                                    and biz_flag_collect['yhd_ord_flag'] <> 1 ----一号店
			)
			b
		                    on
			                    a.item_sku_id = b.item_sku_id
		    left join
			(
				                select
					                lower(trim(unif_user_log_acct)) unif_pin,
					                lower(trim(user_acct_name)) pin
				                from
					                gdm.gdm_m01_userinfo_basic_da
				                where
					                dt = sysdate( - 1)
			) ----归一化用户pin
			                d
		                    on
			                    b.pin = d.pin
	)
	xx
	join
	(
	     select 
		    a.user_pin
		from
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month3to8 group by user_pin
		)
        a
        join
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month1to2 group by user_pin
		)
        b
        on 
            a.user_pin = b.user_pin 
		left join
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month9to12 group by user_pin
		)
        c
        on 
            a.user_pin = c.user_pin 	
		where 
			c.user_pin is null
		group by
            a.user_pin			
	)
	yy
    on 
        xx.unif_pin = yy.user_pin
    group by
        xx.unif_pin	
)
tt

union all

select 
    '性别' 备注,
	cpp_base_sex 指标,
	count(distinct(tt.unif_pin)) 用户数
from 
(	
    select
		case cpp_base_sex
		    when '-1' then '未知'
		    else cpp_base_sex
	    end cpp_base_sex,
		hh.unif_pin
    from
	    (
            select
	            xx.unif_pin    
	        from
            (	
	             select /*+ MAPJOIN(a)*/
		             coalesce(d.unif_pin, b.pin) unif_pin				
	            from
		            (
				                select
					                item_sku_id,
					                item_id
				                from
					                gdm.gdm_m03_sold_item_sku_da
				                where
					                dt = sysdate( - 1)
					                and data_type in('1', '3')
					                and item_first_cate_cd = '1320'
					                and item_third_cate_cd in ('1591','1593')
		            )
		            a
		           join
		           (
		             ----成交
				                SELECT
                                    item_sku_id,
                                    lower(trim(user_log_acct)) pin,
									user_log_acct,
                                    year(dt) year_dt,
                                    sale_ord_id,
									sale_ord_tm,
									rev_addr_city_id,
                                    parent_sale_ord_id,
                                    after_prefr_amount_1,
                                    sale_qtty
                                FROM
                                    app.v_adm_d04_trade_ord_det_sku_snapshot_xfp
                                WHERE
                                    (
                                        (
                                            dt >= '2020-03-01'
                                            and dt <= '2020-08-31'
                                        )  
                                    )
                                    AND intraday_ord_deal_flag = '1' ----成交标记
                                    AND split_status_cd NOT IN('1') --排查拆单的父订单
                                    AND valid_flag = '1' --有效状态
                                    AND biz_flag_collect['int_pur_ord_flag'] <> 1 ----内采
                                    AND biz_flag_collect['dist_ord_flag'] <> 1---分销
                                    AND biz_flag_collect['corp_ord_flag'] <> 1-----企业订单
                                    AND biz_flag_collect['xtl_ord_flag'] <> 1 ----新通路
                                    AND virtual_ord_flag <> '1'---剔除虚拟订单
                                    and biz_flag_collect['yhd_ord_flag'] <> 1 ----一号店
			        )
			        b
		                    on
			                    a.item_sku_id = b.item_sku_id
		            left join
			        (
				                select
					                lower(trim(unif_user_log_acct)) unif_pin,
					                lower(trim(user_acct_name)) pin
				                from
					                gdm.gdm_m01_userinfo_basic_da
				                where
					                dt = sysdate( - 1)
			        ) ----归一化用户pin
			        d
		                    on
			                    b.pin = d.pin
	        )
	        xx
	        join
	        (
	             select 
		    a.user_pin
		from
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month3to8 group by user_pin
		)
        a
        join
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month1to2 group by user_pin
		)
        b
        on 
            a.user_pin = b.user_pin 
		left join
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month9to12 group by user_pin
		)
        c
        on 
            a.user_pin = c.user_pin 	
		where 
			c.user_pin is null
		group by
            a.user_pin				
	        )
	        yy
            on 
                 xx.unif_pin = yy.user_pin
             group by
                xx.unif_pin	
        )
        hh
        join
	        (
		        select
			        lower(trim(user_log_acct)) user_log_acct,
			        cpp_base_sex,
			        cpp_base_age,
			        cpp_base_ulevel,
			        cpp_base_profession1,
			        cpp_addr_city,
			        cgp_action_active_type,
			        cvl_glob_loyalty,
			        cfv_sens_promotion,
			        cfv_sens_comment
		        from
			        adm.adm_l01_nonpolar_view_da_ori
		        where
			        dt = sysdate(-2)
	        )
	        mm
            on
	            hh.unif_pin = mm.user_log_acct
        left join
	        (
		        select dim_city_name, dim_city_jxkh_level from dim.dim_cmo_user_jxkh_county_new group by dim_city_jxkh_level, dim_city_name
	        )
	        nn
            on
	            mm.cpp_addr_city = nn.dim_city_name
		group by
            case cpp_base_sex
		        when '-1' then '未知'
		        else cpp_base_sex
	        end,
		    hh.unif_pin		
)
tt
group by	
	cpp_base_sex	
	
union all

select 
    '年龄' 备注,
	cpp_base_age 指标,
	count(distinct(tt.unif_pin)) 用户数
from 
(	
    select
		case cpp_base_age
		    when '-1' then '未知'
		    else cpp_base_age
	    end cpp_base_age,
		hh.unif_pin
    from
	    (
            select
	            xx.unif_pin    
	        from
            (	
	             select /*+ MAPJOIN(a)*/
		             coalesce(d.unif_pin, b.pin) unif_pin				
	            from
		            (
				                select
					                item_sku_id,
					                item_id
				                from
					                gdm.gdm_m03_sold_item_sku_da
				                where
					                dt = sysdate( - 1)
					                and data_type in('1', '3')
					                and item_first_cate_cd = '1320'
					                and item_third_cate_cd in ('1591','1593')
		            )
		            a
		           join
		           (
		             ----成交
				                SELECT
                                    item_sku_id,
                                    lower(trim(user_log_acct)) pin,
									user_log_acct,
                                    year(dt) year_dt,
                                    sale_ord_id,
									sale_ord_tm,
									rev_addr_city_id,
                                    parent_sale_ord_id,
                                    after_prefr_amount_1,
                                    sale_qtty
                                FROM
                                    app.v_adm_d04_trade_ord_det_sku_snapshot_xfp
                                WHERE
                                    (
                                        (
                                            dt >= '2020-03-01'
                                            and dt <= '2020-08-31'
                                        )  
                                    )
                                    AND intraday_ord_deal_flag = '1' ----成交标记
                                    AND split_status_cd NOT IN('1') --排查拆单的父订单
                                    AND valid_flag = '1' --有效状态
                                    AND biz_flag_collect['int_pur_ord_flag'] <> 1 ----内采
                                    AND biz_flag_collect['dist_ord_flag'] <> 1---分销
                                    AND biz_flag_collect['corp_ord_flag'] <> 1-----企业订单
                                    AND biz_flag_collect['xtl_ord_flag'] <> 1 ----新通路
                                    AND virtual_ord_flag <> '1'---剔除虚拟订单
                                    and biz_flag_collect['yhd_ord_flag'] <> 1 ----一号店
			        )
			        b
		                    on
			                    a.item_sku_id = b.item_sku_id
		            left join
			        (
				                select
					                lower(trim(unif_user_log_acct)) unif_pin,
					                lower(trim(user_acct_name)) pin
				                from
					                gdm.gdm_m01_userinfo_basic_da
				                where
					                dt = sysdate( - 1)
			        ) ----归一化用户pin
			        d
		                    on
			                    b.pin = d.pin
	        )
	        xx
	        join
	        (
	             select 
		    a.user_pin
		from
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month3to8 group by user_pin
		)
        a
        join
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month1to2 group by user_pin
		)
        b
        on 
            a.user_pin = b.user_pin 
		left join
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month9to12 group by user_pin
		)
        c
        on 
            a.user_pin = c.user_pin 	
		where 
			c.user_pin is null
		group by
            a.user_pin				
	        )
	        yy
            on 
                 xx.unif_pin = yy.user_pin
             group by
                xx.unif_pin	
        )
        hh
        join
	        (
		        select
			        lower(trim(user_log_acct)) user_log_acct,
			        cpp_base_sex,
			        cpp_base_age,
			        cpp_base_ulevel,
			        cpp_base_profession1,
			        cpp_addr_city,
			        cgp_action_active_type,
			        cvl_glob_loyalty,
			        cfv_sens_promotion,
			        cfv_sens_comment
		        from
			        adm.adm_l01_nonpolar_view_da_ori
		        where
			        dt = sysdate(-2)
	        )
	        mm
            on
	            hh.unif_pin = mm.user_log_acct
        left join
	        (
		        select dim_city_name, dim_city_jxkh_level from dim.dim_cmo_user_jxkh_county_new group by dim_city_jxkh_level, dim_city_name
	        )
	        nn
            on
	            mm.cpp_addr_city = nn.dim_city_name
		group by
            case cpp_base_age
		        when '-1' then '未知'
		        else cpp_base_age
	        end,
		    hh.unif_pin		
)
tt
group by	
	cpp_base_age	
	
union all

select 
    '区域' 备注,
	cpp_base_quyu 指标,
	count(distinct(tt.unif_pin)) 用户数
from 
(	
    select
		coalesce(nn.dim_region, '未知') cpp_base_quyu,
		hh.unif_pin
    from
	    (
            select
	            xx.unif_pin,
                xx.rev_addr_city_id 				
	        from
            (	
	             select /*+ MAPJOIN(a)*/
		             coalesce(d.unif_pin, b.pin) unif_pin,
					 rev_addr_city_id
	            from
		            (
				                select
					                item_sku_id,
					                item_id
				                from
					                gdm.gdm_m03_sold_item_sku_da
				                where
					                dt = sysdate( - 1)
					                and data_type in('1', '3')
					                and item_first_cate_cd = '1320'
					                and item_third_cate_cd in ('1591','1593')
		            )
		            a
		           join
		           (
		             ----成交
				                SELECT
                                    item_sku_id,
                                    lower(trim(user_log_acct)) pin,
									user_log_acct,
                                    year(dt) year_dt,
                                    sale_ord_id,
									sale_ord_tm,
									rev_addr_city_id,
                                    parent_sale_ord_id,
                                    after_prefr_amount_1,
                                    sale_qtty
                                FROM
                                    app.v_adm_d04_trade_ord_det_sku_snapshot_xfp
                                WHERE
                                    (
                                        (
                                            dt >= '2020-03-01'
                                            and dt <= '2020-08-31'
                                        )  
                                    )
                                    AND intraday_ord_deal_flag = '1' ----成交标记
                                    AND split_status_cd NOT IN('1') --排查拆单的父订单
                                    AND valid_flag = '1' --有效状态
                                    AND biz_flag_collect['int_pur_ord_flag'] <> 1 ----内采
                                    AND biz_flag_collect['dist_ord_flag'] <> 1---分销
                                    AND biz_flag_collect['corp_ord_flag'] <> 1-----企业订单
                                    AND biz_flag_collect['xtl_ord_flag'] <> 1 ----新通路
                                    AND virtual_ord_flag <> '1'---剔除虚拟订单
                                    and biz_flag_collect['yhd_ord_flag'] <> 1 ----一号店
			        )
			        b
		                    on
			                    a.item_sku_id = b.item_sku_id
		            left join
			        (
				                select
					                lower(trim(unif_user_log_acct)) unif_pin,
					                lower(trim(user_acct_name)) pin
				                from
					                gdm.gdm_m01_userinfo_basic_da
				                where
					                dt = sysdate( - 1)
			        ) ----归一化用户pin
			        d
		                    on
			                    b.pin = d.pin
	        )
	        xx
	        join
	        (
	             select 
		    a.user_pin
		from
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month3to8 group by user_pin
		)
        a
        join
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month1to2 group by user_pin
		)
        b
        on 
            a.user_pin = b.user_pin 
		left join
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month9to12 group by user_pin
		)
        c
        on 
            a.user_pin = c.user_pin 	
		where 
			c.user_pin is null
		group by
            a.user_pin			
	        )
	        yy
            on 
                 xx.unif_pin = yy.user_pin
             group by
                xx.unif_pin,
				xx.rev_addr_city_id
        )
        hh
       left join
	        (
		        select dim_city_id, dim_city_jxkh_level, dim_province_name,dim_region from dim.dim_cmo_user_jxkh_county_new group by dim_city_id, dim_city_jxkh_level, dim_province_name,dim_region	
	        )
	        nn
            on
	            hh.rev_addr_city_id = nn.dim_city_id	
		group by
            coalesce(nn.dim_region, '未知'),
		    hh.unif_pin		
)
tt
group by	
	cpp_base_quyu		
	
union all

select 
    '城市等级' 备注,
	cpp_base_citylevel 指标,
	count(distinct(tt.unif_pin)) 用户数
from 
(	
    select
		coalesce(nn.dim_city_jxkh_level, '未知')  cpp_base_citylevel,
		hh.unif_pin
    from
	    (
            select
	            xx.unif_pin,
                xx.rev_addr_city_id 				
	        from
            (	
	             select /*+ MAPJOIN(a)*/
		             coalesce(d.unif_pin, b.pin) unif_pin,
					 rev_addr_city_id
	            from
		            (
				                select
					                item_sku_id,
					                item_id
				                from
					                gdm.gdm_m03_sold_item_sku_da
				                where
					                dt = sysdate( - 1)
					                and data_type in('1', '3')
					                and item_first_cate_cd = '1320'
					                and item_third_cate_cd in ('1591','1593')
		            )
		            a
		           join
		           (
		             ----成交
				                SELECT
                                    item_sku_id,
                                    lower(trim(user_log_acct)) pin,
									user_log_acct,
                                    year(dt) year_dt,
                                    sale_ord_id,
									sale_ord_tm,
									rev_addr_city_id,
                                    parent_sale_ord_id,
                                    after_prefr_amount_1,
                                    sale_qtty
                                FROM
                                    app.v_adm_d04_trade_ord_det_sku_snapshot_xfp
                                WHERE
                                    (
                                        (
                                            dt >= '2020-03-01'
                                            and dt <= '2020-08-31'
                                        )  
                                    )
                                    AND intraday_ord_deal_flag = '1' ----成交标记
                                    AND split_status_cd NOT IN('1') --排查拆单的父订单
                                    AND valid_flag = '1' --有效状态
                                    AND biz_flag_collect['int_pur_ord_flag'] <> 1 ----内采
                                    AND biz_flag_collect['dist_ord_flag'] <> 1---分销
                                    AND biz_flag_collect['corp_ord_flag'] <> 1-----企业订单
                                    AND biz_flag_collect['xtl_ord_flag'] <> 1 ----新通路
                                    AND virtual_ord_flag <> '1'---剔除虚拟订单
                                    and biz_flag_collect['yhd_ord_flag'] <> 1 ----一号店
			        )
			        b
		                    on
			                    a.item_sku_id = b.item_sku_id
		            left join
			        (
				                select
					                lower(trim(unif_user_log_acct)) unif_pin,
					                lower(trim(user_acct_name)) pin
				                from
					                gdm.gdm_m01_userinfo_basic_da
				                where
					                dt = sysdate( - 1)
			        ) ----归一化用户pin
			        d
		                    on
			                    b.pin = d.pin
	        )
	        xx
	        join
	        (
	             select 
		    a.user_pin
		from
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month3to8 group by user_pin
		)
        a
        join
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month1to2 group by user_pin
		)
        b
        on 
            a.user_pin = b.user_pin 
		left join
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month9to12 group by user_pin
		)
        c
        on 
            a.user_pin = c.user_pin 	
		where 
			c.user_pin is null
		group by
            a.user_pin			
	        )
	        yy
            on 
                 xx.unif_pin = yy.user_pin
             group by
                xx.unif_pin,
				xx.rev_addr_city_id
        )
        hh
       left join
	        (
		        select dim_city_id, dim_city_jxkh_level, dim_province_name,dim_region from dim.dim_cmo_user_jxkh_county_new group by dim_city_id, dim_city_jxkh_level, dim_province_name,dim_region	
	        )
	        nn
            on
	            hh.rev_addr_city_id = nn.dim_city_id	
		group by
            coalesce(nn.dim_city_jxkh_level, '未知'),
		    hh.unif_pin		
)
tt
group by	
	cpp_base_citylevel

union all

select 
    '京享值' 备注,
	cpp_base_total_score 指标,
	count(distinct(tt.unif_pin)) 用户数
from 
(	
    select
		case 
		    when total_score <= 2300 then '0至2300'
		    when total_score > 2300 and total_score <= 4600  then '2301至4600'
			when total_score > 4600 and total_score <= 6900  then '4601至6900'
			when total_score > 6900 and total_score <= 9200  then '6901至9200'
			when total_score > 9200 then '9201及以上'
		    else null
	    end cpp_base_total_score,
		hh.unif_pin
    from
	    (
            select
	            xx.unif_pin				
	        from
            (	
	             select /*+ MAPJOIN(a)*/
		             coalesce(d.unif_pin, b.pin) unif_pin
	            from
		            (
				                select
					                item_sku_id,
					                item_id
				                from
					                gdm.gdm_m03_sold_item_sku_da
				                where
					                dt = sysdate( - 1)
					                and data_type in('1', '3')
					                and item_first_cate_cd = '1320'
					                and item_third_cate_cd in ('1591','1593')
		            )
		            a
		           join
		           (
		             ----成交
				                SELECT
                                    item_sku_id,
                                    lower(trim(user_log_acct)) pin,
									user_log_acct,
                                    year(dt) year_dt,
                                    sale_ord_id,
									sale_ord_tm,
									rev_addr_city_id,
                                    parent_sale_ord_id,
                                    after_prefr_amount_1,
                                    sale_qtty
                                FROM
                                    app.v_adm_d04_trade_ord_det_sku_snapshot_xfp
                                WHERE
                                    (
                                        (
                                            dt >= '2020-03-01'
                                            and dt <= '2020-08-31'
                                        )  
                                    )
                                    AND intraday_ord_deal_flag = '1' ----成交标记
                                    AND split_status_cd NOT IN('1') --排查拆单的父订单
                                    AND valid_flag = '1' --有效状态
                                    AND biz_flag_collect['int_pur_ord_flag'] <> 1 ----内采
                                    AND biz_flag_collect['dist_ord_flag'] <> 1---分销
                                    AND biz_flag_collect['corp_ord_flag'] <> 1-----企业订单
                                    AND biz_flag_collect['xtl_ord_flag'] <> 1 ----新通路
                                    AND virtual_ord_flag <> '1'---剔除虚拟订单
                                    and biz_flag_collect['yhd_ord_flag'] <> 1 ----一号店
			        )
			        b
		                    on
			                    a.item_sku_id = b.item_sku_id
		            left join
			        (
				                select
					                lower(trim(unif_user_log_acct)) unif_pin,
					                lower(trim(user_acct_name)) pin
				                from
					                gdm.gdm_m01_userinfo_basic_da
				                where
					                dt = sysdate( - 1)
			        ) ----归一化用户pin
			        d
		                    on
			                    b.pin = d.pin
	        )
	        xx
	        join
	        (
	             select 
		    a.user_pin
		from
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month3to8 group by user_pin
		)
        a
        join
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month1to2 group by user_pin
		)
        b
        on 
            a.user_pin = b.user_pin 
		left join
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month9to12 group by user_pin
		)
        c
        on 
            a.user_pin = c.user_pin 	
		where 
			c.user_pin is null
		group by
            a.user_pin		
	        )
	        yy
            on 
                 xx.unif_pin = yy.user_pin
             group by
                xx.unif_pin
        )
        hh
       left join
        (
							    select 
								    lower(trim(jd_pin)) pin,
                                    sum(total_score) total_score
                                from 
                                    app.app_cmo_dmt_jdmem_user_score_da
                                where 
                                    dt = sysdate(-1)
								group by
                                    lower(trim(jd_pin))							
		)
	    nn
        on
	        hh.unif_pin = nn.pin	
		group by
            case 
		    when total_score <= 2300 then '0至2300'
		    when total_score > 2300 and total_score <= 4600  then '2301至4600'
			when total_score > 4600 and total_score <= 6900  then '4601至6900'
			when total_score > 6900 and total_score <= 9200  then '6901至9200'
			when total_score > 9200 then '9201及以上'
		    else null
	        end,
		    hh.unif_pin		
)
tt
group by	
	cpp_base_total_score
	
union all

select 
    '京享值' 备注,
	plusornot 指标,
	count(distinct(zz.unif_pin)) 用户数
from 
(	
    select
		CASE
			when identity_cnt >= 1 then 'plus'
			ELSE 'noplus'
		end as plusornot,
		tt.unif_pin
	from
    (	
	select
        hh.unif_pin,
		sum(
			CASE
				WHEN hh.sale_ord_tm >= nn.begin_date AND hh.sale_ord_tm <= nn.end_real_date THEN 1 ELSE 0
			end
		) AS identity_cnt
    from
	    (
            select
	            xx.unif_pin,
                xx.sale_ord_tm				
	        from
            (	
	             select /*+ MAPJOIN(a)*/
		             coalesce(d.unif_pin, b.pin) unif_pin,
					 sale_ord_tm
	            from
		            (
				                select
					                item_sku_id,
					                item_id
				                from
					                gdm.gdm_m03_sold_item_sku_da
				                where
					                dt = sysdate( - 1)
					                and data_type in('1', '3')
					                and item_first_cate_cd = '1320'
					                and item_third_cate_cd in ('1591','1593')
		            )
		            a
		           join
		           (
		             ----成交
				                SELECT
                                    item_sku_id,
                                    lower(trim(user_log_acct)) pin,
									user_log_acct,
                                    year(dt) year_dt,
                                    sale_ord_id,
									sale_ord_tm,
									rev_addr_city_id,
                                    parent_sale_ord_id,
                                    after_prefr_amount_1,
                                    sale_qtty
                                FROM
                                    app.v_adm_d04_trade_ord_det_sku_snapshot_xfp
                                WHERE
                                    (
                                        (
                                            dt >= '2020-03-01'
                                            and dt <= '2020-08-31'
                                        )  
                                    )
                                    AND intraday_ord_deal_flag = '1' ----成交标记
                                    AND split_status_cd NOT IN('1') --排查拆单的父订单
                                    AND valid_flag = '1' --有效状态
                                    AND biz_flag_collect['int_pur_ord_flag'] <> 1 ----内采
                                    AND biz_flag_collect['dist_ord_flag'] <> 1---分销
                                    AND biz_flag_collect['corp_ord_flag'] <> 1-----企业订单
                                    AND biz_flag_collect['xtl_ord_flag'] <> 1 ----新通路
                                    AND virtual_ord_flag <> '1'---剔除虚拟订单
                                    and biz_flag_collect['yhd_ord_flag'] <> 1 ----一号店
			        )
			        b
		                    on
			                    a.item_sku_id = b.item_sku_id
		            left join
			        (
				                select
					                lower(trim(unif_user_log_acct)) unif_pin,
					                lower(trim(user_acct_name)) pin
				                from
					                gdm.gdm_m01_userinfo_basic_da
				                where
					                dt = sysdate( - 1)
			        ) ----归一化用户pin
			        d
		                    on
			                    b.pin = d.pin
	        )
	        xx
	        join
	        (
	             select 
		    a.user_pin
		from
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month3to8 group by user_pin
		)
        a
        join
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month1to2 group by user_pin
		)
        b
        on 
            a.user_pin = b.user_pin 
		left join
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month9to12 group by user_pin
		)
        c
        on 
            a.user_pin = c.user_pin 	
		where 
			c.user_pin is null
		group by
            a.user_pin			
	        )
	        yy
            on 
                 xx.unif_pin = yy.user_pin
             group by
                xx.unif_pin,
				xx.sale_ord_tm
        )
        hh
       left join
        (
						        SELECT
							        lower(trim(pin)) as pin,
							        begin_date,
							        end_real_date
						        FROM
							        fdm.fdm_plus_n_plus_pins_stage__chain
						        WHERE
							        dp = 'ACTIVE'
							        AND 
                                    (
								        stage IN(4000)
								        or sku_no = '100012971100'
							        )
							        AND flag <> '-1'
						        GROUP BY
							        lower(trim(pin)),
							        begin_date,
							        end_real_date
		)
	    nn
        on
	        hh.unif_pin = nn.pin	
		group by
		    hh.unif_pin		
)
tt
group by	
	CASE
		when identity_cnt >= 1 then 'plus'
		ELSE 'noplus'
	end,
	tt.unif_pin
)
zz
   group by
        plusornot 

union all

select 
    '京享值' 备注,
	time_chazhi 指标,
	count(distinct(ww.unif_pin)) 用户数
from
(
   select
        tt.unif_pin,
        case 
		    when chazhi <= 1080 then '0至1080'
		    when chazhi > 1081 and chazhi <= 2160  then '1081至2160'
			when chazhi > 2161 and chazhi <= 3240  then '2161至3240'
			when chazhi > 3241 and chazhi <= 4320  then '3241至4320'
			when chazhi > 4321 then '4321及以上'
		    else null
	    end time_chazhi	
from 
(	
    select
    y.unif_pin,
	last_orderid_tm,
	reg_time,
	datediff(last_orderid_tm,reg_time) chazhi
from
(
select
    unif_pin,
	last_orderid_tm,
	rank1
from
    (	
select
    unif_pin,
	substr(sale_ord_tm,1,10) last_orderid_tm,
    row_number() over(partition BY unif_pin order by sale_ord_tm DESC, parent_sale_ord_id DESC) rank1
from
    (	
						
						select
	            xx.unif_pin,
                xx.sale_ord_tm,
                xx.parent_sale_ord_id
	        from
            (	
	             select /*+ MAPJOIN(a)*/
		             coalesce(d.unif_pin, b.pin) unif_pin,
					 sale_ord_tm,
					 parent_sale_ord_id
	            from
		            (
				                select
					                item_sku_id,
					                item_id
				                from
					                gdm.gdm_m03_sold_item_sku_da
				                where
					                dt = sysdate( - 1)
					                and data_type in('1', '3')
					                and item_first_cate_cd = '1320'
					                and item_third_cate_cd in ('1591','1593')
		            )
		            a
		           join
		           (
		             ----成交
				                SELECT
                                    item_sku_id,
                                    lower(trim(user_log_acct)) pin,
									user_log_acct,
                                    year(dt) year_dt,
                                    sale_ord_id,
									sale_ord_tm,
									rev_addr_city_id,
                                    parent_sale_ord_id,
                                    after_prefr_amount_1,
                                    sale_qtty
                                FROM
                                    app.v_adm_d04_trade_ord_det_sku_snapshot_xfp
                                WHERE
                                    (
                                        (
                                            dt >= '2020-03-01'
                                            and dt <= '2020-08-31'
                                        )  
                                    )
                                    AND intraday_ord_deal_flag = '1' ----成交标记
                                    AND split_status_cd NOT IN('1') --排查拆单的父订单
                                    AND valid_flag = '1' --有效状态
                                    AND biz_flag_collect['int_pur_ord_flag'] <> 1 ----内采
                                    AND biz_flag_collect['dist_ord_flag'] <> 1---分销
                                    AND biz_flag_collect['corp_ord_flag'] <> 1-----企业订单
                                    AND biz_flag_collect['xtl_ord_flag'] <> 1 ----新通路
                                    AND virtual_ord_flag <> '1'---剔除虚拟订单
                                    and biz_flag_collect['yhd_ord_flag'] <> 1 ----一号店
			        )
			        b
		                    on
			                    a.item_sku_id = b.item_sku_id
		            left join
			        (
				                select
					                lower(trim(unif_user_log_acct)) unif_pin,
					                lower(trim(user_acct_name)) pin
				                from
					                gdm.gdm_m01_userinfo_basic_da
				                where
					                dt = sysdate( - 1)
			        ) ----归一化用户pin
			        d
		                    on
			                    b.pin = d.pin
	        )
	        xx
	        join
	        (
	             select 
		    a.user_pin
		from
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month3to8 group by user_pin
		)
        a
        join
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month1to2 group by user_pin
		)
        b
        on 
            a.user_pin = b.user_pin 
		left join
        (
		    select user_pin from dev_dkx.mjt_jianguo_userpin_month9to12 group by user_pin
		)
        c
        on 
            a.user_pin = c.user_pin 	
		where 
			c.user_pin is null
		group by
            a.user_pin			
	        )
	        yy
            on 
                 xx.unif_pin = yy.user_pin
             group by
                xx.unif_pin,
				xx.sale_ord_tm,
				xx.parent_sale_ord_id
	)
    n
)
m
where 
    rank1 = 1
)
y
left join
(
 select
					                lower(trim(unif_user_log_acct)) unif_pin,
					                lower(trim(user_acct_name)) pin,
									substr(reg_tm,1,10) reg_time
				                from
					                gdm.gdm_m01_userinfo_basic_da
				                where
					                dt = sysdate( - 1)
)
z
on 
y.unif_pin = z.unif_pin 
group by
    y.unif_pin,
	last_orderid_tm,
	reg_time
)
tt
group by	
	    tt.unif_pin,
        case 
		    when chazhi <= 1080 then '0至1080'
		    when chazhi > 1081 and chazhi <= 2160  then '1081至2160'
			when chazhi > 2161 and chazhi <= 3240  then '2161至3240'
			when chazhi > 3241 and chazhi <= 4320  then '3241至4320'
			when chazhi > 4321 then '4321及以上'
		    else null
	    end			
)
ww
group by
    time_chazhi;
"""
ht.exec_sql(
    schema_name = 'dev_dkx',
    sql=sql,
    table_name = 'mjt_jianguo_userpin_huaxiang_already_huiliu',
    merge_flag = True)
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;
  
set hive.exec.parallel = true;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
set hive.map.aggr = true;
set hive.groupby.mapaggr.checkinterval = 100000;
set hive.auto.convert.join = true;

----内部归一化
drop table if exists dev_dkx.mjt_jianguo_userpin_fenbu_test_time;
create
  table dev_dkx.mjt_jianguo_userpin_fenbu_test_time STORED AS ORC tblproperties
  (
    'orc.compress' = 'SNAPPY'
  ) as
select
    y.unif_pin,
	last_orderid_tm,
	reg_tm,
	last_orderid_tm - reg_tm chazhi
from
(
select
    unif_pin,
	last_orderid_tm,
	last_orderid,
	rank1
from
    (	
select
    unif_pin,
	sale_ord_tm last_orderid_tm,
	parent_sale_ord_id last_orderid,
    row_number() over(partition BY user_log_acct order by sale_ord_tm DESC, parent_sale_ord_id DESC) rank1
from
    (	
						
						select /*+ MAPJOIN(a)*/
			                coalesce(d.unif_pin, b.pin) unif_pin,
			                user_log_acct,
			                sale_ord_tm,
					        parent_sale_ord_id					
		                from
			                (
				                select
					                item_sku_id,
					                item_id
				                from
					                gdm.gdm_m03_sold_item_sku_da
				                where
					                dt = sysdate( - 1)
					                and data_type in('1', '3')
					                and item_first_cate_cd = '1320'
					                and item_third_cate_cd in ('1591','1593')
			                )
			                a
		                    join
			                (
		                        ----成交
				                SELECT
                                    item_sku_id,
                                    lower(trim(user_log_acct)) pin,
									user_log_acct,
                                    year(dt) year_dt,
                                    sale_ord_id,
									sale_ord_tm,
									rev_addr_city_id,
                                    parent_sale_ord_id,
                                    after_prefr_amount_1,
                                    sale_qtty
                                FROM
                                    app.v_adm_d04_trade_ord_det_sku_snapshot_xfp
                                WHERE
                                    (
                                        (
                                            dt >= '2020-03-01'
                                            and dt <= '2021-02-28'
                                        )  
                                    )
                                    AND intraday_ord_deal_flag = '1' ----成交标记
                                    AND split_status_cd NOT IN('1') --排查拆单的父订单
                                    AND valid_flag = '1' --有效状态
                                    AND biz_flag_collect['int_pur_ord_flag'] <> 1 ----内采
                                    AND biz_flag_collect['dist_ord_flag'] <> 1---分销
                                    AND biz_flag_collect['corp_ord_flag'] <> 1-----企业订单
                                    AND biz_flag_collect['xtl_ord_flag'] <> 1 ----新通路
                                    AND virtual_ord_flag <> '1'---剔除虚拟订单
                                    and biz_flag_collect['yhd_ord_flag'] <> 1 ----一号店
			                )
			                b
		                    on
			                    a.item_sku_id = b.item_sku_id
		                    left join
			                (
				                select
					                lower(trim(unif_user_log_acct)) unif_pin,
					                lower(trim(user_acct_name)) pin
				                from
					                gdm.gdm_m01_userinfo_basic_da
				                where
					                dt = sysdate( - 1)
			                ) ----归一化用户pin
			                d
		                    on
			                    b.pin = d.pin
	)
    n
)
m
where 
    rank1 = 1
)
y
left join
(
 select
					                lower(trim(unif_user_log_acct)) unif_pin,
					                lower(trim(user_acct_name)) pin,
									reg_tm
				                from
					                gdm.gdm_m01_userinfo_basic_da
				                where
					                dt = sysdate( - 1)
)
z
on 
y.unif_pin = z.unif_pin 
group by
    y.unif_pin,
	last_orderid_tm,
	reg_tm
order by  
    rand()
limit 10000;
"""
ht.exec_sql(
    schema_name = 'dev_dkx',
    sql=sql,
    table_name = 'mjt_jianguo_userpin_fenbu_test_time',
    merge_flag = True)
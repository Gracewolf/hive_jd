#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess
import calendar

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 
# 流量日报-整合-月至今-商详末次

sql = """
DROP TABLE IF EXISTS dev_dkx.mjt_muying_traffic_report_sxmc_d;
CREATE
	TABLE dev_dkx.mjt_muying_traffic_report_sxmc_d STORED AS ORC tblproperties
	(
		'orc.compress' = 'SNAPPY'
	) AS
SELECT
    t1.dt,
    t1.qujian,
	t1.dept_name,
	t1.src_url_first_cate_name,
	t1.src_url_second_cate_name,
	t1.pv,
	t1.uv
FROM
	(
		SELECT * FROM dev_dkx.mjt_muying_traffic_report_dept_sxmc_pvuv_d
	)
	t1;
"""
ht.exec_sql(
    schema_name='dev_dkx',
    sql=sql,
    table_name = 'mjt_muying_traffic_report_sxmc_d',
    merge_flag = True)
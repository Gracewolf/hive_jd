#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess
import calendar

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 
# 流量日报-整合-日账期数据

sql = """
DROP TABLE IF EXISTS dev_dkx.mjt_muying_traffic_report_d;
CREATE
	TABLE dev_dkx.mjt_muying_traffic_report_d STORED AS ORC tblproperties
	(
		'orc.compress' = 'SNAPPY'
	) AS
SELECT
	t1.dt,
	t1.dept_name,
	t1.dept_id,
	(
	CASE
		WHEN SUBSTR(t1.dt,1,4) = SUBSTR(add_months(TRUNC(sysdate( - 1), 'MM'), - 12),1,4) 
		THEN '去年'
		WHEN SUBSTR(t1.dt,1,4) = SUBSTR(sysdate(-1),1,4)
		THEN '今年'
		ELSE '其他'
	END) AS qujian,
	t1.pv,
	t1.uv,
	t2.order_num,
	t3.GMV, 
	t2.order_num/t1.uv as uv_zhl,
	t3.GMV/t1.uv as uv_value,
	t1.pv/t1.uv as visit_depth
FROM
	(
		SELECT * FROM dev_dkx.mjt_traffic_report_dept_pvuv_d 
	)
	t1
JOIN
	(
		SELECT dt,dept_name,dept_id,par_order_num as order_num  FROM dev_dkx.mjt_traffic_order_dept_d
	)
	t2
ON
	t1.dt = t2.dt
	AND t1.dept_id = t2.dept_id
left JOIN
	(
		SELECT * FROM dev_dkx.mjt_traffic_report_dept_order_amount_d
	)
	t3
ON
	t1.dt = t3.statdate
	AND t1.dept_id = t3.dept_id

"""
ht.exec_sql(
    schema_name='dev_dkx',
    sql=sql,
    table_name = 'mjt_muying_traffic_report_d',
    merge_flag = True)
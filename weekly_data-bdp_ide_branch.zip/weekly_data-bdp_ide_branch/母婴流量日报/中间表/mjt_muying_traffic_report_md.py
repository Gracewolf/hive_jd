#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess
import calendar

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 
# 流量日报-整合-日账期数据

sql = """
DROP TABLE IF EXISTS dev_dkx.mjt_muying_traffic_report_md;
CREATE
	TABLE dev_dkx.mjt_muying_traffic_report_md STORED AS ORC tblproperties
	(
		'orc.compress' = 'SNAPPY'
	) AS
SELECT
	case
        when t1.qujian between trunc(sysdate(-1), 'MM') and sysdate(-1)
        then 'benqi'
        when t1.qujian between add_months(trunc(sysdate(-1), 'MM'),-12) and date_add(add_months(trunc(sysdate(-1), 'MM'),-12),day(sysdate(-1))-1)
        then 'qunian'
    end qujian,
	t1.dept_name,
	t1.dept_id,
	sum(t1.pv) pv,
	sum(t1.uv) uv,
	sum(t2.order_num) order_num,
	sum(t3.GMV) GMV, 
	sum(t2.order_num)/sum(t1.uv) as uv_zhl,
	sum(t3.GMV)/sum(t1.uv) as uv_value,
	sum(t1.pv)/sum(t1.uv) as visit_depth
FROM
	(
		SELECT * FROM dev_dkx.mjt_traffic_report_dept_pvuv_md 
	)
	t1
JOIN
	(
		SELECT qujian,dept_name,dept_id,par_order_num as order_num  FROM dev_dkx.mjt_traffic_order_dept_md
	)
	t2
ON
	t1.qujian = t2.qujian
	AND t1.dept_id = t2.dept_id
left JOIN
	(
		SELECT * FROM dev_dkx.mjt_traffic_report_dept_order_amount_md
	)
	t3
ON
	t1.qujian = t3.statdate
	AND t1.dept_id = t3.dept_id
group by
   case
        when t1.qujian between trunc(sysdate(-1), 'MM') and sysdate(-1)
        then 'benqi'
        when t1.qujian between add_months(trunc(sysdate(-1), 'MM'),-12) and date_add(add_months(trunc(sysdate(-1), 'MM'),-12),day(sysdate(-1))-1)
        then 'qunian'
    end,
	t1.dept_name,
	t1.dept_id;
"""
ht.exec_sql(
    schema_name='dev_dkx',
    sql=sql,
    table_name = 'mjt_muying_traffic_report_md',
    merge_flag = True)
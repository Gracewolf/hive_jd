#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess
import calendar

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 
# 流量日报-月至今-商详末次来源-一级部门pv和uv汇总
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
SET hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
SET hive.merge.mapredfiles = true;
--合并文件的大小
SET hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
SET hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
SET spark.sql.hive.mergeFiles = true;
SET hive.exec.parallel = true;
--Reduce阶段优化
SET hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
SET hive.map.aggr = true;
SET hive.groupby.mapaggr.checkinterval = 100000;
SET hive.auto.convert.join = true;
----月至今

DROP TABLE IF EXISTS dev_dkx.mjt_muying_traffic_report_dept3_sxmc_pvuv_md_jn;
CREATE
	TABLE dev_dkx.mjt_muying_traffic_report_dept3_sxmc_pvuv_md_jn STORED AS ORC tblproperties
	(
		'orc.compress' = 'SNAPPY'
	) AS
SELECT
	dept_name_3 AS dept_name,
	qujian,
	last_src_url_first_cate_name AS src_url_first_cate_name,
	last_src_url_second_cate_name AS src_url_second_cate_name,
	last_src_url_first_cate_id,
	last_src_url_second_cate_id,
	sysdate( - 1) AS thedate,
	COUNT(1) pv,
	COUNT(DISTINCT browser_uniq_id) uv
FROM
	(
		SELECT
			sku_id,
			user_log_acct,
			browser_uniq_id,
			last_src_url_first_cate_name,
	        last_src_url_second_cate_name,
	        last_src_url_first_cate_id,
	        last_src_url_second_cate_id,
			(
				CASE
					WHEN dt BETWEEN add_months(TRUNC(sysdate( - 1), 'MM'), - 12) AND date_add(add_months(TRUNC(sysdate( - 1), 'MM'), - 12), DAY(sysdate( - 1)) - 1)
					THEN '去年'
					WHEN dt BETWEEN TRUNC(sysdate( - 1), 'MM') AND sysdate( - 1)
					THEN '今年'
					ELSE '其他'
				END) AS qujian
		FROM
			adm.adm_d14_traffic_item_src_next_d x
		WHERE
			(
				(
					dt BETWEEN TRUNC(sysdate( - 1), 'MM') AND sysdate( - 1) --今年月至今
				)
				--OR
				--(
				--	dt BETWEEN add_months(TRUNC(sysdate( - 1), 'MM'), - 12) AND date_add(add_months(TRUNC(sysdate( - 1), 'MM'), - 12), DAY(sysdate( - 1)) - 1) --去年月至今，若遇到2月29号，则延长到3月1号
				--)
			)
	)
	a
JOIN
	(
		SELECT
			item_sku_id,
			dept_name_3
		FROM
			gdm.gdm_m03_mkt_item_sku_da
		WHERE
			dt = sysdate( - 1)
			AND dept_name_1 = '消费品事业部'
			AND dept_name_2 = '母婴非食POP部'
			AND dept_name_3 <> 'NULL'
	)
	b
ON
	a.sku_id = b.item_sku_id
GROUP BY
    dept_name_3,
	qujian,
	last_src_url_first_cate_name,
	last_src_url_second_cate_name,
	last_src_url_first_cate_id,
	last_src_url_second_cate_id;	    
"""
ht.exec_sql(
    schema_name='dev_dkx',
    sql=sql,
    table_name = 'mjt_muying_traffic_report_dept3_sxmc_pvuv_md_jn',
    merge_flag = True)
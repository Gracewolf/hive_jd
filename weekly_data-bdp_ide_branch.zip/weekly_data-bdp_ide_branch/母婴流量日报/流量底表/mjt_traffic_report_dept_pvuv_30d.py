#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess
import calendar

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 
# 流量日报_插入增量数据_部门pv和和uv_日账期

sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
SET hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
SET hive.merge.mapredfiles = true;
--合并文件的大小
SET hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
SET hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
SET spark.sql.hive.mergeFiles = true;
SET hive.exec.parallel = true;
--Reduce阶段优化
SET hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
SET hive.map.aggr = true;
SET hive.groupby.mapaggr.checkinterval = 100000;
SET hive.auto.convert.join = true;

insert into table dev_dkx.mjt_traffic_report_dept_pvuv_30d
select
    dt,
    dept_name,
    '无' dept_id,
    pv,
    uv
from
    dev_dkx.mjt_muying_traffic_report_d_last;	    
"""
ht.exec_sql(
    schema_name='dev_dkx',
    sql=sql,
    table_name = 'mjt_traffic_report_dept_pvuv_30d',
    merge_flag = True)
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess
import calendar

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 
# 流量日报-日账期一级部门GMV
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
SET hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
SET hive.merge.mapredfiles = true;
--合并文件的大小
SET hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
SET hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
SET spark.sql.hive.mergeFiles = true;
SET hive.exec.parallel = true;
--Reduce阶段优化
SET hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
SET hive.map.aggr = true;
SET hive.groupby.mapaggr.checkinterval = 100000;
SET hive.auto.convert.join = true;
----月至今用户

drop table if exists dev_dkx.mjt_traffic_report_dept_order_amount_md ;
create
  table dev_dkx.mjt_traffic_report_dept_order_amount_md STORED AS ORC tblproperties
  (
    'orc.compress' = 'SNAPPY'
  ) as
SELECT
	statdate,
	--pur_first_dept_name as dept_name,
	--pur_second_dept_name,
	pur_first_dept_cd as dept_id,
	SUM(gmv) AS GMV
FROM
	app.v_app_pur_morning_report_gmv_rev_non_double_xfp
WHERE
	dt in (TRUNC(sysdate( - 1), 'MM'), add_months(TRUNC(sysdate( - 1), 'MM'), - 12))
	AND 
	( 
	   statdate between trunc(sysdate(-1), 'MM') and sysdate(-1)
	   or statdate between add_months(trunc(sysdate(-1), 'MM'),-12) and date_add(add_months(trunc(sysdate(-1), 'MM'),-12),day(sysdate(-1))-1)
	)
	--AND type = 'B2C'
	AND pur_first_dept_name = '消费品事业部'
	AND pur_second_dept_name <> 'NULL'
group by 
    statdate,
	--pur_first_dept_name,
	pur_first_dept_cd
	
union all

SELECT
    statdate,
	--pur_first_dept_name,
	--pur_second_dept_name as dept_name,
	pur_second_dept_cd as dept_id,
	SUM(gmv) AS GMV
FROM
	app.v_app_pur_morning_report_gmv_rev_non_double_xfp
WHERE
	dt in (TRUNC(sysdate( - 1), 'MM'), add_months(TRUNC(sysdate( - 1), 'MM'), - 12))
    AND 
	( 
	   statdate between trunc(sysdate(-1), 'MM') and sysdate(-1)
	   or statdate between add_months(trunc(sysdate(-1), 'MM'),-12) and date_add(add_months(trunc(sysdate(-1), 'MM'),-12),day(sysdate(-1))-1)
	)
	--AND type = 'B2C'
	AND pur_first_dept_name = '消费品事业部'
	AND pur_second_dept_name = '母婴非食POP部'
group by 
    statdate,
	--pur_second_dept_name,
	pur_second_dept_cd
	
union all

SELECT
    ord.sale_ord_dt as statdate,
	t2.dept_id_3 AS dept_id,
	sum(after_prefr_amount_1) AS GMV
FROM
	(
		SELECT
			dt sale_ord_dt,
			parent_sale_ord_id,
			sale_ord_id,
			item_sku_id,
			check_account_tm,
			intraday_ord_intr_flag,
			intraday_ord_deal_flag,
			intraday_ord_valid_flag,
			after_prefr_amount_1
		FROM
			app.v_adm_d04_trade_ord_det_sku_snapshot_xfp
		WHERE
		    (
				 dt between trunc(sysdate(-1), 'MM') and sysdate(-1)
                 or dt between add_months(trunc(sysdate(-1), 'MM'),-12) and date_add(add_months(trunc(sysdate(-1), 'MM'),-12),day(sysdate(-1))-1)
                               -- 阳历日期做同比，遇到2月29号，则和去年3月1号做同比
		    )
			AND intraday_ord_deal_flag = '1' ----成交标记
            AND split_status_cd NOT IN('1') --排查拆单的父订单
            AND valid_flag = '1' --有效状态
            AND biz_flag_collect['int_pur_ord_flag'] <> 1 ----内采
            AND biz_flag_collect['dist_ord_flag'] <> 1---分销
            AND biz_flag_collect['corp_ord_flag'] <> 1-----企业订单
            AND biz_flag_collect['xtl_ord_flag'] <> 1 ----新通路
            AND virtual_ord_flag <> '1'---剔除虚拟订单
            AND biz_flag_collect['yhd_ord_flag'] <> 1 ----一号店
		GROUP BY
			dt,
			parent_sale_ord_id,
			sale_ord_id,
			item_sku_id,
			check_account_tm,
			intraday_ord_intr_flag,
			intraday_ord_deal_flag,
			intraday_ord_valid_flag,
			after_prefr_amount_1
	)
	ord
JOIN
	(
		SELECT
			item_sku_id,
			dept_name_1,
			dept_name_3,
			dept_id_3
		FROM
			gdm.gdm_m03_mkt_item_sku_da
		WHERE
			dt = sysdate( - 1)
			AND dept_name_1 = '消费品事业部'
			AND dept_name_2 = '母婴非食POP部'
			AND dept_name_3 <> 'NULL'
	)
	t2
ON
	ord.item_sku_id = t2.item_sku_id
GROUP BY
	ord.sale_ord_dt,
	t2.dept_id_3;	    
"""
ht.exec_sql(
    schema_name='dev_dkx',
    sql=sql,
    table_name = 'mjt_traffic_report_dept_order_amount_md',
    merge_flag = True)
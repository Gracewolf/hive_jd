#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess
import calendar

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 
# 流量日报_插入增量数据_部门pv和和uv_日账期

sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
SET hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
SET hive.merge.mapredfiles = true;
--合并文件的大小
SET hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
SET hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
SET spark.sql.hive.mergeFiles = true;
SET hive.exec.parallel = true;
--Reduce阶段优化
SET hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
SET hive.map.aggr = true;
SET hive.groupby.mapaggr.checkinterval = 100000;
SET hive.auto.convert.join = true;

drop table if exists dev_dkx.mjt_traffic_report_dept_pvuv_30d;
create
  table dev_dkx.mjt_traffic_report_dept_pvuv_30d STORED AS ORC tblproperties
  (
    'orc.compress' = 'SNAPPY'
  ) as
SELECT
	dt,
	b.dept_name_1 AS dept_name,
	b.dept_id_1 as dept_id,
	--b.dept_name_2,
	SUM(sku_pv) AS pv,
	COUNT(DISTINCT browser_uniq_id) AS uv
FROM
	(
		SELECT
			dt,
			sku_id,
			sku_pv,
			browser_uniq_id
		FROM
			adm.adm_s14_online_log_smart_item_d
		WHERE
			dt >= sysdate(-40)
			and dt <= sysdate(-2)
	)
	a
JOIN
	(
		SELECT
			item_sku_id,
			dept_name_1,
			dept_id_1,
			dept_name_2
		FROM
			gdm.gdm_m03_mkt_item_sku_da
		WHERE
		    dt = sysdate(-1)
			AND dept_name_1 = '消费品事业部'
			AND dept_name_2 <> 'NULL'
			AND dept_name_3 <> 'NULL'
	)
	b
ON
	a.sku_id = b.item_sku_id
GROUP BY
	dt,
	b.dept_name_1,
	b.dept_id_1
	--b.dept_name_2
	
union all	
	
SELECT
	dt,
	--b.dept_name_1,
	b.dept_name_2 AS dept_name,
	b.dept_id_2 as dept_id,
	SUM(sku_pv) AS pv,
	COUNT(DISTINCT browser_uniq_id) AS uv
FROM
	(
		SELECT
			dt,
			sku_id,
			sku_pv,
			browser_uniq_id
		FROM
			adm.adm_s14_online_log_smart_item_d
		WHERE
			dt >= sysdate(-40)
			and dt <= sysdate(-2)
	)
	a
JOIN
	(
		SELECT
			item_sku_id,
			dept_name_1,
			dept_name_2,
			dept_id_2
		FROM
			gdm.gdm_m03_mkt_item_sku_da
		WHERE
		    dt = sysdate(-1)
			AND dept_name_1 = '消费品事业部'
			AND dept_name_2 = '母婴非食POP部'
			AND dept_name_3 <> 'NULL'
	)
	b
ON
	a.sku_id = b.item_sku_id
GROUP BY
	dt,
	--b.dept_name_1
	b.dept_name_2,
	b.dept_id_2	
	
union all

SELECT
	dt,
	--b.dept_name_1,
	b.dept_name_3 AS dept_name,
	b.dept_id_3 as dept_id,
	SUM(sku_pv) AS pv,
	COUNT(DISTINCT browser_uniq_id) AS uv
FROM
	(
		SELECT
			dt,
			sku_id,
			sku_pv,
			browser_uniq_id
		FROM
			adm.adm_s14_online_log_smart_item_d
		WHERE
			dt >= sysdate(-40)
			and dt <= sysdate(-2)
	)
	a
JOIN
	(
		SELECT
			item_sku_id,
			dept_name_1,
			dept_name_3,
			dept_id_3
		FROM
			gdm.gdm_m03_mkt_item_sku_da
		WHERE
		    dt = sysdate(-1)
			AND dept_name_1 = '消费品事业部'
			AND dept_name_2 = '母婴非食POP部'
			AND dept_name_3 <> 'NULL'
	)
	b
ON
	a.sku_id = b.item_sku_id
GROUP BY
	dt,
	--b.dept_name_1
	b.dept_name_3,
	b.dept_id_3;	    
"""
ht.exec_sql(
    schema_name='dev_dkx',
    sql=sql,
    table_name = 'mjt_traffic_report_dept_pvuv_30d',
    merge_flag = True)
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess
import calendar

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 
# 经营分析_月至今uv同比

sql = """
SET hive.exec.parallel = true;
SET hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
SET hive.hadoop.supports.splittable.combineinputformat = true;
SET hive.exec.parallel = true;
SET hive.optimize.cp = true;
SET mapreduce.input.fileinputformat.split.maxsize = 256000000;
SET mapreduce.input.fileinputformat.split.minsize.per.node = 256000000;
SET mapreduce.input.fileinputformat.split.minsize.per.rack = 256000000;
SET hive.merge.mapfiles = true;
SET hive.merge.mapredfiles = true;
SET hive.merge.size.per.task = 256000000;
SET hive.merge.smallfiles.avgsize = 256000000;
SET hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
SET mapred.min.split.size = 1000000000;
SET mapred.max.split.size = 3000000000;

drop table if exists dev_dkx.mjt_traffic_order_dept_d;
create
  table dev_dkx.mjt_traffic_order_dept_d STORED AS ORC tblproperties
  (
    'orc.compress' = 'SNAPPY'
  ) as
SELECT
   ord.sale_ord_dt as dt,
	t2.dept_name_1 AS dept_name,
	t2.dept_id_1 AS dept_id,
	--,count(distinct case when intraday_ord_intr_flag = 1 then ord.parent_sale_ord_id end) as 引入父单量
	--,count(distinct case when intraday_ord_intr_flag = 1 then ord.sale_ord_id end ) as 引入子单量
	--,sum(case when intraday_ord_intr_flag = 1 then ord.after_prefr_amount_1 end) as 引入订单金额
	--COUNT(DISTINCT
	--CASE
	--	WHEN ord.intraday_ord_valid_flag = 1
	--	THEN ord.sale_ord_id
	--END) AS order_num,
	COUNT(DISTINCT
	CASE
		WHEN ord.intraday_ord_deal_flag = 1
		THEN ord.parent_sale_ord_id
	END) AS par_order_num ---成交父单量
	--,count(distinct case when ord.intraday_ord_deal_flag = 1 then ord.sale_ord_id end) as 成交子单量
	,sum(case when ord.intraday_ord_deal_flag = 1 then ord.after_prefr_amount_1 end) as amount
FROM
	(
		SELECT
			--dt,
			to_date(sale_ord_tm) as sale_ord_dt,
			parent_sale_ord_id,
			sale_ord_id,
			item_sku_id,
			check_account_tm,
			intraday_ord_intr_flag,
			intraday_ord_deal_flag,
			intraday_ord_valid_flag,
			after_prefr_amount_1
		FROM
			app.v_adm_d04_trade_ord_det_sku_snapshot_xfp
		WHERE
			dt >= date_add(add_months(TRUNC(sysdate( - 1), 'MM'), - 12), DAY(sysdate( - 1)) - 1)
			AND to_date(sale_ord_tm) in (date_add(add_months(TRUNC(sysdate( - 1), 'MM'), - 12), DAY(sysdate( - 1)) - 1) ,sysdate( - 1))
		    AND intraday_ord_deal_flag = 1 ----成交标记
			AND split_status_cd NOT IN('1') --排查拆单的父订单
			AND valid_flag = '1' --有效状态
			AND
			(
				ord_status_1_cd <> 6
				OR ord_status_2_cd <> 9
			) --剔除预售定金
			AND SUBSTR(ord_flag, 18, 1) NOT IN('1', '2') --剔除售后订单
			AND
			(
				SUBSTR(ord_flag, 31, 1) <> '2' --非行政内采
				OR
				(
					SUBSTR(ord_flag, 31, 1) = '2'
					AND user_log_acct IN('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
				)
			) --剔除内采订单
			AND item_third_cate_cd <> '6980' --剔除礼品卡三级类目
			AND
			(
				(
					substring(ord_flag, 46, 1) NOT IN(1, 2, 3, 7)
					AND substring(ord_flag, 60, 3) NOT IN('013')
				)
				AND sale_ord_type_cd <> 68
			) --剔除拍卖业务
			AND SUBSTR(ord_flag, 154, 3) NOT IN('136') --剔除拼团抽奖订单
			AND biz_flag_collect['int_pur_ord_flag'] = 0 -----内采订单标志
			AND sale_cha_cd NOT IN('yhd') ------剔除1号店订单
			AND virtual_ord_flag <> 1---剔除虚拟订单
			AND biz_flag_collect['corp_ord_flag'] <> 1---剔除企业订单
			AND biz_flag_collect['yhd_ord_flag'] <> 1---剔除1号店订单
			AND biz_flag_collect['dist_ord_flag'] <> 1--剔除分销订单
		GROUP BY
			to_date(sale_ord_tm),
			parent_sale_ord_id,
			sale_ord_id,
			item_sku_id,
			check_account_tm,
			intraday_ord_intr_flag,
			intraday_ord_deal_flag,
			intraday_ord_valid_flag,
			after_prefr_amount_1
	)
	ord
JOIN
	(
		SELECT
			item_sku_id,
			dept_name_1,
			dept_name_2,
			dept_id_1
		FROM
			gdm.gdm_m03_mkt_item_sku_da
		WHERE
			dt = sysdate( - 1)
			AND dept_name_1 = '消费品事业部'
			AND dept_name_2 <> 'NULL'
			AND dept_name_3 <> 'NULL'
	)
	t2
ON
	ord.item_sku_id = t2.item_sku_id
GROUP BY
	ord.sale_ord_dt,
	t2.dept_name_1,
	t2.dept_id_1
	
union all

SELECT
    ord.sale_ord_dt as dt,
	t2.dept_name_2 AS dept_name,
	t2.dept_id_2 AS dept_id,
	--,count(distinct case when intraday_ord_intr_flag = 1 then ord.parent_sale_ord_id end) as 引入父单量
	--,count(distinct case when intraday_ord_intr_flag = 1 then ord.sale_ord_id end ) as 引入子单量
	--,sum(case when intraday_ord_intr_flag = 1 then ord.after_prefr_amount_1 end) as 引入订单金额
	--COUNT(DISTINCT
	--CASE
	--	WHEN ord.intraday_ord_valid_flag = 1
	--	THEN ord.sale_ord_id
	--END) AS order_num,
	COUNT(DISTINCT
	CASE
		WHEN ord.intraday_ord_deal_flag = 1
		THEN ord.parent_sale_ord_id
	END) AS par_order_num ---成交父单量
	--,count(distinct case when ord.intraday_ord_deal_flag = 1 then ord.sale_ord_id end) as 成交子单量
	,sum(case when ord.intraday_ord_deal_flag = 1 then ord.after_prefr_amount_1 end) as amount
FROM
	(
		SELECT
			--dt,
			to_date(sale_ord_tm) as sale_ord_dt,
			parent_sale_ord_id,
			sale_ord_id,
			item_sku_id,
			check_account_tm,
			intraday_ord_intr_flag,
			intraday_ord_deal_flag,
			intraday_ord_valid_flag,
			after_prefr_amount_1
		FROM
			app.v_adm_d04_trade_ord_det_sku_snapshot_xfp
		WHERE
			dt >= date_add(add_months(TRUNC(sysdate( - 1), 'MM'), - 12), DAY(sysdate( - 1)) - 1)
			AND to_date(sale_ord_tm) in (date_add(add_months(TRUNC(sysdate( - 1), 'MM'), - 12), DAY(sysdate( - 1)) - 1) ,sysdate( - 1))
			AND intraday_ord_deal_flag = 1 ----成交标记
			AND split_status_cd NOT IN('1') --排查拆单的父订单
			AND valid_flag = '1' --有效状态
			AND
			(
				ord_status_1_cd <> 6
				OR ord_status_2_cd <> 9
			) --剔除预售定金
			AND SUBSTR(ord_flag, 18, 1) NOT IN('1', '2') --剔除售后订单
			AND
			(
				SUBSTR(ord_flag, 31, 1) <> '2' --非行政内采
				OR
				(
					SUBSTR(ord_flag, 31, 1) = '2'
					AND user_log_acct IN('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
				)
			) --剔除内采订单
			AND item_third_cate_cd <> '6980' --剔除礼品卡三级类目
			AND
			(
				(
					substring(ord_flag, 46, 1) NOT IN(1, 2, 3, 7)
					AND substring(ord_flag, 60, 3) NOT IN('013')
				)
				AND sale_ord_type_cd <> 68
			) --剔除拍卖业务
			AND SUBSTR(ord_flag, 154, 3) NOT IN('136') --剔除拼团抽奖订单
			AND biz_flag_collect['int_pur_ord_flag'] = 0 -----内采订单标志
			AND sale_cha_cd NOT IN('yhd') ------剔除1号店订单
			AND virtual_ord_flag <> 1---剔除虚拟订单
			AND biz_flag_collect['corp_ord_flag'] <> 1---剔除企业订单
			AND biz_flag_collect['yhd_ord_flag'] <> 1---剔除1号店订单
			AND biz_flag_collect['dist_ord_flag'] <> 1--剔除分销订单
		GROUP BY
			to_date(sale_ord_tm),
			parent_sale_ord_id,
			sale_ord_id,
			item_sku_id,
			check_account_tm,
			intraday_ord_intr_flag,
			intraday_ord_deal_flag,
			intraday_ord_valid_flag,
			after_prefr_amount_1
	)
	ord
JOIN
	(
		SELECT
			item_sku_id,
			dept_name_1,
			dept_name_2,
			dept_id_2
		FROM
			gdm.gdm_m03_mkt_item_sku_da
		WHERE
			dt = sysdate( - 1)
			AND dept_name_1 = '消费品事业部'
			AND dept_name_2 = '母婴非食POP部'
			AND dept_name_3 <> 'NULL'
	)
	t2
ON
	ord.item_sku_id = t2.item_sku_id
GROUP BY
	ord.sale_ord_dt,
	t2.dept_name_2,
	t2.dept_id_2
	
union all

SELECT
    ord.sale_ord_dt as dt,
	t2.dept_name_3 AS dept_name,
	t2.dept_id_3 AS dept_id,
	--,count(distinct case when intraday_ord_intr_flag = 1 then ord.parent_sale_ord_id end) as 引入父单量
	--,count(distinct case when intraday_ord_intr_flag = 1 then ord.sale_ord_id end ) as 引入子单量
	--,sum(case when intraday_ord_intr_flag = 1 then ord.after_prefr_amount_1 end) as 引入订单金额
	--COUNT(DISTINCT
	--CASE
	--	WHEN ord.intraday_ord_valid_flag = 1
	--	THEN ord.sale_ord_id
	--END) AS order_num,
	COUNT(DISTINCT
	CASE
		WHEN ord.intraday_ord_deal_flag = 1
		THEN ord.parent_sale_ord_id
	END) AS par_order_num ---成交父单量
	--,count(distinct case when ord.intraday_ord_deal_flag = 1 then ord.sale_ord_id end) as 成交子单量
	,sum(case when ord.intraday_ord_deal_flag = 1 then ord.after_prefr_amount_1 end) as amount
FROM
	(
		SELECT
			--dt,
			to_date(sale_ord_tm) as sale_ord_dt,
			parent_sale_ord_id,
			sale_ord_id,
			item_sku_id,
			check_account_tm,
			intraday_ord_intr_flag,
			intraday_ord_deal_flag,
			intraday_ord_valid_flag,
			after_prefr_amount_1
		FROM
			app.v_adm_d04_trade_ord_det_sku_snapshot_xfp
		WHERE
			dt >= date_add(add_months(TRUNC(sysdate( - 1), 'MM'), - 12), DAY(sysdate( - 1)) - 1)
			AND to_date(sale_ord_tm) in (date_add(add_months(TRUNC(sysdate( - 1), 'MM'), - 12), DAY(sysdate( - 1)) - 1) ,sysdate( - 1))
			AND intraday_ord_deal_flag = 1 ----成交标记
			AND split_status_cd NOT IN('1') --排查拆单的父订单
			AND valid_flag = '1' --有效状态
			AND
			(
				ord_status_1_cd <> 6
				OR ord_status_2_cd <> 9
			) --剔除预售定金
			AND SUBSTR(ord_flag, 18, 1) NOT IN('1', '2') --剔除售后订单
			AND
			(
				SUBSTR(ord_flag, 31, 1) <> '2' --非行政内采
				OR
				(
					SUBSTR(ord_flag, 31, 1) = '2'
					AND user_log_acct IN('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
				)
			) --剔除内采订单
			AND item_third_cate_cd <> '6980' --剔除礼品卡三级类目
			AND
			(
				(
					substring(ord_flag, 46, 1) NOT IN(1, 2, 3, 7)
					AND substring(ord_flag, 60, 3) NOT IN('013')
				)
				AND sale_ord_type_cd <> 68
			) --剔除拍卖业务
			AND SUBSTR(ord_flag, 154, 3) NOT IN('136') --剔除拼团抽奖订单
			AND biz_flag_collect['int_pur_ord_flag'] = 0 -----内采订单标志
			AND sale_cha_cd NOT IN('yhd') ------剔除1号店订单
			AND virtual_ord_flag <> 1---剔除虚拟订单
			AND biz_flag_collect['corp_ord_flag'] <> 1---剔除企业订单
			AND biz_flag_collect['yhd_ord_flag'] <> 1---剔除1号店订单
			AND biz_flag_collect['dist_ord_flag'] <> 1--剔除分销订单
		GROUP BY
			to_date(sale_ord_tm),
			parent_sale_ord_id,
			sale_ord_id,
			item_sku_id,
			check_account_tm,
			intraday_ord_intr_flag,
			intraday_ord_deal_flag,
			intraday_ord_valid_flag,
			after_prefr_amount_1
	)
	ord
JOIN
	(
		SELECT
			item_sku_id,
			dept_name_1,
			dept_name_3,
			dept_id_3
		FROM
			gdm.gdm_m03_mkt_item_sku_da
		WHERE
			dt = sysdate( - 1)
			AND dept_name_1 = '消费品事业部'
			AND dept_name_2 = '母婴非食POP部'
			AND dept_name_3 <> 'NULL'
	)
	t2
ON
	ord.item_sku_id = t2.item_sku_id
GROUP BY
	ord.sale_ord_dt,
	t2.dept_name_3,
	t2.dept_id_3;
"""
ht.exec_sql(
    schema_name='dev_dkx',
    sql=sql,
    table_name = 'mjt_traffic_order_dept_d',
    merge_flag = True)
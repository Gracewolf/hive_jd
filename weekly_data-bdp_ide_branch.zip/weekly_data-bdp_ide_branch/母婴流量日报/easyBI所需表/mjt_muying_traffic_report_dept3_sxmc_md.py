#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess
import calendar

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 
# 流量日报-日报应用-月至今-商详末次-一级部门

sql = """
DROP TABLE IF EXISTS dev_dkx.mjt_muying_traffic_report_dept3_sxmc_md;
CREATE
	TABLE dev_dkx.mjt_muying_traffic_report_dept3_sxmc_md STORED AS ORC tblproperties
	(
		'orc.compress' = 'SNAPPY'
	) AS
WITH
	temp AS
	(
		SELECT
			sysdate(-1) as thedate,
			qujian,
			dept_name,
			src_url_second_cate_name,
			SUM(pv) AS pv_all,
			SUM(uv) AS uv_all
		FROM
			dev_dkx.mjt_muying_traffic_report_sxmc_d
		WHERE
			(
		    	(
					dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1)
					and dt <= sysdate(-1)
				)
				OR
				(
				    dt >= date_sub(sysdate( - 366), day(sysdate( - 1)) - 1)
					and dt <= sysdate(-366)
				)
			)
			AND dept_name in  ('家清POP','玩具POP','奶粉用品POP','车床孕产POP','乐器POP')
		GROUP BY
			qujian,
			dept_name,
			src_url_second_cate_name
	)
SELECT
	thedate,
	dept_name,
	rank,
	src_url_second_cate_name,
	pv,
	pv_qn,
	pv_tb,
	uv,
	uv_qn,
	uv_tb,
	pv_zb,
	pv_zb_qn,
	pv_zb_tb
FROM
	(
		SELECT
			jn.thedate,
			jn.dept_name,
			row_number() over(PARTITION BY jn.dept_name order by jn.pv_all DESC) AS rank, --排名
			jn.src_url_second_cate_name,
			jn.pv_all AS pv,
			qn.pv_all AS pv_qn,
			ROUND((jn.pv_all / qn.pv_all - 1), 4) AS pv_tb,
			jn.uv_all AS uv,
			qn.uv_all AS uv_qn,
			ROUND((jn.uv_all / qn.uv_all - 1), 4) AS uv_tb,
			jn.pv_zb,
			qn.pv_zb AS pv_zb_qn,
			ROUND((jn.pv_zb - qn.pv_zb), 4) AS pv_zb_tb
		FROM
			(
				SELECT
					thedate,
					qujian,
					dept_name,
					src_url_second_cate_name,
					pv_all,
					uv_all,
					SUM(pv_all) over(PARTITION BY dept_name) AS sum_dept_uv,
					ROUND((pv_all / SUM(pv_all) over(PARTITION BY dept_name)), 4) AS pv_zb
				FROM
					temp
				WHERE
					qujian = '今年'
			)
			jn
		JOIN
			(
				SELECT
					thedate,
					qujian,
					dept_name,
					src_url_second_cate_name,
					pv_all,
					uv_all,
					SUM(pv_all) over(PARTITION BY dept_name) AS sum_dept_uv,
					ROUND((pv_all / SUM(pv_all) over(PARTITION BY dept_name)), 4) AS pv_zb
				FROM
					temp
				WHERE
					qujian = '去年'
			)
			qn
		ON
			jn.dept_name = qn.dept_name
			AND jn.src_url_second_cate_name = qn.src_url_second_cate_name
	)
	x
"""
ht.exec_sql(
    schema_name='dev_dkx',
    sql=sql,
    table_name = 'mjt_muying_traffic_report_dept3_sxmc_md',
    merge_flag = True)
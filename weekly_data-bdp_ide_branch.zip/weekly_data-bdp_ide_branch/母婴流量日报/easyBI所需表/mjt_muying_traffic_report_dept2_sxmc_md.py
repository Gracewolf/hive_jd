#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess
import calendar

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 
# 流量日报-日报应用-月至今-商详末次-一级部门

sql = """
DROP TABLE IF EXISTS dev_dkx.mjt_muying_traffic_report_dept2_sxmc_md;
CREATE
	TABLE dev_dkx.mjt_muying_traffic_report_dept2_sxmc_md STORED AS ORC tblproperties
	(
		'orc.compress' = 'SNAPPY'
	) AS
WITH
	temp AS
	(
		SELECT
			sysdate(-1) as thedate,
			qujian,
			dept_name,
			src_url_second_cate_name,
			SUM(pv) AS pv_all,
			SUM(uv) AS uv_all
		FROM
			dev_dkx.mjt_muying_traffic_report_sxmc_d
		WHERE
			(
		    	(
					dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1)
					and dt <= sysdate(-1)
				)
				OR
				(
				    dt >= date_sub(sysdate( - 366), day(sysdate( - 1)) - 1)
					and dt <= sysdate(-366)
				)
			)
			AND dept_name = '母婴非食POP部'
		GROUP BY
			qujian,
			dept_name,
			src_url_second_cate_name
	)
SELECT
	t1.thedate,
	t1.dept_name,
	t1.rank,
	t1.src_url_second_cate_name,
	t1.pv,
	t1.pv_qn,
	t1.pv_tb,
	ROUND((t1.pv / t2.sum_pv), 4) AS pv_zb, --pv占比
	ROUND((t1.pv_qn / t3.sum_pv), 4) AS pv_zb_qn, --qn_pv占比
	(ROUND((t1.pv / t2.sum_pv), 4) - ROUND((t1.pv_qn / t3.sum_pv), 4)) AS pv_zb_tb,
	t1.uv,
	t1.uv_qn,
	t1.uv_tb
FROM
	(
		SELECT
			*
		FROM
			(
				SELECT
					jn.thedate,
					jn.dept_name,
					row_number() over(PARTITION BY jn.dept_name order by jn.pv_all DESC) AS rank, --排名
					jn.src_url_second_cate_name,
					jn.pv_all AS pv,
					qn.pv_all AS pv_qn,
					ROUND((jn.pv_all / qn.pv_all - 1), 4) AS pv_tb,
					jn.uv_all AS uv,
					qn.uv_all AS uv_qn,
					ROUND((jn.uv_all / qn.uv_all - 1), 4) AS uv_tb
				FROM
					(
						SELECT * FROM temp WHERE qujian = '今年'
					)
					jn
				JOIN
					(
						SELECT * FROM temp WHERE qujian = '去年'
					)
					qn
				ON
					jn.src_url_second_cate_name = qn.src_url_second_cate_name
			)
			x
	)
	t1,
	(
		SELECT
			dept_name,
			SUM(pv_all) AS sum_pv
		FROM
			temp
		WHERE
			qujian = '今年'
		GROUP BY
			dept_name
	)
	t2,
	(
		SELECT
			dept_name,
			SUM(pv_all) AS sum_pv
		FROM
			temp
		WHERE
			qujian = '去年'
		GROUP BY
			dept_name
	)
	t3
"""
ht.exec_sql(
    schema_name='dev_dkx',
    sql=sql,
    table_name = 'mjt_muying_traffic_report_dept2_sxmc_md',
    merge_flag = True)
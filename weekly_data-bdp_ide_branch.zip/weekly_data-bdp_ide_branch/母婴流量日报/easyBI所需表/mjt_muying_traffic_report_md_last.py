#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess
import calendar

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 
# 流量日报-日报应用-日账期-汇总表

sql = """
DROP TABLE IF EXISTS dev_dkx.mjt_muying_traffic_report_md_last;
CREATE
	TABLE dev_dkx.mjt_muying_traffic_report_md_last STORED AS ORC tblproperties
	(
		'orc.compress' = 'SNAPPY'
	) AS
SELECT
     jn.qujian,
     jn.dept_name,
     jn.pv,
     qn.pv as pv_qn,
     round((jn.pv/qn.pv-1),4) as pv_tb,
     jn.uv,
     qn.uv as uv_qn,
     round((jn.uv/qn.uv-1),4) as uv_tb,
     jn.uv_zhl,
     qn.uv_zhl as uv_zhl_qn,
     round((jn.uv_zhl-qn.uv_zhl),4) as uv_zhl_tb,
     jn.uv_value,
     qn.uv_value as uv_value_qn,
     round((jn.uv_value/qn.uv_value-1),4) as uv_value_tb,
     jn.visit_depth,
     qn.visit_depth as visit_depth_qn,
     round((jn.visit_depth/qn.visit_depth-1),4) as visit_depth_tb
FROM
	(
		select * from dev_dkx.mjt_muying_traffic_report_md where qujian = 'benqi'
	)
	jn
	JOIN
	(
		select * from dev_dkx.mjt_muying_traffic_report_md where qujian = 'qunian'
	)
	qn
ON
  jn.dept_name = qn.dept_name
"""
ht.exec_sql(
    schema_name='dev_dkx',
    sql=sql,
    table_name = 'mjt_muying_traffic_report_md_last',
    merge_flag = True)
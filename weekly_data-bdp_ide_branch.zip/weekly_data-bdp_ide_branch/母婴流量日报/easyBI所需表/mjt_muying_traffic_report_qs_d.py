#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess
import calendar

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 
# 流量日报-日报应用-月至今-汇总表

sql = """
DROP TABLE IF EXISTS dev_dkx.mjt_muying_traffic_report_qs_d;
CREATE
	TABLE dev_dkx.mjt_muying_traffic_report_qs_d STORED AS ORC tblproperties
	(
		'orc.compress' = 'SNAPPY'
	) AS
SELECT
	jn.dt,
	jn.dept_name,
	jn.pv,
	qn.pv AS pv_qn,
	ROUND((jn.pv / qn.pv - 1), 4) AS pv_tb,
	jn.uv,
	qn.uv AS uv_qn,
	ROUND((jn.uv / qn.uv - 1), 4) AS uv_tb
FROM
	(
		SELECT
			dt,
			dept_name,
			pv,
			uv
		FROM
			dev_dkx.mjt_muying_traffic_report_d
		WHERE
			qujian = '今年'
			AND dt BETWEEN sysdate( - 30) AND sysdate( - 1)
	)
	jn
JOIN
	(
		SELECT
			dt,
			dept_name,
			pv,
			uv
		FROM
			dev_dkx.mjt_muying_traffic_report_d
		WHERE
			qujian = '去年'
			AND dt BETWEEN date_add(add_months(TRUNC(sysdate( - 1), 'MM'), - 12), DAY(sysdate( - 1)) - 30) AND date_add(add_months(TRUNC(sysdate( - 1), 'MM'), - 12), DAY(sysdate( - 1)) - 1)
	)
	qn
ON
	jn.dept_name = qn.dept_name
	AND SUBSTR(jn.dt, 6, 5) = SUBSTR(qn.dt, 6, 5)
"""
ht.exec_sql(
    schema_name='dev_dkx',
    sql=sql,
    table_name = 'mjt_muying_traffic_report_qs_d',
    merge_flag = True)
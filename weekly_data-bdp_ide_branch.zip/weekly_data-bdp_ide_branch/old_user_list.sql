----老用户表

set hive.exec.parallel = true;
insert overwrite table dev_xfp.nz_user_list
select
	tp,
	dept_id_2 pt_id,
	lower(trim(unif_user_log_acct)) user_log_acct,
	min(fst_ord_dt) fst_ord_dt
from
	app.v_adm_s01_user_new_or_old_flag_detail_xfp
where
	dt = sysdate( - 1)
	and tp = 'dept'
	and dept_id_2 = '47'
group by
	tp,
	dept_id_2,
	lower(trim(unif_user_log_acct))

union all

select
	tp,
	dept_id_3 pt_id,
	lower(trim(unif_user_log_acct)) user_log_acct,
	min(fst_ord_dt) fst_ord_dt
from
	app.v_adm_s01_user_new_or_old_flag_detail_xfp
where
	dt = sysdate( - 1)
	and tp = 'dept'
	and dept_id_2 = '47'
group by
	tp,
	dept_id_3,
	lower(trim(unif_user_log_acct))
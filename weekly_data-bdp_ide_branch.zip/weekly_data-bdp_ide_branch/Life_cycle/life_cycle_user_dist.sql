----生命周期统计
select
	life_cycle_fin,
	count(*) cn
from
	dev_xfp.nz_lifecycle_1
group by
	life_cycle_fin

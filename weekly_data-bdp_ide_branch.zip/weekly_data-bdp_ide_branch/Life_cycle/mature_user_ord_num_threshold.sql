----y次订单成熟用户阈值判断
drop table dev_xfp.niuzhe_mature_user_ord_num_1;
create table dev_xfp.niuzhe_mature_user_ord_num_1 as
select
	qtty_last,
	count( *) cn,
	count(if(qtty_next > 0, 1, NULL)) stay_cn
from
	(
		SELECT
			lower(trim(user_log_acct)) pin,
			count(distinct IF(sale_ord_dt >= sysdate( - 483)
			AND sale_ord_dt < sysdate( - 262), parent_sale_ord_id, NULL)) qtty_last,
			count(distinct IF(sale_ord_dt >= sysdate( - 262)
			AND sale_ord_dt < sysdate( - 41), parent_sale_ord_id, NULL)) qtty_next
		from
			(
				select * FROM app.app_cmo_cw_ord_det_sum WHERE dt >= sysdate( - 483)
			)
			x
		join
			(
				select
					*
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = '2019-06-30' ----防止拆架构
					and dept_id_1 = '33'
					and dept_id_2 = '47'
			)
			y
		on
			x.item_sku_id = y.item_sku_id
		GROUP BY
			lower(trim(user_log_acct))
	)
	a
WHERE
	qtty_last > 0
GROUP BY
	qtty_last;

drop table dev_xfp.niuzhe_mature_user_threshold;
create table dev_xfp.niuzhe_mature_user_threshold as
select
	*
from
	(
		select
			item_first_cate_name,
			item_second_cate_name,
			item_third_cate_cd,
			item_third_cate_name,
			qtty_last,
			cn_retained / cn_last retained_ratio,
			lag(cn_retained / cn_last) over(partition by item_first_cate_name, item_second_cate_name, item_third_cate_name order by qtty_last desc) as lag_ratio
		from
			(
				select
					item_first_cate_name,
					item_second_cate_name,
					item_third_cate_cd,
					item_third_cate_name,
					qtty_last,
					sum(cn) over(partition by item_first_cate_name, item_second_cate_name, item_third_cate_name order by qtty_last desc) as cn_last,
					sum(stay_cn) over(partition by item_first_cate_name, item_second_cate_name, item_third_cate_name order by qtty_last desc) as cn_retained
				from
					(
						select
							item_first_cate_name,
							item_second_cate_name,
							item_third_cate_cd,
							item_third_cate_name,
							qtty_last,
							count( *) cn,
							count(if(qtty_next > 0, 1, NULL)) stay_cn
						from
							(
								SELECT
									z.item_first_cate_name,
									z.item_second_cate_name,
									z.item_third_cate_cd,
									z.item_third_cate_name,
									lower(trim(user_log_acct)) pin,
									count(distinct IF(sale_ord_dt >= sysdate( - jiange * 2)
									AND sale_ord_dt < sysdate( - jiange), parent_sale_ord_id, NULL)) qtty_last,
									count(distinct IF(sale_ord_dt >= sysdate( - jiange)
									AND sale_ord_dt < sysdate( - 1), parent_sale_ord_id, NULL)) qtty_next
								from
									(
										select * FROM app.app_cmo_cw_ord_det_sum WHERE dt >= sysdate( - 1014)
									)
									x
								join
									(
										select
											*
										from
											gdm.gdm_m03_sold_item_sku_da
										where
											dt = sysdate( - 1)
											and dept_id_2 in('47', '1699')
											and item_first_cate_cd = '1320'
											and item_third_cate_cd in('5020', '5023', '15055', '15053', '5024', '12215', '15051', '5021', '5022', '15052', '15054', '2679', '13760', '2675', '13789', '2678', '2676', '2677', '13790', '12213', '12212', '12207', '12209', '12210', '12205', '12206', '17308', '12204', '12214', '12203', '12208', '12211', '1595', '1591', '1593', '1592', '13757', '1594', '1590', '12201', '1601', '12200', '3986', '9434', '1602', '10975')
									)
									y
								on
									x.item_sku_id = y.item_sku_id
								join
									(
										select * from dev_xfp.nz_lost_user_threshold
									)
									z
								on
									y.item_third_cate_cd = z.item_third_cate_cd
								GROUP BY
									z.item_first_cate_name,
									z.item_second_cate_name,
									z.item_third_cate_cd,
									z.item_third_cate_name,
									lower(trim(user_log_acct))
							)
							a
						WHERE
							qtty_last > 0
						GROUP BY
							item_first_cate_name,
							item_second_cate_name,
							item_third_cate_cd,
							item_third_cate_name,
							qtty_last
					)
					a
			)
			b
	)
	c
where
	retained_ratio >= 0.8
	and lag_ratio <=0.8;

select
	qtty_last,
	cn,
	stay_cn,
	cn_last,
	cn_retained,
	cn_retained / cn_last retained_ratio
from
	(
		select
			qtty_last,
			cn,
			stay_cn,
			sum(cn) over(partition by 1 order by qtty_last desc) as cn_last,
			sum(stay_cn) over(partition by 1 order by qtty_last desc) as cn_retained
		from
			(
				select
					qtty_last,
					sum(1) cn,
					sum(if(qtty_next > 0, 1, 0)) stay_cn
				from
					(
						SELECT
							lower(trim(user_log_acct)) pin,
							count(distinct IF(sale_ord_dt >= sysdate( - 440 * 2)
							AND sale_ord_dt <= sysdate( - 441), parent_sale_ord_id, NULL)) qtty_last,
							count(distinct IF(sale_ord_dt >= sysdate( - 440)
							AND sale_ord_dt <= sysdate( - 1), parent_sale_ord_id, NULL)) qtty_next
						from
							(
								select
									item_sku_id
								from
									gdm.gdm_m03_sold_item_sku_da
								where
									dt = sysdate( - 1)
									and dept_id_1 = '33'
									and brand_code = '14633'
									and item_first_cate_cd = '1320'
									and item_third_cate_cd in('3986', '15053')
							)
							a
						join
							(
								select
									user_log_acct,
									parent_sale_ord_id,
									sale_ord_dt,
									item_sku_id
								from
									app.v_app_cmo_cw_ord_det_sum_rb
								where
									dt >= sysdate( - 440 * 2)
									and dt <= sysdate( - 1)
									and sale_ord_dt >= sysdate( - 440 * 2)
									and sale_ord_dt <= sysdate( - 1)
									and valid_flag = '1'
							)
							b
						on
							a.item_sku_id = b.item_sku_id
						GROUP BY
							lower(trim(user_log_acct))
					)
					a
				WHERE
					qtty_last > 0
				GROUP BY
					qtty_last
			)
			a
	)
	b
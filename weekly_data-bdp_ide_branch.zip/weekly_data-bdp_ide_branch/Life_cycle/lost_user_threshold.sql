----x天流失用户判断
select
	beizhu,
	min(jiange) x_day
from
	(
		select
			'beizhu' beizhu,
			jiange,
			cn,
			sum(cn) over(partition by 1 order by jiange) as cul_cn,
			sum(cn) over(partition by 1) as total_cn
		from
			(
				select
					datediff(latest_purchase_dt, previous_purchase_dt) jiange,
					count(user_log_acct) cn
				from
					(
						select
							user_log_acct,
							sale_ord_dt,
							max(sale_ord_dt) over(partition by user_log_acct) as latest_purchase_dt,
							lag(sale_ord_dt) over(partition by user_log_acct order by sale_ord_dt) as previous_purchase_dt
						from
							(
								select
									user_log_acct,
									sale_ord_dt
								from
									(
										select
											item_sku_id
										from
											gdm.gdm_m03_sold_item_sku_da
										where
											dt = sysdate( - 1)
											and dept_id_1 = '33'
											and brand_code = '14633'
											and item_first_cate_cd = '1320'
											and item_third_cate_cd in('3986', '15053')
									)
									a
								join
									(
										select
											user_log_acct,
											sale_ord_dt,
											item_sku_id
										from
											app.v_app_cmo_cw_ord_det_sum_rb
										where
											dt >= '2014-01-01'
											and dt <= sysdate( - 1)
											and sale_ord_dt >= '2014-01-01'
											and sale_ord_dt <= sysdate( - 1)
											and valid_flag = '1'
									)
									b
								on
									a.item_sku_id = b.item_sku_id
								group by
									user_log_acct,
									sale_ord_dt
							)
							c
					)
					d
				where
					d.sale_ord_dt = d.latest_purchase_dt
					and datediff(latest_purchase_dt, previous_purchase_dt) >= 1
				group by
					datediff(latest_purchase_dt, previous_purchase_dt)
			)
			a
	)
	ff
where
	cul_cn / total_cn >= 0.8
group by
	beizhu
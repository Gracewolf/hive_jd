drop table dev_xfp.nz_lifecycle_1;
set hive.exec.parallel = true;
create table dev_xfp.nz_lifecycle_1
STORED AS ORC tblproperties ('orc.compress'='SNAPPY') as
select
	sysdate( - 1) dt,
	userpin,
	max(life_cycle) life_cycle_fin
from
	(
		select
			pin,
			max(case
				when brand_all_ord_cnt > 0
					and brand_first_ord_days < 440
					and brand_this_ord_cnt = 1
				then 5 --引入期
				when brand_all_ord_cnt > 0
					and brand_this_ord_cnt < 7
					and brand_this_ord_cnt > 0
					and brand_this_ord_cnt >= brand_prev_ord_cnt
				then 6 --成长期
				when brand_all_ord_cnt > 0
					and brand_this_ord_cnt >= 7
				then 7 --成熟期
				when brand_all_ord_cnt > 0
					and brand_this_ord_cnt < 7
					and brand_this_ord_cnt > 0
					and brand_this_ord_cnt < brand_prev_ord_cnt
				then 8 --衰退期
				when brand_all_ord_cnt > 0
					and brand_last_ord_days >= 440
				then 9 --流失期
				else 0
			end) life_cycle
		from
			(
				select
					lower(trim(user_log_acct)) pin,
					count(distinct case when sale_ord_dt > sysdate( - 440) then parent_sale_ord_id end) as brand_this_ord_cnt, ----最近一个周期的下单数
					count(distinct parent_sale_ord_id) as brand_all_ord_cnt, ----部门内订单数
					count(distinct case when sale_ord_dt <= sysdate( - 441) and sale_ord_dt >= sysdate( - 880) then parent_sale_ord_id end) as brand_prev_ord_cnt, ----上一个周期下单数
					datediff(sysdate(0), min(sale_ord_dt)) as brand_first_ord_days, ----雀巢首单距今天数
					datediff(sysdate(0), max(sale_ord_dt)) as brand_last_ord_days ----雀巢最近订单距今天数
				from
					(
						select
							item_sku_id
						from
							gdm.gdm_m03_sold_item_sku_da
						where
							dt = sysdate( - 1)
							and dept_id_1 = '33'
							and brand_code = '14633'
							and item_first_cate_cd = '1320'
							and item_third_cate_cd in('3986', '15053')
					)
					a
				join
					(
						select
							user_log_acct,
							item_sku_id,
							parent_sale_ord_id,
							sale_ord_dt,
							cw_gmv
						from
							app.v_app_cmo_cw_ord_det_sum_rb
						where
							dt >= '2014-01-01'
							and dt <= sysdate( - 1)
							and sale_ord_dt >= '2014-01-01'
							and sale_ord_dt <= sysdate( - 1)
							and valid_flag = '1'
					)
					b
				on
					a.item_sku_id = b.item_sku_id
				group by
					lower(trim(user_log_acct))
			)
			t1
		group by
			pin

		union all

		select
			lower(trim(user_log_acct)) pin,
			4 life_cycle ----高潜
		from
			(
				select
					item_sku_id
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and dept_id_1 = '33'
					and brand_code = '14633'
					and item_first_cate_cd = '1320'
					and item_third_cate_cd in('3986', '15053')
			)
			a
		join
			(
				select
					sku_id,
					user_log_acct
				from
					adm.adm_s14_online_log_smart_item_d
				where
					dt <= sysdate( - 1)
					and dt >= sysdate( - 30)
					and user_log_acct <> 'NULL'
				
				union all
				
				select
					sku_id,
					user_log_acct
				from
					adm.adm_m14_online_log_cart_d
				where
					dt <= sysdate( - 1)
					and dt >= sysdate( - 30)
					and user_log_acct <> 'NULL'
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			lower(trim(user_log_acct))

		union all

		select
			lower(trim(user_log_acct)) pin,
			3 life_cycle ----低潜
		from
			adm.adm_s14_ol_user_di
		where
			dt >= sysdate( - 730)
			and dt <= sysdate( - 1)
			and user_log_acct <> 'NULL'
		group by
			lower(trim(user_log_acct))
	)
	x
join
	(
		select
			user_acct_name userpin,
			lower(trim(user_acct_name)) pin
		from
			gdm.gdm_m01_userinfo_basic_da
		where
			dt = sysdate( - 1)
	) ----归一化用户pin
	y
on
	x.pin = y.pin
group by
	userpin
having
	life_cycle_fin >= 3
set hive.exec.parallel=true; 
set hive.exec.parallel.thread.number=16; 
--合并小文件
set hive.merge.mapfiles = true;  
set hive.merge.mapredfiles = true;  
set hive.merge.size.per.task=64000000;
set hive.merge.smallfiles.avgsize = 256000000; 
--Map阶段优化
set mapred.max.split.size=256000000; 
set mapred.min.split.size.per.node=256000000; 
set mapred.min.split.size.per.rack=256000000;  
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set hive.join.emit.interval = 2000;
set hive.mapjoin.size.key = 20000;
set hive.mapjoin.cache.numrows = 20000;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer=2000000000;
--数据倾斜
set hive.map.aggr=true;
set hive.groupby.mapaggr.checkinterval=100000;
set hive.auto.convert.join = true;
drop table dev_xfp.niuzhe_mature_user_threshold_1;
create table dev_xfp.niuzhe_mature_user_threshold_1 as
select
	item_first_cate_name,
	item_second_cate_name,
	item_third_cate_cd,
	item_third_cate_name,
	qtty_last,
	cn,
	stay_cn,
	sum(cn) over(partition by item_first_cate_name, item_second_cate_name, item_third_cate_name order by qtty_last desc) as cn_last,
	sum(stay_cn) over(partition by item_first_cate_name, item_second_cate_name, item_third_cate_name order by qtty_last desc) as cn_retained
from
	(
		select
			item_first_cate_name,
			item_second_cate_name,
			item_third_cate_cd,
			item_third_cate_name,
			qtty_last,
			count( *) cn,
			count(if(qtty_next > 0, 1, NULL)) stay_cn
		from
			(
				SELECT /*+mapjoin(y)*/
					z.item_first_cate_name,
					z.item_second_cate_name,
					z.item_third_cate_cd,
					z.item_third_cate_name,
					lower(trim(user_log_acct)) pin,
					count(distinct IF(sale_ord_dt >= sysdate( - jiange * 2)
					AND sale_ord_dt < sysdate( - jiange), parent_sale_ord_id, NULL)) qtty_last,
					count(distinct IF(sale_ord_dt >= sysdate( - jiange)
					AND sale_ord_dt < sysdate( - 1), parent_sale_ord_id, NULL)) qtty_next
				from
					(
						select * from dev_xfp.nz_lost_user_threshold
					)
					z
				join
					(
						select
							*
						from
							gdm.gdm_m03_sold_item_sku_da
						where
							dt = sysdate( - 1)
							and data_type in('1', '3')
							and dept_id_2 in('47', '1699')
							and item_first_cate_cd = '1320'
							and item_third_cate_cd in('5020', '5023', '15055', '15053', '5024', '12215', '15051', '5021', '5022', '15052', '15054', '2679', '13760', '2675', '13789', '2678', '2676', '2677', '13790', '12213', '12212', '12207', '12209', '12210', '12205', '12206', '17308', '12204', '12214', '12203', '12208', '12211', '1595', '1591', '1593', '1592', '13757', '1594', '1590', '12201', '1601', '12200', '3986', '9434', '1602', '10975')
					)
					y
				on
					y.item_third_cate_cd = z.item_third_cate_cd
				join
					(
						select * FROM app.app_cmo_cw_ord_det_sum WHERE dt >= sysdate( - 1014) and valid_flag = '1'
					)
					x
				on
					x.item_sku_id = y.item_sku_id
				GROUP BY
					z.item_first_cate_name,
					z.item_second_cate_name,
					z.item_third_cate_cd,
					z.item_third_cate_name,
					lower(trim(user_log_acct))
			)
			a
		WHERE
			qtty_last > 0
		GROUP BY
			item_first_cate_name,
			item_second_cate_name,
			item_third_cate_cd,
			item_third_cate_name,
			qtty_last
	)
	a
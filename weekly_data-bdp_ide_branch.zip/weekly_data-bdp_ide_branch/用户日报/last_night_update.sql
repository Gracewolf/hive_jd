select
	sale_ord_dt 时间,
	usr 总用户数,
	amount 总用户有效金额,
	inner_usr 站内新用户数,
	inner_amount 站内新有效金额,
	outer_usr 站外新用户数,
	outer_amount 站外新有效金额,
	old_usr 老用户数,
	old_amount 老用户有效金额
from
	dev_xfp.nz_morning_last_night_update
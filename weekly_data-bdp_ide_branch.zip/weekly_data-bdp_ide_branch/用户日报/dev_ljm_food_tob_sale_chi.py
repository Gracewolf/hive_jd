#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;
  
set hive.exec.parallel = true;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
set hive.map.aggr = true;
set hive.groupby.mapaggr.checkinterval = 100000;
set hive.auto.convert.join = true;

----内部归一化
DROP TABLE dev_xfp.ljm_brand_tea_gmv;
CREATE
	external  TABLE dev_xfp.ljm_brand_tea_gmv
	(
		dt string COMMENT '日期',
		brand_code string COMMENT '品牌代码',
		barndname_full string COMMENT '品牌名称',
		data_type string COMMENT '销售代码',
		gmv_lastday DOUBLE COMMENT '昨日gmv',
		gmv_lastyear DOUBLE COMMENT '去年昨日gmv',
		gmv_llastday DOUBLE COMMENT '前天gmv',
		gmv_mtd DOUBLE COMMENT '月至今gmv',
		gmv_mtd_lastyear DOUBLE COMMENT '去年月至今gmv',
		gmv_mtd_lastmonth DOUBLE COMMENT '上月月至今gmv',
		profit_lastday DOUBLE COMMENT '昨日毛利',
		profit_llastday DOUBLE COMMENT '前天毛利',
		profit_mtd DOUBLE COMMENT '月至今毛利',
		profit_mtd_lastyear DOUBLE COMMENT '去年月至今毛利',
		profit_mtd_lastmonth DOUBLE COMMENT '上月月至今毛利',
		gross_profit DOUBLE COMMENT '月至今广告费'
	)
	STORED AS ORC tblproperties('orc.compress' = 'SNAPPY');
INSERT INTO TABLE dev_xfp.ljm_brand_tea_gmv
SELECT
	sysdate( - 1),
	brand_code,
	barndname_full,
	x1.data_type,
	SUM(gmv_lastday) gmv_lastday, --昨日销售额
	SUM(gmv_lastyear) gmv_lastyear, --去年昨日销售额
	SUM(gmv_llastday) gmv_llastday, --前天销售额
	SUM(gmv_mtd) gmv_mtd, --月至今销售额
	SUM(gmv_mtd_lastyear) gmv_mtd_lastyear, --去年月至今销售额
	SUM(gmv_mtd_lastmonth) gmv_mtd_lastmonth, --上月月至今销售额
	SUM(profit_lastday) profit_lastday, --昨日毛利
	SUM(profit_llastday) profit_llastday, --前天毛利
	SUM(profit_mtd) profit_mtd, --月至今毛利
	SUM(profit_mtd_lastyear) profit_mtd_lastyear, --去年月至今毛利
	SUM(profit_mtd_lastmonth) profit_mtd_lastmonth, --上月月至今毛利
	SUM(gross_profit) gross_profit --月至今广告费
FROM
	(
		SELECT
			brand_code,
			barndname_full,
			data_type,
			SUM(
				CASE
					WHEN op_time = sysdate( - 1)
					THEN cw_gmv
				END) gmv_lastday, --昨日销售额
			SUM(
				CASE
					WHEN op_time = sysdate( - 1 - 365)
					THEN cw_gmv
				END) gmv_lastyear, --去年昨日销售额
			SUM(
				CASE
					WHEN op_time = sysdate( - 2)
					THEN cw_gmv
				END) gmv_llastday, --前天销售额
			SUM(
				CASE
					WHEN op_time <= sysdate( - 1)
						AND op_time >= TRUNC(sysdate( - 1), 'MM')
					THEN cw_gmv
				END) gmv_mtd, --月至今销售额
			SUM(
				CASE
					WHEN op_time <= sysdate( - 1 - 365)
						AND op_time >= TRUNC(sysdate( - 1 - 365), 'MM')
					THEN cw_gmv
				END) gmv_mtd_lastyear, --去年月至今销售额
			SUM(
				CASE
					WHEN op_time <= date_add(TRUNC(date_sub(TRUNC(sysdate( - 1), 'MM'), 1), 'MM'), dayofmonth(sysdate( - 2)))
						AND op_time >= TRUNC(date_sub(TRUNC(sysdate( - 1), 'MM'), 1), 'MM')
					THEN cw_gmv
				END) gmv_mtd_lastmonth, --上月月至今销售额
			SUM(
				CASE
					WHEN op_time = sysdate( - 1)
					THEN profit
				END) profit_lastday, --昨日毛利
			SUM(
				CASE
					WHEN op_time = sysdate( - 2)
					THEN profit
				END) profit_llastday, --前天毛利
			SUM(
				CASE
					WHEN op_time <= sysdate( - 1)
						AND op_time >= TRUNC(sysdate( - 1), 'MM')
					THEN profit
				END) profit_mtd, --月至今毛利
			SUM(
				CASE
					WHEN op_time <= sysdate( - 1 - 365)
						AND op_time >= TRUNC(sysdate( - 1 - 365), 'MM')
					THEN profit
				END) profit_mtd_lastyear, --去年月至今毛利
			SUM(
				CASE
					WHEN op_time <= date_add(TRUNC(date_sub(TRUNC(sysdate( - 1), 'MM'), 1), 'MM'), dayofmonth(sysdate( - 2)))
						AND op_time >= TRUNC(date_sub(TRUNC(sysdate( - 1), 'MM'), 1), 'MM')
					THEN profit
				END) profit_mtd_lastmonth--上月月至今毛利
		FROM
			(
				SELECT
					item_sku_id,
					item_name,
					brand_code,
					barndname_full,
					data_type
				FROM
					gdm.gdm_m03_sold_item_sku_da
				WHERE
					dt = sysdate( - 1)
					AND dept_id_2 = '47'
					AND dept_id_3 IN('985', '3818')
					AND
					(
						item_second_cate_cd <> '4980'
						OR item_third_cate_cd <> '4992'
					)
					AND brand_code IN('147668','3821','17799','28127','5792','19585','11735','28129','238328','21082','11384','6998','20964','25905','8700','168720','28392','61741','17836','56948','482647','33841','130077','68715','15793','424396','570830','43035','457113','146932')
					AND item_second_cate_name NOT IN('赠品', '虚拟商品')
					AND item_third_cate_name NOT IN('虚拟赠品', '赠品', '实物赠品', '特殊商品')
			)
			sold
		JOIN
			(
				SELECT
					op_time,
					item_sku_id,
					SUM(cw_gmv) cw_gmv,
					rebateamount + cw_gross_profit profit
				FROM
					app.app_cmo_cw_ord_det_sum_xfp_mid
				WHERE
					(
						dt >= '2018-12-01'
						AND dt <= sysdate( - 1)
					)
					AND SUBSTR(ord_flag, 40, 1) NOT IN('1')
				GROUP BY
					op_time,
					item_sku_id,
					rebateamount + cw_gross_profit
			)
			cw
		ON
			sold.item_sku_id = cw.item_sku_id
		GROUP BY
			brand_code,
			barndname_full,
			data_type
	)
	x1
JOIN
	(
		SELECT
			brand_id,
			brand_name,
			CASE
				WHEN mode_type = 'POP'
				THEN '3'
				ELSE '1'
			END data_type,
			SUM(gross_profit) gross_profit
		FROM
			app.v_app_cmo_jarvis_ad_adtype_detail_xfp
		WHERE
			dt >= TRUNC(sysdate( - 1), 'MM')
			AND dept_id_2 = '47'
			AND dept_id_3 IN('985', '3818')
		GROUP BY
			brand_id,
			brand_name,
			CASE
				WHEN mode_type = 'POP'
				THEN '3'
				ELSE '1'
			END
	)
	y2
ON
	x1.brand_code = y2.brand_id
	AND x1.data_type = y2.data_type
GROUP BY
	sysdate( - 1),
	brand_code,
	barndname_full,
	x1.data_type;
"""
ht.exec_sql(
    schema_name = 'dev_xfp',
    sql=sql,
    table_name = 'ljm_brand_tea_gmv',
    merge_flag = True)
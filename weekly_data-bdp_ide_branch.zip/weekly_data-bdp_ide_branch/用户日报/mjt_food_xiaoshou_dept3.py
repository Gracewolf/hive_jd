#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;
  
set hive.exec.parallel = true;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
set hive.map.aggr = true;
set hive.groupby.mapaggr.checkinterval = 100000;
set hive.auto.convert.join = true;

----内部归一化
drop table if exists dev_dkx.mjt_food_xiaoshou_dept3;
create
  table dev_dkx.mjt_food_xiaoshou_dept3 STORED AS ORC tblproperties
  (
    'orc.compress' = 'SNAPPY'
  ) as

SELECT
 a.pur_third_dept_name ,
 a.qd,
 CASE
  WHEN a.qd IN('合计')
  THEN 10
  WHEN a.qd IN('TOC零售')
  THEN 11
  WHEN a.qd IN('TOC大客户')
  THEN 12
  WHEN a.qd IN('XTL双记')
  THEN 13
  WHEN a.qd IN('XTL联营')
  THEN 14
  WHEN a.qd IN('7Fresh内采')
  THEN 15
  WHEN a.qd IN('集采双记')
  THEN 16
  WHEN a.qd IN('一盘货')
  THEN 17
  WHEN a.qd IN('自有品牌双记')
  THEN 18
  WHEN a.qd IN('分销')
  THEN 19
  WHEN a.qd IN('美赞臣')
  THEN 20
  WHEN a.qd IN('其他')
  THEN 21
  ELSE 23
 END AS qd_order,
 SUM(a.cw_gmv) AS cw_gmv_year,
 SUM(c.cw_gmv) AS cw_gmv_yearlast,
 SUM(a.cw_gmv) /(
  CASE
   WHEN
    (
     SUM(c.cw_gmv)
    )
    = 0
   THEN NULL
   ELSE SUM(c.cw_gmv)
  END) - 1 tb_year,
 SUM(d.cw_gmv) AS cw_gmv_Q,
 SUM(e.cw_gmv) AS cw_gmv_Qlast,
 SUM(d.cw_gmv) /(
  CASE
   WHEN
    (
     SUM(e.cw_gmv)
    )
    = 0
   THEN NULL
   ELSE SUM(e.cw_gmv)
  END) - 1 tb_Q,
 SUM(f.cw_gmv) AS cw_gmv_m,
 SUM(g.cw_gmv) AS cw_gmv_mlast,
 SUM(f.cw_gmv) /(
  CASE
   WHEN
    (
     SUM(g.cw_gmv)
    )
    = 0
   THEN NULL
   ELSE SUM(g.cw_gmv)
  END) - 1 tb_m,
 SUM(h.cw_gmv) AS cw_gmv_d,
 SUM(i.cw_gmv) AS cw_gmv_dlast,
 SUM(h.cw_gmv) /(
  CASE
   WHEN
    (
     SUM(i.cw_gmv)
    )
    = 0
   THEN NULL
   ELSE SUM(i.cw_gmv)
  END) - 1 tb_d
FROM
 (
  SELECT
   qd,
   pur_third_dept_name ,
   SUM(cw_gmv) AS cw_gmv
  FROM
   (
    SELECT
     statdate AS op_time,
	 pur_third_dept_name ,
     CASE
      WHEN
       (
        double_type IN('5')
        AND user_flag IN('XTL')
       )
      THEN 'XTL双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('XTL')
       )
      THEN 'XTL联营'
      WHEN
       (
        double_type IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '7Fresh内采'
      WHEN
       (
        double_type NOT IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '分销'
      WHEN
       (
        double_type IN('19_2')
        AND user_flag IN('XTL')
       )
      THEN '集采双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('ENFAMIL')
       )
      THEN '美赞臣'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('YIPANHUO')
       )
      THEN '一盘货'
      WHEN
       (
        double_type IN('1')
        AND user_flag IN('TOC', 'XTL')
       )
      THEN '自有品牌双记'
      WHEN
       (
        double_type IN('3')
        AND user_flag IN('TOC')
       )
      THEN '全球购双计'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_大客户')
       )
      THEN 'TOC大客户'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_零售')
       )
      THEN 'TOC零售'
      ELSE '其他'
     END AS qd,
     SUM(gmv) / 10000 AS cw_gmv
    FROM
     dev_xfp.v_app_pur_morning_report_gmv_rev_sum_arc_dsc_xfpchenbao
    WHERE
     dt = sysdate( - 1)
     AND statdate <= sysdate( - 1)
     AND statdate >= '2021-01-01'
     AND pur_first_dept_name IN('消费品事业部')
     AND pur_second_dept_cd IN('47')
	 AND pur_third_dept_cd in ('3842','989','3816','3836','966','4159','3840','4046','4044','3814','141','147','3818','985','4165','3838','433','3824','3826','4161','4162','4157','3828','3830'
)
    AND type='B2C'
    GROUP BY
     statdate,
	 pur_third_dept_name ,
     CASE
      WHEN
       (
        double_type IN('5')
        AND user_flag IN('XTL')
       )
      THEN 'XTL双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('XTL')
       )
      THEN 'XTL联营'
      WHEN
       (
        double_type IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '7Fresh内采'
      WHEN
       (
        double_type NOT IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '分销'
      WHEN
       (
        double_type IN('19_2')
        AND user_flag IN('XTL')
       )
      THEN '集采双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('ENFAMIL')
       )
      THEN '美赞臣'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('YIPANHUO')
       )
      THEN '一盘货'
      WHEN
       (
        double_type IN('1')
        AND user_flag IN('TOC', 'XTL')
       )
      THEN '自有品牌双记'
      WHEN
       (
        double_type IN('3')
        AND user_flag IN('TOC')
       )
      THEN '全球购双计'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_大客户')
       )
      THEN 'TOC大客户'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_零售')
       )
      THEN 'TOC零售'
      ELSE '其他'
     END

    UNION ALL

    SELECT
     statdate AS op_time,
	 pur_third_dept_name ,
     '合计' AS qd,
     SUM(gmv) / 10000 AS cw_gmv
    FROM
     dev_xfp.v_app_pur_morning_report_gmv_rev_sum_arc_dsc_xfpchenbao
    WHERE
     dt = sysdate( - 1)
     AND pur_first_dept_cd IN('33')
     AND pur_second_dept_cd IN('47')
     AND statdate <= sysdate( - 1)
     AND statdate >= '2021-01-01'
	 AND pur_third_dept_cd in ('3842','989','3816','3836','966','4159','3840','4046','4044','3814','141','147','3818','985','4165','3838','433','3824','3826','4161','4162','4157','3828','3830'
)
    AND type='B2C'
    GROUP BY
     statdate,
	 pur_third_dept_name ,
     '合计'
   )
   aa
  GROUP BY
   qd,
   pur_third_dept_name 
 )
 a
LEFT JOIN
 (
  SELECT
   qd,
   pur_third_dept_name ,
   SUM(cw_gmv) AS cw_gmv
  FROM
   (
    SELECT
     statdate AS op_time,
	 pur_third_dept_name ,
     CASE
      WHEN
       (
        double_type IN('5')
        AND user_flag IN('XTL')
       )
      THEN 'XTL双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('XTL')
       )
      THEN 'XTL联营'
      WHEN
       (
        double_type IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '7Fresh内采'
      WHEN
       (
        double_type NOT IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '分销'
      WHEN
       (
        double_type IN('19_2')
        AND user_flag IN('XTL')
       )
      THEN '集采双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('ENFAMIL')
       )
      THEN '美赞臣'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('YIPANHUO')
       )
      THEN '一盘货'
      WHEN
       (
        double_type IN('1')
        AND user_flag IN('TOC', 'XTL')
       )
      THEN '自有品牌双记'
      WHEN
       (
        double_type IN('3')
        AND user_flag IN('TOC')
       )
      THEN '全球购双计'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_大客户')
       )
      THEN 'TOC大客户'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_零售')
       )
      THEN 'TOC零售'
      ELSE '其他'
     END AS qd,
     SUM(gmv) / 10000 AS cw_gmv
    FROM
     dev_xfp.v_app_pur_morning_report_gmv_rev_sum_arc_dsc_xfpchenbao
    WHERE
     dt = sysdate( - 1)
     AND statdate <= sysdate( - 1)
     AND statdate >= add_months(concat(year(sysdate(-1)),'-',substr(concat('0',floor((month(sysdate(-1))+2)/3)*3+1),-2),'-01'),-3)
     AND pur_first_dept_name IN('消费品事业部')
     AND pur_second_dept_cd IN('47')
	 AND pur_third_dept_cd in ('3842','989','3816','3836','966','4159','3840','4046','4044','3814','141','147','3818','985','4165','3838','433','3824','3826','4161','4162','4157','3828','3830'
)
    AND type='B2C'
    GROUP BY
     statdate,
	 pur_third_dept_name ,
     CASE
      WHEN
       (
        double_type IN('5')
        AND user_flag IN('XTL')
       )
      THEN 'XTL双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('XTL')
       )
      THEN 'XTL联营'
      WHEN
       (
        double_type IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '7Fresh内采'
      WHEN
       (
        double_type NOT IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '分销'
      WHEN
       (
        double_type IN('19_2')
        AND user_flag IN('XTL')
       )
      THEN '集采双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('ENFAMIL')
       )
      THEN '美赞臣'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('YIPANHUO')
       )
      THEN '一盘货'
      WHEN
       (
        double_type IN('1')
        AND user_flag IN('TOC', 'XTL')
       )
      THEN '自有品牌双记'
      WHEN
       (
        double_type IN('3')
        AND user_flag IN('TOC')
       )
      THEN '全球购双计'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_大客户')
       )
      THEN 'TOC大客户'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_零售')
       )
      THEN 'TOC零售'
      ELSE '其他'
     END

    UNION ALL

    SELECT
     statdate AS op_time,
	 pur_third_dept_name ,
     '合计' AS qd,
     SUM(gmv) / 10000 AS cw_gmv
    FROM
     dev_xfp.v_app_pur_morning_report_gmv_rev_sum_arc_dsc_xfpchenbao
    WHERE
     dt = sysdate( - 1)
     AND pur_first_dept_cd IN('33')
     AND pur_second_dept_cd IN('47')
     AND statdate <= sysdate( - 1)
     AND statdate >= add_months(concat(year(sysdate(-1)),'-',substr(concat('0',floor((month(sysdate(-1))+2)/3)*3+1),-2),'-01'),-3)
	 AND pur_third_dept_cd in ('3842','989','3816','3836','966','4159','3840','4046','4044','3814','141','147','3818','985','4165','3838','433','3824','3826','4161','4162','4157','3828','3830'
)
    AND type='B2C'
    GROUP BY
     statdate,
	 pur_third_dept_name ,
     '合计'
   )
   dd
  GROUP BY
   qd,
   pur_third_dept_name 
 )
 d
ON
 a.qd = d.qd
 and a.pur_third_dept_name  = d.pur_third_dept_name 
LEFT JOIN
 (
  SELECT
   qd,
   pur_third_dept_name ,
   SUM(cw_gmv) AS cw_gmv
  FROM
   (
    SELECT
     statdate AS op_time,
	 pur_third_dept_name ,
     CASE
      WHEN
       (
        double_type IN('5')
        AND user_flag IN('XTL')
       )
      THEN 'XTL双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('XTL')
       )
      THEN 'XTL联营'
      WHEN
       (
        double_type IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '7Fresh内采'
      WHEN
       (
        double_type NOT IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '分销'
      WHEN
       (
        double_type IN('19_2')
        AND user_flag IN('XTL')
       )
      THEN '集采双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('ENFAMIL')
       )
      THEN '美赞臣'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('YIPANHUO')
       )
      THEN '一盘货'
      WHEN
       (
        double_type IN('1')
        AND user_flag IN('TOC', 'XTL')
       )
      THEN '自有品牌双记'
      WHEN
       (
        double_type IN('3')
        AND user_flag IN('TOC')
       )
      THEN '全球购双计'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_大客户')
       )
      THEN 'TOC大客户'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_零售')
       )
      THEN 'TOC零售'
      ELSE '其他'
     END AS qd,
     SUM(gmv) / 10000 AS cw_gmv
    FROM
     dev_xfp.v_app_pur_morning_report_gmv_rev_sum_arc_dsc_xfpchenbao
    WHERE
     dt = sysdate( - 1)
     AND statdate <= sysdate( - 1)
     AND statdate >= concat(SUBSTR(sysdate( - 1), 1, 7), '-01')
     AND pur_first_dept_name IN('消费品事业部')
     AND pur_second_dept_cd IN('47')
	 AND pur_third_dept_cd in ('3842','989','3816','3836','966','4159','3840','4046','4044','3814','141','147','3818','985','4165','3838','433','3824','3826','4161','4162','4157','3828','3830'
)
    AND type='B2C'
    GROUP BY
     statdate,
	 pur_third_dept_name ,
     CASE
      WHEN
       (
        double_type IN('5')
        AND user_flag IN('XTL')
       )
      THEN 'XTL双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('XTL')
       )
      THEN 'XTL联营'
      WHEN
       (
        double_type IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '7Fresh内采'
      WHEN
       (
        double_type NOT IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '分销'
      WHEN
       (
        double_type IN('19_2')
        AND user_flag IN('XTL')
       )
      THEN '集采双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('ENFAMIL')
       )
      THEN '美赞臣'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('YIPANHUO')
       )
      THEN '一盘货'
      WHEN
       (
        double_type IN('1')
        AND user_flag IN('TOC', 'XTL')
       )
      THEN '自有品牌双记'
      WHEN
       (
        double_type IN('3')
        AND user_flag IN('TOC')
       )
      THEN '全球购双计'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_大客户')
       )
      THEN 'TOC大客户'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_零售')
       )
      THEN 'TOC零售'
      ELSE '其他'
     END

    UNION ALL

    SELECT
     statdate AS op_time,
	 pur_third_dept_name ,
     '合计' AS qd,
     SUM(gmv) / 10000 AS cw_gmv
    FROM
     dev_xfp.v_app_pur_morning_report_gmv_rev_sum_arc_dsc_xfpchenbao
    WHERE
     dt = sysdate( - 1)
     AND pur_first_dept_cd IN('33')
     AND pur_second_dept_cd IN('47')
     AND statdate <= sysdate( - 1)
     AND statdate >= concat(SUBSTR(sysdate( - 1), 1, 7), '-01')
	 AND pur_third_dept_cd in ('3842','989','3816','3836','966','4159','3840','4046','4044','3814','141','147','3818','985','4165','3838','433','3824','3826','4161','4162','4157','3828','3830'
)
    AND type='B2C'
    GROUP BY
     statdate,
	 pur_third_dept_name ,
     '合计'
   )
   ff
  GROUP BY
   qd,
   pur_third_dept_name 
 )
 f
ON
 d.qd = f.qd
 and d.pur_third_dept_name  = f.pur_third_dept_name 
LEFT JOIN
 (
  SELECT
   qd,
   pur_third_dept_name ,
   SUM(cw_gmv) AS cw_gmv
  FROM
   (
    SELECT
     statdate AS op_time,
	 pur_third_dept_name ,
     CASE
      WHEN
       (
        double_type IN('5')
        AND user_flag IN('XTL')
       )
      THEN 'XTL双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('XTL')
       )
      THEN 'XTL联营'
      WHEN
       (
        double_type IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '7Fresh内采'
      WHEN
       (
        double_type NOT IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '分销'
      WHEN
       (
        double_type IN('19_2')
        AND user_flag IN('XTL')
       )
      THEN '集采双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('ENFAMIL')
       )
      THEN '美赞臣'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('YIPANHUO')
       )
      THEN '一盘货'
      WHEN
       (
        double_type IN('1')
        AND user_flag IN('TOC', 'XTL')
       )
      THEN '自有品牌双记'
      WHEN
       (
        double_type IN('3')
        AND user_flag IN('TOC')
       )
      THEN '全球购双计'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_大客户')
       )
      THEN 'TOC大客户'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_零售')
       )
      THEN 'TOC零售'
      ELSE '其他'
     END AS qd,
     SUM(gmv) / 10000 AS cw_gmv
    FROM
     dev_xfp.v_app_pur_morning_report_gmv_rev_sum_arc_dsc_xfpchenbao
    WHERE
     dt = sysdate( - 1)
     AND pur_first_dept_cd IN('33')
     AND pur_second_dept_cd IN('47')
     AND statdate <= sysdate( - 366)
     AND statdate >= '2020-01-01'
	 AND pur_third_dept_cd in ('3842','989','3816','3836','966','4159','3840','4046','4044','3814','141','147','3818','985','4165','3838','433','3824','3826','4161','4162','4157','3828','3830'
)
    AND type='B2C'
    GROUP BY
     statdate,
	 pur_third_dept_name ,
     CASE
      WHEN
       (
        double_type IN('5')
        AND user_flag IN('XTL')
       )
      THEN 'XTL双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('XTL')
       )
      THEN 'XTL联营'
      WHEN
       (
        double_type IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '7Fresh内采'
      WHEN
       (
        double_type NOT IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '分销'
      WHEN
       (
        double_type IN('19_2')
        AND user_flag IN('XTL')
       )
      THEN '集采双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('ENFAMIL')
       )
      THEN '美赞臣'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('YIPANHUO')
       )
      THEN '一盘货'
      WHEN
       (
        double_type IN('1')
        AND user_flag IN('TOC', 'XTL')
       )
      THEN '自有品牌双记'
      WHEN
       (
        double_type IN('3')
        AND user_flag IN('TOC')
       )
      THEN '全球购双计'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_大客户')
       )
      THEN 'TOC大客户'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_零售')
       )
      THEN 'TOC零售'
      ELSE '其他'
     END

    UNION ALL

    SELECT
     statdate AS op_time,
	 pur_third_dept_name ,
     '合计' AS qd,
     SUM(gmv) / 10000 AS cw_gmv
    FROM
     dev_xfp.v_app_pur_morning_report_gmv_rev_sum_arc_dsc_xfpchenbao
    WHERE
     dt = sysdate( - 1)
     AND pur_first_dept_cd IN('33')
     AND pur_second_dept_cd IN('47')
     AND statdate <= sysdate( - 366)
     AND statdate >= '2020-01-01'
	 AND pur_third_dept_cd in ('3842','989','3816','3836','966','4159','3840','4046','4044','3814','141','147','3818','985','4165','3838','433','3824','3826','4161','4162','4157','3828','3830'
)
    AND type='B2C'
    GROUP BY
     statdate,
	 pur_third_dept_name ,
     '合计'
   )
   cc
  GROUP BY
   qd,
   pur_third_dept_name 
 )
 c
ON
 c.qd = a.qd
 and c.pur_third_dept_name  = a.pur_third_dept_name 
LEFT JOIN
 (
  SELECT
   qd,
   pur_third_dept_name ,
   SUM(cw_gmv) AS cw_gmv
  FROM
   (
    SELECT
     statdate AS op_time,
	 pur_third_dept_name ,
     CASE
      WHEN
       (
        double_type IN('5')
        AND user_flag IN('XTL')
       )
      THEN 'XTL双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('XTL')
       )
      THEN 'XTL联营'
      WHEN
       (
        double_type IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '7Fresh内采'
      WHEN
       (
        double_type NOT IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '分销'
      WHEN
       (
        double_type IN('19_2')
        AND user_flag IN('XTL')
       )
      THEN '集采双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('ENFAMIL')
       )
      THEN '美赞臣'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('YIPANHUO')
       )
      THEN '一盘货'
      WHEN
       (
        double_type IN('1')
        AND user_flag IN('TOC', 'XTL')
       )
      THEN '自有品牌双记'
      WHEN
       (
        double_type IN('3')
        AND user_flag IN('TOC')
       )
      THEN '全球购双计'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_大客户')
       )
      THEN 'TOC大客户'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_零售')
       )
      THEN 'TOC零售'
      ELSE '其他'
     END AS qd,
     SUM(gmv) / 10000 AS cw_gmv
    FROM
     dev_xfp.v_app_pur_morning_report_gmv_rev_sum_arc_dsc_xfpchenbao
    WHERE
     dt = sysdate( - 1)
     AND pur_first_dept_cd IN('33')
     AND pur_second_dept_cd IN('47')
     AND statdate <= sysdate( - 366)
     AND statdate >= add_months(concat(year(sysdate(-366)),'-',substr(concat('0',floor((month(sysdate(-366))+2)/3)*3+1),-2),'-01'),-3)
	 AND pur_third_dept_cd in ('3842','989','3816','3836','966','4159','3840','4046','4044','3814','141','147','3818','985','4165','3838','433','3824','3826','4161','4162','4157','3828','3830'
)
    AND type='B2C'
    GROUP BY
     statdate,
	 pur_third_dept_name ,
     CASE
      WHEN
       (
        double_type IN('5')
        AND user_flag IN('XTL')
       )
      THEN 'XTL双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('XTL')
       )
      THEN 'XTL联营'
      WHEN
       (
        double_type IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '7Fresh内采'
      WHEN
       (
        double_type NOT IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '分销'
      WHEN
       (
        double_type IN('19_2')
        AND user_flag IN('XTL')
       )
      THEN '集采双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('ENFAMIL')
       )
      THEN '美赞臣'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('YIPANHUO')
       )
      THEN '一盘货'
      WHEN
       (
        double_type IN('1')
        AND user_flag IN('TOC', 'XTL')
       )
      THEN '自有品牌双记'
      WHEN
       (
        double_type IN('3')
        AND user_flag IN('TOC')
       )
      THEN '全球购双计'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_大客户')
       )
      THEN 'TOC大客户'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_零售')
       )
      THEN 'TOC零售'
      ELSE '其他'
     END

    UNION ALL

    SELECT
     statdate AS op_time,
	 pur_third_dept_name ,
     '合计' AS qd,
     SUM(gmv) / 10000 AS cw_gmv
    FROM
     dev_xfp.v_app_pur_morning_report_gmv_rev_sum_arc_dsc_xfpchenbao
    WHERE
     dt = sysdate( - 1)
     AND pur_first_dept_cd IN('33')
     AND pur_second_dept_cd IN('47')
     AND statdate <= sysdate( - 366)
     AND statdate >= add_months(concat(year(sysdate(-366)),'-',substr(concat('0',floor((month(sysdate(-366))+2)/3)*3+1),-2),'-01'),-3)
	 AND pur_third_dept_cd in ('3842','989','3816','3836','966','4159','3840','4046','4044','3814','141','147','3818','985','4165','3838','433','3824','3826','4161','4162','4157','3828','3830'
)
    AND type='B2C'
    GROUP BY
     statdate,
	 pur_third_dept_name ,
     '合计'
   )
   ee
  GROUP BY
   qd,
   pur_third_dept_name 
 )
 e
ON
 a.qd = e.qd
 and a.pur_third_dept_name  = e.pur_third_dept_name 
LEFT JOIN
 (
  SELECT
   qd,
   pur_third_dept_name ,
   SUM(cw_gmv) AS cw_gmv
  FROM
   (
    SELECT
     statdate AS op_time,
	 pur_third_dept_name ,
     CASE
      WHEN
       (
        double_type IN('5')
        AND user_flag IN('XTL')
       )
      THEN 'XTL双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('XTL')
       )
      THEN 'XTL联营'
      WHEN
       (
        double_type IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '7Fresh内采'
      WHEN
       (
        double_type NOT IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '分销'
      WHEN
       (
        double_type IN('19_2')
        AND user_flag IN('XTL')
       )
      THEN '集采双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('ENFAMIL')
       )
      THEN '美赞臣'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('YIPANHUO')
       )
      THEN '一盘货'
      WHEN
       (
        double_type IN('1')
        AND user_flag IN('TOC', 'XTL')
       )
      THEN '自有品牌双记'
      WHEN
       (
        double_type IN('3')
        AND user_flag IN('TOC')
       )
      THEN '全球购双计'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_大客户')
       )
      THEN 'TOC大客户'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_零售')
       )
      THEN 'TOC零售'
      ELSE '其他'
     END AS qd,
     SUM(gmv) / 10000 AS cw_gmv
    FROM
     dev_xfp.v_app_pur_morning_report_gmv_rev_sum_arc_dsc_xfpchenbao
    WHERE
     dt = sysdate( - 1)
     AND pur_first_dept_cd IN('33')
     AND pur_second_dept_cd IN('47')
     AND statdate <= sysdate( - 366)
     AND statdate >= concat(SUBSTR(sysdate( - 366), 1, 7), '-01')
	 AND pur_third_dept_cd in ('3842','989','3816','3836','966','4159','3840','4046','4044','3814','141','147','3818','985','4165','3838','433','3824','3826','4161','4162','4157','3828','3830'
)
    AND type='B2C'
    GROUP BY
     statdate,
	 pur_third_dept_name ,
     CASE
      WHEN
       (
        double_type IN('5')
        AND user_flag IN('XTL')
       )
      THEN 'XTL双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('XTL')
       )
      THEN 'XTL联营'
      WHEN
       (
        double_type IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '7Fresh内采'
      WHEN
       (
        double_type NOT IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '分销'
      WHEN
       (
        double_type IN('19_2')
        AND user_flag IN('XTL')
       )
      THEN '集采双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('ENFAMIL')
       )
      THEN '美赞臣'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('YIPANHUO')
       )
      THEN '一盘货'
      WHEN
       (
        double_type IN('1')
        AND user_flag IN('TOC', 'XTL')
       )
      THEN '自有品牌双记'
      WHEN
       (
        double_type IN('3')
        AND user_flag IN('TOC')
       )
      THEN '全球购双计'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_大客户')
       )
      THEN 'TOC大客户'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_零售')
       )
      THEN 'TOC零售'
      ELSE '其他'
     END

    UNION ALL

    SELECT
     statdate AS op_time,
	 pur_third_dept_name ,
     '合计' AS qd,
     SUM(gmv) / 10000 AS cw_gmv
    FROM
     dev_xfp.v_app_pur_morning_report_gmv_rev_sum_arc_dsc_xfpchenbao
    WHERE
     dt = sysdate( - 1)
     AND pur_first_dept_cd IN('33')
     AND pur_second_dept_cd IN('47')
     AND statdate <= sysdate( - 366)
     AND statdate >= concat(SUBSTR(sysdate( - 366), 1, 7), '-01')
	 AND pur_third_dept_cd in ('3842','989','3816','3836','966','4159','3840','4046','4044','3814','141','147','3818','985','4165','3838','433','3824','3826','4161','4162','4157','3828','3830'
)
    AND type='B2C'
    GROUP BY
     statdate,
	 pur_third_dept_name ,
     '合计'
   )
   gg
  GROUP BY
   qd,
   pur_third_dept_name 
 )
 g
ON
 g.qd = e.qd
 and g.pur_third_dept_name  = e.pur_third_dept_name 
LEFT JOIN
 (
  SELECT
   qd,
   pur_third_dept_name ,
   SUM(cw_gmv) AS cw_gmv
  FROM
   (
    SELECT
     statdate AS op_time,
	 pur_third_dept_name ,
     CASE
      WHEN
       (
        double_type IN('5')
        AND user_flag IN('XTL')
       )
      THEN 'XTL双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('XTL')
       )
      THEN 'XTL联营'
      WHEN
       (
        double_type IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '7Fresh内采'
      WHEN
       (
        double_type NOT IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '分销'
      WHEN
       (
        double_type IN('19_2')
        AND user_flag IN('XTL')
       )
      THEN '集采双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('ENFAMIL')
       )
      THEN '美赞臣'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('YIPANHUO')
       )
      THEN '一盘货'
      WHEN
       (
        double_type IN('1')
        AND user_flag IN('TOC', 'XTL')
       )
      THEN '自有品牌双记'
      WHEN
       (
        double_type IN('3')
        AND user_flag IN('TOC')
       )
      THEN '全球购双计'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_大客户')
       )
      THEN 'TOC大客户'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_零售')
       )
      THEN 'TOC零售'
      ELSE '其他'
     END AS qd,
     SUM(gmv) / 10000 AS cw_gmv
    FROM
     dev_xfp.v_app_pur_morning_report_gmv_rev_sum_arc_dsc_xfpchenbao
    WHERE
     dt = sysdate( - 1)
     AND statdate = sysdate( - 1)
     AND pur_first_dept_name IN('消费品事业部')
     AND pur_second_dept_cd IN('47')
	 AND pur_third_dept_cd in ('3842','989','3816','3836','966','4159','3840','4046','4044','3814','141','147','3818','985','4165','3838','433','3824','3826','4161','4162','4157','3828','3830'
)
    AND type='B2C'
    GROUP BY
     statdate,
	 pur_third_dept_name ,
     CASE
      WHEN
       (
        double_type IN('5')
        AND user_flag IN('XTL')
       )
      THEN 'XTL双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('XTL')
       )
      THEN 'XTL联营'
      WHEN
       (
        double_type IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '7Fresh内采'
      WHEN
       (
        double_type NOT IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '分销'
      WHEN
       (
        double_type IN('19_2')
        AND user_flag IN('XTL')
       )
      THEN '集采双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('ENFAMIL')
       )
      THEN '美赞臣'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('YIPANHUO')
       )
      THEN '一盘货'
      WHEN
       (
        double_type IN('1')
        AND user_flag IN('TOC', 'XTL')
       )
      THEN '自有品牌双记'
      WHEN
       (
        double_type IN('3')
        AND user_flag IN('TOC')
       )
      THEN '全球购双计'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_大客户')
       )
      THEN 'TOC大客户'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_零售')
       )
      THEN 'TOC零售'
      ELSE '其他'
     END

    UNION ALL

    SELECT
     statdate AS op_time,
	 pur_third_dept_name ,
     '合计' AS qd,
     SUM(gmv) / 10000 AS cw_gmv
    FROM
     dev_xfp.v_app_pur_morning_report_gmv_rev_sum_arc_dsc_xfpchenbao
    WHERE
     dt = sysdate( - 1)
     AND pur_first_dept_cd IN('33')
     AND pur_second_dept_cd IN('47')
     AND statdate = sysdate( - 1)
	 AND pur_third_dept_cd in ('3842','989','3816','3836','966','4159','3840','4046','4044','3814','141','147','3818','985','4165','3838','433','3824','3826','4161','4162','4157','3828','3830'
)
    AND type='B2C'
    GROUP BY
     statdate,
	 pur_third_dept_name ,
     '合计'
   )
   hh
  GROUP BY
   qd,
   pur_third_dept_name 
 )
 h
ON
 h.qd = a.qd
 and h.pur_third_dept_name  = a.pur_third_dept_name 
LEFT JOIN
 (
  SELECT
   qd,
   pur_third_dept_name ,
   SUM(cw_gmv) AS cw_gmv
  FROM
   (
    SELECT
     statdate AS op_time,
	 pur_third_dept_name ,
     CASE
      WHEN
       (
        double_type IN('5')
        AND user_flag IN('XTL')
       )
      THEN 'XTL双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('XTL')
       )
      THEN 'XTL联营'
      WHEN
       (
        double_type IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '7Fresh内采'
      WHEN
       (
        double_type NOT IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '分销'
      WHEN
       (
        double_type IN('19_2')
        AND user_flag IN('XTL')
       )
      THEN '集采双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('ENFAMIL')
       )
      THEN '美赞臣'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('YIPANHUO')
       )
      THEN '一盘货'
      WHEN
       (
        double_type IN('1')
        AND user_flag IN('TOC', 'XTL')
       )
      THEN '自有品牌双记'
      WHEN
       (
        double_type IN('3')
        AND user_flag IN('TOC')
       )
      THEN '全球购双计'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_大客户')
       )
      THEN 'TOC大客户'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_零售')
       )
      THEN 'TOC零售'
      ELSE '其他'
     END AS qd,
     SUM(gmv) / 10000 AS cw_gmv
    FROM
     dev_xfp.v_app_pur_morning_report_gmv_rev_sum_arc_dsc_xfpchenbao
    WHERE
     dt = sysdate( - 1)
     AND pur_first_dept_cd IN('33')
     AND pur_second_dept_cd IN('47')
	 AND pur_third_dept_cd in ('3842','989','3816','3836','966','4159','3840','3814','141','147','3818','985','4165','3838','433','3824','3826','4161','4162','4157','3828','3830','5066'
)
     AND statdate = sysdate( - 366)
     AND type='B2C'
    GROUP BY
     statdate,
	 pur_third_dept_name ,
     CASE
      WHEN
       (
        double_type IN('5')
        AND user_flag IN('XTL')
       )
      THEN 'XTL双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('XTL')
       )
      THEN 'XTL联营'
      WHEN
       (
        double_type IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '7Fresh内采'
      WHEN
       (
        double_type NOT IN('14')
        AND user_flag IN('FENXIAO')
       )
      THEN '分销'
      WHEN
       (
        double_type IN('19_2')
        AND user_flag IN('XTL')
       )
      THEN '集采双记'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('ENFAMIL')
       )
      THEN '美赞臣'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('YIPANHUO')
       )
      THEN '一盘货'
      WHEN
       (
        double_type IN('1')
        AND user_flag IN('TOC', 'XTL')
       )
      THEN '自有品牌双记'
      WHEN
       (
        double_type IN('3')
        AND user_flag IN('TOC')
       )
      THEN '全球购双计'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_大客户')
       )
      THEN 'TOC大客户'
      WHEN
       (
        double_type IN('0')
        AND user_flag IN('TOC_零售')
       )
      THEN 'TOC零售'
      ELSE '其他'
     END

    UNION ALL

    SELECT
     statdate AS op_time,
	 pur_third_dept_name ,
     '合计' AS qd,
     SUM(gmv) / 10000 AS cw_gmv
    FROM
     dev_xfp.v_app_pur_morning_report_gmv_rev_sum_arc_dsc_xfpchenbao
    WHERE
     dt = sysdate( - 1)
     AND pur_first_dept_cd IN('33')
     AND pur_second_dept_cd IN('47')
	 and pur_third_dept_cd in ('3842','989','3816','3836','966','4159','3840','4046','4044','3814','141','147','3818','985','4165','3838','433','3824','3826','4161','4162','4157','3828','3830'
)
     AND statdate = sysdate( - 366)
     AND type='B2C'
    GROUP BY
     statdate,
	 pur_third_dept_name ,
     '合计'
   )
   ii
  GROUP BY
   qd,
   pur_third_dept_name 
 )
 i
ON
 i.qd = c.qd
 and i.pur_third_dept_name  = c.pur_third_dept_name 
GROUP BY
 a.qd,
 a.pur_third_dept_name ,
 CASE
  WHEN a.qd IN('合计')
  THEN 10
  WHEN a.qd IN('TOC零售')
  THEN 11
  WHEN a.qd IN('TOC大客户')
  THEN 12
  WHEN a.qd IN('XTL双记')
  THEN 13
  WHEN a.qd IN('XTL联营')
  THEN 14
  WHEN a.qd IN('7Fresh内采')
  THEN 15
  WHEN a.qd IN('分销')
  THEN 16
  WHEN a.qd IN('集采双记')
  THEN 17
  WHEN a.qd IN('美赞臣')
  THEN 18
  WHEN a.qd IN('一盘货')
  THEN 19
  WHEN a.qd IN('自有品牌双记')
  THEN 20
  WHEN a.qd IN('其他')
  THEN 21
  ELSE 23
 END
ORDER BY
 qd_order;
"""
ht.exec_sql(
    schema_name = 'dev_dkx',
    sql=sql,
    table_name = 'mjt_food_xiaoshou_dept3',
    merge_flag = True)
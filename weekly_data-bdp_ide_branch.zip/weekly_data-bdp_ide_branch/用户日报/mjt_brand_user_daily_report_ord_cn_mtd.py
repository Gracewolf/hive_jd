#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import time
import datetime
import subprocess


sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day

sql_1 = """
--合并小文件
set hive.merge.mapfiles=true;
set hive.merge.mapredfiles = true;
set hive.merge.size.per.task = 256000000;
set hive.merge.smallfiles.avgsize = 256000000;
--存储压缩
set hive.default.fileformat=Orc;
--多线程并发
set hive.exec.parallel = true;
set hive.exec.parallel.thread.number = 8;
--列剪裁
set hive.optimize.cp = true;
set hive.optimize.pruner = true;
--map阶段优化
set mapred.max.split.size = 256000000;
set mapred.min.split.size.per.node = 256000000;
set mapred.min.split.size.per.rack = 256000000;
set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set hive.hadoop.supports.splittable.combineinputformat = true;
set mapreduce.input.fileinputformat.split.maxsize = 256000000;
set mapreduce.input.fileinputformat.split.minsize.per.node=256000000;
set mapreduce.input.fileinputformat.split.minsize.per.rack=256000000;
drop
	table if exists dev_xfp.mjt_brand_user_daily_report_ord_cn_mtd;
create
	table dev_xfp.mjt_brand_user_daily_report_ord_cn_mtd STORED AS ORC tblproperties
	(
		'orc.compress' = 'SNAPPY'
	) as
select
	dept_name,
	brand_code,
	barndname_full,
	total_usr,
	inner_usr,
	outer_usr,
	total_usr - inner_usr - outer_usr old_usr,
	total_value / total_ord total_vpr,
	inner_value / inner_ord inner_vpr,
	outer_value / outer_ord outer_vpr,
	(total_value - inner_value - outer_value) / (total_ord - inner_ord - outer_ord) old_vpr,
	re_usr / total_usr rebuy_ritio,
	total_usr / total_usr_1 - 1 total_usr_YoY,
	inner_usr / inner_usr_1 - 1 inner_usr_YoY,
	outer_usr / outer_usr_1 - 1 outer_usr_YoY,
	(total_usr - inner_usr - outer_usr) / (total_usr_1 - inner_usr_1 - outer_usr_1) - 1 old_usr_YoY,
	(total_value / total_ord) / (total_value_1 / total_ord_1) - 1 total_vpr_YoY,
	(inner_value / inner_ord) / (inner_value_1 / inner_ord_1) - 1 inner_vpr_YoY,
	(outer_value / outer_ord) / (outer_value_1 / outer_ord_1) - 1 outer_vpr_YoY,
	((total_value - inner_value - outer_value) / (total_ord - inner_ord - outer_ord)) / ((total_value_1 - inner_value_1 - outer_value_1) / (total_ord_1 - inner_ord_1 - outer_ord_1)) - 1 old_vpr_YoY,
	(re_usr / total_usr) / (re_usr_1 / total_usr_1) - 1 rebuy_ritio_YoY
from
	(
		select
			dept_name,
			brand_code,
			barndname_full,
			sum(case when year_dt = year(sysdate( - 1)) then total_usr else 0 end) total_usr,
			sum(case when year_dt = year(sysdate( - 1)) then inner_usr else 0 end) inner_usr,
			sum(case when year_dt = year(sysdate( - 1)) then outer_usr else 0 end) outer_usr,
			sum(case when year_dt = year(sysdate( - 1)) then re_usr else 0 end) re_usr,
			sum(case when year_dt = year(sysdate( - 1)) then total_ord else 0 end) total_ord,
			sum(case when year_dt = year(sysdate( - 1)) then inner_ord else 0 end) inner_ord,
			sum(case when year_dt = year(sysdate( - 1)) then outer_ord else 0 end) outer_ord,
			sum(case when year_dt = year(sysdate( - 1)) then total_value else 0 end) total_value,
			sum(case when year_dt = year(sysdate( - 1)) then inner_value else 0 end) inner_value,
			sum(case when year_dt = year(sysdate( - 1)) then outer_value else 0 end) outer_value,
			sum(case when year_dt = year(sysdate( - 1)) - 1 then total_usr else 0 end) total_usr_1,
			sum(case when year_dt = year(sysdate( - 1)) - 1 then inner_usr else 0 end) inner_usr_1,
			sum(case when year_dt = year(sysdate( - 1)) - 1 then outer_usr else 0 end) outer_usr_1,
			sum(case when year_dt = year(sysdate( - 1)) - 1 then re_usr else 0 end) re_usr_1,
			sum(case when year_dt = year(sysdate( - 1)) - 1 then total_ord else 0 end) total_ord_1,
			sum(case when year_dt = year(sysdate( - 1)) - 1 then inner_ord else 0 end) inner_ord_1,
			sum(case when year_dt = year(sysdate( - 1)) - 1 then outer_ord else 0 end) outer_ord_1,
			sum(case when year_dt = year(sysdate( - 1)) - 1 then total_value else 0 end) total_value_1,
			sum(case when year_dt = year(sysdate( - 1)) - 1 then inner_value else 0 end) inner_value_1,
			sum(case when year_dt = year(sysdate( - 1)) - 1 then outer_value else 0 end) outer_value_1
		from
			(
				select
					x.year_dt,
					dept_name_3 dept_name,
					brand_code,
					barndname_full,
					sum(1) total_usr,
					sum(case when par_ord_num >= 2 then 1 else 0 end) re_usr,
					sum(par_ord_num) total_ord,
					sum(amount) total_value,
					sum(case when fst_all_yn = 0 then 1 else 0 end) inner_usr,
					sum(case when fst_all_yn = 0 then par_ord_num else 0 end) inner_ord,
					sum(case when fst_all_yn = 0 then amount else 0 end) inner_value,
					sum(case when fst_all_yn = 1 then 1 else 0 end) outer_usr,
					sum(case when fst_all_yn = 1 then par_ord_num else 0 end) outer_ord,
					sum(case when fst_all_yn = 1 then amount else 0 end) outer_value
				from
					(
						select
							user_log_acct,
							dept_id_3,
							dept_name_3,
							brand_code,
							barndname_full,
							case when this_year_flag = 1 then year(sysdate( - 1)) else year(sysdate( - 1)) - 1 end year_dt,
							count(distinct parent_sale_ord_id) par_ord_num,
							sum(after_prefr_amount) amount
						from
							dev_xfp.nz_user_daily_report_ord
						where
							dept_id_2 = '47'
							and brand_code in ('11187','5673','3681','14633','10361','27810','27776','11540','3979','27776','11540','3979','127616','6030','121636','15840','9429','7095','9429','7095','11742','327878','87563','11384','3821','11735','376553','12690','19306','15139','6024','262379','55567','38876','63953','55567','217343','5962','27905','18768','7876','11330','75406')
							and (this_year_flag = 1 or last_year_flag = 1)
						group by
							user_log_acct,
							dept_id_3,
							dept_name_3,
							brand_code,
							barndname_full,
							case when this_year_flag = 1 then year(sysdate( - 1)) else year(sysdate( - 1)) - 1 end
					)
					x
				left join
					(
						select
							case when this_year_flag = 1 then year(sysdate( - 1)) else year(sysdate( - 1)) - 1 end year_dt,
							bs,
							user_log_acct,
							fst_all_yn,
							fst_ord_dt
						from
							dev_xfp.nz_new_user_flag
						where
							(
								this_year_flag = 1 or last_year_flag = 1
							)
							and tp = 'dept3'
					)
					y
				on
					x.user_log_acct = y.user_log_acct
					and x.year_dt = y.year_dt
					and x.dept_id_3 = y.bs
				left join
					(
						select user_log_acct from dev_xfp.spite_user_list_xfp
					)
					c
				on
					x.user_log_acct = c.user_log_acct
				where
					c.user_log_acct is null
				group by
					x.year_dt,
					dept_name_3,
					brand_code,
					barndname_full
			)
			ff
		group by
			dept_name,
			brand_code,
	        barndname_full
	)
	ff
"""

ht.exec_sql(schema_name='dev_xfp', sql=sql_1, table_name = 'mjt_brand_user_daily_report_ord_cn_mtd', merge_flag=False)					
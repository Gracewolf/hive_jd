#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;
  
set hive.exec.parallel = true;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
set hive.map.aggr = true;
set hive.groupby.mapaggr.checkinterval = 100000;
set hive.auto.convert.join = true;

----内部归一化
drop table if exists dev_dkx.mjt_dept_flow_mtd;
create
  table dev_dkx.mjt_dept_flow_mtd STORED AS ORC tblproperties
  (
    'orc.compress' = 'SNAPPY'
  ) as
select
	dept_name,
	pv,
	pv / pv_1 - 1 PV_yoy,
	pv / pv_2 - 1 PV_moon_yoy,
	uv,
	uv / uv_1 - 1 uv_yoy,
	uv / uv_2 - 1 uv_moon_yoy,
	ord_num / uv uv_zhuanhua,
	(ord_num / uv) / (ord_num_1 / uv_1) - 1 uv_zhuanhua_yoy,
	(ord_num / uv) / (ord_num_2 / uv_2) - 1 uv_zhuanhua_moon_yoy,
	gmv / uv uv_value,
	(gmv / uv) / (gmv_1 / uv_1) - 1 uv_value_yoy,
	(gmv / uv) / (gmv_2 / uv_2) - 1 uv_value_moon_yoy
from
	(
		select
			dept_name,
			sum(case when dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1) and dt <= sysdate( - 1) then pv else 0 end) pv,
			sum(case when dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1) and dt <= sysdate( - 1) then uv else 0 end) uv,
			sum(case when dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1) and dt <= sysdate( - 1) then ord_num else 0 end) ord_num,
			sum(case when dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1) and dt <= sysdate( - 1) then gmv else 0 end) gmv,
			sum(case when dt >= date_sub(sysdate( - 367), day(sysdate( - 1)) - 1) and dt <= sysdate( - 367) then pv else 0 end) pv_1,
			sum(case when dt >= date_sub(sysdate( - 367), day(sysdate( - 1)) - 1) and dt <= sysdate( - 367) then uv else 0 end) uv_1,
			sum(case when dt >= date_sub(sysdate( - 367), day(sysdate( - 1)) - 1) and dt <= sysdate( - 367) then ord_num else 0 end) ord_num_1,
			sum(case when dt >= date_sub(sysdate( - 367), day(sysdate( - 1)) - 1) and dt <= sysdate( - 367) then gmv else 0 end) gmv_1,
			sum(case when dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1) and dt <= sysdate( - 385) then pv else 0 end) pv_2,
			sum(case when dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1) and dt <= sysdate( - 385) then uv else 0 end) uv_2,
			sum(case when dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1) and dt <= sysdate( - 385) then ord_num else 0 end) ord_num_2,
			sum(case when dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1) and dt <= sysdate( - 385) then gmv else 0 end) gmv_2
		from
			(
				select
					coalesce(a.dept_name, b.dept_name) dept_name,
					coalesce(a.dt, b.dt) dt,
					pv,
					uv,
					ord_num,
					gmv	
				from
					(
						select
							dept_name_2 dept_name,
                            dt,
							count(distinct sale_ord_id) ord_num,
							sum(gmv) gmv
						from
							dev_xfp.nz_flow_daily_report_order_base
						where
						(
							(
								dt >= date_sub(sysdate( - 367), day(sysdate( - 1)) - 1)
								and dt <= sysdate( - 367)
							)
							or
							(
								dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1)
								and dt <= sysdate( - 1)
							)
							or
							(
								dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1)
								and dt <= sysdate( - 385)
							)
                        )							
						group by
							dept_name_2,
							dt
					)
					a
				full outer join
					(
						select
							dept_name_2 dept_name,
							dt,
							count(distinct browser_uniq_id) uv,
							sum(pv) pv
						from
							dev_xfp.nz_flow_daily_report_view_base
						where
						(	
							(
								dt >= date_sub(sysdate( - 367), day(sysdate( - 1)) - 1)
								and dt <= sysdate( - 367)
							)
							or
							(
								dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1)
								and dt <= sysdate( - 1)
							)
							or
							(
							    dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1)
								and dt <= sysdate( - 385)
							)
                        ) 							
						group by
							dept_name_2,
							dt
					)
					b
				on
					a.dept_name = b.dept_name
					and a.dt = b.dt
			)
			ff
		group by
			dept_name
	)
	ff

union all

select
	dept_name,
	pv,
	pv / pv_1 - 1 PV_yoy,
	pv / pv_2 - 1 PV_moon_yoy,
	uv,
	uv / uv_1 - 1 uv_yoy,
	uv / uv_2 - 1 uv_moon_yoy,
	ord_num / uv uv_zhuanhua,
	(ord_num / uv) / (ord_num_1 / uv_1) - 1 uv_zhuanhua_yoy,
	(ord_num / uv) / (ord_num_2 / uv_2) - 1 uv_zhuanhua_moon_yoy,
	gmv / uv uv_value,
	(gmv / uv) / (gmv_1 / uv_1) - 1 uv_value_yoy,
	(gmv / uv) / (gmv_2 / uv_2) - 1 uv_value_moon_yoy
from
	(
		select
			dept_name,
			sum(case when dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1) and dt <= sysdate( - 1) then pv else 0 end) pv,
			sum(case when dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1) and dt <= sysdate( - 1) then uv else 0 end) uv,
			sum(case when dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1) and dt <= sysdate( - 1) then ord_num else 0 end) ord_num,
			sum(case when dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1) and dt <= sysdate( - 1) then gmv else 0 end) gmv,
			sum(case when dt >= date_sub(sysdate( - 367), day(sysdate( - 1)) - 1) and dt <= sysdate( - 367) then pv else 0 end) pv_1,
			sum(case when dt >= date_sub(sysdate( - 367), day(sysdate( - 1)) - 1) and dt <= sysdate( - 367) then uv else 0 end) uv_1,
			sum(case when dt >= date_sub(sysdate( - 367), day(sysdate( - 1)) - 1) and dt <= sysdate( - 367) then ord_num else 0 end) ord_num_1,
			sum(case when dt >= date_sub(sysdate( - 367), day(sysdate( - 1)) - 1) and dt <= sysdate( - 367) then gmv else 0 end) gmv_1,
			sum(case when dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1) and dt <= sysdate( - 385) then pv else 0 end) pv_2,
			sum(case when dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1) and dt <= sysdate( - 385) then uv else 0 end) uv_2,
			sum(case when dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1) and dt <= sysdate( - 385) then ord_num else 0 end) ord_num_2,
			sum(case when dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1) and dt <= sysdate( - 385) then gmv else 0 end) gmv_2
		from
			(
				select
					coalesce(a.dept_name, b.dept_name) dept_name,
					coalesce(a.dt, b.dt) dt,
					pv,
					uv,
					ord_num,
					gmv	
				from
					(
						select
							dept_name_3 dept_name,
							dt,
							count(distinct sale_ord_id) ord_num,
							sum(gmv) gmv
						from
							dev_xfp.nz_flow_daily_report_order_base
						where
						(
							(
								dt >= date_sub(sysdate( - 367), day(sysdate( - 1)) - 1)
								and dt <= sysdate( - 367)
							)
							or
							(
								dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1)
								and dt <= sysdate( - 1)
							)
							or
							(
							    dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1)
								and dt <= sysdate( - 385)
							 )  
						)
						group by
							dept_name_3,
							dt
					)
					a
				full outer join
					(
						select
							dept_name_3 dept_name,
							dt,
							count(distinct browser_uniq_id) uv,
							sum(pv) pv
						from
							dev_xfp.nz_flow_daily_report_view_base
						where
							(
								(
									dt >= date_sub(sysdate( - 367), day(sysdate( - 1)) - 1)
									and dt <= sysdate( - 367)
								)
								or
								(
									dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1)
									and dt <= sysdate( - 1)
								)
								or
							    (
							        dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1)
								    and dt <= sysdate( - 385)
							    ) 
							)
						group by
							dept_name_3,
							dt
					)
					b
				on
					a.dept_name = b.dept_name
					and a.dt = b.dt
			)
			ff
		group by
			dept_name
	)
	ff;
"""
ht.exec_sql(
    schema_name = 'dev_dkx',
    sql=sql,
    table_name = 'mjt_dept_flow_mtd',
    merge_flag = True)
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;

----------------------------------------------------------------------------------
drop table if exists dev_dkx.mjt_user_amount_all_d_wide_table;
create
	table dev_dkx.mjt_user_amount_all_d_wide_table
STORED AS ORC  tblproperties ('orc.compress'='SNAPPY')
as
select
	benqi.dt dt,
	benqi.dept_name_3,
	benqi.user_no user_no_benqi,
	benqi.out_new_user_no out_new_user_no_benqi,
	benqi.in_new_user_no in_new_user_no_benqi,
	qunian.user_no user_no_qunian,
	qunian.out_new_user_no out_new_user_no_qunian,
	qunian.in_new_user_no in_new_user_no_qunian,
	nongli.user_no user_no_nongli,
	nongli.out_new_user_no out_new_user_no_nongli,
	nongli.in_new_user_no in_new_user_no_nongli,
	benqi.gmv_sum gmv_sum_benqi,
	benqi.out_new_amount out_new_amount_benqi,
	benqi.in_new_amount in_new_amount_benqi,
	qunian.gmv_sum gmv_sum_qunian,
	qunian.out_new_amount out_new_amount_qunian,
	qunian.in_new_amount in_new_amount_qunian,
	nongli.gmv_sum gmv_sum_nongli,
	nongli.out_new_amount out_new_amount_nongli,
	nongli.in_new_amount in_new_amount_nongli,
	benqi.ord_num ord_num_benqi,
	benqi.out_new_ord_num out_new_ord_num_benqi,
	benqi.in_new_ord_num in_new_ord_num_benqi,
	qunian.ord_num ord_num_qunian,
	qunian.out_new_ord_num out_new_ord_num_qunian,
	qunian.in_new_ord_num in_new_ord_num_qunian,
	nongli.ord_num ord_num_nongli,
	nongli.out_new_ord_num out_new_ord_num_nongli,
	nongli.in_new_ord_num in_new_ord_num_nongli,
	benqi.item_qtty item_qtty_benqi,
	benqi.out_new_sale_qtty out_new_sale_qtty_benqi,
	benqi.in_new_sale_qtty in_new_sale_qtty_benqi,
	qunian.item_qtty item_qtty_qunian,
	qunian.out_new_sale_qtty out_new_sale_qtty_qunian,
	qunian.in_new_sale_qtty in_new_sale_qtty_qunian,
	nongli.item_qtty item_qtty_nongli,
	nongli.out_new_sale_qtty out_new_sale_qtty_nongli,
	nongli.in_new_sale_qtty in_new_sale_qtty_nongli
from
	(
		select * from dev_dkx.mjt_user_amount_join1_2_d_v1 where qujian = 'benqi'
	)
	benqi
join
	(
		select * from dev_dkx.mjt_user_amount_join1_2_d_v1 where qujian = 'qunian'
	)
	qunian
on
	benqi.dept_name_3 = qunian.dept_name_3
join
	(
		select * from dev_dkx.mjt_user_amount_join1_2_d_v1 where qujian = 'nongli'
	)
	nongli
on
	benqi.dept_name_3 = nongli.dept_name_3;
"""
ht.exec_sql(
    schema_name = 'dev_dkx',
    sql=sql,
    table_name = 'mjt_user_amount_all_d_wide_table',
    merge_flag = True)
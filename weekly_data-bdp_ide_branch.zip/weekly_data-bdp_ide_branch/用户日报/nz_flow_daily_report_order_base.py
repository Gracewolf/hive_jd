#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import time
import datetime
import subprocess


sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day

sql_1 = """
--合并小文件
set hive.merge.mapfiles=true;
set hive.merge.mapredfiles = true;
set hive.merge.size.per.task = 256000000;
set hive.merge.smallfiles.avgsize = 256000000;
--存储压缩
set hive.default.fileformat=Orc;
--多线程并发
set hive.exec.parallel = true;
set hive.exec.parallel.thread.number = 8;
--列剪裁
set hive.optimize.cp = true;
set hive.optimize.pruner = true;
--map阶段优化
set mapred.max.split.size = 256000000;
set mapred.min.split.size.per.node = 256000000;
set mapred.min.split.size.per.rack = 256000000;
set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set hive.hadoop.supports.splittable.combineinputformat = true;
set mapreduce.input.fileinputformat.split.maxsize = 256000000;
set mapreduce.input.fileinputformat.split.minsize.per.node=256000000;
set mapreduce.input.fileinputformat.split.minsize.per.rack=256000000;
insert overwrite table dev_xfp.nz_flow_daily_report_order_base
select /*+ MAPJOIN(a)*/
    dept_id_2,
	dept_name_2,
	dept_id_3,
	dept_name_3,
	model,
	dt,
	sale_ord_id,
	sum(cw_gmv) gmv
from
	(
		select
			item_sku_id,
			item_id,
			dept_id_2,
			dept_name_2,
			dept_id_3,
			dept_name_3,
			case data_type
				when '1' then '自营'
				when '3' then 'POP'
			end model
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and dept_id_2 in('47', '1699')
	)
	a
left join
	(
		select
			item_id
		from
			gdm.gdm_m03_item_spec_attr_da
		where
			dt = sysdate( - 1)
			and attr_name in('factoryShip')
			and attr_val in('1')
	)
	c
on
	a.item_id = c.item_id
join
	(
		select
			dt,
			item_sku_id,
			sale_ord_id,
			cw_gmv
		from
			app.v_app_cmo_cw_ord_det_sum_rb
		where
			(
				(
					dt >= date_sub(sysdate( - 366), day(sysdate( - 1)) - 1)
					and dt <= sysdate( - 366)
				)
				or
				(
					dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1)
					and dt <= sysdate( - 1)
				)
				or
				(
				    dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1)
				    and dt <= sysdate(-385)
				)
				or
				(
					dt >= sysdate( - 372)
					and dt <= sysdate( - 366)
				)
				or
				(
					dt >= sysdate( - 7)
					and dt <= sysdate( - 1)
				)
				or
				(
					dt >= sysdate( - 391)
					and dt <= sysdate( - 385)
				)
			)
			and valid_flag = '1'
			and
			(
				(
					tp = '1'
					and substr(ord_flag, 40, 1) <> '1'
				) ----自营剔分销
				or
				(
					tp = '2'
					and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
				) ----POP剔赠品
			)
	)
	b
on
	a.item_sku_id = b.item_sku_id
where
	c.item_id is null
group by
    dept_id_2,
	dept_name_2,
	dept_id_3,
	dept_name_3,
	model,
	dt,
	sale_ord_id;
"""

ht.exec_sql(schema_name='dev_xfp', sql=sql_1, merge_flag=False)
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;
  
set hive.exec.parallel = true;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
set hive.map.aggr = true;
set hive.groupby.mapaggr.checkinterval = 100000;
set hive.auto.convert.join = true;

----内部归一化
drop table if exists dev_dkx.mjt_user_all2_d;
create
  table dev_dkx.mjt_user_all2_d STORED AS ORC tblproperties
  (
    'orc.compress' = 'SNAPPY'
  ) as
    select
      coalesce(d.user_log_acct, b.user_log_acct) user_log_acct,
      a.dept_id_3,
      a.dept_name_3,
      qujian
    from
	(
		select
			item_sku_id,
			item_id
			,dept_id_3,
			dept_name_3
		from
			dev_dkx.mjt_gdm_m03_sold_item_sku_da_xfp_d
	)
	a
    join
      (
        SELECT
							case
							    when dt = sysdate( - 1)
							    then 'benqi'
							    when dt = concat(year(sysdate( - 1)) - 1, if(substr(sysdate( - 1), 5) = '-02-29', '-03-01', substr(sysdate( - 1), 5)))
							    then 'qunian' -- 阳历日期做同比，遇到2月29号，则和去年3月1号做同比
							    when dt = sysdate( - 385)
							    then 'nongli' 
						    end qujian,
							item_sku_id,
							lower(trim(user_log_acct)) user_log_acct,
							sale_ord_id,
							parent_sale_ord_id,
							after_prefr_amount_1,
							sale_qtty
						FROM
							app.v_adm_d04_trade_ord_det_sku_snapshot_xfp
						WHERE
							(
						      dt = sysdate( - 1)
						      or dt = concat(year(sysdate( - 1)) - 1, if(substr(sysdate( - 1), 5) = '-02-29', '-03-01', substr(sysdate( - 1), 5)))
						      -- 阳历日期做同比，遇到2月29号，则和去年3月1号做同比
						      or  dt = sysdate( - 385)
					        )
							AND intraday_ord_deal_flag = '1' ----成交标记
							AND split_status_cd NOT IN('1') --排查拆单的父订单
							AND valid_flag = '1' --有效状态
							AND biz_flag_collect['int_pur_ord_flag'] <> 1 ----内采
							AND biz_flag_collect['dist_ord_flag'] <> 1---分销
							AND biz_flag_collect['corp_ord_flag'] <> 1-----企业订单
							AND biz_flag_collect['xtl_ord_flag'] <> 1 ----新通路
							AND virtual_ord_flag <> '1'---剔除虚拟订单
							and biz_flag_collect['yhd_ord_flag'] <> 1 ----一号店
      )
      b
    on
      a.item_sku_id = b.item_sku_id
    left join
      (
        select
          lower(trim(unif_user_log_acct)) user_log_acct,
          lower(trim(user_acct_name)) pin
        from
          gdm.gdm_m01_userinfo_basic_da
        where
          dt = sysdate( - 1)
      ) ----归一化用户pin
      d
    on
      b.user_log_acct = d.pin
    group by
      coalesce(d.user_log_acct, b.user_log_acct),
      a.dept_id_3,
      a.dept_name_3,
      qujian
"""
ht.exec_sql(
    schema_name = 'dev_dkx',
    sql=sql,
    table_name = 'mjt_user_all2_d',
    merge_flag = True)
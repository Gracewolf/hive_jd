#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;
  
set hive.exec.parallel = true;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
set hive.map.aggr = true;
set hive.groupby.mapaggr.checkinterval = 100000;
set hive.auto.convert.join = true;

----内部归一化
drop table if exists dev_dkx.mjt_model_user;
create
  table dev_dkx.mjt_model_user STORED AS ORC tblproperties
  (
    'orc.compress' = 'SNAPPY'
  ) as
  select
	a.year_dt 时间,
	a.dept_name,
	sum(1) 整体用户数,
	sum(case when par_ord_num >= 2 then 1 else 0 end) 复购用户数,
	sum(ord_num) 有效子单数,
	sum(par_ord_num) 有效父单数,
	sum(amount) 有效金额,
	sum(case when fst_all_yn = 1 then 1 else 0 end) 站外新用户数,
	sum(case when fst_all_yn = 1 then ord_num else 0 end) 站外新有效子单数,
	sum(case when fst_all_yn = 1 then par_ord_num else 0 end) 站外新有效父单数,
	sum(case when fst_all_yn = 1 then amount else 0.0 end) 站外新有效金额,
	sum(case when fst_all_yn = 0 then 1 else 0 end) 站内新用户数,
	sum(case when fst_all_yn = 0 then ord_num else 0 end) 站内新有效子单数,
	sum(case when fst_all_yn = 0 then par_ord_num else 0 end) 站内新有效父单数,
	sum(case when fst_all_yn = 0 then amount else 0.0 end) 站内新有效金额
from
	(
		select /*+ MAPJOIN(a)*/
			coalesce(d.unif_pin, b.pin) unif_pin,
			a.dept_name,
			year_dt,
			count(distinct parent_sale_ord_id) par_ord_num,
			count(distinct sale_ord_id) ord_num,
			sum(after_prefr_amount_1) amount
		from
			(
				select
					item_sku_id,
					item_id,
					case data_type
				when '1' then '自营'
				when '3' then 'POP'
			end dept_name
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in ('47')
			)
			a
		join
			(
		----有效订单模板
				select
					b.*
				from
					(
						select
							lower(trim(user_log_acct)) pin,
							item_sku_id,
							substr(sale_ord_dt,1,7) year_dt,
							parent_sale_ord_id,
							sale_ord_id,
							after_prefr_amount_1 ,
							check_account_tm,
							sale_qtty,
							sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
						from
							app.app_m04_ord_det_sum_xfp_mid
						where
							dt >= '2019-01-01'
							and
							(
								(
								    sale_ord_dt >= '2019-01-01'
								    and sale_ord_dt <= '2019-12-31'
								)									
							)
							and sale_ord_valid_flag = '1'
							and item_third_cate_cd not in('6980') --剔除礼品卡
							and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
							and
							(
								substr(ord_flag, 31, 1) <> '2' --非行政内采
								or
								(
									substr(ord_flag, 31, 1) = '2'
									and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
								)
							)
							and
							(
								substr(ord_flag, 46, 1) not in('1', '2', '3', '7')
								or substr(ord_flag, 60, 3) not in('013')
							)
							and sale_ord_type_cd <> '68' --剔除拍卖
							and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
							and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
							and user_log_acct not like 'ept%'
							and free_goods_flag = 0
					)
					b
				where
					b.ord_amount < 100000
					or
					(
						b.ord_amount >= 100000
						and coalesce(b.check_account_tm, '') <> ''
					)
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		left join
			(
				select
					lower(trim(unif_user_log_acct)) unif_pin,
					lower(trim(user_acct_name)) pin
				from
					gdm.gdm_m01_userinfo_basic_da
				where
					dt = sysdate( - 1)
			) ----归一化用户pin
			d
		on
			b.pin = d.pin
		group by
			coalesce(d.unif_pin, b.pin),
            a.dept_name,
			year_dt
	)
	a
left join
	(
		select
			x.unif_pin,
			x.fst_all_yn,
			substr(fst_ord_dt,1,7) year_dt
		from
			(
				select
					lower(trim(unif_user_log_acct)) unif_pin,
					max(
						case
							when fst_all_yn = 1
							then 1
							else 0
						end) fst_all_yn,
					min(fst_ord_dt) fst_ord_dt
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 2)
					and tp = 'dept'
				group by
					lower(trim(unif_user_log_acct))
			)
			x
		where
			(
			    (
				    fst_ord_dt >= '2019-01-01'
				    and fst_ord_dt <= '2019-12-31'
				)			
			)
	)
	b
on
	b.unif_pin = a.unif_pin
	and b.year_dt = a.year_dt
left join
	(
		select
            lower(trim(unif_user_log_acct)) unif_pin,
            spite_user_flag
        from
            app.v_adm_s01_user_new_or_old_flag_detail_xfp
        where
            dt = sysdate(-2)
            and spite_user_flag = 1
        group by
            lower(trim(unif_user_log_acct)),
            spite_user_flag
	)
	c
on
	a.unif_pin = c.unif_pin
where
	c.unif_pin is null
group by
	a.year_dt,
    a.dept_name	
	
union all

select
	a.year_dt 时间,
	a.dept_name,
	sum(1) 整体用户数,
	sum(case when par_ord_num >= 2 then 1 else 0 end) 复购用户数,
	sum(ord_num) 有效子单数,
	sum(par_ord_num) 有效父单数,
	sum(amount) 有效金额,
	sum(case when fst_all_yn = 1 then 1 else 0 end) 站外新用户数,
	sum(case when fst_all_yn = 1 then ord_num else 0 end) 站外新有效子单数,
	sum(case when fst_all_yn = 1 then par_ord_num else 0 end) 站外新有效父单数,
	sum(case when fst_all_yn = 1 then amount else 0.0 end) 站外新有效金额,
	sum(case when fst_all_yn = 0 then 1 else 0 end) 站内新用户数,
	sum(case when fst_all_yn = 0 then ord_num else 0 end) 站内新有效子单数,
	sum(case when fst_all_yn = 0 then par_ord_num else 0 end) 站内新有效父单数,
	sum(case when fst_all_yn = 0 then amount else 0.0 end) 站内新有效金额
from
	(
		select /*+ MAPJOIN(a)*/
			coalesce(d.unif_pin, b.pin) unif_pin,
			a.dept_name,
			year_dt,
			count(distinct parent_sale_ord_id) par_ord_num,
			count(distinct sale_ord_id) ord_num,
			sum(after_prefr_amount_1) amount
		from
			(
				select
					item_sku_id,
					item_id,
					case data_type
				when '1' then '自营'
				when '3' then 'POP'
			end dept_name
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in ('47')
			)
			a
		join
			(
		----有效订单模板
				select
					b.*
				from
					(
						select
							lower(trim(user_log_acct)) pin,
							item_sku_id,
							substr(sale_ord_dt,1,7) year_dt,
							parent_sale_ord_id,
							sale_ord_id,
							after_prefr_amount_1 ,
							check_account_tm,
							sale_qtty,
							sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
						from
							app.app_m04_ord_det_sum_xfp_mid
						where
							dt >= '2020-01-01'
							and
							(
								(
								    sale_ord_dt >= '2020-01-01'
								    and sale_ord_dt <= '2020-12-31'
								)									
							)
							and sale_ord_valid_flag = '1'
							and item_third_cate_cd not in('6980') --剔除礼品卡
							and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
							and
							(
								substr(ord_flag, 31, 1) <> '2' --非行政内采
								or
								(
									substr(ord_flag, 31, 1) = '2'
									and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
								)
							)
							and
							(
								substr(ord_flag, 46, 1) not in('1', '2', '3', '7')
								or substr(ord_flag, 60, 3) not in('013')
							)
							and sale_ord_type_cd <> '68' --剔除拍卖
							and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
							and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
							and user_log_acct not like'ept%'
							and free_goods_flag = 0
					)
					b
				where
					b.ord_amount < 100000
					or
					(
						b.ord_amount >= 100000
						and coalesce(b.check_account_tm, '') <> ''
					)
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		left join
			(
				select
					lower(trim(unif_user_log_acct)) unif_pin,
					lower(trim(user_acct_name)) pin
				from
					gdm.gdm_m01_userinfo_basic_da
				where
					dt = sysdate( - 1)
			) ----归一化用户pin
			d
		on
			b.pin = d.pin
		group by
			coalesce(d.unif_pin, b.pin),
            a.dept_name,
			year_dt
	)
	a
left join
	(
		select
			x.unif_pin,
			x.fst_all_yn,
			substr(fst_ord_dt,1,7) year_dt
		from
			(
				select
					lower(trim(unif_user_log_acct)) unif_pin,
					max(
						case
							when fst_all_yn = 1
							then 1
							else 0
						end) fst_all_yn,
					min(fst_ord_dt) fst_ord_dt
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 2)
					and tp = 'dept'
				group by
					lower(trim(unif_user_log_acct))
			)
			x
		where
			(
			    (
				    fst_ord_dt >= '2020-01-01'
				    and fst_ord_dt <= '2020-12-31'
				)			
			)
	)
	b
on
	b.unif_pin = a.unif_pin
	and b.year_dt = a.year_dt
left join
	(
		select
            lower(trim(unif_user_log_acct)) unif_pin,
            spite_user_flag
        from
            app.v_adm_s01_user_new_or_old_flag_detail_xfp
        where
            dt = sysdate(-2)
            and spite_user_flag = 1
        group by
            lower(trim(unif_user_log_acct)),
            spite_user_flag
	)
	c
on
	a.unif_pin = c.unif_pin
where
	c.unif_pin is null
group by
	a.year_dt,
    a.dept_name		
	
union all

select
	a.year_dt 时间,
	a.dept_name,
	sum(1) 整体用户数,
	sum(case when par_ord_num >= 2 then 1 else 0 end) 复购用户数,
	sum(ord_num) 有效子单数,
	sum(par_ord_num) 有效父单数,
	sum(amount) 有效金额,
	sum(case when fst_all_yn = 1 then 1 else 0 end) 站外新用户数,
	sum(case when fst_all_yn = 1 then ord_num else 0 end) 站外新有效子单数,
	sum(case when fst_all_yn = 1 then par_ord_num else 0 end) 站外新有效父单数,
	sum(case when fst_all_yn = 1 then amount else 0.0 end) 站外新有效金额,
	sum(case when fst_all_yn = 0 then 1 else 0 end) 站内新用户数,
	sum(case when fst_all_yn = 0 then ord_num else 0 end) 站内新有效子单数,
	sum(case when fst_all_yn = 0 then par_ord_num else 0 end) 站内新有效父单数,
	sum(case when fst_all_yn = 0 then amount else 0.0 end) 站内新有效金额
from
	(
		select /*+ MAPJOIN(a)*/
			coalesce(d.unif_pin, b.pin) unif_pin,
			a.dept_name,
			year_dt,
			count(distinct parent_sale_ord_id) par_ord_num,
			count(distinct sale_ord_id) ord_num,
			sum(after_prefr_amount_1) amount
		from
			(
				select
					item_sku_id,
					item_id,
					case data_type
				when '1' then '自营'
				when '3' then 'POP'
			end dept_name
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in ('47')
			)
			a
		join
			(
		----有效订单模板
				select
					b.*
				from
					(
						select
							lower(trim(user_log_acct)) pin,
							item_sku_id,
							substr(sale_ord_dt,1,7) year_dt,
							parent_sale_ord_id,
							sale_ord_id,
							after_prefr_amount_1 ,
							check_account_tm,
							sale_qtty,
							sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
						from
							app.app_m04_ord_det_sum_xfp_mid
						where
							dt >= '2018-01-01'
							and
							(
								(
								    sale_ord_dt >= '2018-01-01'
								    and sale_ord_dt <= '2018-12-31'
								)									
							)
							and sale_ord_valid_flag = '1'
							and item_third_cate_cd not in('6980') --剔除礼品卡
							and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
							and
							(
								substr(ord_flag, 31, 1) <> '2' --非行政内采
								or
								(
									substr(ord_flag, 31, 1) = '2'
									and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
								)
							)
							and
							(
								substr(ord_flag, 46, 1) not in('1', '2', '3', '7')
								or substr(ord_flag, 60, 3) not in('013')
							)
							and sale_ord_type_cd <> '68' --剔除拍卖
							and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
							and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
							and user_log_acct not like'ept%'
							and free_goods_flag = 0
					)
					b
				where
					b.ord_amount < 100000
					or
					(
						b.ord_amount >= 100000
						and coalesce(b.check_account_tm, '') <> ''
					)
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		left join
			(
				select
					lower(trim(unif_user_log_acct)) unif_pin,
					lower(trim(user_acct_name)) pin
				from
					gdm.gdm_m01_userinfo_basic_da
				where
					dt = sysdate( - 1)
			) ----归一化用户pin
			d
		on
			b.pin = d.pin
		group by
			coalesce(d.unif_pin, b.pin),
            a.dept_name,
			year_dt
	)
	a
left join
	(
		select
			x.unif_pin,
			x.fst_all_yn,
			substr(fst_ord_dt,1,7) year_dt
		from
			(
				select
					lower(trim(unif_user_log_acct)) unif_pin,
					max(
						case
							when fst_all_yn = 1
							then 1
							else 0
						end) fst_all_yn,
					min(fst_ord_dt) fst_ord_dt
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 2)
					and tp = 'dept'
				group by
					lower(trim(unif_user_log_acct))
			)
			x
		where
			(
			    (
				    fst_ord_dt >= '2018-01-01'
				    and fst_ord_dt <= '2018-12-31'
				)			
			)
	)
	b
on
	b.unif_pin = a.unif_pin
	and b.year_dt = a.year_dt
left join
	(
		select
            lower(trim(unif_user_log_acct)) unif_pin,
            spite_user_flag
        from
            app.v_adm_s01_user_new_or_old_flag_detail_xfp
        where
            dt = sysdate(-2)
            and spite_user_flag = 1
        group by
            lower(trim(unif_user_log_acct)),
            spite_user_flag
	)
	c
on
	a.unif_pin = c.unif_pin
where
	c.unif_pin is null
group by
	a.year_dt,
    a.dept_name;
"""
ht.exec_sql(
    schema_name = 'dev_dkx',
    sql=sql,
    table_name = 'mjt_model_user',
    merge_flag = True)	
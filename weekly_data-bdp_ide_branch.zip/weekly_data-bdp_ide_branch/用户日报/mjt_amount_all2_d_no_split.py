#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;
  
set hive.exec.parallel = true;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
set hive.map.aggr = true;
set hive.groupby.mapaggr.checkinterval = 100000;
set hive.auto.convert.join = true;

----内部归一化
drop table if exists dev_dkx.mjt_amount_all2_d_no_split;
create
  table dev_dkx.mjt_amount_all2_d_no_split STORED AS ORC tblproperties
  (
    'orc.compress' = 'SNAPPY'
  ) as
select
	a.qujian,
	b.pin,
	a.dept_id_3,
	a.dept_name_3,
	b.fst_all_yn,
	a.sale_order_id,
	sum(a.item_qtty) item_qtty,
	sum(a.gmv_sum) gmv_sum
from
	(
		select
			qujian,
			dept_id_3,
			dept_name_3,
			sale_order_id,
			item_qtty,
			gmv_sum
		from
			dev_dkx.mjt_amount_all2_d
	)
	a
left join
	(
		SELECT
			x.pin,
			x.dept_id_3,
			x.fst_all_yn,
			x.sale_ord_id,
			(
				case
					when fst_ord_dt = sysdate( - 1)
					then 'benqi'
					when fst_ord_dt = add_months(sysdate( - 1), - 12)
					then 'qunian'
					when fst_ord_dt = sysdate( - 385)
					then 'nongli'
				end) qujian
		FROM
			(
				SELECT
					lower(trim(unif_user_log_acct)) pin,
					dept_id_3,
					fst_ord_tm, --首单订购时间
					fst_ord_dt, --首单订购日期
					sale_ord_id,
					spite_user_flag,
					MAX(
						CASE fst_all_yn
							WHEN '1'
							THEN 1
							ELSE 0
						END) over(partition BY lower(trim(unif_user_log_acct)), dept_name_1) AS fst_all_yn,
					MIN(fst_ord_tm) over(partition BY lower(trim(unif_user_log_acct)), dept_name_1) AS min_fst_ord_tm
				FROM
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				WHERE
					dt = sysdate( - 1)
					AND tp = 'dept'
			)
			x
		WHERE
			fst_ord_tm = min_fst_ord_tm
			AND
			(
				fst_ord_dt = sysdate( - 1)
				or fst_ord_dt = add_months(sysdate( - 1), - 12)
				or fst_ord_dt = sysdate( - 385)
			)
	)
	b
on
	b.sale_ord_id = a.sale_order_id
	and b.qujian = a.qujian
	and a.dept_id_3 = b.dept_id_3
group by
	a.qujian,
	b.pin,
	a.dept_id_3,
	a.dept_name_3,
	b.fst_all_yn,
	a.sale_order_id;
"""
ht.exec_sql(
    schema_name = 'dev_dkx',
    sql=sql,
    table_name = 'mjt_amount_all2_d_no_split',
    merge_flag = True)
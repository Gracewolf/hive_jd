#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;
  
set hive.exec.parallel = true;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
set hive.map.aggr = true;
set hive.groupby.mapaggr.checkinterval = 100000;
set hive.auto.convert.join = true;

----内部归一化
drop table if exists dev_dkx.mjt_amount_all1_d_split;
create
  table dev_dkx.mjt_amount_all1_d_split STORED AS ORC tblproperties
  (
    'orc.compress' = 'SNAPPY'
  ) as
select
	sysdate( - 1) benqi_dt,
	a.qujian,
	'47' dept_id_3,
	'干货食品部' dept_name_3,
	count(distinct sale_order_id) ord_num,
	sum(gmv_sum) gmv_sum,
	sum(item_qtty) item_qtty,
	count(distinct
	case
		when fst_all_yn = 1
		then sale_order_id
		else null
	end) out_new_ord_num,
	sum(
		case
			when fst_all_yn = 1
			then gmv_sum
			else 0.0
		end) out_new_amount,
	sum(
		case
			when fst_all_yn = 1
			then item_qtty
			else 0.0
		end) out_new_sale_qtty,
	count(distinct
	case
		when fst_all_yn = 0
		then sale_order_id
		else null
	end) in_new_ord_num,
	sum(
		case
			when fst_all_yn = 0
			then gmv_sum
			else 0.0
		end) in_new_amount,
	sum(
		case
			when fst_all_yn = 0
			then item_qtty
			else 0.0
		end) in_new_sale_qtty
from
(select
	qujian,
	pin,
	fst_all_yn,
	sale_order_id,
	item_qtty,
	gmv_sum
from dev_dkx.mjt_amount_all1_d_no_split
) a
left join
	(
		select
			lower(trim(unif_user_log_acct)) user_log_acct
		from
			dev_dkx.gx_spite_user_list_xfp_d
	)
	c
on
	a.pin = c.user_log_acct
where
	c.user_log_acct is null
group by
	a.qujian;
"""
ht.exec_sql(
    schema_name = 'dev_dkx',
    sql=sql,
    table_name = 'mjt_amount_all1_d_split',
    merge_flag = True)
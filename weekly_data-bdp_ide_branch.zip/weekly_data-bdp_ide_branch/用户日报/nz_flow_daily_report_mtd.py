#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import time
import datetime
import subprocess


sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day

sql_1 = """
--合并小文件
set hive.merge.mapfiles=true;
set hive.merge.mapredfiles = true;
set hive.merge.size.per.task = 256000000;
set hive.merge.smallfiles.avgsize = 256000000;
--存储压缩
set hive.default.fileformat=Orc;
--多线程并发
set hive.exec.parallel = true;
set hive.exec.parallel.thread.number = 8;
--列剪裁
set hive.optimize.cp = true;
set hive.optimize.pruner = true;
--map阶段优化
set mapred.max.split.size = 256000000;
set mapred.min.split.size.per.node = 256000000;
set mapred.min.split.size.per.rack = 256000000;
set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set hive.hadoop.supports.splittable.combineinputformat = true;
set mapreduce.input.fileinputformat.split.maxsize = 256000000;
set mapreduce.input.fileinputformat.split.minsize.per.node=256000000;
set mapreduce.input.fileinputformat.split.minsize.per.rack=256000000;
drop
	table if exists dev_xfp.nz_flow_daily_report_mtd;
create
	table dev_xfp.nz_flow_daily_report_mtd STORED AS ORC tblproperties
	(
		'orc.compress' = 'SNAPPY'
	) as
select
	dept_name,
	pv,
	pv / pv_1 - 1 PV同比,
	pv / pv_2 - 1 PV农历同比,
	uv,
	uv / uv_1 - 1 uv同比,
	uv / uv_2 - 1 uv农历同比,
	ord_num / uv uv转化率,
	(ord_num / uv) / (ord_num_1 / uv_1) - 1 uv转化率同比,
	(ord_num / uv) / (ord_num_2 / uv_2) - 1 uv转化率农历同比,
	gmv / uv uv价值,
	(gmv / uv) / (gmv_1 / uv_1) - 1 uv价值同比,
	(gmv / uv) / (gmv_2 / uv_2) - 1 uv价值农历同比
from
	(
		select
			dept_name,
			sum(case when dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1) and dt <= sysdate( - 1) then pv else 0 end) pv,
			sum(case when dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1) and dt <= sysdate( - 1) then uv else 0 end) uv,
			sum(case when dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1) and dt <= sysdate( - 1) then ord_num else 0 end) ord_num,
			sum(case when dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1) and dt <= sysdate( - 1) then gmv else 0 end) gmv,
			sum(case when dt >= date_sub(sysdate( - 366), day(sysdate( - 1)) - 1) and dt <= sysdate( - 366) then pv else 0 end) pv_1,
			sum(case when dt >= date_sub(sysdate( - 366), day(sysdate( - 1)) - 1) and dt <= sysdate( - 366) then uv else 0 end) uv_1,
			sum(case when dt >= date_sub(sysdate( - 366), day(sysdate( - 1)) - 1) and dt <= sysdate( - 366) then ord_num else 0 end) ord_num_1,
			sum(case when dt >= date_sub(sysdate( - 366), day(sysdate( - 1)) - 1) and dt <= sysdate( - 366) then gmv else 0 end) gmv_1,
			sum(case when dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1) and dt <= sysdate( - 385) then pv else 0 end) pv_2,
			sum(case when dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1) and dt <= sysdate( - 385) then uv else 0 end) uv_2,
			sum(case when dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1) and dt <= sysdate( - 385) then ord_num else 0 end) ord_num_2,
			sum(case when dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1) and dt <= sysdate( - 385) then gmv else 0 end) gmv_2
		from
			(
				select
					coalesce(a.dept_name, b.dept_name) dept_name,
					coalesce(a.dt, b.dt) dt,
					pv,
					uv,
					ord_num,
					gmv	
				from
					(
						select
							dept_name_2 dept_name,
                            dt,
							count(distinct sale_ord_id) ord_num,
							sum(gmv) gmv
						from
							dev_xfp.nz_flow_daily_report_order_base
						where
						(
							(
								dt >= date_sub(sysdate( - 366), day(sysdate( - 1)) - 1)
								and dt <= sysdate( - 366)
							)
							or
							(
								dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1)
								and dt <= sysdate( - 1)
							)
							or
							(
								dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1)
								and dt <= sysdate( - 385)
							)
                        )							
						group by
							dept_name_2,
							dt
					)
					a
				full outer join
					(
						select
							dept_name_2 dept_name,
							dt,
							count(distinct browser_uniq_id) uv,
							sum(pv) pv
						from
							dev_xfp.nz_flow_daily_report_view_base
						where
						(	
							(
								dt >= date_sub(sysdate( - 366), day(sysdate( - 1)) - 1)
								and dt <= sysdate( - 366)
							)
							or
							(
								dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1)
								and dt <= sysdate( - 1)
							)
							or
							(
							    dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1)
								and dt <= sysdate( - 385)
							)
                        ) 							
						group by
							dept_name_2,
							dt
					)
					b
				on
					a.dept_name = b.dept_name
					and a.dt = b.dt
			)
			ff
		group by
			dept_name
	)
	ff

union all

select
	dept_name,
	pv,
	pv / pv_1 - 1 PV同比,
	pv / pv_2 - 1 PV农历同比,
	uv,
	uv / uv_1 - 1 uv同比,
	uv / uv_2 - 1 uv农历同比,
	ord_num / uv uv转化率,
	(ord_num / uv) / (ord_num_1 / uv_1) - 1 uv转化率同比,
	(ord_num / uv) / (ord_num_2 / uv_2) - 1 uv转化率农历同比,
	gmv / uv uv价值,
	(gmv / uv) / (gmv_1 / uv_1) - 1 uv价值同比,
	(gmv / uv) / (gmv_2 / uv_2) - 1 uv价值农历同比
from
	(
		select
			dept_name,
			sum(case when dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1) and dt <= sysdate( - 1) then pv else 0 end) pv,
			sum(case when dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1) and dt <= sysdate( - 1) then uv else 0 end) uv,
			sum(case when dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1) and dt <= sysdate( - 1) then ord_num else 0 end) ord_num,
			sum(case when dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1) and dt <= sysdate( - 1) then gmv else 0 end) gmv,
			sum(case when dt >= date_sub(sysdate( - 366), day(sysdate( - 1)) - 1) and dt <= sysdate( - 366) then pv else 0 end) pv_1,
			sum(case when dt >= date_sub(sysdate( - 366), day(sysdate( - 1)) - 1) and dt <= sysdate( - 366) then uv else 0 end) uv_1,
			sum(case when dt >= date_sub(sysdate( - 366), day(sysdate( - 1)) - 1) and dt <= sysdate( - 366) then ord_num else 0 end) ord_num_1,
			sum(case when dt >= date_sub(sysdate( - 366), day(sysdate( - 1)) - 1) and dt <= sysdate( - 366) then gmv else 0 end) gmv_1,
			sum(case when dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1) and dt <= sysdate( - 385) then pv else 0 end) pv_2,
			sum(case when dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1) and dt <= sysdate( - 385) then uv else 0 end) uv_2,
			sum(case when dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1) and dt <= sysdate( - 385) then ord_num else 0 end) ord_num_2,
			sum(case when dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1) and dt <= sysdate( - 385) then gmv else 0 end) gmv_2
		from
			(
				select
					coalesce(a.dept_name, b.dept_name) dept_name,
					coalesce(a.dt, b.dt) dt,
					pv,
					uv,
					ord_num,
					gmv	
				from
					(
						select
							dept_name_3 dept_name,
							dt,
							count(distinct sale_ord_id) ord_num,
							sum(gmv) gmv
						from
							dev_xfp.nz_flow_daily_report_order_base
						where
						(
							(
								dt >= date_sub(sysdate( - 366), day(sysdate( - 1)) - 1)
								and dt <= sysdate( - 366)
							)
							or
							(
								dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1)
								and dt <= sysdate( - 1)
							)
							or
							(
							    dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1)
								and dt <= sysdate( - 385)
							 )  
						)
						group by
							dept_name_3,
							dt
					)
					a
				full outer join
					(
						select
							dept_name_3 dept_name,
							dt,
							count(distinct browser_uniq_id) uv,
							sum(pv) pv
						from
							dev_xfp.nz_flow_daily_report_view_base
						where
							(
								(
									dt >= date_sub(sysdate( - 366), day(sysdate( - 1)) - 1)
									and dt <= sysdate( - 366)
								)
								or
								(
									dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1)
									and dt <= sysdate( - 1)
								)
								or
							    (
							        dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1)
								    and dt <= sysdate( - 385)
							    ) 
							)
						group by
							dept_name_3,
							dt
					)
					b
				on
					a.dept_name = b.dept_name
					and a.dt = b.dt
			)
			ff
		group by
			dept_name
	)
	ff;
"""

ht.exec_sql(schema_name='dev_xfp', sql=sql_1, merge_flag=False)
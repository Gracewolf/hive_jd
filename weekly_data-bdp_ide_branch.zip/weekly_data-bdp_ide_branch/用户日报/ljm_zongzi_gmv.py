#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;
  
set hive.exec.parallel = true;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
set hive.map.aggr = true;
set hive.groupby.mapaggr.checkinterval = 100000;
set hive.auto.convert.join = true;

----内部归一化
DROP TABLE if exists dev_xfp.ljm_zongzi_gmv;
CREATE
	TABLE dev_xfp.ljm_zongzi_gmv STORED AS ORC tblproperties
	(
		'orc.compress' = 'SNAPPY'
	) as
select
substr(b.op_time, 1, 10) 统计日期,
 a.data_type 模式,
 a.dept_id_1 一级部门ID,
 a.dept_name_1 一级部门,
 a.dept_id_2 二级部门ID,
 a.dept_name_2 二级部门,
 a.dept_id_3 三级部门ID,
 a.dept_name_3 三级部门,
 a.item_first_cate_cd 一级分类代码,
 a.item_first_cate_name 一级分类,
 a.item_second_cate_cd 二级分类代码,
 a.item_second_cate_name 二级分类,
 a.item_third_cate_cd 三级分类代码,
 a.item_third_cate_name 三级分类,
  a.brand_code 品牌id,
 a.barndname_full 品牌,
 sum(cw_gmv) GMV,
 sum(cw_quantity) 销量
from
 (
  select
   item_sku_id,
   regexp_replace(regexp_replace(trim(sku_name), '"', ''), ',', '，') sku_name,
   data_type,
   major_item_first_cate_id,
   item_first_cate_cd,
   regexp_replace(regexp_replace(trim(item_first_cate_name), '"', ''), ',', '，') item_first_cate_name,
   item_second_cate_cd,
   regexp_replace(regexp_replace(trim(item_second_cate_name), '"', ''), ',', '，') item_second_cate_name,
   item_third_cate_cd,
   regexp_replace(regexp_replace(trim(item_third_cate_name), '"', ''), ',', '，') item_third_cate_name,
   item_last_cate_cd,
   regexp_replace(regexp_replace(trim(item_last_cate_name), '"', ''), ',', '，') item_last_cate_name,
   brand_code,
   regexp_replace(regexp_replace(trim(barndname_full), '"', ''), ',', '，') barndname_full,
   major_supp_brevity_code,
   major_supp_name,
   pop_vender_id,
   pop_vender_name,
   sku_status_cd ,
            vender_direct_delv_flag ,
   shop_id,
   shop_name,
   pop_operator_erp_acct,
   saler_erp_acct,
   sale_staf_name,
   dept_id_1,
   dept_name_1,
   dept_id_2,
   dept_name_2,
   dept_id_3,
   dept_name_3,
   dept_id_4,
   dept_name_4,
   purchaser_erp_acct,
   purchaser_name,
   otc_tm,
   utc_tm,
   sku_valid_flag,
   jd_prc,
   mkt_prc
  from
   gdm.gdm_m03_sold_item_sku_da
  where
   dt =sysdate(-1)
   and data_type in('1','3')
   and dept_id_1 in('33')
   and item_third_cate_name like'%粽子%'
 )
 a
join
 (
  select
   op_time,
   sale_ord_id,
   parent_sale_ord_id,
   cw_ord_type_cd,
   sale_ord_type_cd,
   user_log_acct,
   user_place_ord_lv_cd,
   item_second_cate_cd,
   rev_addr_province_id,
   sku_freight_amount,
   rebateamount,
   cw_gross_profit,
   advertising_income,
   ord_flag,
   valid_flag,
   cx_dept_id,
   cw_gmv,
   item_sku_id,
   cw_quantity
  from
   app.v_app_cmo_cw_ord_det_sum_rb
  where

    (dt >= '2020-04-01'
    and dt <= '2020-06-30')
 )
 b
on
 a.item_sku_id = b.item_sku_id
group by
 substr(b.op_time, 1, 10) ,
 a.data_type ,
 a.dept_id_1 ,
 a.dept_name_1 ,
 a.dept_id_2 ,
 a.dept_name_2 ,
 a.dept_id_3 ,
 a.dept_name_3 ,
 a.item_first_cate_cd ,
 a.item_first_cate_name ,
 a.item_second_cate_cd ,
 a.item_second_cate_name ,
 a.item_third_cate_cd ,
 a.item_third_cate_name ,
  a.brand_code ,
 a.barndname_full;
"""
ht.exec_sql(
    schema_name = 'dev_xfp',
    sql=sql,
    table_name = 'ljm_zongzi_gmv',
    merge_flag = True)
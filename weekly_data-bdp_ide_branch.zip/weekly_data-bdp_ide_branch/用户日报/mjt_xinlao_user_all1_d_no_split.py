#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;
  
set hive.exec.parallel = true;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
set hive.map.aggr = true;
set hive.groupby.mapaggr.checkinterval = 100000;
set hive.auto.convert.join = true;

----内部归一化
drop table if exists dev_dkx.mjt_xinlao_user_all1_d_no_split;
create
  table dev_dkx.mjt_xinlao_user_all1_d_no_split STORED AS ORC tblproperties
  (
    'orc.compress' = 'SNAPPY'
  ) as
select
	a.user_log_acct,
	a.qujian,
	a.dept_id_2,
	a.dept_name_2,
	b.fst_all_yn
from
	(
		select
			/*+ MAPJOIN(a)*/
			user_log_acct,
			dept_id_2,
			dept_name_2,
			qujian
		from
			dev_dkx.mjt_user_all1_d
	)
	a
left join
	(
		select
			dept_id_2,
			x.user_log_acct,
			x.fst_all_yn,
			(
				case
					when fst_ord_dt = sysdate( - 1)
					then 'benqi'
					when fst_ord_dt = concat(year(sysdate( - 1)) - 1, if(substr(sysdate( - 1), 5) = '-02-29', '-03-01', substr(sysdate( - 1), 5)))
					then 'qunian' -- 阳历日期做同比，遇到2月29号，则和去年3月1号做同比
					when fst_ord_dt = sysdate( - 385)
					then 'nongli'
				end) qujian
		from
			(
				select
					dept_id_2,
					lower(trim(unif_user_log_acct)) user_log_acct,
					max(
						case
							when fst_all_yn = 1
							then 1
							else 0
						end) fst_all_yn,
					min(fst_ord_dt) fst_ord_dt
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 1)
					and tp = 'dept'
				group by
					dept_id_2,
					lower(trim(unif_user_log_acct))
			)
			x
		where
			(
				fst_ord_dt = sysdate( - 1)
				or fst_ord_dt = concat(year(sysdate( - 1)) - 1, if(substr(sysdate( - 1), 5) = '-02-29', '-03-01', substr(sysdate( - 1), 5)))
				-- 阳历日期做同比，遇到2月29号，则和去年3月1号做同比
				or fst_ord_dt = sysdate( - 385)
			)
	)
	b
on
	b.user_log_acct = a.user_log_acct
	and b.qujian = a.qujian
	and a.dept_id_2 = b.dept_id_2
group by
	a.user_log_acct,
	a.qujian,
	a.dept_id_2,
	a.dept_name_2,
	b.fst_all_yn;
"""
ht.exec_sql(
    schema_name = 'dev_dkx',
    sql=sql,
    table_name = 'mjt_xinlao_user_all1_d_no_split',
    merge_flag = True)
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;

set hive.exec.parallel = true;

drop
	table if exists dev_dkx.mjt_food_dept3_yonghu_day;
create
	table dev_dkx.mjt_food_dept3_yonghu_day STORED AS ORC tblproperties
	(
		'orc.compress' = 'SNAPPY'
	) as
SELECT
	dept_name_3,
	zuorizongyonghu,
	zuorilaoyonghu,
	zuorixinyonghu,
	zuorizhanwaixin,
	zuorizhanneixin,
	zuorizongyonghu/qunianzongyonghu - 1 zongyonghutongbi,
	zuorilaoyonghu/qunianlaoyonghu - 1 laoyonghutongbi,
	zuorixinyonghu/qunianxinyonghu - 1 xinyonghutongbi,
	zuorizhanwaixin/qunianzhanwaixin - 1 zhanwaixintongbi,
	zuorizhanneixin/qunianzhanneixin - 1 zhanneixintongbi
FROM
	(
		SELECT
			a.dept_name_3,
			COUNT(DISTINCT
			CASE
				WHEN a.qujian = 'benqi'
				THEN a.user_log_acct
				ELSE NULL
			END) zuorizongyonghu,
			COUNT(DISTINCT
			CASE
				WHEN a.qujian = 'qunian'
				THEN a.user_log_acct
				ELSE NULL
			END) qunianzongyonghu,
			COUNT(DISTINCT
			CASE
				WHEN a.qujian = 'benqi'
				THEN a.user_log_acct
				ELSE NULL
			END) - COUNT(DISTINCT
			CASE
				WHEN fst_all_yn IN('0', '1')
					AND a.qujian = 'benqi'
				THEN a.user_log_acct
				ELSE NULL
			END) zuorilaoyonghu,
			COUNT(DISTINCT
			CASE
				WHEN a.qujian = 'qunian'
				THEN a.user_log_acct
				ELSE NULL
			END) - COUNT(DISTINCT
			CASE
				WHEN fst_all_yn IN('0', '1')
					AND a.qujian = 'qunian'
				THEN a.user_log_acct
				ELSE NULL
			END) qunianlaoyonghu,
			COUNT(DISTINCT
			CASE
				WHEN fst_all_yn IN('0', '1')
					AND a.qujian = 'benqi'
				THEN a.user_log_acct
				ELSE NULL
			END) zuorixinyonghu,
			COUNT(DISTINCT
			CASE
				WHEN fst_all_yn IN('0', '1')
					AND a.qujian = 'qunian'
				THEN a.user_log_acct
				ELSE NULL
			END) qunianxinyonghu,
			COUNT(DISTINCT
			CASE
				WHEN fst_all_yn = 1
					AND a.qujian = 'benqi'
				THEN a.user_log_acct
				ELSE NULL
			END) zuorizhanwaixin,
			COUNT(DISTINCT
			CASE
				WHEN fst_all_yn = 1
					AND a.qujian = 'qunian'
				THEN a.user_log_acct
				ELSE NULL
			END) qunianzhanwaixin,
			COUNT(DISTINCT
			CASE
				WHEN fst_all_yn = 0
					AND a.qujian = 'benqi'
				THEN a.user_log_acct
				ELSE NULL
			END) zuorizhanneixin,
			COUNT(DISTINCT
			CASE
				WHEN fst_all_yn = 0
					AND a.qujian = 'qunian'
				THEN a.user_log_acct
				ELSE NULL
			END) qunianzhanneixin
		FROM
			(
				SELECT
					/*+ MAPJOIN(a)*/
					COALESCE(d.user_log_acct, b.user_log_acct) user_log_acct,
					a.dept_id_2,
					a.dept_name_2,
					a.dept_id_3,
					a.dept_name_3,
					qujian,
					parent_sale_ord_id,
					sale_ord_id,
					after_prefr_amount,
					after_prefr_amount_1,
					before_prefr_amount,
					total_offer_amount,
					sale_qtty
				FROM
					(
						SELECT
							item_sku_id,
							item_id,
							dept_id_2,
							dept_name_2,
							dept_id_3,
							dept_name_3
						FROM
							gdm.gdm_m03_sold_item_sku_da
						WHERE
							dt = sysdate( - 1)
							AND dept_name_1 = '消费品事业部'
							AND dept_id_2 = '47'
							AND dept_name_3 in ('3842','989','3816','3836','966','4159','3840','4046','4044','3814','141','147','3818','985','4165','3838','433','3824','3826','4161','4162','4157','3828','3830')
					)
					a
				JOIN
					(
						----有效订单模板
						SELECT
							b.*
						FROM
							(
								SELECT
									lower(trim(user_log_acct)) user_log_acct,
									item_sku_id,
									(
										CASE
											WHEN sale_ord_dt = sysdate( - 1)
											THEN 'benqi'
											WHEN sale_ord_dt = concat(YEAR(sysdate( - 1)) - 1, IF(SUBSTR(sysdate( - 1), 5) = '-02-29', '-03-01', SUBSTR(sysdate( - 1), 5)))
											THEN 'qunian' -- 阳历日期做同比，遇到2月29号，则和去年3月1号做同比
											WHEN sale_ord_dt = sysdate( - 2)
											THEN 'shangqi'
										END) qujian,
									parent_sale_ord_id,
									sale_ord_id,
									after_prefr_amount,
									after_prefr_amount_1,
									before_prefr_amount,
									total_offer_amount,
									sale_qtty,
									check_account_tm,
									SUM(after_prefr_amount) over(partition BY parent_sale_ord_id) AS ord_amount
								FROM
									-- gdm.gdm_m04_ord_det_sum
									app.app_m04_ord_det_sum_xfp_mid
								WHERE
									dt >= sysdate( - 367)
									AND
									(
										sale_ord_dt = sysdate( - 1)
										OR sale_ord_dt = sysdate( - 2)
										OR sale_ord_dt = concat(YEAR(sysdate( - 1)) - 1, IF(SUBSTR(sysdate( - 1), 5) = '-02-29', '-03-01', SUBSTR(sysdate( - 1), 5)))
										-- 阳历日期做同比，遇到2月29号，则和去年3月1号做同比
									)
									AND sale_ord_valid_flag = '1'
									AND item_third_cate_cd NOT IN('6980') --剔除礼品卡
									AND SUBSTR(ord_flag, 18, 1) NOT IN('1', '2') --剔除售后
									AND
									(
										SUBSTR(ord_flag, 31, 1) <> '2' --非行政内采
										OR
										(
											SUBSTR(ord_flag, 31, 1) = '2'
											AND user_log_acct IN('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
										)
									)
									AND
									(
										SUBSTR(ord_flag, 46, 1) NOT IN('1', '2', '3', '7')
										OR SUBSTR(ord_flag, 60, 3) NOT IN('013')
									)
									AND sale_ord_type_cd <> '68' --剔除拍卖
									AND SUBSTR(ord_flag, 154, 3) NOT IN('136') --剔除拼团抽奖订单
									AND split_status_cd NOT IN('1') --剔除订单状态为拆分后的父单
									AND user_log_acct NOT LIKE 'ept%'
									AND free_goods_flag = 0
							)
							b
						WHERE
							b.ord_amount < 100000
							OR
							(
								b.ord_amount >= 100000
								AND COALESCE(b.check_account_tm, '') <> ''
							)
					)
					b
				ON
					a.item_sku_id = b.item_sku_id
				LEFT JOIN
					(
						SELECT
							lower(trim(unif_user_log_acct)) user_log_acct,
							lower(trim(user_acct_name)) pin
						FROM
							gdm.gdm_m01_userinfo_basic_da
						WHERE
							dt = sysdate( - 1)
					) ----归一化用户pin
					d
				ON
					b.user_log_acct = d.pin
			)
			a
		LEFT JOIN
			(
				SELECT
					dept_id_2,
					dept_id_3,
					x.user_log_acct,
					x.fst_all_yn,
					(
						CASE
							WHEN fst_ord_dt = sysdate( - 1)
							THEN 'benqi'
							WHEN fst_ord_dt = concat(YEAR(sysdate( - 1)) - 1, IF(SUBSTR(sysdate( - 1), 5) = '-02-29', '-03-01', SUBSTR(sysdate( - 1), 5)))
							THEN 'qunian' -- 阳历日期做同比，遇到2月29号，则和去年3月1号做同比
							WHEN fst_ord_dt = sysdate( - 2)
							THEN 'shangqi'
						END) qujian
				FROM
					(
						SELECT
							dept_id_2,
							dept_id_3,
							lower(trim(unif_user_log_acct)) user_log_acct,
							MAX(
								CASE
									WHEN fst_all_yn = 1
									THEN 1
									ELSE 0
								END) fst_all_yn,
							MIN(fst_ord_dt) fst_ord_dt
						FROM
							app.v_adm_s01_user_new_or_old_flag_detail_xfp
						WHERE
							dt = sysdate( - 1)
							AND tp = 'dept'
						GROUP BY
							dept_id_2,
								dept_id_3,
							lower(trim(unif_user_log_acct))
					)
					x
				WHERE
					(
						fst_ord_dt = sysdate( - 1)
						OR fst_ord_dt = sysdate( - 2)
						OR fst_ord_dt = concat(YEAR(sysdate( - 1)) - 1, IF(SUBSTR(sysdate( - 1), 5) = '-02-29', '-03-01', SUBSTR(sysdate( - 1), 5)))
						-- 阳历日期做同比，遇到2月29号，则和去年3月1号做同比
					)
			)
			b
		ON
			b.user_log_acct = a.user_log_acct
			AND b.qujian = a.qujian
			AND a.dept_id_2 = b.dept_id_2
		    AND a.dept_id_3 = b.dept_id_3	
		LEFT JOIN
			(
				SELECT
					lower(trim(unif_user_log_acct)) user_log_acct
				FROM
					dev_dkx.gx_spite_user_list_xfp_d
			)
			c
		ON
			a.user_log_acct = c.user_log_acct
		WHERE
			c.user_log_acct IS NULL
		GROUP BY
		    a.dept_name_3
	)
	mm
	
		;
"""
ht.exec_sql(
    schema_name = 'dev_dkx',
    sql=sql,
    table_name = 'mjt_food_dept3_yonghu_day',
    merge_flag = True)
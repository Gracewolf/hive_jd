#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;

----------------------------------------------------------------------------------
drop table if exists dev_dkx.mjt_user_amount_join1_2_d_v1;
create
	table dev_dkx.mjt_user_amount_join1_2_d_v1
STORED AS ORC  tblproperties ('orc.compress'='SNAPPY')
as
select
    user.benqi_dt dt,
    user.qujian qujian,
    user.dept_name_3 dept_name_3,
    user.user_no user_no,
    user.out_new_user_no out_new_user_no,
    user.in_new_user_no in_new_user_no,
    amount.ord_num ord_num,
    amount.gmv_sum gmv_sum,
    amount.item_qtty item_qtty,
    amount.out_new_ord_num out_new_ord_num,
    amount.out_new_amount out_new_amount,
    amount.out_new_sale_qtty out_new_sale_qtty,
    amount.in_new_ord_num in_new_ord_num,
    amount.in_new_amount in_new_amount,
    amount.in_new_sale_qtty in_new_sale_qtty
from
(select * from dev_dkx.mjt_xinlao_user_union1_2_d_v1) user
join
(select * from dev_dkx.mjt_amount_union1_2_d_v1) amount
on
user.dept_name_3 = amount.dept_name_3
and user.qujian = amount.qujian
;
"""
ht.exec_sql(
    schema_name = 'dev_dkx',
    sql=sql,
    table_name = 'mjt_user_amount_join1_2_d_v1',
    merge_flag = True)
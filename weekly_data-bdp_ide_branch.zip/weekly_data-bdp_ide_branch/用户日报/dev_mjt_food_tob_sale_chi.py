#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;
  
set hive.exec.parallel = true;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
set hive.map.aggr = true;
set hive.groupby.mapaggr.checkinterval = 100000;
set hive.auto.convert.join = true;

drop table if exists dev_xfp.dev_mjt_food_tob_sale_chi;
create
  table dev_xfp.dev_mjt_food_tob_sale_chi STORED AS ORC tblproperties
  (
    'orc.compress' = 'SNAPPY'
  ) as
SELECT
	a.*,
	b.gmv_dp2_mon,
	b.gmv_dp2_ys,
	c.gmv_dp3_mon,
	c.gmv_dp3_ys,
	d.gmv_cx_mon,
	d.gmv_cx_ys,
	e.gmv_pp_mon,
	e.gmv_pp_ys,
	f.gmv_sf_mon,
	f.gmv_sf_ys
FROM
	(
		SELECT
			a.item_sku_id,
			a.item_name,
			CASE
				WHEN a.data_type = 1
				THEN '自营'
				WHEN a.data_type = 2
				THEN '图书'
				WHEN a.data_type = 3
				THEN 'pop'
				WHEN a.data_type = 4
				THEN '其他'
				ELSE '未知'
			END mod,
			a.item_first_cate_cd,
			a.item_first_cate_name,
			a.item_second_cate_cd,
			a.item_second_cate_name,
			a.item_third_cate_cd,
			a.item_third_cate_name,
			a.brand_code,
			a.barndname_full,
			a.staf_pop_operator_erp,
			staf_pop_name,
			a.major_supp_pop_vender_id,
			a.major_supp_pop_vender_name,
			a.shop_id,
			a.shop_name,
			CASE
				WHEN a.pop_coop_mode_cd = '1'
				THEN 'FBP'
				WHEN a.pop_coop_mode_cd = '0'
				THEN 'SOP'
				WHEN a.pop_coop_mode_cd = '2'
				THEN 'LBP'
				WHEN a.pop_coop_mode_cd = '5'
				THEN 'SOPL'
				WHEN a.pop_coop_mode_cd = '4'
				THEN 'LBV'
				WHEN a.pop_coop_mode_cd = '10'
				THEN 'FCS'
				ELSE '其他'
			END POP_type,
			CASE
				WHEN a.sku_status_cd = '3000'
				THEN '下柜'
				WHEN a.sku_status_cd = '3001'
				THEN '上柜'
				WHEN a.sku_status_cd = '3002'
				THEN '可上柜'
				ELSE '其他'
			END sku_status,
			a.dept_id_2,
			a.dept_name_2,
			a.dept_id_3,
			a.dept_name_3,
			CASE
				WHEN c.user_log_acct LIKE('xtl_%')
				THEN '新通路'
				WHEN c.user_log_acct IN('四季优选-7fresh')
				THEN '7fresh'
				WHEN three.channel_id = '1'
				THEN '万家'
				WHEN two.big_user_id = '1'
					AND three.channel_id IS NULL
				THEN '大客户'
				ELSE '其他'
			END user_type,
			c.user_log_acct,
			c.sale_ord_id,
			two.big_user_id,
			three.channel_id, --1万家，
			three.channel_name,
			dim_province_name,
			dim_city_name,
			SUM(
				CASE
					WHEN SUBSTR(op_time, 1, 4) = SUBSTR(sysdate( - 1), 1, 4)
					THEN c.cw_gmv
					ELSE 0
				END) cw_gmv_mon,
			SUM(
				CASE
					WHEN SUBSTR(op_time, 1, 4) = SUBSTR(add_months(sysdate( - 1), - 12), 1, 4)
					THEN c.cw_gmv
					ELSE 0
				END) cw_gmv_lsm,
			SUM(
				CASE
					WHEN SUBSTR(op_time, 1, 10) = sysdate( - 1)
					THEN c.cw_gmv
					ELSE 0
				END) cw_gmv_ys,
			SUM(
				CASE
					WHEN SUBSTR(op_time, 1, 10) = add_months(sysdate( - 1), - 12)
					THEN c.cw_gmv
					ELSE 0
				END) cw_gmv_lys,
			DAY(sysdate( - 1)) day_nu
		FROM
			(
				SELECT
					item_sku_id,
					regexp_replace(regexp_replace(trim(item_name), '\\"', ''), ',', '，') item_name,
					data_type,
					item_first_cate_cd,
					regexp_replace(regexp_replace(trim(item_first_cate_name), '\\"', ''), ',', '，') item_first_cate_name,
					item_second_cate_cd,
					regexp_replace(regexp_replace(trim(item_second_cate_name), '\\"', ''), ',', '，') item_second_cate_name,
					item_third_cate_cd,
					regexp_replace(regexp_replace(trim(item_third_cate_name), '\\"', ''), ',', '，') item_third_cate_name,
					brand_code,
					regexp_replace(regexp_replace(trim(barndname_full), '\\"', ''), ',', '，') barndname_full,
					CASE
						WHEN data_type = 1
						THEN saler_erp_acct
						WHEN data_type = 3
						THEN pop_operator_erp_acct
						ELSE '其他'
					END staf_pop_operator_erp,
					--销售员或POP运营人员erp
					CASE
						WHEN data_type = 1
						THEN sale_staf_name
						WHEN data_type = 3
						THEN pop_operator_name
						ELSE '其他'
					END staf_pop_name,
					CASE
						WHEN data_type = 1
						THEN major_supp_brevity_code
						WHEN data_type = 3
						THEN pop_vender_id
						ELSE '其他'
					END major_supp_pop_vender_id, --
					-- 主供应商或商家id
					CASE
						WHEN data_type = 1
						THEN regexp_replace(regexp_replace(trim(major_supp_name), '\\"', ''), ',', '，')
						WHEN data_type = 3
						THEN regexp_replace(regexp_replace(trim(pop_vender_name), '\\"', ''), ',', '，')
						ELSE '其他'
					END major_supp_pop_vender_name,
					--主供应商或商家名称
					shop_id,
					regexp_replace(regexp_replace(trim(shop_name), '\\"', ''), ',', '，') shop_name,
					pop_coop_mode_cd,
					sku_status_cd,
					purchaser_erp_acct,
					purchaser_name,
					dept_id_1,
					dept_name_1,
					dept_id_2,
					dept_name_2,
					dept_id_3,
					dept_name_3,
					dept_id_4,
					dept_name_4,
					work_post_cd
				FROM
					gdm.gdm_m03_sold_item_sku_da
				WHERE
					dt = sysdate( - 1)
					AND dept_id_1 = '33'
					AND dept_id_2 IN('47')
					--AND dept_name_3 = '洋酒组'
			)
			a
		JOIN
			(
				SELECT
					op_time,
					parent_sale_ord_id,
					sale_ord_id,
					cw_ord_type_cd,
					channel_flag,
					terminal_flag,
					rev_addr_province_id,
					item_sku_id,
					user_log_acct,
					rev_addr_county_id,
					SUM(cw_gmv) cw_gmv,
					SUM(cw_quantity) cw_quantity
				FROM
					app.app_cmo_cw_ord_det_sum_xfp_mid
				WHERE
					(
						dt >= concat(SUBSTR(sysdate( - 1), 1, 8), '01')
						AND dt < sysdate()
					)
					OR
					(
						dt >= add_months(concat(SUBSTR(sysdate( - 1), 1, 8), '01'), - 12)
						AND dt < add_months(sysdate(), - 12)
					)
				GROUP BY
					op_time,
					parent_sale_ord_id,
					sale_ord_id,
					cw_ord_type_cd,
					channel_flag,
					terminal_flag,
					rev_addr_province_id,
					item_sku_id,
					user_log_acct,
					rev_addr_county_id
			)
			c
		ON
			a.item_sku_id = c.item_sku_id
		LEFT JOIN
			(
				SELECT
					user_log_acct,
					'1' AS big_user_id
				FROM
					gdm.gdm_m01_userinfo_enterprise_da
				WHERE
					dt = sysdate( - 1)
					AND status = 1
					AND user_log_acct NOT LIKE 'xtl_%'
			)
			two
		ON
			LOWER(TRIM(c.user_log_acct)) = LOWER(TRIM(two.user_log_acct))
		LEFT JOIN
			(
				SELECT
					sale_order_id,
					parent_order_id,
					sale_ord_tm,
					user_log_acct,
					sku_id,
					sku_name,
					channel_id, --1万家，
					channel_name,
					SUM(after_prefr_amount) after_prefr_amount
				FROM
					adm.adm_offline_s04_trade_ord_det_snapshot
				WHERE
					(
						(
							dt >= concat(SUBSTR(sysdate( - 1), 1, 8), '01')
							AND sale_ord_tm >= concat(SUBSTR(sysdate( - 1), 1, 8), '01')
							AND sale_ord_tm < sysdate()
						)
						OR
						(
							(
								dt >= concat(SUBSTR(sysdate( - 1), 1, 8), '01')
								AND sale_ord_tm >= concat(SUBSTR(sysdate( - 1), 1, 8), '01')
								AND sale_ord_tm < sysdate()
							)
						)
					)
					AND channel_id = '1'--1为万家
				GROUP BY
					sale_order_id,
					parent_order_id,
					sale_ord_tm,
					user_log_acct,
					sku_id,
					sku_name,
					channel_id, --1万家，
					channel_name
			)
			three
		ON
			c.item_sku_id = three.sku_id
			AND c.sale_ord_id = three.sale_order_id
		LEFT OUTER JOIN
			(
				SELECT
					dim_county_name,
					dim_province_name,
					dim_city_name,
					dim_county_id,
					dim_jxkh_level
				FROM
					app.v_app_jxkh_county
				GROUP BY
					dim_county_name,
					dim_province_name,
					dim_city_name,
					dim_county_id,
					dim_jxkh_level
			)
			b
		ON
			c.rev_addr_county_id = b.dim_county_id
		GROUP BY
			a.item_sku_id,
			a.item_name,
			CASE
				WHEN a.data_type = 1
				THEN '自营'
				WHEN a.data_type = 2
				THEN '图书'
				WHEN a.data_type = 3
				THEN 'pop'
				WHEN a.data_type = 4
				THEN '其他'
				ELSE '未知'
			END,
			a.item_first_cate_cd,
			a.item_first_cate_name,
			a.item_second_cate_cd,
			a.item_second_cate_name,
			a.item_third_cate_cd,
			a.item_third_cate_name,
			a.brand_code,
			a.barndname_full,
			a.staf_pop_operator_erp,
			staf_pop_name,
			a.major_supp_pop_vender_id,
			a.major_supp_pop_vender_name,
			a.shop_id,
			a.shop_name,
			CASE
				WHEN a.pop_coop_mode_cd = '1'
				THEN 'FBP'
				WHEN a.pop_coop_mode_cd = '0'
				THEN 'SOP'
				WHEN a.pop_coop_mode_cd = '2'
				THEN 'LBP'
				WHEN a.pop_coop_mode_cd = '5'
				THEN 'SOPL'
				WHEN a.pop_coop_mode_cd = '4'
				THEN 'LBV'
				WHEN a.pop_coop_mode_cd = '10'
				THEN 'FCS'
				ELSE '其他'
			END,
			CASE
				WHEN a.sku_status_cd = '3000'
				THEN '下柜'
				WHEN a.sku_status_cd = '3001'
				THEN '上柜'
				WHEN a.sku_status_cd = '3002'
				THEN '可上柜'
				ELSE '其他'
			END,
			a.dept_id_2,
			a.dept_name_2,
			a.dept_id_3,
			a.dept_name_3,
			CASE
				WHEN c.user_log_acct LIKE('xtl_%')
				THEN '新通路'
				WHEN c.user_log_acct IN('四季优选-7fresh')
				THEN '7fresh'
				WHEN two.big_user_id = '1'
					AND three.channel_id IS NULL
				THEN '大客户'
				WHEN three.channel_id = '1'
				THEN '万家'
				ELSE '其他'
			END,
			c.user_log_acct,
			c.sale_ord_id,
			two.big_user_id,
			three.channel_id, --1万家，
			three.channel_name,
			dim_province_name,
			dim_city_name
	)
	a
	--二级部门整体销售
JOIN
	(
		SELECT
			a.dept_id_2,
			a.dept_name_2,
			SUM(
				CASE
					WHEN SUBSTR(op_time, 1, 4) = SUBSTR(sysdate( - 1), 1, 4)
					THEN c.cw_gmv
					ELSE 0
				END) gmv_dp2_mon,
			SUM(
				CASE
					WHEN SUBSTR(op_time, 1, 10) = sysdate( - 1)
					THEN c.cw_gmv
					ELSE 0
				END) gmv_dp2_ys
		FROM
			(
				SELECT
					item_sku_id,
					regexp_replace(regexp_replace(trim(item_name), '\\"', ''), ',', '，') item_name,
					dept_id_1,
					dept_name_1,
					dept_id_2,
					dept_name_2
				FROM
					gdm.gdm_m03_sold_item_sku_da
				WHERE
					dt = sysdate( - 1)
					AND dept_id_1 = '33'
					AND dept_id_2 IN('47')
			)
			a
		JOIN
			(
				SELECT
					op_time,
					parent_sale_ord_id,
					sale_ord_id,
					cw_ord_type_cd,
					channel_flag,
					terminal_flag,
					rev_addr_province_id,
					item_sku_id,
					user_log_acct,
					rev_addr_county_id,
					SUM(cw_gmv) cw_gmv,
					SUM(cw_quantity) cw_quantity
				FROM
					app.app_cmo_cw_ord_det_sum_xfp_mid
				WHERE
					(
						dt >= concat(SUBSTR(sysdate( - 1), 1, 8), '01')
						AND dt < sysdate()
					)
					OR
					(
						dt >= add_months(concat(SUBSTR(sysdate( - 1), 1, 8), '01'), - 12)
						AND dt < add_months(sysdate(), - 12)
					)
				GROUP BY
					op_time,
					parent_sale_ord_id,
					sale_ord_id,
					cw_ord_type_cd,
					channel_flag,
					terminal_flag,
					rev_addr_province_id,
					item_sku_id,
					user_log_acct,
					rev_addr_county_id
			)
			c
		ON
			a.item_sku_id = c.item_sku_id
		GROUP BY
			a.dept_id_2,
			a.dept_name_2
	)
	b ON b.dept_id_2 = a.dept_id_2
	--三级部门整体销售
LEFT JOIN
	(
		SELECT
			a.dept_id_2,
			a.dept_name_2,
			a.dept_id_3,
			a.dept_name_3,
			SUM(
				CASE
					WHEN SUBSTR(op_time, 1, 4) = SUBSTR(sysdate( - 1), 1, 4)
					THEN c.cw_gmv
					ELSE 0
				END) gmv_dp3_mon,
			SUM(
				CASE
					WHEN SUBSTR(op_time, 1, 10) = sysdate( - 1)
					THEN c.cw_gmv
					ELSE 0
				END) gmv_dp3_ys
		FROM
			(
				SELECT
					item_sku_id,
					regexp_replace(regexp_replace(trim(item_name), '\\"', ''), ',', '，') item_name,
					dept_id_1,
					dept_name_1,
					dept_id_2,
					dept_name_2,
					CASE
						WHEN data_type = 1
						THEN sale_staf_name
						WHEN data_type = 3
						THEN pop_operator_name
						ELSE '其他'
					END staf_pop_name,
					dept_id_3,
					dept_name_3
				FROM
					gdm.gdm_m03_sold_item_sku_da
				WHERE
					dt = sysdate( - 1)
					AND dept_id_1 = '33'
					AND dept_id_2 IN('47')
					and dept_id_3 in ('3842','989','3816','3836','966','4159','3840','4046','4044','3814','141','147','3818','985','4165','3838','433','3824','3826','4161','4162','4157','3828','3830')
			)
			a
		JOIN
			(
				SELECT
					op_time,
					parent_sale_ord_id,
					sale_ord_id,
					cw_ord_type_cd,
					channel_flag,
					terminal_flag,
					rev_addr_province_id,
					item_sku_id,
					user_log_acct,
					rev_addr_county_id,
					SUM(cw_gmv) cw_gmv,
					SUM(cw_quantity) cw_quantity
				FROM
					app.app_cmo_cw_ord_det_sum_xfp_mid
				WHERE
					(
						dt >= concat(SUBSTR(sysdate( - 1), 1, 8), '01')
						AND dt < sysdate()
					)
					OR
					(
						dt >= add_months(concat(SUBSTR(sysdate( - 1), 1, 8), '01'), - 12)
						AND dt < add_months(sysdate(), - 12)
					)
				GROUP BY
					op_time,
					parent_sale_ord_id,
					sale_ord_id,
					cw_ord_type_cd,
					channel_flag,
					terminal_flag,
					rev_addr_province_id,
					item_sku_id,
					user_log_acct,
					rev_addr_county_id
			)
			c
		ON
			a.item_sku_id = c.item_sku_id
		GROUP BY
			a.dept_id_2,
			a.dept_name_2,
			a.dept_id_3,
			a.dept_name_3
	)
	c ON a.dept_id_3 = c.dept_id_3
	--采销整体销售
LEFT JOIN
	(
		SELECT
			a.dept_id_2,
			a.dept_name_2,
			a.dept_id_3,
			a.dept_name_3,
			a.staf_pop_name,
			SUM(
				CASE
					WHEN SUBSTR(op_time, 1, 4) = SUBSTR(sysdate( - 1), 1, 4)
					THEN c.cw_gmv
					ELSE 0
				END) gmv_cx_mon,
			SUM(
				CASE
					WHEN SUBSTR(op_time, 1, 10) = sysdate( - 1)
					THEN c.cw_gmv
					ELSE 0
				END) gmv_cx_ys
		FROM
			(
				SELECT
					item_sku_id,
					regexp_replace(regexp_replace(trim(item_name), '\\"', ''), ',', '，') item_name,
					dept_id_1,
					dept_name_1,
					dept_id_2,
					dept_name_2,
					CASE
						WHEN data_type = 1
						THEN sale_staf_name
						WHEN data_type = 3
						THEN pop_operator_name
						ELSE '其他'
					END staf_pop_name,
					dept_id_3,
					dept_name_3
				FROM
					gdm.gdm_m03_sold_item_sku_da
				WHERE
					dt = sysdate( - 1)
					AND dept_id_1 = '33'
					AND dept_id_2 IN('47')
					and dept_id_3 in ('3842','989','3816','3836','966','4159','3840','4046','4044','3814','141','147','3818','985','4165','3838','433','3824','3826','4161','4162','4157','3828','3830')
			)
			a
		JOIN
			(
				SELECT
					op_time,
					parent_sale_ord_id,
					sale_ord_id,
					cw_ord_type_cd,
					channel_flag,
					terminal_flag,
					rev_addr_province_id,
					item_sku_id,
					user_log_acct,
					rev_addr_county_id,
					SUM(cw_gmv) cw_gmv,
					SUM(cw_quantity) cw_quantity
				FROM
					app.app_cmo_cw_ord_det_sum_xfp_mid
				WHERE
					(
						dt >= concat(SUBSTR(sysdate( - 1), 1, 8), '01')
						AND dt < sysdate()
					)
					OR
					(
						dt >= add_months(concat(SUBSTR(sysdate( - 1), 1, 8), '01'), - 12)
						AND dt < add_months(sysdate(), - 12)
					)
				GROUP BY
					op_time,
					parent_sale_ord_id,
					sale_ord_id,
					cw_ord_type_cd,
					channel_flag,
					terminal_flag,
					rev_addr_province_id,
					item_sku_id,
					user_log_acct,
					rev_addr_county_id
			)
			c
		ON
			a.item_sku_id = c.item_sku_id
		GROUP BY
			a.dept_id_2,
			a.dept_name_2,
			a.dept_id_3,
			a.dept_name_3,
			a.staf_pop_name
	)
	d ON a.staf_pop_name = d.staf_pop_name
	AND a.dept_id_3 = d.dept_id_3
	--品牌整体销售
LEFT JOIN
	(
		SELECT
			a.barndname_full,
			SUM(
				CASE
					WHEN SUBSTR(op_time, 1, 4) = SUBSTR(sysdate( - 1), 1, 4)
					THEN c.cw_gmv
					ELSE 0
				END) gmv_pp_mon,
			SUM(
				CASE
					WHEN SUBSTR(op_time, 1, 10) = sysdate( - 1)
					THEN c.cw_gmv
					ELSE 0
				END) gmv_pp_ys
		FROM
			(
				SELECT
					item_sku_id,
					regexp_replace(regexp_replace(trim(item_name), '\\"', ''), ',', '，') item_name,
					dept_id_1,
					dept_name_1,
					dept_id_2,
					dept_name_2,
					CASE
						WHEN data_type = 1
						THEN sale_staf_name
						WHEN data_type = 3
						THEN pop_operator_name
						ELSE '其他'
					END staf_pop_name,
					dept_id_3,
					dept_name_3,
					brand_code,
					barndname_full
				FROM
					gdm.gdm_m03_sold_item_sku_da
				WHERE
					dt = sysdate( - 1)
					AND dept_id_1 = '33'
					AND dept_id_2 IN('47')
			)
			a
		JOIN
			(
				SELECT
					op_time,
					parent_sale_ord_id,
					sale_ord_id,
					cw_ord_type_cd,
					channel_flag,
					terminal_flag,
					rev_addr_province_id,
					item_sku_id,
					user_log_acct,
					rev_addr_county_id,
					SUM(cw_gmv) cw_gmv,
					SUM(cw_quantity) cw_quantity
				FROM
					app.app_cmo_cw_ord_det_sum_xfp_mid
				WHERE
					(
						dt >= concat(SUBSTR(sysdate( - 1), 1, 8), '01')
						AND dt < sysdate()
					)
					OR
					(
						dt >= add_months(concat(SUBSTR(sysdate( - 1), 1, 8), '01'), - 12)
						AND dt < add_months(sysdate(), - 12)
					)
				GROUP BY
					op_time,
					parent_sale_ord_id,
					sale_ord_id,
					cw_ord_type_cd,
					channel_flag,
					terminal_flag,
					rev_addr_province_id,
					item_sku_id,
					user_log_acct,
					rev_addr_county_id
			)
			c
		ON
			a.item_sku_id = c.item_sku_id
		GROUP BY
			a.barndname_full
	)
	e ON a.barndname_full = e.barndname_full
	--省份整体销售
LEFT JOIN
	(
		SELECT
			dim_province_name,
			SUM(
				CASE
					WHEN SUBSTR(op_time, 1, 4) = SUBSTR(sysdate( - 1), 1, 4)
					THEN c.cw_gmv
					ELSE 0
				END) gmv_sf_mon,
			SUM(
				CASE
					WHEN SUBSTR(op_time, 1, 10) = sysdate( - 1)
					THEN c.cw_gmv
					ELSE 0
				END) gmv_sf_ys
		FROM
			(
				SELECT
					item_sku_id,
					regexp_replace(regexp_replace(trim(item_name), '\\"', ''), ',', '，') item_name,
					dept_id_1,
					dept_name_1,
					dept_id_2,
					dept_name_2,
					CASE
						WHEN data_type = 1
						THEN sale_staf_name
						WHEN data_type = 3
						THEN pop_operator_name
						ELSE '其他'
					END staf_pop_name,
					dept_id_3,
					dept_name_3,
					brand_code,
					barndname_full
				FROM
					gdm.gdm_m03_sold_item_sku_da
				WHERE
					dt = sysdate( - 1)
					AND dept_id_1 = '33'
					AND dept_id_2 IN('47')
			)
			a
		JOIN
			(
				SELECT
					op_time,
					parent_sale_ord_id,
					sale_ord_id,
					cw_ord_type_cd,
					channel_flag,
					terminal_flag,
					rev_addr_province_id,
					item_sku_id,
					user_log_acct,
					rev_addr_county_id,
					SUM(cw_gmv) cw_gmv,
					SUM(cw_quantity) cw_quantity
				FROM
					app.app_cmo_cw_ord_det_sum_xfp_mid
				WHERE
					(
						dt >= concat(SUBSTR(sysdate( - 1), 1, 8), '01')
						AND dt < sysdate()
					)
					OR
					(
						dt >= add_months(concat(SUBSTR(sysdate( - 1), 1, 8), '01'), - 12)
						AND dt < add_months(sysdate(), - 12)
					)
				GROUP BY
					op_time,
					parent_sale_ord_id,
					sale_ord_id,
					cw_ord_type_cd,
					channel_flag,
					terminal_flag,
					rev_addr_province_id,
					item_sku_id,
					user_log_acct,
					rev_addr_county_id
			)
			c
		ON
			a.item_sku_id = c.item_sku_id
		LEFT OUTER JOIN
			(
				SELECT
					dim_county_name,
					dim_province_name,
					dim_city_name,
					dim_county_id,
					dim_jxkh_level
				FROM
					app.v_app_jxkh_county
				GROUP BY
					dim_county_name,
					dim_province_name,
					dim_city_name,
					dim_county_id,
					dim_jxkh_level
			)
			b
		ON
			c.rev_addr_county_id = b.dim_county_id
		GROUP BY
			dim_province_name
	)
	f ON a.dim_province_name = f.dim_province_name
WHERE
	user_type NOT IN('其他')
;

 
"""

ht.exec_sql(
    schema_name = 'dev_xfp',
    sql=sql,
    table_name = 'dev_mjt_food_tob_sale_chi',
    merge_flag = True)	
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import time
import datetime
import subprocess


sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day

sql_1 = """
--合并小文件
set hive.merge.mapfiles=true;
set hive.merge.mapredfiles = true;
set hive.merge.size.per.task = 256000000;
set hive.merge.smallfiles.avgsize = 256000000;
--存储压缩
set hive.default.fileformat=Orc;
--多线程并发
set hive.exec.parallel = true;
set hive.exec.parallel.thread.number = 8;
--列剪裁
set hive.optimize.cp = true;
set hive.optimize.pruner = true;
--map阶段优化
set mapred.max.split.size = 256000000;
set mapred.min.split.size.per.node = 256000000;
set mapred.min.split.size.per.rack = 256000000;
set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set hive.hadoop.supports.splittable.combineinputformat = true;
set mapreduce.input.fileinputformat.split.maxsize = 256000000;
set mapreduce.input.fileinputformat.split.minsize.per.node=256000000;
set mapreduce.input.fileinputformat.split.minsize.per.rack=256000000;
drop
	table if exists dev_xfp.mjt_brand_user_mtd;
create
	table dev_xfp.mjt_brand_user_mtd STORED AS ORC tblproperties
	(
		'orc.compress' = 'SNAPPY'
	) as
select
	dept_name_2,
	dept_name_3,
	brand_code,
	barndname_full,
	total_usr,
	total_usr / total_usr_1 - 1 total_usr_yoy,
	total_usr / total_usr_2 - 1 total_usr_moon,
	inner_usr,
	inner_usr / inner_usr_1 - 1 inner_usr_yoy,
	inner_usr / inner_usr_2 - 1 inner_usr_moon,
	outer_usr,
	outer_usr / outer_usr_1 - 1 outer_usr_yoy,
	outer_usr / outer_usr_2 - 1 outer_usr_moon,
	total_usr - inner_usr - outer_usr old_user,
	(total_usr - inner_usr - outer_usr) / (total_usr_1 - inner_usr_1 - outer_usr_1) - 1 old_user_yoy,
	(total_usr - inner_usr - outer_usr) / (total_usr_2 - inner_usr_2 - outer_usr_2) - 1 old_user_moon
from
	(
		select
			dept_name_2,
			dept_name_3,
			brand_code,
			barndname_full,
			count(distinct case when a.this_year_flag = 1 then a.user_log_acct end) total_usr,
			count(distinct case when a.this_year_flag = 1 and b.fst_all_yn = 1 then a.user_log_acct end) outer_usr,
			count(distinct case when a.this_year_flag = 1 and b.fst_all_yn = 0 then a.user_log_acct end) inner_usr,
			count(distinct case when a.last_year_flag = 1 then a.user_log_acct end) total_usr_1,
			count(distinct case when a.last_year_flag = 1 and b.fst_all_yn = 1 then a.user_log_acct end) outer_usr_1,
			count(distinct case when a.last_year_flag = 1 and b.fst_all_yn = 0 then a.user_log_acct end) inner_usr_1,
			count(distinct case when a.moon_year_flag = 1 then a.user_log_acct end) total_usr_2,
			count(distinct case when a.moon_year_flag = 1 and b.fst_all_yn = 1 then a.user_log_acct end) outer_usr_2,
			count(distinct case when a.moon_year_flag = 1 and b.fst_all_yn = 0 then a.user_log_acct end) inner_usr_2
		from
			(
				select
					user_log_acct,
					dept_id_2,
					dept_name_2,
					dept_id_3,
					dept_name_3,
					this_year_flag,
					last_year_flag,
					moon_year_flag,
					brand_code,
					barndname_full
				from
					dev_xfp.nz_user_daily_report_ord
				where
					dept_id_2 = '47'
					and model = '自营'
					and (this_year_flag = 1 or last_year_flag = 1 or moon_year_flag = 1)
			)
			a
		left join
			(
				select
					bs,
					user_log_acct,
					fst_all_yn,
					this_year_flag,
					last_year_flag,
					moon_year_flag
				from
					dev_xfp.nz_new_user_flag
				where
					tp = 'dept3'
					and (this_year_flag = 1 or last_year_flag = 1 or moon_year_flag = 1)
			)
			b
		on
			a.user_log_acct = b.user_log_acct
			and a.dept_id_3 = bs
			and a.this_year_flag = b.this_year_flag
			and a.last_year_flag = b.last_year_flag
			and a.moon_year_flag = b.moon_year_flag
		left join
			(
				select user_log_acct from dev_xfp.spite_user_list_xfp
			)
			c
		on
			a.user_log_acct = c.user_log_acct
		where
			c.user_log_acct is null
		group by
			dept_name_2,
			dept_name_3,
			brand_code,
			barndname_full
	)
	a
"""

ht.exec_sql(schema_name='dev_xfp', sql=sql_1, table_name = 'mjt_brand_user_mtd', merge_flag=False)					
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import time
import datetime
import subprocess


sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day

sql_1 = """
--合并小文件
set hive.merge.mapfiles=true;
set hive.merge.mapredfiles = true;
set hive.merge.size.per.task = 256000000;
set hive.merge.smallfiles.avgsize = 256000000;
--存储压缩
set hive.default.fileformat=Orc;
--多线程并发
set hive.exec.parallel = true;
set hive.exec.parallel.thread.number = 8;
--列剪裁
set hive.optimize.cp = true;
set hive.optimize.pruner = true;
--map阶段优化
set mapred.max.split.size = 256000000;
set mapred.min.split.size.per.node = 256000000;
set mapred.min.split.size.per.rack = 256000000;
set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set hive.hadoop.supports.splittable.combineinputformat = true;
set mapreduce.input.fileinputformat.split.maxsize = 256000000;
set mapreduce.input.fileinputformat.split.minsize.per.node=256000000;
set mapreduce.input.fileinputformat.split.minsize.per.rack=256000000;
insert overwrite table dev_xfp.nz_flow_daily_report_7d
select
	dept_name,
	pv,
	uv,
	ord_num / uv uv_cvt,
	gmv / uv vpv,
	pv / pv_1 - 1 pv_yoy,
	uv / uv_1 - 1 uv_yoy,
	(ord_num / uv) / (ord_num_1 / uv_1) - 1 uv_cvt_yoy,
	(gmv / uv) / (gmv_1 / uv_1) - 1 vpv_yoy,
	pv / pv_2 - 1 pv_mom,
	uv / uv_2 - 1 uv_mom,
	(ord_num / uv) / (ord_num_2 / uv_2) - 1 uv_cvt_mom,
	(gmv / uv) / (gmv_2 / uv_2) - 1 vpv_mom,
	pv_2,
	uv_2,
	ord_num_2 / uv_2 uv_cvt_2,
	gmv_2 / uv_2 vpv_2,
	pv_3,
	uv_3,
	ord_num_3 / uv_3 uv_cvt_3,
	gmv_3 / uv_3 vpv_3,
	pv_4,
	uv_4,
	ord_num_4 / uv_4 uv_cvt_4,
	gmv_4 / uv_4 vpv_4,
	pv_5,
	uv_5,
	ord_num_5 / uv_5 uv_cvt_5,
	gmv_5 / uv_5 vpv_5,
	pv_6,
	uv_6,
	ord_num_6 / uv_6 uv_cvt_6,
	gmv_6 / uv_6 vpv_6,
	pv_7,
	uv_7,
	ord_num_7 / uv_7 uv_cvt_7,
	gmv_7 / uv_7 vpv_7
from
	(
		select
			dept_name,
			sum(case when dt = sysdate( - 1) then pv else 0 end) pv,
			sum(case when dt = sysdate( - 1) then uv else 0 end) uv,
			sum(case when dt = sysdate( - 1) then ord_num else 0 end) ord_num,
			sum(case when dt = sysdate( - 1) then gmv else 0 end) gmv,
			sum(case when dt = sysdate( - 366) then pv else 0 end) pv_1,
			sum(case when dt = sysdate( - 366) then uv else 0 end) uv_1,
			sum(case when dt = sysdate( - 366) then ord_num else 0 end) ord_num_1,
			sum(case when dt = sysdate( - 366) then gmv else 0 end) gmv_1,
			sum(case when dt = sysdate( - 2) then pv else 0 end) pv_2,
			sum(case when dt = sysdate( - 2) then uv else 0 end) uv_2,
			sum(case when dt = sysdate( - 2) then ord_num else 0 end) ord_num_2,
			sum(case when dt = sysdate( - 2) then gmv else 0 end) gmv_2,
			sum(case when dt = sysdate( - 3) then pv else 0 end) pv_3,
			sum(case when dt = sysdate( - 3) then uv else 0 end) uv_3,
			sum(case when dt = sysdate( - 3) then ord_num else 0 end) ord_num_3,
			sum(case when dt = sysdate( - 3) then gmv else 0 end) gmv_3,
			sum(case when dt = sysdate( - 4) then pv else 0 end) pv_4,
			sum(case when dt = sysdate( - 4) then uv else 0 end) uv_4,
			sum(case when dt = sysdate( - 4) then ord_num else 0 end) ord_num_4,
			sum(case when dt = sysdate( - 4) then gmv else 0 end) gmv_4,
			sum(case when dt = sysdate( - 5) then pv else 0 end) pv_5,
			sum(case when dt = sysdate( - 5) then uv else 0 end) uv_5,
			sum(case when dt = sysdate( - 5) then ord_num else 0 end) ord_num_5,
			sum(case when dt = sysdate( - 5) then gmv else 0 end) gmv_5,
			sum(case when dt = sysdate( - 6) then pv else 0 end) pv_6,
			sum(case when dt = sysdate( - 6) then uv else 0 end) uv_6,
			sum(case when dt = sysdate( - 6) then ord_num else 0 end) ord_num_6,
			sum(case when dt = sysdate( - 6) then gmv else 0 end) gmv_6,
			sum(case when dt = sysdate( - 7) then pv else 0 end) pv_7,
			sum(case when dt = sysdate( - 7) then uv else 0 end) uv_7,
			sum(case when dt = sysdate( - 7) then ord_num else 0 end) ord_num_7,
			sum(case when dt = sysdate( - 7) then gmv else 0 end) gmv_7
		from
			(
				select
					coalesce(a.dept_name, b.dept_name) dept_name,
					coalesce(a.dt, b.dt) dt,
					pv,
					uv,
					ord_num,
					gmv	
				from
					(
						select
							dept_name_2 dept_name,
							dt,
							count(distinct sale_ord_id) ord_num,
							sum(gmv) gmv
						from
							dev_xfp.nz_flow_daily_report_order_base
						where
							(
								dt >= sysdate( - 372)
								and dt <= sysdate( - 366)
							)
							or
							(
								dt >= sysdate( - 7)
								and dt <= sysdate( - 1)
							)
						group by
							dept_name_2,
							dt
					)
					a
				full outer join
					(
						select
							dept_name_2 dept_name,
							dt,
							count(distinct browser_uniq_id) uv,
							sum(pv) pv
						from
							dev_xfp.nz_flow_daily_report_view_base
						where
							(
								dt >= sysdate( - 372)
								and dt <= sysdate( - 366)
							)
							or
							(
								dt >= sysdate( - 7)
								and dt <= sysdate( - 1)
							)
						group by
							dept_name_2,
							dt
					)
					b
				on
					a.dept_name = b.dept_name
					and a.dt = b.dt
			)
			ff
		group by
			dept_name
	)
	ff

union all

select
	dept_name,
	pv,
	uv,
	ord_num / uv uv_cvt,
	gmv / uv vpv,
	pv / pv_1 - 1 pv_yoy,
	uv / uv_1 - 1 uv_yoy,
	(ord_num / uv) / (ord_num_1 / uv_1) - 1 uv_cvt_yoy,
	(gmv / uv) / (gmv_1 / uv_1) - 1 vpv_yoy,
	pv / pv_2 - 1 pv_mom,
	uv / uv_2 - 1 uv_mom,
	(ord_num / uv) / (ord_num_2 / uv_2) - 1 uv_cvt_mom,
	(gmv / uv) / (gmv_2 / uv_2) - 1 vpv_mom,
	pv_2,
	uv_2,
	ord_num_2 / uv uv_cvt_2,
	gmv_2 / uv_2 vpv_2,
	pv_3,
	uv_3,
	ord_num_3 / uv uv_cvt_3,
	gmv_3 / uv_3 vpv_3,
	pv_4,
	uv_4,
	ord_num_4 / uv uv_cvt_4,
	gmv_4 / uv_4 vpv_4,
	pv_5,
	uv_5,
	ord_num_5 / uv uv_cvt_5,
	gmv_5 / uv_5 vpv_5,
	pv_6,
	uv_6,
	ord_num_6 / uv uv_cvt_6,
	gmv_6 / uv_6 vpv_6,
	pv_7,
	uv_7,
	ord_num_7 / uv uv_cvt_7,
	gmv_7 / uv_7 vpv_7
from
	(
		select
			dept_name,
			sum(case when dt = sysdate( - 1) then pv else 0 end) pv,
			sum(case when dt = sysdate( - 1) then uv else 0 end) uv,
			sum(case when dt = sysdate( - 1) then ord_num else 0 end) ord_num,
			sum(case when dt = sysdate( - 1) then gmv else 0 end) gmv,
			sum(case when dt = sysdate( - 366) then pv else 0 end) pv_1,
			sum(case when dt = sysdate( - 366) then uv else 0 end) uv_1,
			sum(case when dt = sysdate( - 366) then ord_num else 0 end) ord_num_1,
			sum(case when dt = sysdate( - 366) then gmv else 0 end) gmv_1,
			sum(case when dt = sysdate( - 2) then pv else 0 end) pv_2,
			sum(case when dt = sysdate( - 2) then uv else 0 end) uv_2,
			sum(case when dt = sysdate( - 2) then ord_num else 0 end) ord_num_2,
			sum(case when dt = sysdate( - 2) then gmv else 0 end) gmv_2,
			sum(case when dt = sysdate( - 3) then pv else 0 end) pv_3,
			sum(case when dt = sysdate( - 3) then uv else 0 end) uv_3,
			sum(case when dt = sysdate( - 3) then ord_num else 0 end) ord_num_3,
			sum(case when dt = sysdate( - 3) then gmv else 0 end) gmv_3,
			sum(case when dt = sysdate( - 4) then pv else 0 end) pv_4,
			sum(case when dt = sysdate( - 4) then uv else 0 end) uv_4,
			sum(case when dt = sysdate( - 4) then ord_num else 0 end) ord_num_4,
			sum(case when dt = sysdate( - 4) then gmv else 0 end) gmv_4,
			sum(case when dt = sysdate( - 5) then pv else 0 end) pv_5,
			sum(case when dt = sysdate( - 5) then uv else 0 end) uv_5,
			sum(case when dt = sysdate( - 5) then ord_num else 0 end) ord_num_5,
			sum(case when dt = sysdate( - 5) then gmv else 0 end) gmv_5,
			sum(case when dt = sysdate( - 6) then pv else 0 end) pv_6,
			sum(case when dt = sysdate( - 6) then uv else 0 end) uv_6,
			sum(case when dt = sysdate( - 6) then ord_num else 0 end) ord_num_6,
			sum(case when dt = sysdate( - 6) then gmv else 0 end) gmv_6,
			sum(case when dt = sysdate( - 7) then pv else 0 end) pv_7,
			sum(case when dt = sysdate( - 7) then uv else 0 end) uv_7,
			sum(case when dt = sysdate( - 7) then ord_num else 0 end) ord_num_7,
			sum(case when dt = sysdate( - 7) then gmv else 0 end) gmv_7
		from
			(
				select
					coalesce(a.dept_name, b.dept_name) dept_name,
					coalesce(a.dt, b.dt) dt,
					pv,
					uv,
					ord_num,
					gmv	
				from
					(
						select
							dept_name_3 dept_name,
							dt,
							count(distinct sale_ord_id) ord_num,
							sum(gmv) gmv
						from
							dev_xfp.nz_flow_daily_report_order_base
						where
							(
								(
									dt >= sysdate( - 372)
									and dt <= sysdate( - 366)
								)
								or
								(
									dt >= sysdate( - 7)
									and dt <= sysdate( - 1)
								)
							)
							and dept_id_3 in('3842', '989', '3816', '3836', '966', '4159', '3840', '4046', '4044', '3814', '141', '147', '3818', '985', '4165', '3838', '433', '3824', '3826', '4161', '4162', '4157', '3828', '3830', '1700', '1701', '1702', '1703', '1704', '1705')
						group by
							dept_name_3,
							dt
					)
					a
				full outer join
					(
						select
							dept_name_3 dept_name,
							dt,
							count(distinct browser_uniq_id) uv,
							sum(pv) pv
						from
							dev_xfp.nz_flow_daily_report_view_base
						where
							(
								(
									dt >= sysdate( - 372)
									and dt <= sysdate( - 366)
								)
								or
								(
									dt >= sysdate( - 7)
									and dt <= sysdate( - 1)
								)

							)
							and dept_id_3 in('3842', '989', '3816', '3836', '966', '4159', '3840', '4046', '4044', '3814', '141', '147', '3818', '985', '4165', '3838', '433', '3824', '3826', '4161', '4162', '4157', '3828', '3830', '1700', '1701', '1702', '1703', '1704', '1705')
						group by
							dept_name_3,
							dt
					)
					b
				on
					a.dept_name = b.dept_name
					and a.dt = b.dt
			)
			ff
		group by
			dept_name
	)
	ff;
"""

ht.exec_sql(schema_name='dev_xfp', sql=sql_1, merge_flag=False)
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;
  
set hive.exec.parallel = true;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
set hive.map.aggr = true;
set hive.groupby.mapaggr.checkinterval = 100000;
set hive.auto.convert.join = true;

----内部归一化
drop table if exists dev_dkx.mjt_pop_cate_user_last_naifenyongpin_d;
create
  table dev_dkx.mjt_pop_cate_user_last_naifenyongpin_d STORED AS ORC tblproperties
  (
    'orc.compress' = 'SNAPPY'
  ) as
select
    second_name,
	total_user_1 total_user,
	total_user_1 / total_user_2 - 1 total_user_moon_yoy,
	out_user_1 out_user,
	out_user_1 / out_user_2 - 1 out_user_moon_yoy,
	inner_user_1 inner_user,
	inner_user_1 / inner_user_2 - 1 inner_user_moon_yoy,
	total_user_1 - inner_user_1 - out_user_1 old_user,
	(total_user_1 - inner_user_1 - out_user_1) / (total_user_2 - inner_user_2 - out_user_2) -1 old_user_moon_yoy	
from
    (
	    select
	        a.second_name,
	        sum(case when a.year_dt = 2022 then a.total_user end) total_user_1,
		    sum(case when a.year_dt = 2021 then a.total_user end) total_user_2,
		    sum(case when a.year_dt = 2022 then a.out_user end) out_user_1,
		    sum(case when a.year_dt = 2021 then a.out_user end) out_user_2,
		    sum(case when a.year_dt = 2022 then a.inner_user end) inner_user_1,
		    sum(case when a.year_dt = 2021 then a.inner_user end) inner_user_2
	    from
	    (
	        select 
	            year_dt,
	            second_name,
	            total_user,
	            out_user,
	            inner_user 
	        from 
	            dev_dkx.mjt_pop_cate_user_naifenyongpin_d
			group by
                year_dt,
	            second_name,
	            total_user,
	            out_user,
	            inner_user 			
	    )
        a
        group by
            a.second_name	
	)
    b
group by
    second_name,
	total_user_1,
	total_user_1 / total_user_2 - 1 ,
	out_user_1,
	out_user_1 / out_user_2 - 1,
	inner_user_1,
	inner_user_1 / inner_user_2 - 1,
	total_user_1 - inner_user_1 - out_user_1,
	(total_user_1 - inner_user_1 - out_user_1) / (total_user_2 - inner_user_2 - out_user_2) -1;
"""
ht.exec_sql(
    schema_name = 'dev_dkx',
    sql=sql,
    table_name = 'mjt_pop_cate_user_last_naifenyongpin_d',
    merge_flag = True)
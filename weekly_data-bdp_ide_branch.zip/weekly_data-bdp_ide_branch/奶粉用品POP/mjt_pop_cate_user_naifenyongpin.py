#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;
  
set hive.exec.parallel = true;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
set hive.map.aggr = true;
set hive.groupby.mapaggr.checkinterval = 100000;
set hive.auto.convert.join = true;

----内部归一化
drop table if exists dev_dkx.mjt_pop_cate_user_naifenyongpin;
create
  table dev_dkx.mjt_pop_cate_user_naifenyongpin STORED AS ORC tblproperties
  (
    'orc.compress' = 'SNAPPY'
  ) as
select
	a.yyyy_mm year_dt,
	a.item_first_cate_name  first_name,
	a.item_second_cate_name  second_name,
	sum(1) total_user,
	sum(case when fst_all_yn = 1 then 1 else 0 end) out_user,
	sum(case when fst_all_yn = 0 then 1 else 0 end) inner_user
from
	(
		select /*+ MAPJOIN(a)*/
			coalesce(d.unif_pin, b.pin) unif_pin,
			a.item_first_cate_name,
			a.item_second_cate_name,
			a.model,
			yyyy_mm,
			count(distinct parent_sale_ord_id) par_ord_num,
			count(distinct sale_ord_id) ord_num,
			sum(after_prefr_amount) amount
		from
			(
				select
					item_sku_id,
					item_id,
					case data_type
						when '1' then '自营'
						when '3' then 'POP'
					end model,
					item_first_cate_name,
					item_second_cate_name,
					brand_code,
					barndname_full brand_name,
					main_brand_code main_brand_cd
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1','3')
					and dept_id_2 = '5011'
			        and item_first_cate_cd in ('1319')
			)
			a
		join
			(
		----成交订单模板
				SELECT
							item_sku_id,
							lower(trim(user_log_acct)) pin,
							year(dt) yyyy_mm,
							sale_ord_id,
							parent_sale_ord_id,
							after_prefr_amount_1 after_prefr_amount,
							sale_qtty
						FROM
							app.v_adm_d04_trade_ord_det_sku_snapshot_fs
						WHERE
							(
						        (
							         dt >= date_sub(sysdate( - 366), day(sysdate( - 1)) - 1)
							         and dt <= sysdate(-366)
								)	
                                or
								(
							         dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1)
							         and dt <= sysdate(-1)
								)
					        )
							AND intraday_ord_deal_flag = '1' ----成交标记
							AND split_status_cd NOT IN('1') --排查拆单的父订单
							AND valid_flag = '1' --有效状态
							AND biz_flag_collect['int_pur_ord_flag'] <> 1 ----内采
							AND biz_flag_collect['dist_ord_flag'] <> 1---分销
							AND biz_flag_collect['corp_ord_flag'] <> 1-----企业订单
							AND biz_flag_collect['xtl_ord_flag'] <> 1 ----新通路
							and biz_flag_collect['yhd_ord_flag'] <> 1 ----一号店
							and substr(ord_flag,60,3) <>'040' ----用户剔除万家
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		left join
			(
				select
					lower(trim(unif_user_log_acct)) unif_pin,
					lower(trim(user_acct_name)) pin
				from
					gdm.gdm_m01_userinfo_basic_da
				where
					dt = sysdate( - 1)
			) ----归一化用户pin
			d
		on
			b.pin = d.pin
		group by
			coalesce(d.unif_pin, b.pin),
			a.item_first_cate_name,
			a.item_second_cate_name,
			a.model,
			yyyy_mm
	)
	a
left join
	(
		select
			item_second_cate_name,
			x.unif_pin,
			x.fst_all_yn,
			year(fst_ord_dt) yyyy_mm
		from
			(
				select
					item_second_cate_name,
					lower(trim(unif_user_log_acct)) unif_pin,
					max(
						case
							when fst_all_yn = 1
							then 1
							else 0
						end) fst_all_yn,
					min(fst_ord_dt) fst_ord_dt
				from
					app.v_adm_s01_user_new_or_old_flag_detail_fs
				where
					dt = sysdate( - 1)
					and tp = 'cate'
				group by
					item_second_cate_name,
					lower(trim(unif_user_log_acct))
			)
			x
		where
			(
				(
					fst_ord_dt >= date_sub(sysdate( - 366), day(sysdate( - 1)) - 1)
					and fst_ord_dt <= sysdate(-366)
				)
				or
				(
					fst_ord_dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1)
					and fst_ord_dt <= sysdate(-1)
				)
			)
	)
	b
on
	b.unif_pin = a.unif_pin
	and a.item_second_cate_name = b.item_second_cate_name
	and b.yyyy_mm = a.yyyy_mm
left join
	(
		select
            lower(trim(unif_user_log_acct)) unif_pin,
            spite_user_flag
        from
            app.v_adm_s01_user_new_or_old_flag_detail_fs
        where
            dt = sysdate(-1)
            and spite_user_flag = 1
        group by
            lower(trim(unif_user_log_acct)),
            spite_user_flag
	)
	c
on
	a.unif_pin = c.unif_pin
where
	c.unif_pin is null
group by
	a.yyyy_mm,
	a.item_first_cate_name,
	a.item_second_cate_name;
"""
ht.exec_sql(
    schema_name = 'dev_dkx',
    sql=sql,
    table_name = 'mjt_pop_cate_user_naifenyongpin',
    merge_flag = True)
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import time
import datetime
import subprocess


sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day

sql_1 = """
--合并小文件
set hive.merge.mapfiles=true;
set hive.merge.mapredfiles = true;
set hive.merge.size.per.task = 256000000;
set hive.merge.smallfiles.avgsize = 256000000;
--存储压缩
set hive.default.fileformat=Orc;
--多线程并发
set hive.exec.parallel = true;
set hive.exec.parallel.thread.number = 8;
--列剪裁
set hive.optimize.cp = true;
set hive.optimize.pruner = true;
--map阶段优化
set mapred.max.split.size = 256000000;
set mapred.min.split.size.per.node = 256000000;
set mapred.min.split.size.per.rack = 256000000;
set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set hive.hadoop.supports.splittable.combineinputformat = true;
set mapreduce.input.fileinputformat.split.maxsize = 256000000;
set mapreduce.input.fileinputformat.split.minsize.per.node=256000000;
set mapreduce.input.fileinputformat.split.minsize.per.rack=256000000;
drop
	table if exists dev_xfp.mjt_spite_user_list_xfp;
create
	table dev_xfp.mjt_spite_user_list_xfp STORED AS ORC tblproperties
	(
		'orc.compress' = 'SNAPPY'
	) as
select
	lower(trim(unif_user_log_acct)) user_log_acct
from
	app.v_adm_s01_user_new_or_old_flag_detail_fs
where
	dt = sysdate( - 1)
	and tp = 'dept'
	and spite_user_flag = 1
group by
	lower(trim(unif_user_log_acct));
"""

ht.exec_sql(schema_name='dev_xfp', table_name='mjt_spite_user_list_xfp', sql=sql_1, merge_flag=True)
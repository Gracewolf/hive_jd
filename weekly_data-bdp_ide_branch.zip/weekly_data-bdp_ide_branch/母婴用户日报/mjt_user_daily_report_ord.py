#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import time
import datetime
import subprocess


sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day

sql_1 = """
--合并小文件
set hive.merge.mapfiles=true;
set hive.merge.mapredfiles = true;
set hive.merge.size.per.task = 256000000;
set hive.merge.smallfiles.avgsize = 256000000;
--存储压缩
set hive.default.fileformat=Orc;
--多线程并发
set hive.exec.parallel = true;
set hive.exec.parallel.thread.number = 8;
--列剪裁
set hive.optimize.cp = true;
set hive.optimize.pruner = true;
--map阶段优化
set mapred.max.split.size = 256000000;
set mapred.min.split.size.per.node = 256000000;
set mapred.min.split.size.per.rack = 256000000;
set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set hive.hadoop.supports.splittable.combineinputformat = true;
set mapreduce.input.fileinputformat.split.maxsize = 256000000;
set mapreduce.input.fileinputformat.split.minsize.per.node=256000000;
set mapreduce.input.fileinputformat.split.minsize.per.rack=256000000;
drop
	table if exists dev_xfp.mjt_user_daily_report_ord;
create
	table dev_xfp.mjt_user_daily_report_ord STORED AS ORC tblproperties
	(
		'orc.compress' = 'SNAPPY'
	) as
select /*+ MAPJOIN(a)*/
	coalesce(d.user_log_acct, b.user_log_acct) user_log_acct,
	coalesce(dim_city_jxkh_level, '未知') dim_city_jxkh_level,
	food_flag,
	dept_id_1,
	dept_name_1,
	dept_id_2,
	dept_name_2,
	dept_id_3,
	dept_name_3,
	item_first_cate_cd,
	item_first_cate_name,
	item_second_cate_cd,
	item_second_cate_name,
	item_third_cate_cd,
	item_third_cate_name,
	main_brand_cd,
	sale_ord_dt,
	this_year_flag,
	last_year_flag,
	moon_year_flag,
	after_prefr_amount,
	sale_ord_id,
	parent_sale_ord_id,
	model,
	brand_code,
	barndname_full,
	shop_id,
	shop_name
from
	(
		select
			item_sku_id,
			dept_id_1,
			dept_name_1,
			dept_id_2,
			dept_name_2,
			dept_id_3,
			dept_name_3,
			item_first_cate_cd,
			item_first_cate_name,
			item_second_cate_cd,
			item_second_cate_name,
			item_third_cate_cd,
			item_third_cate_name,
			case when item_first_cate_cd = '1320' then 1 else 0 end food_flag,
			brand_code,
			barndname_full,
			main_brand_code main_brand_cd,
			shop_id,
			shop_name,
			case data_type
			    when '1' then '自营'
			    when '3' then 'POP'
		    end model
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and dept_id_1 in ('6368')
	)
	a
join
	(
		SELECT
							case when dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1) and dt <= sysdate( - 1) then 1 else 0 end this_year_flag,
			                case when dt >= date_sub(sysdate( - 366), day(sysdate( - 1)) - 1) and dt <= sysdate( - 366) then 1 else 0 end last_year_flag,
			                case when dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1) and dt <= sysdate(-385) then 1 else 0 end moon_year_flag,
			                dt sale_ord_dt,
							item_sku_id,
							rev_addr_city_id,	
							lower(trim(user_log_acct)) user_log_acct,
							sale_ord_id,
							parent_sale_ord_id,
							after_prefr_amount_1 after_prefr_amount,
							sale_qtty
						FROM
							app.v_adm_d04_trade_ord_det_sku_snapshot_fs
						WHERE
							(
				(
					dt >= date_sub(sysdate( - 385), day(sysdate( - 1)) - 1)
					and dt <= sysdate(-385)
				)
				or
				(
					dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1)
					and dt <= sysdate( - 1)
				)
				or
				(
					dt >= date_sub(sysdate( - 366), day(sysdate( - 1)) - 1)
					and dt <= sysdate( - 366)
				)
				or
				(
					dt >= sysdate( - 372)
					and dt <= sysdate( - 366)
				)
				or
				(
					dt >= sysdate( - 7)
					and dt <= sysdate( - 1)
				)
				or 
				(
					dt >= sysdate( - 391)
					and dt <= sysdate(-385)
				)
			)
							AND intraday_ord_deal_flag = '1' ----成交标记
							AND split_status_cd NOT IN('1') --排查拆单的父订单
							AND valid_flag = '1' --有效状态
							AND biz_flag_collect['int_pur_ord_flag'] <> 1 ----内采
							AND biz_flag_collect['dist_ord_flag'] <> 1---分销
							AND biz_flag_collect['corp_ord_flag'] <> 1-----企业订单
							AND biz_flag_collect['xtl_ord_flag'] <> 1 ----新通路
							and biz_flag_collect['yhd_ord_flag'] <> 1 ----一号店
							and substr(ord_flag,60,3) <>'040' ----用户剔除万家
	)
	b
on
	a.item_sku_id = b.item_sku_id
left join
	(
		select
			lower(trim(unif_user_log_acct)) user_log_acct,
			lower(trim(user_acct_name)) pin
		from
			gdm.gdm_m01_userinfo_basic_da
		where
			dt = sysdate( - 1)
	) ----归一化用户pin
	d
on
	b.user_log_acct = d.pin
left join
	(
		select dim_city_id, dim_city_jxkh_level from dim.dim_cmo_user_jxkh_county_new group by dim_city_jxkh_level, dim_city_id
	)
	e
on
	b.rev_addr_city_id = e.dim_city_id;
	
--合并小文件
set hive.merge.mapfiles=true;
set hive.merge.mapredfiles = true;
set hive.merge.size.per.task = 256000000;
set hive.merge.smallfiles.avgsize = 256000000;
--存储压缩
set hive.default.fileformat=Orc;
--多线程并发
set hive.exec.parallel = true;
set hive.exec.parallel.thread.number = 8;
--列剪裁
set hive.optimize.cp = true;
set hive.optimize.pruner = true;
--map阶段优化
set mapred.max.split.size = 256000000;
set mapred.min.split.size.per.node = 256000000;
set mapred.min.split.size.per.rack = 256000000;
set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set hive.hadoop.supports.splittable.combineinputformat = true;
set mapreduce.input.fileinputformat.split.maxsize = 256000000;
set mapreduce.input.fileinputformat.split.minsize.per.node=256000000;
set mapreduce.input.fileinputformat.split.minsize.per.rack=256000000;
insert overwrite table dev_xfp.nz_user_daily_report_ord_total
select
    cmt,
    user_log_acct,
    sum(after_prefr_amount) after_prefr_amount
from
    (
        select
        	'今年' cmt,
        	user_log_acct,
        	after_prefr_amount
        from
        	dev_xfp.mjt_user_daily_report_ord
        where
        	this_year_flag = 1 and dept_id_2 = '5011'
        
        union all
        
        select
        	'公历' cmt,
        	user_log_acct,
        	after_prefr_amount
        from
        	dev_xfp.mjt_user_daily_report_ord
        where
        	last_year_flag = 1 and dept_id_2 = '5011'
        
        union all
        
        select
        	'农历' cmt,
        	user_log_acct,
        	after_prefr_amount
        from
        	dev_xfp.mjt_user_daily_report_ord
        where
        	moon_year_flag = 1 and dept_id_2 = '5011'
    )
    ff
group by
    cmt,
    user_log_acct;	

"""

ht.exec_sql(schema_name='dev_xfp', sql=sql_1, merge_flag=False)
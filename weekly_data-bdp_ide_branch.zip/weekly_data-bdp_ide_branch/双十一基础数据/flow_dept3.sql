set hive.exec.parallel = true;
select
	coalesce(t1.dept_name_2, t2.dept_name_2) 二级部门,
	coalesce(t1.dept_name_3, t2.dept_name_3) 三级部门,
	sum(case when t1.year_dt = 2018 then t1.用户数 end) 2018用户数,
	sum(case when t1.year_dt = 2018 then t1.子单数 end) 2018子单数,
	sum(case when t1.year_dt = 2018 then t1.父单数 end) 2018父单数,
	sum(case when t1.year_dt = 2018 then t1.优惠后金额 end) 2018优惠后金额,
	sum(case when t1.year_dt = 2018 then t2.pv end) 2018pv,
	sum(case when t1.year_dt = 2018 then t2.uv end) 2018uv,
	sum(case when t1.year_dt = 2017 then t1.用户数 end) 2017用户数,
	sum(case when t1.year_dt = 2017 then t1.子单数 end) 2017子单数,
	sum(case when t1.year_dt = 2017 then t1.父单数 end) 2017父单数,
	sum(case when t1.year_dt = 2017 then t1.优惠后金额 end) 2017优惠后金额,
	sum(case when t1.year_dt = 2017 then t2.pv end) 2017pv,
	sum(case when t1.year_dt = 2017 then t2.uv end) 2017uv
from
	(
		select /*+ mapjoin(a)*/
			a.dept_name_2,
			a.dept_name_3,
			b.year_dt,
			count(distinct b.user_log_acct) 用户数,
			count(distinct b.sale_ord_id) 子单数,
			count(distinct b.parent_sale_ord_id) 父单数,
			sum(b.after_prefr_amount_1) 优惠后金额
		from
			(
				select
					item_sku_id,
					dept_name_2,
					dept_name_3
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
			)
			a
		join
			(
				select
					b.*
				from
					(
						select
							user_log_acct,
							item_sku_id,
							year(sale_ord_dt) year_dt,
							parent_sale_ord_id,
							sale_ord_id,
							after_prefr_amount_1,
							check_account_tm,
							sale_qtty,
							sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
						from
							gdm.gdm_m04_ord_det_sum
						where
							dt >= '2017-10-21'
							and
							(
								(
									sale_ord_dt >= '2017-10-21'
									and sale_ord_dt <= '2017-11-15'
								)
								or
								(
									sale_ord_dt >= '2018-10-21'
									and sale_ord_dt <= '2018-11-15'
								)
							)
							and sale_ord_valid_flag = '1'
							and item_third_cate_cd not in('6980') --剔除礼品卡
							and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
							and
							(
								substr(ord_flag, 31, 1) <> '2' --非行政内采
								or
								(
									substr(ord_flag, 31, 1) = '2'
									and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
								)
							)
							and
							(
								substr(ord_flag, 46, 1) not in('1', '2', '3', '7')
								or substr(ord_flag, 60, 3) not in('013')
							)
							and sale_ord_type_cd <> '68' --剔除拍卖
							and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
							and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
							and user_log_acct not like"ept%"
					)
					b
				where
					b.ord_amount < 100000
					or
					(
						b.ord_amount >= 100000
						and coalesce(b.check_account_tm, '') <> ''
					)
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		group by
			a.dept_name_2,
			a.dept_name_3,
			b.year_dt
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			a.dept_name_2,
			a.dept_name_3,
			b.year_dt,
			sum(b.pv) pv,
			count(distinct b.browser_uniq_id) uv
		from
			(
				select
					item_sku_id,
					dept_name_2,
					dept_name_3
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					sku_id,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2017-10-21'
							and dt <= '2017-11-15'
						)
						or
						(
							dt >= '2018-10-21'
							and dt <= '2018-11-15'
						)
					)
				group by
					sku_id,
					year(dt),
					browser_uniq_id
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			a.dept_name_2,
			a.dept_name_3,
			b.year_dt
	)
	t2
on
	t1.dept_name_2 = t2.dept_name_2
	and t1.dept_name_3 = t2.dept_name_3
	and t1.year_dt = t2.year_dt
group by
	coalesce(t1.dept_name_2, t2.dept_name_2),
	coalesce(t1.dept_name_3, t2.dept_name_3)
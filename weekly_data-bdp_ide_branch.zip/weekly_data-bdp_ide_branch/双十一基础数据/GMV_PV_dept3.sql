set hive.exec.parallel = true;
select
	coalesce(t1.dept_name_2, t2.dept_name_2) 二级部门,
	coalesce(t1.dept_name_3, t2.dept_name_3) 三级部门,
	sum(case when t1.year_dt = 2018 then t1.GMV end) 2018GMV,
	sum(case when t1.year_dt = 2018 then t2.pv end) 2018pv,
	sum(case when t1.year_dt = 2017 then t1.GMV end) 2017GMV,
	sum(case when t1.year_dt = 2017 then t2.pv end) 2017pv
from
	(
		select /*+ mapjoin(a)*/
			a.dept_name_2,
			a.dept_name_3,
			b.year_dt,
			sum(b.cw_gmv) GMV
		from
			(
				select
					item_sku_id,
					data_type,
					dept_name_2,
					dept_name_3
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					ord_flag,
					item_second_cate_cd,
					item_third_cate_cd,
					item_sku_id,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2017-10-21'
							and dt <= '2017-11-15'
						)
						or
						(
							dt >= '2018-10-21'
							and dt <= '2018-11-15'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		where
			(
				a.data_type = '1'
				and substr(b.ord_flag, 40, 1) <> '1'
			) ----自营剔分销
			or
			(
				a.data_type = '3'
				and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
			) ----POP剔赠品
		group by
			a.dept_name_2,
			a.dept_name_3,
			b.year_dt
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			a.dept_name_2,
			a.dept_name_3,
			b.year_dt,
			sum(b.pv) pv
		from
			(
				select
					item_sku_id,
					dept_name_2,
					dept_name_3
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					sku_id,
					sum(sku_pv) pv
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2017-10-21'
							and dt <= '2017-11-15'
						)
						or
						(
							dt >= '2018-10-21'
							and dt <= '2018-11-15'
						)
					)
				group by
					sku_id,
					year(dt)
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			a.dept_name_2,
			a.dept_name_3,
			b.year_dt
	)
	t2
on
	t1.dept_name_2 = t2.dept_name_2
	and t1.dept_name_3 = t2.dept_name_3
	and t1.year_dt = t2.year_dt
group by
	coalesce(t1.dept_name_2, t2.dept_name_2),
	coalesce(t1.dept_name_3, t2.dept_name_3)
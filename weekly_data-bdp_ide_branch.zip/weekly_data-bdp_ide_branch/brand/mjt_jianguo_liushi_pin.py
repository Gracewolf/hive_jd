#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;
  
set hive.exec.parallel = true;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
set hive.map.aggr = true;
set hive.groupby.mapaggr.checkinterval = 100000;
set hive.auto.convert.join = true;

----内部归一化
drop table if exists dev_dkx.mjt_jianguo_liushi_pin;
create
  table dev_dkx.mjt_jianguo_liushi_pin STORED AS ORC tblproperties
  (
    'orc.compress' = 'SNAPPY'
  ) as
select 
    yy.user_pin,
	yy.京享值,
	yy.plusornot,
	yy.城市等级,
	yy.省份,
	yy.区域,
	yy.浏览次数,
	ww.dept_name_3 流失期间购买的其他食品品类,
	count(ww.dept_name_3) 流失期间购买其他食品品类次数,
	yy.流失前购买坚果品类,
	yy.流失前购买坚果品类次数,
	yy.流失前购买坚果品牌,
	yy.流失前购买品牌次数,
	yy.流失前购买坚果金额,
	yy.流失前购买坚果子单量
from
    (          
    	select  
            tt.user_pin,
			sum(total_score) 京享值,
			plusornot,
			城市等级,
			省份,
			区域,
			浏览次数,
			tt.item_third_cate_name 流失前购买坚果品类,
		    count(tt.item_third_cate_name) 流失前购买坚果品类次数,
			tt.brand_name 流失前购买坚果品牌,
			count(tt.brand_name) 流失前购买品牌次数,
			sum(tt.after_prefr_amount_1) 流失前购买坚果金额,
			count(distinct tt.sale_ord_id) 流失前购买坚果子单量
		from		
            (
                select
	                a.unif_pin user_pin,
					coalesce(d.dim_city_jxkh_level, '未知') 城市等级,
					coalesce(d.dim_province_name, '未知') 省份,
					coalesce(d.dim_region, '未知') 区域,
					brand_name,
					item_third_cate_name,
					after_prefr_amount_1,
                    sale_ord_id,
                    CASE
				        when identity_cnt >= 1 then 'plus'
				        ELSE 'noplus'
			        end as plusornot,
                    total_score				
                from
	                (
		                select /*+ MAPJOIN(a)*/
			                coalesce(d.unif_pin, b.pin) unif_pin,
			                b.year_dt,
			                a.brand_code,
			                a.brand_name,
							a.item_third_cate_name,
			                a.main_brand_cd,
							rev_addr_city_id,
							after_prefr_amount_1,
							sale_ord_id,
							sum(
						        CASE
							        WHEN b.sale_ord_tm >= pluser.begin_date AND b.sale_ord_tm <= pluser.end_real_date THEN 1 ELSE 0
						            end
							    ) AS identity_cnt,
							 total_score   
		                from
			                (
				                select
					                item_sku_id,
					                item_id,
									item_third_cate_name,
					                brand_code,
					                barndname_full brand_name,
					                main_brand_code main_brand_cd
				                from
					                gdm.gdm_m03_sold_item_sku_da
				                where
					                dt = sysdate( - 1)
					                and data_type in('1', '3')
					                and dept_id_2 = '47'
					                and dept_id_3 = '3840'
			                )
			                a
		                    join
			                (
		                        ----成交
				                SELECT
                                    item_sku_id,
                                    lower(trim(user_log_acct)) pin,
                                    year(dt) year_dt,
                                    sale_ord_id,
									sale_ord_tm,
									rev_addr_city_id,
                                    parent_sale_ord_id,
                                    after_prefr_amount_1,
                                    sale_qtty
                                FROM
                                    app.v_adm_d04_trade_ord_det_sku_snapshot_xfp
                                WHERE
                                    (
                                        (
                                            dt >= '2020-03-01'
                                            and dt <= '2020-08-31'
                                        )  
                                    )
                                    AND intraday_ord_deal_flag = '1' ----成交标记
                                    AND split_status_cd NOT IN('1') --排查拆单的父订单
                                    AND valid_flag = '1' --有效状态
                                    AND biz_flag_collect['int_pur_ord_flag'] <> 1 ----内采
                                    AND biz_flag_collect['dist_ord_flag'] <> 1---分销
                                    AND biz_flag_collect['corp_ord_flag'] <> 1-----企业订单
                                    AND biz_flag_collect['xtl_ord_flag'] <> 1 ----新通路
                                    AND virtual_ord_flag <> '1'---剔除虚拟订单
                                    and biz_flag_collect['yhd_ord_flag'] <> 1 ----一号店
			                )
			                b
		                    on
			                    a.item_sku_id = b.item_sku_id
		                    left join
			                (
				                select
					                lower(trim(unif_user_log_acct)) unif_pin,
					                lower(trim(user_acct_name)) pin
				                from
					                gdm.gdm_m01_userinfo_basic_da
				                where
					                dt = sysdate( - 1)
			                ) ----归一化用户pin
			                d
		                    on
			                    b.pin = d.pin
							left join
					        (
						        SELECT
							        lower(trim(pin)) as pin,
							        begin_date,
							        end_real_date
						        FROM
							        fdm.fdm_plus_n_plus_pins_stage__chain
						        WHERE
							        dp = 'ACTIVE'
							        AND 
                                    (
								        stage IN(4000)
								        or sku_no = '100012971100'
							        )
							        AND flag <> '-1'
						        GROUP BY
							        lower(trim(pin)),
							        begin_date,
							        end_real_date
					       )
					       pluser
				           ON
					            b.pin = pluser.pin	
							left join
                            (
							    select 
								    lower(trim(jd_pin)) pin,
                                    total_score
                                from 
                                    app.app_cmo_dmt_jdmem_user_score_da
                                where 
                                    dt = sysdate(-1)
								group by
                                    lower(trim(jd_pin)),
                                    total_score								
							)
                            e
                            on 
							    e.pin = b.pin							
		                    group by
			                    coalesce(d.unif_pin, b.pin),
			                    b.year_dt,
			                    a.brand_code,
			                    a.brand_name,
			                    a.main_brand_cd,
			                    a.item_third_cate_name,
								rev_addr_city_id,
								after_prefr_amount_1,
								sale_ord_id,
								total_score
	                )
	                a
					left join
	                (
		            select dim_city_id, dim_city_jxkh_level, dim_province_name,dim_region from dim.dim_cmo_user_jxkh_county_new group by dim_city_id, dim_city_jxkh_level, dim_province_name,dim_region	
	                )
	                d
                    on
	                 a.rev_addr_city_id = d.dim_city_id	
                    left join
	                (
		                select
                            lower(trim(unif_user_log_acct)) unif_pin,
                            spite_user_flag
                        from
                            app.v_adm_s01_user_new_or_old_flag_detail_xfp
                        where
                            dt = sysdate(-2)
                            and spite_user_flag = 1
                        group by
                            lower(trim(unif_user_log_acct)),
                            spite_user_flag
	                )
	                c
                    on
	                    a.unif_pin = c.unif_pin
                    where
	                    c.unif_pin is null
	           group by 
	                a.unif_pin,
					coalesce(d.dim_city_jxkh_level, '未知'),
					coalesce(d.dim_province_name, '未知'),
					coalesce(d.dim_region, '未知'),
					brand_name,
					item_third_cate_name,
					after_prefr_amount_1,
                    sale_ord_id,
                    CASE
				        when identity_cnt >= 1 then 'plus'
				        ELSE 'noplus'
			        end,
                    total_score
            )	
            tt
            left join
            (
			    select
					coalesce(c.user_log_acct, b.user_log_acct) pin,
					sum(sku_pv) 浏览次数
				from
					(
						select
							item_sku_id,
							dept_id_2 pt_id,
							dept_name_2 pt_name
						from
							gdm.gdm_m03_mkt_item_sku_da
						where
							dt = sysdate( - 1)
							and dept_id_1 = '33'
							and dept_id_2 = '47'
							and dept_id_3 = '3840'
					)
					a
				join
					(
						select
							sku_id,
							lower(trim(user_log_acct)) user_log_acct,
							sku_pv
						from
							adm.adm_s14_online_log_smart_item_d
						where
							(
								(
									dt >= '2020-09-01'
									and dt <= '2020-12-31'
								)
							)
					)
					b
				on
					a.item_sku_id = b.sku_id
				left join
					(
						select
							lower(trim(unif_user_log_acct)) user_log_acct,
							lower(trim(user_acct_name)) pin
						from
							gdm.gdm_m01_userinfo_basic_da
						where
							dt = sysdate( - 1)
					) ----归一化用户pin
					c
				on
					b.user_log_acct = c.pin
				group by
					coalesce(c.user_log_acct, b.user_log_acct)
		    )
			zz
			on
				zz.pin = tt.user_pin
            left join
            (
                select
	                distinct(a.unif_pin) user_pin
                from
	                (
		                select /*+ MAPJOIN(a)*/
			                coalesce(d.unif_pin, b.pin) unif_pin,
			                b.year_dt,
			                a.brand_code,
			                a.brand_name,
			                a.main_brand_cd
		                from
			                (
				                select
					                item_sku_id,
					                item_id,
					                brand_code,
					                barndname_full brand_name,
					                main_brand_code main_brand_cd
				                from
					                gdm.gdm_m03_sold_item_sku_da
				                where
					                dt = sysdate( - 1)
					                and data_type in('1', '3')
					                and dept_id_2 = '47'
					                and dept_id_3 = '3840'
			                )
			                a
		                    join
			                (
		                        ----有效订单模板
				                SELECT
                                    item_sku_id,
                                    lower(trim(user_log_acct)) pin,
                                    year(dt) year_dt,
                                    sale_ord_id,
                                    parent_sale_ord_id,
                                    after_prefr_amount_1,
                                    sale_qtty
                                FROM
                                    app.v_adm_d04_trade_ord_det_sku_snapshot_xfp
                                WHERE
                                    (
                                        (
                                            dt >= '2020-09-01'
                                            and dt <= '2020-12-31'
                                        )  
                                    )
                                    AND intraday_ord_deal_flag = '1' ----成交标记
                                    AND split_status_cd NOT IN('1') --排查拆单的父订单
                                    AND valid_flag = '1' --有效状态
                                    AND biz_flag_collect['int_pur_ord_flag'] <> 1 ----内采
                                    AND biz_flag_collect['dist_ord_flag'] <> 1---分销
                                    AND biz_flag_collect['corp_ord_flag'] <> 1-----企业订单
                                    AND biz_flag_collect['xtl_ord_flag'] <> 1 ----新通路
                                    AND virtual_ord_flag <> '1'---剔除虚拟订单
                                    and biz_flag_collect['yhd_ord_flag'] <> 1 ----一号店
			                )
			                b
		                    on
			                    a.item_sku_id = b.item_sku_id
		                    left join
			                (
				                select
					                lower(trim(unif_user_log_acct)) unif_pin,
					                lower(trim(user_acct_name)) pin
				                from
					                gdm.gdm_m01_userinfo_basic_da
				                where
					                dt = sysdate( - 1)
			                ) ----归一化用户pin
			                d
		                    on
			                    b.pin = d.pin
		                    group by
			                    coalesce(d.unif_pin, b.pin),
			                    b.year_dt,
			                    a.brand_code,
			                    a.brand_name,
			                    a.main_brand_cd
	                )
	                a
                    left join
	                (
		                select
                            lower(trim(unif_user_log_acct)) unif_pin,
                            spite_user_flag
                        from
                            app.v_adm_s01_user_new_or_old_flag_detail_xfp
                        where
                            dt = sysdate(-2)
                            and spite_user_flag = 1
                        group by
                            lower(trim(unif_user_log_acct)),
                            spite_user_flag
	                )
	                c
                    on
	                    a.unif_pin = c.unif_pin
                    where
	                    c.unif_pin is null
            )
            ff
            on 
                tt.user_pin = ff.user_pin
            where
                ff.user_pin is null	 
        group by 
            tt.user_pin,
			plusornot,
			城市等级,
			省份,
			区域,
			浏览次数,
			tt.item_third_cate_name,
			tt.brand_name
	)
    yy
    left join
    (
	            select
				    dept_name_3,
	                a.unif_pin user_pin
                from
	                (
		                select /*+ MAPJOIN(a)*/
			                coalesce(d.unif_pin, b.pin) unif_pin,
			                b.year_dt,
			                a.brand_code,
			                a.brand_name,
			                a.main_brand_cd,
							dept_name_3
		                from
			                (
				                select
					                item_sku_id,
					                item_id,
									dept_name_3,
					                brand_code,
					                barndname_full brand_name,
					                main_brand_code main_brand_cd
				                from
					                gdm.gdm_m03_sold_item_sku_da
				                where
					                dt = sysdate( - 1)
					                and data_type in('1')
					                and dept_id_2 = '47'
					                and dept_id_3 not in ('3840')
			                )
			                a
		                    join
			                (
		                        ----有效订单模板
				                SELECT
                                    item_sku_id,
                                    lower(trim(user_log_acct)) pin,
                                    year(dt) year_dt,
                                    sale_ord_id,
                                    parent_sale_ord_id,
                                    after_prefr_amount_1,
                                    sale_qtty
                                FROM
                                    app.v_adm_d04_trade_ord_det_sku_snapshot_xfp
                                WHERE
                                    (
                                        (
                                            dt >= '2020-09-01'
                                            and dt <= '2020-12-31'
                                        )  
                                    )
                                    AND intraday_ord_deal_flag = '1' ----成交标记
                                    AND split_status_cd NOT IN('1') --排查拆单的父订单
                                    AND valid_flag = '1' --有效状态
                                    AND biz_flag_collect['int_pur_ord_flag'] <> 1 ----内采
                                    AND biz_flag_collect['dist_ord_flag'] <> 1---分销
                                    AND biz_flag_collect['corp_ord_flag'] <> 1-----企业订单
                                    AND biz_flag_collect['xtl_ord_flag'] <> 1 ----新通路
                                    AND virtual_ord_flag <> '1'---剔除虚拟订单
                                    and biz_flag_collect['yhd_ord_flag'] <> 1 ----一号店
			                )
			                b
		                    on
			                    a.item_sku_id = b.item_sku_id
		                    left join
			                (
				                select
					                lower(trim(unif_user_log_acct)) unif_pin,
					                lower(trim(user_acct_name)) pin
				                from
					                gdm.gdm_m01_userinfo_basic_da
				                where
					                dt = sysdate( - 1)
			                ) ----归一化用户pin
			                d
		                    on
			                    b.pin = d.pin
		                    group by
			                    coalesce(d.unif_pin, b.pin),
			                    b.year_dt,
			                    a.brand_code,
			                    a.brand_name,
			                    a.main_brand_cd,
			                    dept_name_3
	                )
	                a
                    left join
	                (
		                select
                            lower(trim(unif_user_log_acct)) unif_pin,
                            spite_user_flag
                        from
                            app.v_adm_s01_user_new_or_old_flag_detail_xfp
                        where
                            dt = sysdate(-2)
                            and spite_user_flag = 1
                        group by
                            lower(trim(unif_user_log_acct)),
                            spite_user_flag
	                )
	                c
                    on
	                    a.unif_pin = c.unif_pin
                    where
	                    c.unif_pin is null
	               group by
	                   dept_name_3,
	                   a.unif_pin
	)
    ww
    on 
	   yy.user_pin = ww.user_pin	
group by 
    yy.user_pin,
	yy.京享值,
	yy.plusornot,
	yy.城市等级,
	yy.省份,
	yy.区域,
	yy.浏览次数,
	ww.dept_name_3,
	yy.流失前购买坚果品类,
	yy.流失前购买坚果品类次数,
	yy.流失前购买坚果品牌,
	yy.流失前购买品牌次数,
	yy.流失前购买坚果金额,
	yy.流失前购买坚果子单量;
"""
ht.exec_sql(
    schema_name = 'dev_dkx',
    sql=sql,
    table_name = 'mjt_jianguo_liushi_pin',
    merge_flag = True)
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;
  
set hive.exec.parallel = true;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
set hive.map.aggr = true;
set hive.groupby.mapaggr.checkinterval = 100000;
set hive.auto.convert.join = true;

----内部归一化
drop table if exists dev_dkx.mjt_plus_sku;
create
  table dev_dkx.mjt_plus_sku STORED AS ORC tblproperties
  (
    'orc.compress' = 'SNAPPY'
  ) as
SELECT
			b.item_sku_id
		FROM
			(
				SELECT
					item_sku_id
				FROM
					gdm.gdm_m03_mkt_item_sku_da
				WHERE
					dt = sysdate( - 1)
					AND dept_id_1 = '33'
					AND dept_id_2 = '47'
			)
			a
		JOIN
			(
				SELECT
					sale_ord_id,
					item_sku_id,
					sku_promotion_id,
					mm.promt_name
				FROM
					(
						SELECT
							promt_id,
							promt_name
						FROM
							gdm.gdm_m07_sku_promotion
						WHERE
							dt >= '2021-01-08'
							AND plus_flag = '1'
							AND promt_type_cd = '1'
					)
					mm
				JOIN
					(
						SELECT
							sale_ord_id,
							item_sku_id,
							sku_promotion_id
						FROM
							app.v_gdm_m04_ord_promotion_sum_xfp
						WHERE
							dt >= '2021-01-08'
							AND dt <= '2021-01-08'
					)
					nn
				ON
					mm. promt_id = nn.sku_promotion_id
			)
			b 
			ON a.item_sku_id = b.item_sku_id
		group by
			b.item_sku_id;
"""
ht.exec_sql(
    schema_name = 'dev_dkx',
    sql=sql,
    table_name = 'mjt_plus_sku',
    merge_flag = True)
			
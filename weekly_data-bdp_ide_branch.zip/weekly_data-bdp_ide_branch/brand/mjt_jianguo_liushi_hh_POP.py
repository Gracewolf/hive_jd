#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;
  
set hive.exec.parallel = true;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
set hive.map.aggr = true;
set hive.groupby.mapaggr.checkinterval = 100000;
set hive.auto.convert.join = true;

----内部归一化
drop table if exists dev_dkx.mjt_jianguo_liushi_hh_POP;
create
  table dev_dkx.mjt_jianguo_liushi_hh_POP STORED AS ORC tblproperties
  (
    'orc.compress' = 'SNAPPY'
  ) as
select 
    yy.user_pin,
	yy.jingxiangzhi,
	yy.plusornot,
	yy.city_level,
	yy.province,
	yy.region,
	yy.liulancishu,
	ww.item_third_cate_name  in_other_food,
	count(ww.item_third_cate_name) in_other_food_number,
	yy.item_third_cate_name before_jianguo,
	count(yy.item_third_cate_name) before_jianguo_number,
	yy.brand_name before_jianguo_brand,
	count(yy.brand_name) before_jianguo_brand_number,
	sum(yy.after_prefr_amount_1) before_jianguo_amount,
	yy.sale_ord_id
from
    (          
    	select  
            tt.user_pin,
			sum(total_score) jingxiangzhi,
			plusornot,
			city_level,
			province,
			region,
			liulancishu,
			tt.item_third_cate_name,
			tt.brand_name,
			tt.after_prefr_amount_1,
			tt.sale_ord_id
		from		
            (
                select * from dev_dkx.mjt_jianguo_liushi_tt_POP
            )	
            tt
            left join
            (
			    select * from dev_dkx.mjt_jianguo_liushi_zz_POP
		    )
			zz
			on
				zz.pin = tt.user_pin
            left join
            (
                select * from dev_dkx.mjt_jianguo_liushi_ff_POP
            )
            ff
            on 
                tt.user_pin = ff.user_pin
            where
                ff.user_pin is null	 
        group by 
            tt.user_pin,
			plusornot,
			city_level,
			province,
			region,
			liulancishu,
			tt.item_third_cate_name,
			tt.brand_name,
			tt.after_prefr_amount_1,
			tt.sale_ord_id
	)
    yy
    left join
    (
	    select * from dev_dkx.mjt_jianguo_liushi_ww_POP        
	)
    ww
    on 
	   yy.user_pin = ww.user_pin	
group by 
    yy.user_pin,
	yy.jingxiangzhi,
	yy.plusornot,
	yy.city_level,
	yy.province,
	yy.region,
	yy.liulancishu,
	ww.item_third_cate_name, 
	yy.item_third_cate_name,
	yy.brand_name,
	yy.sale_ord_id;
"""
ht.exec_sql(
    schema_name = 'dev_dkx',
    sql=sql,
    table_name = 'mjt_jianguo_liushi_hh_POP',
    merge_flag = True)

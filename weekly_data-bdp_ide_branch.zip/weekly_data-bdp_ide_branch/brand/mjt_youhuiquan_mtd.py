#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;
  
set hive.exec.parallel = true;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
set hive.map.aggr = true;
set hive.groupby.mapaggr.checkinterval = 100000;
set hive.auto.convert.join = true;

----内部归一化
drop table if exists dev_dkx.mjt_youhuiquan_mtd;
create
  table dev_dkx.mjt_youhuiquan_mtd STORED AS ORC tblproperties
  (
    'orc.compress' = 'SNAPPY'
  ) as
select
	a.批次号,
	coalesce(b.优惠券名称, '未知') 优惠券名称,
	coalesce(b.面额, '未知') 面额,
	coalesce(b.消费限额, '未知') 消费限额,
	coalesce(b.创建时间, '未知') 创建时间,
	coalesce(b.优惠券总量, '未知') 优惠券总量,
	coalesce(c.cn, '未知') 优惠券领用量,
	a.优惠券使用量,
	a.子单数,
	a.父单数,
	a.优惠券成本,
	a.金额,
	a.用户数,
	a.用户数剔刷,
	a.全站新用户,
	a.全站新用户剔刷,
	a.品类新用户,
	a.品类新用户剔刷
from
	(
		select
			batch_id 批次号,
			count(distinct cps_id) 优惠券使用量,
			count(distinct b.sale_ord_id) 子单数,
			count(distinct b.parent_sale_ord_id) 父单数,
			sum(pay_amount) 优惠券成本,
			sum(after_prefr_amount_1) 金额,
			count(distinct b.pin) 用户数,
			count(distinct case when d.user_log_acct is null then b.pin end) 用户数剔刷,
			count(distinct case when fst_all_yn = 1 then b.pin end) 全站新用户,
			count(distinct case when fst_all_yn = 1 and d.user_log_acct is null then b.pin end) 全站新用户剔刷,
			count(distinct c.pin) 品类新用户,
			count(distinct case when d.user_log_acct is null then c.pin end) 品类新用户剔刷
		from
			(
				select
					item_sku_id
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
			)
			a
		join
			(
				select
					lower(trim(user_log_acct_unif)) pin,
					year(sale_ord_tm) year_dt,
					batch_id,
					cps_name,
					cps_id,
					sale_ord_id,
					parent_sale_ord_id,
					sale_qtty,
					pay_amount,
					after_prefr_amount_1,
					sku_id
				from
					adm.adm_d07_cps_batch_ord_sku_det_sz
				where
					dt >= '2021-01-01'
					and dt <= sysdate(-1)
					and batch_id in ('766668158','762433542','762097594','763294090','763195774','763195778','763226486','763334510','763250914','763346446','766220550','766220486','765128774','763514230','763249702','765328714','766948486','765713494','761920670','762780206','762888602','766946518','766947030','766191526','766214694','765842798','766214362','766222422','766222390','765849810','766222374','765849810','766222330','766194162','766194342','766194358','765125846','766218706','766945994','765326154','765326166','765331926','763323550','763515710','763515718','763335294','766476802','766668930','766800734','766656942','761995710')
					and index_flag = '1'
			)
			b
		on
			a.item_sku_id = b.sku_id
		left join
			(
				select
				    pin,
					parent_sale_ord_id,
					sale_ord_id,
					fst_all_yn
				from
					(
						select
							lower(trim(unif_user_log_acct)) pin,
							sale_ord_id,
							parent_sale_ord_id,
							fst_ord_tm,
							max(case when fst_all_yn = '1' then 1 else 0 end) over(partition by lower(trim(unif_user_log_acct))) as fst_all_yn,
							min(fst_ord_tm) over(partition by lower(trim(unif_user_log_acct))) as min_ord_tm
						from
							app.v_adm_s01_user_new_or_old_flag_detail_xfp
						where
							dt = sysdate( - 1)
							and tp = 'dept'
							and dept_id_2 = '47'
					)
					ff
				where
					fst_ord_tm = min_ord_tm
				group by
				    pin,
					parent_sale_ord_id,
					sale_ord_id,
					fst_all_yn
			)
			c
		on
			b.sale_ord_id = c.sale_ord_id
			and b.parent_sale_ord_id = c.parent_sale_ord_id
		left join
			(
				select
					lower(trim(unif_user_log_acct)) user_log_acct
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 1)
					and spite_user_flag = '1'
				group by
					lower(trim(unif_user_log_acct))
			)
			d
		on
			b.pin = d.user_log_acct
		group by
			batch_id,
			year_dt
	)
	a
left join
	(
		select
			batch_id 批次号,
			cps_name 优惠券名称,
			cps_face_value 面额,
			consume_lim 消费限额,
			batch_cps_total_qtty 优惠券总量,
			create_tm 创建时间
		from
			gdm.gdm_m07_cps_batch_da
		where
			dt = sysdate( - 1)
			and batch_id in ('766668158','762433542','762097594','763294090','763195774','763195778','763226486','763334510','763250914','763346446','766220550','766220486','765128774','763514230','763249702','765328714','766948486','765713494','761920670','762780206','762888602','766946518','766947030','766191526','766214694','765842798','766214362','766222422','766222390','765849810','766222374','765849810','766222330','766194162','766194342','766194358','765125846','766218706','766945994','765326154','765326166','765331926','763323550','763515710','763515718','763335294','766476802','766668930','766800734','766656942','761995710')
	)
	b
on
	a.批次号 = b.批次号
left join
	(
		select
			batch_id,
			count(distinct cps_id) cn
		from
			gdm.gdm_m07_cps_basic_info
		where
			dt >= '2021-01-01'
			and batch_id in ('766668158','762433542','762097594','763294090','763195774','763195778','763226486','763334510','763250914','763346446','766220550','766220486','765128774','763514230','763249702','765328714','766948486','765713494','761920670','762780206','762888602','766946518','766947030','766191526','766214694','765842798','766214362','766222422','766222390','765849810','766222374','765849810','766222330','766194162','766194342','766194358','765125846','766218706','766945994','765326154','765326166','765331926','763323550','763515710','763515718','763335294','766476802','766668930','766800734','766656942','761995710')
		group by
			batch_id
	)
	c
on
	a.批次号 = c.batch_id;
"""
ht.exec_sql(
    schema_name = 'dev_dkx',
    sql=sql,
    table_name = 'mjt_youhuiquan_mtd',
    merge_flag = True)
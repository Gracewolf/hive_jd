set hive.exec.parallel=true; 
set hive.exec.parallel.thread.number=16; 
--合并小文件
set hive.merge.mapfiles = true;  
set hive.merge.mapredfiles = true;  
set hive.merge.size.per.task=64000000;
set hive.merge.smallfiles.avgsize = 256000000; 
--Map阶段优化
set mapred.max.split.size=256000000; 
set mapred.min.split.size.per.node=256000000; 
set mapred.min.split.size.per.rack=256000000;  
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set hive.join.emit.interval = 2000;
set hive.mapjoin.size.key = 20000;
set hive.mapjoin.cache.numrows = 20000;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer=2000000000;
--数据倾斜
set hive.map.aggr=true;
set hive.groupby.mapaggr.checkinterval=100000;
set hive.auto.convert.join = true;

drop table if exists dev_xfp.nz_pin_out;
create table dev_xfp.nz_pin_out as
select
	coalesce(d.unif_user_log_acct, a.user_log_acct) userpin,
	max(coalesce(total_score, 0)) score
from
	(
		select
			user_log_acct,
			pin
		from
			(
				select
					item_sku_id
				from
					gdm.gdm_m03_mkt_item_sku_da
				where
					dt = sysdate( - 1)
					and item_first_cate_cd = '1320'
					and (item_second_cate_cd = '1583' or item_third_cate_cd in('5022', '5021', '5020'))
			)
			a
		join
			(
				select
					sku_id,
					user_log_acct,
					lower(trim(user_log_acct)) pin
				from
					adm.adm_s14_online_log_smart_item_d
				where
					dt >= sysdate( - 30)
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			user_log_acct,
			pin
	)
	a
left join
	(
		select
			pin
		from
			(
				select
					item_sku_id
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and item_first_cate_cd = '1320'
					and (item_second_cate_cd = '1583' or item_third_cate_cd in('5022', '5021', '5020'))
			)
			a
		join
			(
				select
					item_sku_id,
					user_log_acct,
					lower(trim(user_log_acct)) pin
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					dt >= sysdate( - 30)
					and sale_ord_dt >= sysdate( - 30)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		group by
			pin
	)
	b
on
	a.pin = b.pin
left join
	(
		select
			*
		from
			dev_xfp.nz_risk_user_pin
	)
	c ----风险用户剔除
on
	a.pin = c.pin
left join
	(
		select
			unif_user_log_acct,
			lower(trim(user_acct_name)) pin
		from
			gdm.gdm_m01_userinfo_basic_da
		where
			dt = sysdate( - 1)
	) ----归一化用户pin
	d
on
	a.pin = d.pin
left join
    (
        select
            lower(trim(jd_pin)) pin,
            total_score
        from
            app.app_cmo_dmt_jdmem_user_score_simple_da
        where
            dt = sysdate( - 1)
    )
    e
on
    a.pin = e.pin
join
	(
		select
			lower(trim(user_log_acct)) pin
		from
			adm.adm_l01_nonpolar_view_da_ori
		where
			dt = sysdate( - 2)
			and cpp_seni_haschild in('高', '较高')
		group by
			lower(trim(user_log_acct))
	)
	f
on
    a.pin = f.pin
where
	c.pin is null
	and b.pin is null
	and a.pin not like'*yx%'
    and a.pin not like'%yhd%'
    and a.pin not like'xtl%'
    and a.pin not like'ept%'
group by
	coalesce(d.unif_user_log_acct, a.user_log_acct);


select
    case
        when score >= 20000 then '20000'
        when score >= 10000 then '10000'
        when score >= 5000 then '5000'
        when score > 0 then '0'
        else 'mmm'
    end score_level,
    count(1) cn
from
    dev_xfp.nz_pin_out
where
    userpin not like'%yhd%'
    and userpin not like'%xtl%'
    and userpin not like'%ept%'
group by
    case
        when score >= 20000 then '20000'
        when score >= 10000 then '10000'
        when score >= 5000 then '5000'
        when score > 0 then '0'
        else 'mmm'
    end
set hive.exec.dynamic.partition.mode = nonstrict;
set hive.exec.dynamic.partition = true;
set hive.exec.max.dynamic.partitions = 100000;
set hive.exec.max.dynamic.partitions.pernode = 100000;
set hive.exec.parallel = true;
drop table if exists dev_xfp.nz_del_user_pin;
create table dev_xfp.nz_del_user_pin as
select
	pin
from
	(
		select
			lower(trim(pin)) pin
		from
			app_risk.app_st_risk_gooduser_creditscore_result_v3_da ----成都风控表
		where
			dt = sysdate( - 1)
			and gooduser_score > 0
		group by
			lower(trim(pin)) ----风险0级以上用户（不包括0）
		
		union all
		
		select
			pin
		from
			(
				select
					parent_sale_ord_id
				from
					app.app_first_order_abnormal_detection_v2_new
				group by
					parent_sale_ord_id
			)
			a
		join
			(
				select
					lower(trim(user_log_acct)) pin,
					1st_parent_sale_ord_id
				from
					gdm.gdm_m01_user_third_cate_da
				where
					dt = sysdate( - 1)
			)
			b
		on
			a.parent_sale_ord_id = b.1st_parent_sale_ord_id
		group by
			pin
	)
	a
group by
	pin;
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day 

### 新建分区
sql = """
-- 合并小文件 处理小文件参数
--是否和并 Map 输出文件，默认为 True
set hive.merge.mapfiles = true;
--是否合并 Reduce 输出文件，默认为 False
set hive.merge.mapredfiles = true;
--合并文件的大小
set hive.merge.size.per.task = 256000000;
--当输出文件的平均大小小于该值时，启动一个独立的map-reduce任务进行文件merge
set hive.merge.smallfiles.avgsize = 256000000;
-- 执行引擎为spark的任务，如何合并小文件方式
set spark.sql.hive.mergeFiles=true;
  
set hive.exec.parallel = true;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer = 2000000000;
--数据倾斜
set hive.map.aggr = true;
set hive.groupby.mapaggr.checkinterval = 100000;
set hive.auto.convert.join = true;

----内部归一化
drop table if exists dev_dkx.yh_pop_dept_user_mtd;
create
  table dev_dkx.yh_pop_dept_user_mtd STORED AS ORC tblproperties
  (
    'orc.compress' = 'SNAPPY'
  ) as
select
	dept_name,
	total_usr,
	total_usr / total_usr_1 - 1 total_usr_yoy,
	total_usr / total_usr_2 - 1 total_usr_moon_yoy,
	inner_usr inner_usr,
	inner_usr / inner_usr_1 - 1 inner_usr_yoy,
	inner_usr / inner_usr_2 - 1 inner_usr_moon_yoy,
	outer_usr,
	outer_usr / outer_usr_1 - 1 outer_usr_yoy,
	outer_usr / outer_usr_2 - 1 outer_usr_moon_yoy,
	total_usr - inner_usr - outer_usr old_user,
	(total_usr - inner_usr - outer_usr) / (total_usr_1 - inner_usr_1 - outer_usr_1) - 1 old_user_yoy,
	(total_usr - inner_usr - outer_usr) / (total_usr_2 - inner_usr_2 - outer_usr_2) - 1 old_user_moon_yoy,
	total_value / total_usr total_arpu,
	inner_value / inner_usr inner_arpu,
	outer_value / outer_usr outer_arpu,
	(total_value - inner_value - outer_value) / (total_usr - inner_usr - outer_usr) old_arpu,
	(total_value / total_usr) / (total_value_1 / total_usr_1) - 1 total_arpu_YoY,
	(inner_value / inner_usr) / (inner_value_1 / inner_usr_1) - 1 inner_arpu_YoY,
	(outer_value / outer_usr) / (outer_value_1 / outer_usr_1) - 1 outer_arpu_YoY,
	((total_value - inner_value - outer_value) / (total_usr - inner_usr - outer_usr)) / ((total_value_1 - inner_value_1 - outer_value_1) / (total_usr_1 - inner_usr_1 - outer_usr_1)) - 1 old_arpu_YoY,
	(total_value / total_usr) / (total_value_2 / total_usr_2) - 1 total_arpu_moon,
	(inner_value / inner_usr) / (inner_value_2 / inner_usr_2) - 1 inner_arpu_moon,
	(outer_value / outer_usr) / (outer_value_2 / outer_usr_2) - 1 outer_arpu_moon,
	((total_value - inner_value - outer_value) / (total_usr - inner_usr - outer_usr)) / ((total_value_2 - inner_value_2 - outer_value_2) / (total_usr_2 - inner_usr_2 - outer_usr_2)) - 1 old_arpu_moon
from
	(
		select
			dept_name_3 dept_name,
			count(distinct case when a.this_year_flag = 1 then a.user_log_acct end) total_usr,
			count(distinct case when a.this_year_flag = 1 and b.fst_all_yn = 1 then a.user_log_acct end) outer_usr,
			count(distinct case when a.this_year_flag = 1 and b.fst_all_yn = 0 then a.user_log_acct end) inner_usr,
			sum(case when a.this_year_flag = 1 then a.after_prefr_amount else 0 end) total_value,
			sum(case when a.this_year_flag = 1 and b.fst_all_yn = 0 then a.after_prefr_amount else 0 end) inner_value,
			sum(case when a.this_year_flag = 1 and b.fst_all_yn = 1 then a.after_prefr_amount else 0 end) outer_value,
			count(distinct case when a.last_year_flag = 1 then a.user_log_acct end) total_usr_1,
			count(distinct case when a.last_year_flag = 1 and b.fst_all_yn = 1 then a.user_log_acct end) outer_usr_1,
			count(distinct case when a.last_year_flag = 1 and b.fst_all_yn = 0 then a.user_log_acct end) inner_usr_1,
			sum(case when a.last_year_flag = 1 then a.after_prefr_amount else 0 end) total_value_1,
			sum(case when a.last_year_flag = 1 and b.fst_all_yn = 0 then a.after_prefr_amount else 0 end) inner_value_1,
			sum(case when a.last_year_flag = 1 and b.fst_all_yn = 1 then a.after_prefr_amount else 0 end) outer_value_1,
			count(distinct case when a.moon_year_flag = 1 then a.user_log_acct end) total_usr_2,
			count(distinct case when a.moon_year_flag = 1 and b.fst_all_yn = 1 then a.user_log_acct end) outer_usr_2,
			count(distinct case when a.moon_year_flag = 1 and b.fst_all_yn = 0 then a.user_log_acct end) inner_usr_2,
			sum(case when a.moon_year_flag = 1 then a.after_prefr_amount else 0 end) total_value_2,
			sum(case when a.moon_year_flag = 1 and b.fst_all_yn = 0 then a.after_prefr_amount else 0 end) inner_value_2,
			sum(case when a.moon_year_flag = 1 and b.fst_all_yn = 1 then a.after_prefr_amount else 0 end) outer_value_2
		from
			(
				select
					user_log_acct,
					after_prefr_amount,
					dept_id_2,
					dept_name_2,
					dept_id_3,
					dept_name_3,
					this_year_flag,
					last_year_flag,
					moon_year_flag,
					brand_code,
					barndname_full
				from
					dev_xfp.nz_user_daily_report_ord
				where
					dept_id_2 = '5012'
					and (this_year_flag = 1 or last_year_flag = 1 or moon_year_flag = 1)
			)
			a
		left join
			(
				select
					bs,
					user_log_acct,
					fst_all_yn,
					this_year_flag,
					last_year_flag,
					moon_year_flag
				from
					dev_dkx.yh_pop_new_user_flag
				where
					tp = 'dept3'
					and (this_year_flag = 1 or last_year_flag = 1 or moon_year_flag = 1)
			)
			b
		on
			a.user_log_acct = b.user_log_acct
			and a.dept_id_3 = bs
			and a.this_year_flag = b.this_year_flag
			and a.last_year_flag = b.last_year_flag
			and a.moon_year_flag = b.moon_year_flag
		left join
			(
				select user_log_acct from dev_xfp.spite_user_list_xfp
			)
			c
		on
			a.user_log_acct = c.user_log_acct
		where
			c.user_log_acct is null
		group by
			dept_name_3
	
        union all
        
		select
			dept_name_2 dept_name,
			count(distinct case when a.this_year_flag = 1 then a.user_log_acct end) total_usr,
			count(distinct case when a.this_year_flag = 1 and b.fst_all_yn = 1 then a.user_log_acct end) outer_usr,
			count(distinct case when a.this_year_flag = 1 and b.fst_all_yn = 0 then a.user_log_acct end) inner_usr,
			sum(case when a.this_year_flag = 1 then a.after_prefr_amount else 0 end) total_value,
			sum(case when a.this_year_flag = 1 and b.fst_all_yn = 0 then a.after_prefr_amount else 0 end) inner_value,
			sum(case when a.this_year_flag = 1 and b.fst_all_yn = 1 then a.after_prefr_amount else 0 end) outer_value,
			count(distinct case when a.last_year_flag = 1 then a.user_log_acct end) total_usr_1,
			count(distinct case when a.last_year_flag = 1 and b.fst_all_yn = 1 then a.user_log_acct end) outer_usr_1,
			count(distinct case when a.last_year_flag = 1 and b.fst_all_yn = 0 then a.user_log_acct end) inner_usr_1,
			sum(case when a.last_year_flag = 1 then a.after_prefr_amount else 0 end) total_value_1,
			sum(case when a.last_year_flag = 1 and b.fst_all_yn = 0 then a.after_prefr_amount else 0 end) inner_value_1,
			sum(case when a.last_year_flag = 1 and b.fst_all_yn = 1 then a.after_prefr_amount else 0 end) outer_value_1,
			count(distinct case when a.moon_year_flag = 1 then a.user_log_acct end) total_usr_2,
			count(distinct case when a.moon_year_flag = 1 and b.fst_all_yn = 1 then a.user_log_acct end) outer_usr_2,
			count(distinct case when a.moon_year_flag = 1 and b.fst_all_yn = 0 then a.user_log_acct end) inner_usr_2,
			sum(case when a.moon_year_flag = 1 then a.after_prefr_amount else 0 end) total_value_2,
			sum(case when a.moon_year_flag = 1 and b.fst_all_yn = 0 then a.after_prefr_amount else 0 end) inner_value_2,
			sum(case when a.moon_year_flag = 1 and b.fst_all_yn = 1 then a.after_prefr_amount else 0 end) outer_value_2
		from
			(
				select
					user_log_acct,
					dept_id_2,
					dept_name_2,
					dept_id_3,
					dept_name_3,
					after_prefr_amount,
					this_year_flag,
					last_year_flag,
					moon_year_flag,
					brand_code,
					barndname_full
				from
					dev_xfp.nz_user_daily_report_ord
				where
					dept_id_2 = '5012'
					and (this_year_flag = 1 or last_year_flag = 1 or moon_year_flag = 1)
			)
			a
		left join
			(
				select
					bs,
					user_log_acct,
					fst_all_yn,
					this_year_flag,
					last_year_flag,
					moon_year_flag
				from
					dev_dkx.yh_pop_new_user_flag
				where
					tp = 'dept2'
					and (this_year_flag = 1 or last_year_flag = 1 or moon_year_flag = 1)
			)
			b
		on
			a.user_log_acct = b.user_log_acct
			and a.dept_id_2 = bs
			and a.this_year_flag = b.this_year_flag
			and a.last_year_flag = b.last_year_flag
			and a.moon_year_flag = b.moon_year_flag
		left join
			(
				select user_log_acct from dev_xfp.spite_user_list_xfp
			)
			c
		on
			a.user_log_acct = c.user_log_acct
		where
			c.user_log_acct is null
		group by
			dept_name_2		
	)
	a;
"""
ht.exec_sql(
    schema_name = 'dev_dkx',
    sql=sql,
    table_name = 'yh_pop_dept_user_mtd',
    merge_flag = True)
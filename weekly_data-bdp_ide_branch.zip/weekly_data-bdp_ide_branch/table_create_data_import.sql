drop table if exists dev_xfp.nz_lost_user_threshold;
create table dev_xfp.nz_lost_user_threshold
(
	item_first_cate_name string,
	item_second_cate_name string,
	item_third_cate_cd string,
	item_third_cate_name string,
	jiange bigint
)
row format delimited fields terminated by ','
#!/usr/bin/env python3
#===============================================================================
#
#         FILE: 
#
#        USAGE: 
#
#  DESCRIPTION: 
#
#      OPTIONS: ---
# REQUIREMENTS: ---
#         BUGS: ---
#        NOTES: 
#       AUTHOR: fuqifeng@jd.com
#      COMPANY: jd.com
#      VERSION: 1.0
#      CREATED: 20200518
#    SRC_TABLE: 
#               
#               
#               
#    TGT_TABLE: 
#===============================================================================
import sys
import os
sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask

ht = HiveTask()
sql = """

use app;
--set spark.sql.hive.mergeFiles=true;

set hive.map.aggr = true;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.exec.dynamic.partition=true;
set hive.exec.max.dynamic.partitions=100000;
set hive.exec.max.dynamic.partitions.pernode=100000;
set mapred.output.compress=true;
set hive.exec.compress.output=true;
set mapred.output.compression.codec=com.hadoop.compression.lzo.LzopCodec ;
set io.compression.codecs=com.hadoop.compression.lzo.LzopCodec;
set mapreduce.job.running.reduce.limit=1000;
set mapreduce.job.running.map.limit=2000;
set mapreduce.map.memory.mb=6144;
set mapreduce.map.java.opts=-Xmx6144M;
set mapreduce.map.cpu.vcores = 2;
set mapreduce.reduce.memory.mb=8192;
set mapreduce.reduce.java.opts=-Xmx6144M;
set mapreduce.reduce.cpu.vcores = 4;
set yarn.app.mapreduce.am.resource.cpu-vcores = 3;
set yarn.app.mapreduce.am.resource.mb = 8192;
set yarn.app.mapreduce.am.command-opts = -Xmx6144m;
set mapreduce.task.io.sort.mb=1024;
set mapreduce.job.reduce.slowstart.completedmaps=1;
set hive.auto.convert.join=true;
set hive.mapjoin.smalltable.filesize=250000000;
set hive.groupby.skewindata=true;
set hive.exec.parallel=true;
set hive.exec.parallel.thread.number=20;

insert overwrite table app.app_js_contest_top_data_dsc partition(dt='"""+ht.data_day_str+"""',bs='mypop')

select 
    '' as cid,
	sysdate(-1) as snapshot,
	category,
	id,
	name,
	data,
	'' as extend
from 
    (
        select 
		    'consumermbfoodpop_wjstdp7207_sku_date_sum_top' category,
			item_sku_id AS id,
			sku_name AS name,
			sum(after_prefr_amount) data,
			row_number() over(order by sum(after_prefr_amount) desc) rank
        from
            app.v_app_js_dsc_day_my_pop a
        where 
		    dt = sysdate(-1)
            and dept_id_2 in (5011)
            and global_purchasing_flag = 0
            and mode='POP'
        group by 
		    item_sku_id,
			sku_name
    ) 
	a
where 
    rank <= 100
	
union all

select 
    '' as cid,
	sysdate(-1) as snapshot,
	category,
	id,
	name,
	data,
	'' as extend
from 
    (
        select 
		    'consumermbfoodpop_wjhwdp7197_sku_date_sum_top' category,
			item_sku_id AS id,
			sku_name AS name,
			sum(after_prefr_amount) data,
			row_number() over(order by sum(after_prefr_amount) desc) rank
        from
            app.v_app_js_dsc_day_my_pop a
        where 
		    dt = sysdate(-1)
            and dept_id_2 in (5011)
            and global_purchasing_flag = 0
            and mode='POP'
        group by 
		    item_sku_id,
			sku_name
    ) 
	a
where 
    rank <= 100	
	
union all

select 
    '' as cid,
	sysdate(-1) as snapshot,
	category,
	id,
	name,
	data,
	'' as extend
from 
    (
        select 
		    'consumermbfoodpop_wjmrdp7191_sku_date_sum_top' category,
			item_sku_id AS id,
			sku_name AS name,
			sum(after_prefr_amount) data,
			row_number() over(order by sum(after_prefr_amount) desc) rank
        from
            app.v_app_js_dsc_day_my_pop a
        where 
		    dt = sysdate(-1)
            and dept_id_2 in (5011)
            and global_purchasing_flag = 0
            and mode='POP'
        group by 
		    item_sku_id,
			sku_name
    ) 
	a
where 
    rank <= 100	
	
union all

select 
    '' as cid,
	sysdate(-1) as snapshot,
	category,
	id,
	name,
	data,
	'' as extend
from 
    (
        select 
		    'consumermbfoodpop_wjcwdp7163_sku_date_sum_top' category,
			item_sku_id AS id,
			sku_name AS name,
			sum(after_prefr_amount) data,
			row_number() over(order by sum(after_prefr_amount) desc) rank
        from
            app.v_app_js_dsc_day_my_pop a
        where 
		    dt = sysdate(-1)
            and dept_id_2 in (5011)
            and global_purchasing_flag = 0
            and mode='POP'
        group by 
		    item_sku_id,
			sku_name
    ) 
	a
where 
    rank <= 100		
	
union all

select 
    '' as cid,
	sysdate(-1) as snapshot,
	category,
	id,
	name,
	data,
	'' as extend
from 
    (
        select 
		    'consumermbfoodpop_jiazigudianpin7107_sku_date_sum_top' category,
			item_sku_id AS id,
			sku_name AS name,
			sum(after_prefr_amount) data,
			row_number() over(order by sum(after_prefr_amount) desc) rank
        from
            app.v_app_js_dsc_day_my_pop a
        where 
		    dt = sysdate(-1)
            and dept_id_2 in (5011)
            and global_purchasing_flag = 0
            and mode='POP'
        group by 
		    item_sku_id,
			sku_name
    ) 
	a
where 
    rank <= 100			
	
union all

select 
    '' as cid,
	sysdate(-1) as snapshot,
	category,
	id,
	name,
	data,
	'' as extend
from 
    (
        select 
		    'consumermbfoodpop_diannaoyinyuedanpin7091_sku_date_sum_top' category,
			item_sku_id AS id,
			sku_name AS name,
			sum(after_prefr_amount) data,
			row_number() over(order by sum(after_prefr_amount) desc) rank
        from
            app.v_app_js_dsc_day_my_pop a
        where 
		    dt = sysdate(-1)
            and dept_id_2 in (5011)
            and global_purchasing_flag = 0
            and mode='POP'
        group by 
		    item_sku_id,
			sku_name
    ) 
	a
where 
    rank <= 100				
	
union all

select 
    '' as cid,
	sysdate(-1) as snapshot,
	category,
	id,
	name,
	data,
	'' as extend
from 
    (
        select 
		    'consumermbfoodpop_wjykdp7073_sku_date_sum_top' category,
			item_sku_id AS id,
			sku_name AS name,
			sum(after_prefr_amount) data,
			row_number() over(order by sum(after_prefr_amount) desc) rank
        from
            app.v_app_js_dsc_day_my_pop a
        where 
		    dt = sysdate(-1)
            and dept_id_2 in (5011)
            and global_purchasing_flag = 0
            and mode='POP'
        group by 
		    item_sku_id,
			sku_name
    ) 
	a
where 
    rank <= 100					
	
union all

select 
    '' as cid,
	sysdate(-1) as snapshot,
	category,
	id,
	name,
	data,
	'' as extend
from 
    (
        select 
		    'consumermbfoodpop_guzhengdanpin7069_sku_date_sum_top' category,
			item_sku_id AS id,
			sku_name AS name,
			sum(after_prefr_amount) data,
			row_number() over(order by sum(after_prefr_amount) desc) rank
        from
            app.v_app_js_dsc_day_my_pop a
        where 
		    dt = sysdate(-1)
            and dept_id_2 in (5011)
            and global_purchasing_flag = 0
            and mode='POP'
        group by 
		    item_sku_id,
			sku_name
    ) 
	a
where 
    rank <= 100					
	
union all

select 
    '' as cid,
	sysdate(-1) as snapshot,
	category,
	id,
	name,
	data,
	'' as extend
from 
    (
        select 
		    'consumermbfoodpop_diangangqindanpin7059_sku_date_sum_top' category,
			item_sku_id AS id,
			sku_name AS name,
			sum(after_prefr_amount) data,
			row_number() over(order by sum(after_prefr_amount) desc) rank
        from
            app.v_app_js_dsc_day_my_pop a
        where 
		    dt = sysdate(-1)
            and dept_id_2 in (5011)
            and global_purchasing_flag = 0
            and mode='POP'
        group by 
		    item_sku_id,
			sku_name
    ) 
	a
where 
    rank <= 100				
	
union all

select 
    '' as cid,
	sysdate(-1) as snapshot,
	category,
	id,
	name,
	data,
	'' as extend
from 
    (
        select 
		    'consumermbfoodpop_wjzjdp7057_sku_date_sum_top' category,
			item_sku_id AS id,
			sku_name AS name,
			sum(after_prefr_amount) data,
			row_number() over(order by sum(after_prefr_amount) desc) rank
        from
            app.v_app_js_dsc_day_my_pop a
        where 
		    dt = sysdate(-1)
            and dept_id_2 in (5011)
            and global_purchasing_flag = 0
            and mode='POP'
        group by 
		    item_sku_id,
			sku_name
    ) 
	a
where 
    rank <= 100					
	
union all

select 
    '' as cid,
	sysdate(-1) as snapshot,
	category,
	id,
	name,
	data,
	'' as extend
from 
    (
        select 
		    'consumermbfoodpop_wjjmsku7049_sku_date_sum_top' category,
			item_sku_id AS id,
			sku_name AS name,
			sum(after_prefr_amount) data,
			row_number() over(order by sum(after_prefr_amount) desc) rank
        from
            app.v_app_js_dsc_day_my_pop a
        where 
		    dt = sysdate(-1)
            and dept_id_2 in (5011)
            and global_purchasing_flag = 0
            and mode='POP'
        group by 
		    item_sku_id,
			sku_name
    ) 
	a
where 
    rank <= 100		

union all

select 
    '' as cid,
	sysdate(-1) as snapshot,
	category,
	id,
	name,
	data,
	'' as extend
from 
    (
        select 
		    'consumermbfoodpop_jitadianpin7047_sku_date_sum_top' category,
			item_sku_id AS id,
			sku_name AS name,
			sum(after_prefr_amount) data,
			row_number() over(order by sum(after_prefr_amount) desc) rank
        from
            app.v_app_js_dsc_day_my_pop a
        where 
		    dt = sysdate(-1)
            and dept_id_2 in (5011)
            and global_purchasing_flag = 0
            and mode='POP'
        group by 
		    item_sku_id,
			sku_name
    ) 
	a
where 
    rank <= 100			
	
union all

select 
    '' as cid,
	sysdate(-1) as snapshot,
	category,
	id,
	name,
	data,
	'' as extend
from 
    (
        select 
		    'consumermbfoodpop_gangqindanpin7027_sku_date_sum_top' category,
			item_sku_id AS id,
			sku_name AS name,
			sum(after_prefr_amount) data,
			row_number() over(order by sum(after_prefr_amount) desc) rank
        from
            app.v_app_js_dsc_day_my_pop a
        where 
		    dt = sysdate(-1)
            and dept_id_2 in (5011)
            and global_purchasing_flag = 0
            and mode='POP'
        group by 
		    item_sku_id,
			sku_name
    ) 
	a
where 
    rank <= 100			

union all

select 
    '' as cid,
	sysdate(-1) as snapshot,
	category,
	id,
	name,
	data,
	'' as extend
from 
    (
        select 
		    'consumermbfoodpop_popwjdp7013_sku_date_sum_top' category,
			item_sku_id AS id,
			sku_name AS name,
			sum(after_prefr_amount) data,
			row_number() over(order by sum(after_prefr_amount) desc) rank
        from
            app.v_app_js_dsc_day_my_pop a
        where 
		    dt = sysdate(-1)
            and dept_id_2 in (5011)
            and global_purchasing_flag = 0
            and mode='POP'
        group by 
		    item_sku_id,
			sku_name
    ) 
	a
where 
    rank <= 100		

union all

select 
    '' as cid,
	sysdate(-1) as snapshot,
	category,
	id,
	name,
	data,
	'' as extend
from 
    (
        select 
		    'consumermbfoodpop_yueqidanpin7005_sku_date_sum_top' category,
			item_sku_id AS id,
			sku_name AS name,
			sum(after_prefr_amount) data,
			row_number() over(order by sum(after_prefr_amount) desc) rank
        from
            app.v_app_js_dsc_day_my_pop a
        where 
		    dt = sysdate(-1)
            and dept_id_2 in (5011)
            and global_purchasing_flag = 0
            and mode='POP'
        group by 
		    item_sku_id,
			sku_name
    ) 
	a
where 
    rank <= 100			

;

"""

ht.exec_sql(schema_name = 'app', table_name = 'app_js_contest_top_data_dsc', sql = sql , merge_flag = True, merge_part_dir = ['dt='+ ht.data_day_str +'/bs=mypop'], merge_type='mr')
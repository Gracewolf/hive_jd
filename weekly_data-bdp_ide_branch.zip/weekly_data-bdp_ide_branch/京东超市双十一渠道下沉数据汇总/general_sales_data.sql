select
	item_first_cate_cd 一级类目id,
	item_first_cate_name 一级类目,
	'' 二级类目id,
	'' 二级类目,
	'' 三级类目id,
	'' 三级类目,
	period 时期,
	province 省份,
	city_level 城市等级,
	count(distinct user_log_acct) 有效用户数,
	count(distinct sale_ord_id) 有效子单数,
	count(distinct parent_sale_ord_id) 有效父单数,
	sum(after_prefr_amount_1) 有效优惠后金额,
	sum(sale_qtty) 有效销量
from
	dev_xfp.nz_mkt_channel_dive_ord_table_1
group by
	item_first_cate_cd,
	item_first_cate_name,
	period,
	province,
	city_level

union all

select
	item_first_cate_cd 一级类目id,
	item_first_cate_name 一级类目,
	item_second_cate_cd 二级类目id,
	item_second_cate_name 二级类目,
	'' 三级类目id,
	'' 三级类目,
	period 时期,
	province 省份,
	city_level 城市等级,
	count(distinct user_log_acct) 有效用户数,
	count(distinct sale_ord_id) 有效子单数,
	count(distinct parent_sale_ord_id) 有效父单数,
	sum(after_prefr_amount_1) 有效优惠后金额,
	sum(sale_qtty) 有效销量
from
	dev_xfp.nz_mkt_channel_dive_ord_table_1
group by
	item_first_cate_cd,
	item_first_cate_name,
	item_second_cate_cd,
	item_second_cate_name,
	period,
	province,
	city_level

union all

select
	item_first_cate_cd 一级类目id,
	item_first_cate_name 一级类目,
	item_second_cate_cd 二级类目id,
	item_second_cate_name 二级类目,
	item_third_cate_cd 三级类目id,
	item_third_cate_name 三级类目,
	period 时期,
	province 省份,
	city_level 城市等级,
	count(distinct user_log_acct) 有效用户数,
	count(distinct sale_ord_id) 有效子单数,
	count(distinct parent_sale_ord_id) 有效父单数,
	sum(after_prefr_amount_1) 有效优惠后金额,
	sum(sale_qtty) 有效销量
from
	dev_xfp.nz_mkt_channel_dive_ord_table_1
group by
	item_first_cate_cd,
	item_first_cate_name,
	item_second_cate_cd,
	item_second_cate_name,
	item_third_cate_cd,
	item_third_cate_name,
	period,
	province,
	city_level
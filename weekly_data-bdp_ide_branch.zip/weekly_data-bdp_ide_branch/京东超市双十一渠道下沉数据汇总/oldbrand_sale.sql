select
	city_level 城市等级,
	period 时期,
	count(distinct user_log_acct) 有效用户数,
	count(distinct sale_ord_id) 有效子单数,
	count(distinct parent_sale_ord_id) 有效父单数,
	sum(after_prefr_amount_1) 有效优惠后金额,
	sum(sale_qtty) 有效销量
from
	(
		select
			item_sku_id
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and item_first_cate_cd = '1320'
			and dept_id_2 in('47', '1699')
			and
			(
				item_name like'%老字号%'
				or sku_name like'%老字号%'
			)
	)
	a
join
	(
		select
			*
		from
			dev_xfp.nz_mkt_channel_dive_ord_table_1
	)
	b
on
	a.item_sku_id = b.item_sku_id
group by
	city_level,
	period
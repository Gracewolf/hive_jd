drop table if exists dev_xfp.nz_mkt_channel_dive_ord_table_2;
create table dev_xfp.nz_mkt_channel_dive_ord_table_2 as
select
	item_first_cate_cd,
	item_first_cate_name,
	item_second_cate_cd,
	item_second_cate_name,
	item_third_cate_cd,
	item_third_cate_name,
	user_log_acct,
	sale_ord_id,
	parent_sale_ord_id,
	after_prefr_amount_1,
	sale_qtty,
	coalesce(dim_province_name, '未知') province,
	coalesce(dim_city_name, '未知') city,
	coalesce(dim_jxkh_level, '未知') city_level
from
	(
		select
			item_sku_id,
			item_first_cate_cd,
			item_first_cate_name,
			item_second_cate_cd,
			item_second_cate_name,
			item_third_cate_cd,
			item_third_cate_name
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and item_first_cate_cd = '1320'
			and dept_id_2 in('47', '1699')
	)
	a
join
	(
----有效订单模板
		select
			b.*
		from
			(
				select
					user_log_acct,
					item_sku_id,
					parent_sale_ord_id,
					sale_ord_id,
					case
						when after_prefr_amount_1 is not null and after_prefr_amount_1 <> '' then after_prefr_amount_1
						else after_prefr_amount
					end after_prefr_amount_1,
					check_account_tm,
					sale_qtty,
					rev_addr_city_id,
					sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
				from
					gdm.gdm_m04_ord_det_sum
				where
					dt >= '2019-01-01'
					and sale_ord_dt >= '2019-01-01'
					and sale_ord_dt <= '2019-09-20'
					and sale_ord_valid_flag = '1'
					and item_third_cate_cd not in('6980') --剔除礼品卡
					and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
					and
					(
						substr(ord_flag, 31, 1) <> '2' --非行政内采
						or
						(
							substr(ord_flag, 31, 1) = '2'
							and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
						)
					)
					and
					(
						substr(ord_flag, 46, 1) not in('1', '2', '3', '7')
						or substr(ord_flag, 60, 3) not in('013')
					)
					and sale_ord_type_cd <> '68' --剔除拍卖
					and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
					and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
					and user_log_acct not like"ept%"
			)
			b
		where
			b.ord_amount < 100000
			or
			(
				b.ord_amount >= 100000
				and coalesce(b.check_account_tm, '') <> ''
			)
	)
	b
on
	a.item_sku_id = b.item_sku_id
left join
	(
		select * from dim.dim_city_level
	)
	c
on
	b.rev_addr_city_id = c.city_id;

drop table dev_xfp.nz_mkt_channel_dive_userpool;
create table dev_xfp.nz_mkt_channel_dive_userpool as
select
    a.city_level,
    b.*
from
    (
        select
            user_log_acct,
            city_level
        from
            dev_xfp.nz_mkt_channel_dive_ord_table_2
        group by
            user_log_acct,
            city_level
    )
    a
join
    (
		select
			*
		from
			app.app_ba_userprofile_prop_nonpolar_view_ext
		where
			dt = sysdate( - 3)
    )
    b
on a.user_log_acct = b.user_log_acct;

select
    city_level,
	cpp_base_sex,
	count(distinct user_log_acct) cn
from
	dev_xfp.nz_mkt_channel_dive_userpool
group by
    city_level,
	cpp_base_sex;

select
    city_level,
	cpp_base_age,
	count(distinct user_log_acct) cn
from
	dev_xfp.nz_mkt_channel_dive_userpool
group by
    city_level,
	cpp_base_age;

select
    city_level,
    case cpp_base_education
		when 1 then '初中及以下'
		when 2 then '高中(中专)'
		when 3 then '大学(专科及本科)'
		when 4 then '研究生(硕士及以上)'
		else '未知'
	end cpp_base_education,
	count(distinct user_log_acct) cn
from
	dev_xfp.nz_mkt_channel_dive_userpool
group by
    city_level,
    case cpp_base_education
		when 1 then '初中及以下'
		when 2 then '高中(中专)'
		when 3 then '大学(专科及本科)'
		when 4 then '研究生(硕士及以上)'
		else '未知'
	end;
	
select
    city_level,
	case cpp_base_profession
		when 'a' then '金融从业者'
		when 'b' then '医务人员'
		when 'c' then '公务员/事业单位'
		when 'd' then '白领/一般职员'
		when 'e' then '工人/服务业人员'
		when 'f' then '教师'
		when 'g' then '农民'
		when 'h' then '学生'
		else '未知'
	end cpp_base_profession,
	count(distinct user_log_acct) cn
from
	dev_xfp.nz_mkt_channel_dive_userpool
group by
    city_level,
	case cpp_base_profession
		when 'a' then '金融从业者'
		when 'b' then '医务人员'
		when 'c' then '公务员/事业单位'
		when 'd' then '白领/一般职员'
		when 'e' then '工人/服务业人员'
		when 'f' then '教师'
		when 'g' then '农民'
		when 'h' then '学生'
		else '未知'
	end;	
	
select
    city_level,
	case cgp_cust_purchpower
		when '1' then '土豪'
		when '2' then '高级白领'
		when '3' then '小白领'
		when '4' then '蓝领'
		when '5' then '收入很少'
		else '未知'
	end cgp_cust_purchpower,
	count(distinct user_log_acct) cn
from
	dev_xfp.nz_mkt_channel_dive_userpool
group by
    city_level,
	case cgp_cust_purchpower
		when '1' then '土豪'
		when '2' then '高级白领'
		when '3' then '小白领'
		when '4' then '蓝领'
		when '5' then '收入很少'
		else '未知'
	end;

select
    city_level,
	case
		when not (substr(cfv_sens_promotion, 1, 1) = 'L') then '未知'
		else substr(cfv_sens_promotion, 4, 1)
	end cfv_sens_promotion,
	count(distinct user_log_acct) cn
from
	dev_xfp.nz_mkt_channel_dive_userpool
group by
    city_level,
	case
		when not (substr(cfv_sens_promotion, 1, 1) = 'L') then '未知'
		else substr(cfv_sens_promotion, 4, 1)
	end;

select
    city_level,
	case
		when not (substr(cfv_sens_comment, 1, 1) = 'L') then '未知'
		else substr(cfv_sens_comment, 4, 1)
	end cfv_sens_comment,
	count(distinct user_log_acct) cn
from
	dev_xfp.nz_mkt_channel_dive_userpool
group by
    city_level,
	case
		when not (substr(cfv_sens_comment, 1, 1) = 'L') then '未知'
		else substr(cfv_sens_comment, 4, 1)
	end;

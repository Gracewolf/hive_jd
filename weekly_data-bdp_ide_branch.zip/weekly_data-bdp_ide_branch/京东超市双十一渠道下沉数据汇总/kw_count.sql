select
	kw,
	sum(1) times
from
	(
		select
			comment_content,
			1 tt
		from
			(
				select
					item_sku_id,
					comment_content
				from
					gdm.gdm_m13_sku_comment
				where
					dt >= '2019-06-01'
					and dt <= '2019-06-30'
					and item_first_cate_cd = '1320'
			)
			a
		left semi join
			(
				select
					item_sku_id
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and item_first_cate_cd = '1320'
					and dept_id_2 in('47', '1699')
			)
			b
		on
			a.item_sku_id = b.item_sku_id
	)
	a
join
	(
		select
			concat(concat('%', kw), '%') kw,
			1 tt
		from
			dev_xfp.nz_dive_kw
		group by
		    concat(concat('%', kw), '%')
	)
	b
on
    a.tt = b.tt
where
	a.comment_content like kw
group by
	kw
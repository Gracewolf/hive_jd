drop table if exists dev_xfp.nz_mkt_channel_dive_ord_table_1;
create table dev_xfp.nz_mkt_channel_dive_ord_table_1 as
select
    a.item_sku_id,
	item_first_cate_cd,
	item_first_cate_name,
	item_second_cate_cd,
	item_second_cate_name,
	item_third_cate_cd,
	item_third_cate_name,
	user_log_acct,
	period,
	sale_ord_id,
	parent_sale_ord_id,
	after_prefr_amount_1,
	sale_qtty,
	coalesce(dim_province_name, '未知') province,
	coalesce(dim_jxkh_level, '未知') city_level
from
	(
		select
			item_sku_id,
			item_first_cate_cd,
			item_first_cate_name,
			item_second_cate_cd,
			item_second_cate_name,
			item_third_cate_cd,
			item_third_cate_name
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and item_first_cate_cd = '1320'
			and dept_id_2 in('47', '1699')
	)
	a
join
	(
----有效订单模板
		select
			b.*
		from
			(
				select
					user_log_acct,
					item_sku_id,
					case
						when sale_ord_dt >= '2016-09-01' and sale_ord_dt <= '2017-08-31' then '201609-201708'
						when sale_ord_dt >= '2017-09-01' and sale_ord_dt <= '2018-08-31' then '201709-201808'
						when sale_ord_dt >= '2018-09-01' and sale_ord_dt <= '2019-08-31' then '201809-201908'
					end period,
					parent_sale_ord_id,
					sale_ord_id,
					case
						when after_prefr_amount_1 is not null and after_prefr_amount_1 <> '' then after_prefr_amount_1
						else after_prefr_amount
					end after_prefr_amount_1,
					check_account_tm,
					sale_qtty,
					rev_addr_city_id,
					sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
				from
					gdm.gdm_m04_ord_det_sum
				where
					dt >= '2016-09-01'
					and sale_ord_dt >= '2016-09-01'
					and sale_ord_dt <= '2019-08-31'
					and sale_ord_valid_flag = '1'
					and item_third_cate_cd not in('6980') --剔除礼品卡
					and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
					and
					(
						substr(ord_flag, 31, 1) <> '2' --非行政内采
						or
						(
							substr(ord_flag, 31, 1) = '2'
							and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
						)
					)
					and
					(
						substr(ord_flag, 46, 1) not in('1', '2', '3', '7')
						or substr(ord_flag, 60, 3) not in('013')
					)
					and sale_ord_type_cd <> '68' --剔除拍卖
					and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
					and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
					and user_log_acct not like"ept%"
			)
			b
		where
			b.ord_amount < 100000
			or
			(
				b.ord_amount >= 100000
				and coalesce(b.check_account_tm, '') <> ''
			)
	)
	b
on
	a.item_sku_id = b.item_sku_id
left join
	(
		select * from dim.dim_city_level
	)
	c
on
	b.rev_addr_city_id = c.city_id
select
	count(distinct item_sku_id) sku_cn,
	count(distinct case when sku_valid_flag = 1 and item_valid_flag = 1 then item_sku_id end) valid_sku_cn,
	count(distinct case when shelves_dt <= '2019-08-31' and substr(otc_tm, 1, 10) <= '2019-08-31' and substr(coalesce(utc_tm, '2222-12-12'), 1, 10) >= '2018-09-01' then item_sku_id end) tc_sku_cn,
	count(distinct case when shelves_dt <= '2019-08-31' and sku_valid_flag = 1 and item_valid_flag = 1 and substr(otc_tm, 1, 10) <= '2019-08-31' and substr(coalesce(utc_tm, '2222-12-12'), 1, 10) >= '2018-09-01' then item_sku_id end) tc_valid_sku_cn
from
	gdm.gdm_m03_sold_item_sku_da
where
	dt = '2019-08-31'
	and item_first_cate_cd = '1320'
	and dept_id_2 in('47', '1699');

	

select
	count(distinct item_sku_id) sku_cn,
	count(distinct case when sku_valid_flag = 1 and item_valid_flag = 1 then item_sku_id end) valid_sku_cn,
	count(distinct case when shelves_dt <= '2018-08-31' and substr(otc_tm, 1, 10) <= '2018-08-31' and substr(coalesce(utc_tm, '2222-12-12'), 1, 10) >= '2017-09-01' then item_sku_id end) tc_sku_cn,
	count(distinct case when shelves_dt <= '2018-08-31' and sku_valid_flag = 1 and item_valid_flag = 1 and substr(otc_tm, 1, 10) <= '2018-08-31' and substr(coalesce(utc_tm, '2222-12-12'), 1, 10) >= '2017-09-01' then item_sku_id end) tc_valid_sku_cn
from
	gdm.gdm_m03_sold_item_sku_da_arc
where
    dm = '2018-08'
    and start_date <= '2018-08-31'
    and end_date > '2018-08-31'
	and item_first_cate_cd = '1320'
	and dept_id_2 in('47', '1699');


select
	count(distinct item_sku_id) sku_cn,
	count(distinct case when sku_valid_flag = 1 and item_valid_flag = 1 then item_sku_id end) valid_sku_cn,
	count(distinct case when shelves_dt <= '2017-08-31' and substr(otc_tm, 1, 10) <= '2017-08-31' and substr(coalesce(utc_tm, '2222-12-12'), 1, 10) >= '2016-09-01' then item_sku_id end) tc_sku_cn,
	count(distinct case when shelves_dt <= '2017-08-31' and sku_valid_flag = 1 and item_valid_flag = 1 and substr(otc_tm, 1, 10) <= '2017-08-31' and substr(coalesce(utc_tm, '2222-12-12'), 1, 10) >= '2016-09-01' then item_sku_id end) tc_valid_sku_cn
from
	gdm.gdm_m03_sold_item_sku_da_arc
where
    dm = '2017-08'
    and start_date <= '2017-08-31'
    and end_date > '2017-08-31'
	and item_first_cate_cd = '1320'
	and dept_id_2 in('47', '1699');

select
    count(distinct brand_code) brand_num
from
    gdm.gdm_m03_sold_item_sku_da
where
	dt = '2019-08-31'
	and item_first_cate_cd = '1320'
	and dept_id_2 in('47', '1699')
	and shelves_dt <= '2019-08-31'
	and substr(otc_tm, 1, 10) <= '2019-08-31'
	and substr(coalesce(utc_tm, '2222-12-12'), 1, 10) >= '2018-09-01';

select
    count(distinct brand_code) brand_num
from
	gdm.gdm_m03_sold_item_sku_da_arc
where
    dm = '2018-08'
    and start_date <= '2018-08-31'
    and end_date > '2018-08-31'
	and item_first_cate_cd = '1320'
	and dept_id_2 in('47', '1699')
	and shelves_dt <= '2018-08-31'
	and substr(otc_tm, 1, 10) <= '2018-08-31'
	and substr(coalesce(utc_tm, '2222-12-12'), 1, 10) >= '2017-09-01';

select
    count(distinct brand_code) brand_num
from
	gdm.gdm_m03_sold_item_sku_da_arc
where
    dm = '2017-08'
    and start_date <= '2017-08-31'
    and end_date > '2017-08-31'
	and item_first_cate_cd = '1320'
	and dept_id_2 in('47', '1699')
	and shelves_dt <= '2017-08-31'
	and substr(otc_tm, 1, 10) <= '2017-08-31'
	and substr(coalesce(utc_tm, '2222-12-12'), 1, 10) >= '2016-09-01';
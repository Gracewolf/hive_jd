select
	item_first_cate_cd,
	item_first_cate_name,
	'' 二级类目id,
	'' 二级类目,
	city 城市,
	province 省份,
	city_level 城市等级,
	count(distinct user_log_acct) 有效用户数,
	count(distinct sale_ord_id) 有效子单数,
	count(distinct parent_sale_ord_id) 有效父单数,
	sum(after_prefr_amount_1) 有效优惠后金额,
	sum(sale_qtty) 有效销量
from
	dev_xfp.nz_mkt_channel_dive_ord_table_2
group by
	item_first_cate_cd,
	item_first_cate_name,
	city,
	province,
	city_level

union all

select
	item_first_cate_cd,
	item_first_cate_name,
	item_second_cate_cd 二级类目id,
	item_first_cate_name 二级类目,
	city 城市,
	province 省份,
	city_level 城市等级,
	count(distinct user_log_acct) 有效用户数,
	count(distinct sale_ord_id) 有效子单数,
	count(distinct parent_sale_ord_id) 有效父单数,
	sum(after_prefr_amount_1) 有效优惠后金额,
	sum(sale_qtty) 有效销量
from
	dev_xfp.nz_mkt_channel_dive_ord_table_2
group by
	item_first_cate_cd,
	item_first_cate_name,
	item_second_cate_cd,
	item_second_cate_name,
	city,
	province,
	city_level
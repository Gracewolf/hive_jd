----全局用户首购时间

insert overwrite table dev_xfp.nz_global_user_list
select
	coalesce(b.user_log_acct, a.user_log_acct) user_log_acct,
	min(fst_ord_dt) fst_ord_dt
from
	(
		select
			lower(trim(user_log_acct)) user_log_acct,
			to_date(coalesce(first_create_ord_tm, '4127-01-01')) fst_ord_dt
		from
			gdm.gdm_m01_userinfo_basic_sum
		where
			dt = sysdate( - 1)
	)
	a
left join
	(
		select
			lower(trim(unif_user_log_acct)) user_log_acct,
			lower(trim(user_acct_name)) pin
		from
			gdm.gdm_m01_userinfo_basic_da
		where
			dt = sysdate( - 1)
	) ----归一化用户pin
	b
on
	a.user_log_acct = b.pin
group by
	coalesce(b.user_log_acct, a.user_log_acct);
----浏览加购用户表
drop table if exists dev_xfp.nz_pin_view_cart_filter;
create table dev_xfp.nz_pin_view_cart_filter as
select
    user_log_acct,
    item_second_cate_id,
    item_second_cate_name
from
    adm.adm_s14_online_log_smart_item_d
where
    dt >= sysdate( - 90)
    and dt <= sysdate( - 1)
    and item_first_cate_id = '1320'
    and item_second_cate_id in('1583', '1584', '1585', '12202')
    and
    (
        sku_pv > 0
        or cart_flag = '1'
    )
group by
    user_log_acct,
    item_second_cate_id,
    item_second_cate_name
-----历史购买表
drop table if exists dev_xfp.nz_pin_history_filter;
create table dev_xfp.nz_pin_history_filter as
select
    user_log_acct,
    2st_item_first_cate_cd item_second_cate_cd
from
    gdm.gdm_m01_user_third_cate_da
where
    dt = sysdate( - 1)
    and 1st_item_first_cate_cd = '1320'
    and 2st_item_first_cate_cd in('1583', '1584', '1585', '12202')
    and 1st_sale_ord_dt is not null
group by
    user_log_acct,
    2st_item_first_cate_cd
    
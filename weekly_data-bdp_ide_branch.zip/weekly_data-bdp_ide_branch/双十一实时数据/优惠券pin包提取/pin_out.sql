----pin包输出
set hive.exec.parallel = true;
drop table if exists dev_xfp.nz_coupon_pin_pool;
create table dev_xfp.nz_coupon_pin_pool as
select
    a.userpin,
    case
        when a.item_second_cate_cd = '1583' and b.item_second_cate_id = '1584' then 1
        when a.item_second_cate_cd = '1583' and b.item_second_cate_id = '1585' then 2
        when a.item_second_cate_cd = '1585' and b.item_second_cate_id = '1583' then 3
        when a.item_second_cate_cd = '1585' and b.item_second_cate_id = '1584' then 4
        when a.item_second_cate_cd = '1585' and b.item_second_cate_id = '12202' then 6
        else 0
    end flag,
    min(a.score) score
from
    (
        select * from dev_xfp.nz_coupon_pin_pool_base
        where item_second_cate_cd in('1583', '1585')
    )
    a
join
    (
        select * from dev_xfp.nz_pin_view_cart_filter
        where item_second_cate_id in('1583', '1584', '1585', '12202')
    )
    b
on
    a.user_log_acct = b.user_log_acct
left join
    (
        select * from dev_xfp.nz_pin_history_filter
    )
    c
on
    b.user_log_acct = c.user_log_acct
    and b.item_second_cate_id = c.item_second_cate_cd
where
    a.item_second_cate_cd <> b.item_second_cate_id
    and c.user_log_acct is null
    and
    (
        (
            a.item_second_cate_cd = '1583'
            and b.item_second_cate_id <> '12202'
        )
		or a.item_second_cate_cd = '1585'
    )
group by
    a.userpin,
    case
        when a.item_second_cate_cd = '1583' and b.item_second_cate_id = '1584' then 1
        when a.item_second_cate_cd = '1583' and b.item_second_cate_id = '1585' then 2
        when a.item_second_cate_cd = '1585' and b.item_second_cate_id = '1583' then 3
        when a.item_second_cate_cd = '1585' and b.item_second_cate_id = '1584' then 4
        when a.item_second_cate_cd = '1585' and b.item_second_cate_id = '12202' then 6
        else 0
    end
union all
select
    a.userpin,
    5 flag,
    min(a.score) score
from
    (
        select * from dev_xfp.nz_coupon_pin_pool_base
        where item_second_cate_cd = '1583'
    )
    a
join
    (
        select user_log_acct from dev_xfp.nz_pin_view_cart_filter
        where item_second_cate_id in('1584', '1585') group by user_log_acct
    )
    b
on
    a.user_log_acct = b.user_log_acct
left join
    (
        select user_log_acct from dev_xfp.nz_pin_history_filter where item_second_cate_cd in('1584', '1585') group by user_log_acct
    )
    c
on
    b.user_log_acct = c.user_log_acct
where
    c.user_log_acct is null
group by
    a.userpin
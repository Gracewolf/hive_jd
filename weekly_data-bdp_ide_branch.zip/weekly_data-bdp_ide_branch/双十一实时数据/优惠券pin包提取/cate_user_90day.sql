set hive.exec.parallel = true;
drop table dev_xfp.nz_coupon_pin_pool_base;
create table dev_xfp.nz_coupon_pin_pool_base as
select
    b.user_log_acct,
	coalesce(b.user_log_acct, d.unif_user_log_acct) userpin,
    item_second_cate_cd,
    item_second_cate_name,
	max(coalesce(total_score, 0)) score
from
	(
		select
			user_log_acct,
			lower(trim(user_log_acct)) pin,
			item_first_cate_cd,
			item_second_cate_cd,
			item_second_cate_name,
			item_sku_id,
			sale_ord_dt,
			parent_sale_ord_id,
			sale_ord_id,
			case
				when after_prefr_amount_1 is not null and after_prefr_amount_1 <> '' then after_prefr_amount_1
				else after_prefr_amount
			end after_prefr_amount_1,
			check_account_tm,
			sale_qtty,
			sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
		from
			gdm.gdm_m04_ord_det_sum
		where
			dt >= sysdate( - 400)
			and sale_ord_dt >= sysdate( - 400)
			and sale_ord_dt <= sysdate( - 1)
			and sale_ord_valid_flag = '1'
			and item_third_cate_cd not in('6980') --剔除礼品卡
			and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
			and
			(
				substr(ord_flag, 31, 1) <> '2' --非行政内采
				or
				(
					substr(ord_flag, 31, 1) = '2'
					and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
				)
			)
			and
			(
				substr(ord_flag, 46, 1) not in('1', '2', '3', '7')
				or substr(ord_flag, 60, 3) not in('013')
			)
			and sale_ord_type_cd <> '68' --剔除拍卖
			and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
			and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
			and user_log_acct not like 'ept%'
			and user_log_acct not like '*yhd%'
			and user_log_acct not like 'xtl%'
	)
	b
left join
    (
        select * from dev_xfp.nz_risk_user_pin
    )
    c
on
    b.pin = c.pin
left join
	(
		select
			unif_user_log_acct,
			user_acct_name user_log_acct
		from
			gdm.gdm_m01_userinfo_basic_da
		where
			dt = sysdate( - 1)
	) ----归一化用户pin
	d
on
	b.user_log_acct = d.user_log_acct
left join
    (
        select
            lower(trim(jd_pin)) pin,
            total_score
        from
            app.app_cmo_dmt_jdmem_user_score_simple_da
        where
            dt = sysdate( - 1)
    )
    e
on
    b.pin = e.pin
where
    (
    	b.ord_amount < 100000
    	or
    	(
    		b.ord_amount >= 100000
    		and coalesce(b.check_account_tm, '') <> ''
    	)
    )
    and item_first_cate_cd = '1320'
    and item_second_cate_cd in('1583', '1584', '1585')
    and c.pin is null
group by
    item_second_cate_cd,
    item_second_cate_name,
	coalesce(b.user_log_acct, d.unif_user_log_acct),
    b.user_log_acct
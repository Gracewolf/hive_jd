set hive.exec.parallel = true;
insert into dev_xfp.nz_double11_daily_report_base
select
	t_pv.dt,
	t_pv.dept_id,
	t_pv.dept_name,
	t_pv.pv,
	t_pv.uv,
	t_sale.gmv,
	t_user.user_num,
	t_user.outer_user_num,
	t_user.inner_user_num,
	t_user.valid_ord_num,
	t_user.valid_amount
from
	(
		----PV表
		select
			b.dt,
			'0' dept_id,
			'总计' dept_name,
			sum(pv) pv,
			count(distinct browser_uniq_id) uv
		from
			(
				select
					item_sku_id
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
			)
			a
		join
			(
				select
					dt,
					sku_id,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					dt = sysdate( - 1)
				group by
					sku_id,
					dt,
					browser_uniq_id
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			b.dt

		union all

		select
			b.dt,
			dept_id,
			dept_name,
			sum(pv) pv,
			count(distinct browser_uniq_id) uv
		from
			(
				select
					item_sku_id,
					dept_id_3 dept_id,
					dept_name_3 dept_name
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and dept_id_3 in('3842', '989', '988', '3836', '966', '3816', '4159', '3840', '4046', '4044', '3814', '141', '147', '3818', '985', '3838', '4165', '984', '433', '3824', '3826', '4161', '4162', '4157', '3828', '3830')
			)
			a
		join
			(
				select
					dt,
					sku_id,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					dt = sysdate( - 1)
				group by
					sku_id,
					dt,
					browser_uniq_id
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			b.dt,
			dept_id,
			dept_name
	)
	t_pv
join
	(
		----GMV表
		select
			b.dt,
			'0' dept_id,
			'总计' dept_name,
			sum(cw_gmv) gmv
		from
			(
				select
					item_sku_id
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
			)
			a
		join
			(
				select
					dt,
					item_sku_id,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					dt = sysdate( - 1)
					and valid_flag = '1'
					and
					(
						(
							tp = '1'
							and substr(ord_flag, 40, 1) <> '1'
						) ----自营剔分销
						or
						(
							tp = '2'
							and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
						) ----POP剔赠品
					)
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		group by
			b.dt

		union all

		select
			b.dt,
			dept_id,
			dept_name,
			sum(cw_gmv) gmv
		from
			(
				select
					item_sku_id,
					dept_id_3 dept_id,
					dept_name_3 dept_name
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and dept_id_3 in('3842', '989', '988', '3836', '966', '3816', '4159', '3840', '4046', '4044', '3814', '141', '147', '3818', '985', '3838', '4165', '984', '433', '3824', '3826', '4161', '4162', '4157', '3828', '3830')
			)
			a
		join
			(
				select
					dt,
					item_sku_id,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					dt = sysdate( - 1)
					and valid_flag = '1'
					and
					(
						(
							tp = '1'
							and substr(ord_flag, 40, 1) <> '1'
						) ----自营剔分销
						or
						(
							tp = '2'
							and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
						) ----POP剔赠品
					)
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		group by
			b.dt,
			dept_id,
			dept_name
	)
	t_sale
on
	t_pv.dt = t_sale.dt
	and t_pv.dept_id = t_sale.dept_id
	and t_pv.dept_name = t_sale.dept_name
join
	(
		----用户表
		select
			b.sale_ord_dt,
			'0' dept_id,
			'总计' dept_name,
			count(distinct b.user_log_acct) user_num,
			count(distinct case when fst_all_yn = 1 then b.user_log_acct end) outer_user_num,
			count(distinct case when fst_all_yn = 0 then b.user_log_acct end) inner_user_num,
			count(distinct b.sale_ord_id) valid_ord_num,
			sum(after_prefr_amount_1) valid_amount
		from
			(
				select
					item_sku_id
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
			)
			a
		join
			(
		----有效订单模板
				select
					b.*
				from
					(
						select
							user_log_acct,
							item_sku_id,
							sale_ord_dt,
							parent_sale_ord_id,
							sale_ord_id,
							case
								when after_prefr_amount_1 is not null and after_prefr_amount_1 <> '' then after_prefr_amount_1
								else after_prefr_amount
							end after_prefr_amount_1,
							check_account_tm,
							sale_qtty,
							sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
						from
							gdm.gdm_m04_ord_det_sum
						where
							dt >= sysdate( - 1)
							and sale_ord_dt = sysdate( - 1)
							and sale_ord_valid_flag = '1'
							and item_third_cate_cd not in('6980') --剔除礼品卡
							and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
							and
							(
								substr(ord_flag, 31, 1) <> '2' --非行政内采
								or
								(
									substr(ord_flag, 31, 1) = '2'
									and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
								)
							)
							and
							(
								substr(ord_flag, 46, 1) not in('1', '2', '3', '7')
								or substr(ord_flag, 60, 3) not in('013')
							)
							and sale_ord_type_cd <> '68' --剔除拍卖
							and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
							and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
							and user_log_acct not like"ept%"
					)
					b
				where
					b.ord_amount < 100000
					or
					(
						b.ord_amount >= 100000
						and coalesce(b.check_account_tm, '') <> ''
					)
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		left join
			(
				select
					dept_id_2,
					unif_user_log_acct,
					max(case when fst_all_yn = '1' then 1 else 0 end) fst_all_yn,
					min(fst_ord_dt) fst_dt
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 1)
					and tp = 'dept'
					and dept_id_2 = '47'
				group by
					dept_id_2,
					unif_user_log_acct
				having
					fst_dt = sysdate( - 1)
			)
			c
		on
			b.user_log_acct = c.unif_user_log_acct
			and b.sale_ord_dt = c.fst_dt
		group by
			b.sale_ord_dt

		union all

		select
			b.sale_ord_dt,
			a.dept_id,
			dept_name,
			count(distinct b.user_log_acct) user_num,
			count(distinct case when fst_all_yn = 1 then b.user_log_acct end) outer_user_num,
			count(distinct case when fst_all_yn = 0 then b.user_log_acct end) inner_user_num,
			count(distinct b.sale_ord_id) valid_ord_num,
			sum(after_prefr_amount_1) valid_amount
		from
			(
				select
					item_sku_id,
					dept_id_3 dept_id,
					dept_name_3 dept_name
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and dept_id_3 in('3842', '989', '988', '3836', '966', '3816', '4159', '3840', '4046', '4044', '3814', '141', '147', '3818', '985', '3838', '4165', '984', '433', '3824', '3826', '4161', '4162', '4157', '3828', '3830')
			)
			a
		join
			(
		----有效订单模板
				select
					b.*
				from
					(
						select
							user_log_acct,
							item_sku_id,
							sale_ord_dt,
							parent_sale_ord_id,
							sale_ord_id,
							case
								when after_prefr_amount_1 is not null and after_prefr_amount_1 <> '' then after_prefr_amount_1
								else after_prefr_amount
							end after_prefr_amount_1,
							check_account_tm,
							sale_qtty,
							sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
						from
							gdm.gdm_m04_ord_det_sum
						where
							dt >= sysdate( - 1)
							and sale_ord_dt = sysdate( - 1)
							and sale_ord_valid_flag = '1'
							and item_third_cate_cd not in('6980') --剔除礼品卡
							and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
							and
							(
								substr(ord_flag, 31, 1) <> '2' --非行政内采
								or
								(
									substr(ord_flag, 31, 1) = '2'
									and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
								)
							)
							and
							(
								substr(ord_flag, 46, 1) not in('1', '2', '3', '7')
								or substr(ord_flag, 60, 3) not in('013')
							)
							and sale_ord_type_cd <> '68' --剔除拍卖
							and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
							and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
							and user_log_acct not like"ept%"
					)
					b
				where
					b.ord_amount < 100000
					or
					(
						b.ord_amount >= 100000
						and coalesce(b.check_account_tm, '') <> ''
					)
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		left join
			(
				select
					dept_id_3 dept_id,
					unif_user_log_acct,
					max(case when fst_all_yn = '1' then 1 else 0 end) fst_all_yn,
					min(fst_ord_dt) fst_dt
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 1)
					and tp = 'dept'
					and dept_id_2 = '47'
					and dept_id_3 in('3842', '989', '988', '3836', '966', '3816', '4159', '3840', '4046', '4044', '3814', '141', '147', '3818', '985', '3838', '4165', '984', '433', '3824', '3826', '4161', '4162', '4157', '3828', '3830')
				group by
					dept_id_3,
					unif_user_log_acct
				having
					fst_dt = sysdate( - 1)
			)
			c
		on
			b.user_log_acct = c.unif_user_log_acct
			and b.sale_ord_dt = c.fst_dt
			and a.dept_id = c.dept_id
		group by
			b.sale_ord_dt,
			a.dept_id,
			dept_name
	)
	t_user
on
	t_pv.dt = t_user.sale_ord_dt
	and t_pv.dept_id = t_user.dept_id
	and t_pv.dept_name = t_user.dept_name;
create table dev_xfp.nz_yili_ord_device_2014 as
select
	yyyy_mm,
	model,
	device,
	item_third_cate_cd,
	item_third_cate_name,
	sum(cw_gmv) gmv,
	count(distinct sale_ord_id) ord_num
from
	(
		select
			item_sku_id,
			case data_type
				when '1' then '自营'
				when '3' then 'POP'
			end model,
			item_third_cate_cd,
			item_third_cate_name
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and brand_code = '19306'
	)
	a
join
	(
		select
			item_sku_id,
			sale_ord_id,
			substr(dt, 1, 7) yyyy_mm,
			case
				when terminal_flag in('12', '22', '42', '62') then 'APP'
				when terminal_flag in('13', '23', '43', '63') then 'M端'
				when terminal_flag in('11', '21', '41', '61') then 'PC'
				when terminal_flag in('33', '31', '30') then '微信'
				when terminal_flag in('32') then '手Q'
				else '未知'
			end device,
			cw_gmv
		from
			app.app_cmo_cw_ord_det_sum
		where
			dt >= '2014-01-01'
			and dt <= sysdate( - 1)
			and valid_flag = '1'
	)
	b
on
	a.item_sku_id = b.item_sku_id
group by
	yyyy_mm,
	model,
	device,
	item_third_cate_cd,
	item_third_cate_name
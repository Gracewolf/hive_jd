create table dev_xfp.nz_yili_user_ord_num_2014 as
select /*+mapjoin(a)*/
	yyyy_mm,
	model,
	item_third_cate_cd,
	item_third_cate_name,
	user_log_acct,
	count(distinct sale_ord_id) ord_num,
	count(distinct parent_sale_ord_id) par_ord_num,
	sum(after_prefr_amount_1) after_pre_amount
from
	(
		select
			item_sku_id,
			case data_type
				when '1' then '自营'
				when '3' then 'POP'
			end model,
			item_third_cate_cd,
			item_third_cate_name
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and brand_code = '19306'
			and item_third_cate_cd in('9434', '12201')
	)
	a
join
	(
		select
			user_log_acct,
			item_sku_id,
			substr(sale_ord_dt, 1, 7) yyyy_mm,
			parent_sale_ord_id,
			sale_ord_id,
			after_prefr_amount_1,
			check_account_tm,
			sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
		from
			gdm.gdm_m04_ord_det_sum
		where
			dt >= '2014-01-01'
			and sale_ord_dt >= '2014-01-01'
			and sale_ord_dt <= sysdate( - 1)
			and sale_ord_valid_flag = '1'
			and item_third_cate_cd not in('6980') --剔除礼品卡
			and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
			and
			(
				substr(ord_flag, 31, 1) <> '2' --非行政内采
				or
				(
					substr(ord_flag, 31, 1) = '2'
					and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
				)
			)
			and
			(
				substring(ord_flag, 46, 1) not in('1', '2', '3', '7')
				or substring(ord_flag, 60, 3) not in('013')
			)
			and sale_ord_type_cd <> '68' --剔除拍卖
			and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
			and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
			and user_log_acct not like"ept%"
	)
	b
on
	a.item_sku_id = b.item_sku_id
where
	b.ord_amount < 100000
	or
	(
		b.ord_amount >= 100000
		and coalesce(b.check_account_tm, '') <> ''
	)
group by
	yyyy_mm,
	model,
	item_third_cate_cd,
	item_third_cate_name,
	user_log_acct;
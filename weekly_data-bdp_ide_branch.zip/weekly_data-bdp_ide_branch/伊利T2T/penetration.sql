select
    '月度' 备注,
    year_dt,
    sum(1) 全站用户数,
    sum(niunai_flag) 牛奶乳品用户数,
    sum(naifen_flag) 成人奶粉用户数
from
    (
        select
        	year_dt,
        	user_log_acct,
        	max(case coalesce(a.item_third_cate_cd, 4) when 8 then 1 else 0 end) niunai_flag,
        	min(case coalesce(a.item_third_cate_cd, 4) when 2 then 1 else 0 end) naifen_flag
        from
            (
                select
                    item_sku_id,
                    case item_third_cate_cd
                        when '9434' then 8
                        when '12201' then 2
                        else 4
                    end item_third_cate_cd
                from
                    gdm.gdm_m03_sold_item_sku_da
                where
                    dt = sysdate( - 1)
                    and data_type in('1', '3')
                    and item_third_cate_cd in('9434', '12201')
            )
            a
        right join
        	(
        		select
        		    item_sku_id,
        			user_log_acct,
        			substr(sale_ord_dt, 1, 7) year_dt,
        			check_account_tm,
        			sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
        		from
        			gdm.gdm_m04_ord_det_sum
        		where
        			dt >= '2014-01-01'
        			and sale_ord_dt >= '2014-01-01'
        			and sale_ord_dt <= sysdate( - 1)
        			and sale_ord_valid_flag = '1'
        			and item_third_cate_cd not in('6980') --剔除礼品卡
        			and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
        			and
        			(
        				substr(ord_flag, 31, 1) <> '2' --非行政内采
        				or
        				(
        					substr(ord_flag, 31, 1) = '2'
        					and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
        				)
        			)
        			and
        			(
        				substr(ord_flag, 46, 1) not in('1', '2', '3', '7')
        				or substr(ord_flag, 60, 3) not in('013')
        			)
        			and sale_ord_type_cd <> '68' --剔除拍卖
        			and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
        			and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
        			and user_log_acct not like"ept%"
        	)
        	b
        on
            a.item_sku_id = b.item_sku_id
        where
        	b.ord_amount < 100000
        	or
        	(
        		b.ord_amount >= 100000
        		and coalesce(b.check_account_tm, '') <> ''
        	)
        group by
        	year_dt,
        	user_log_acct
    )
    ff
group by
    year_dt

union all

select
	'年度' 备注,
    year_dt,
    sum(1) 全站用户数,
    sum(niunai_flag) 牛奶乳品用户数,
    sum(naifen_flag) 成人奶粉用户数
from
    (
        select /*+mapjoin(a)*/
        	year_dt,
        	user_log_acct,
        	max(case coalesce(a.item_third_cate_cd, 4) when 8 then 1 else 0 end) niunai_flag,
        	min(case coalesce(a.item_third_cate_cd, 4) when 2 then 1 else 0 end) naifen_flag
        from
            (
                select
                    item_sku_id,
                    case item_third_cate_cd
                        when '9434' then 8
                        when '12201' then 2
                        else 4
                    end item_third_cate_cd
                from
                    gdm.gdm_m03_sold_item_sku_da
                where
                    dt = sysdate( - 1)
                    and data_type in('1', '3')
                    and item_third_cate_cd in('9434', '12201')
            )
            a
        join
        	(
        		select
        		    item_sku_id,
        			user_log_acct,
        			substr(sale_ord_dt, 1, 4) year_dt,
        			check_account_tm,
        			sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
        		from
        			gdm.gdm_m04_ord_det_sum
        		where
        			dt >= '2014-01-01'
        			and sale_ord_dt >= '2014-01-01'
        			and sale_ord_dt <= sysdate( - 1)
        			and sale_ord_valid_flag = '1'
        			and item_third_cate_cd not in('6980') --剔除礼品卡
        			and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
        			and
        			(
        				substr(ord_flag, 31, 1) <> '2' --非行政内采
        				or
        				(
        					substr(ord_flag, 31, 1) = '2'
        					and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
        				)
        			)
        			and
        			(
        				substr(ord_flag, 46, 1) not in('1', '2', '3', '7')
        				or substr(ord_flag, 60, 3) not in('013')
        			)
        			and sale_ord_type_cd <> '68' --剔除拍卖
        			and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
        			and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
        			and user_log_acct not like"ept%"
        	)
        	b
        on
            a.item_sku_id = b.item_sku_id
        where
        	b.ord_amount < 100000
        	or
        	(
        		b.ord_amount >= 100000
        		and coalesce(b.check_account_tm, '') <> ''
        	)
        group by
        	year_dt,
        	user_log_acct
    )
    ff
group by
    year_dt;
    

select
	year_dt,
	item_third_cate_cd,
	count(distinct user_log_acct) user_num
from
	(
		select
			item_sku_id,
			item_third_cate_cd
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and item_third_cate_cd in('9434', '12201')
	)
	a
join
	(
		select
			item_sku_id,
			year(dt) year_dt,
			user_log_acct
		from
			app.v_app_cmo_cw_ord_det_sum_rb
		where
			dt >= '2014-01-01'
			and dt <= '2019-09-25'
			and valid_flag = '1'
	)
	b
on
	a.item_sku_id = b.item_sku_id
group by
	year_dt,
	item_third_cate_cd
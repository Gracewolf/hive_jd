#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import datetime
import subprocess

sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day

dt_list = ['2019-01-31', '2019-02-28', '2019-03-31', '2019-04-30', '2019-05-31', '2019-06-30', '2019-07-31', '2019-08-31', '2019-09-30', '2019-10-31', '2019-11-30', '2019-12-31', '2020-01-31']

### 新建分区
for i in dt_list:
	sql = """
----动态分区
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict; 
set hive.exec.max.dynamic.partitions=100000;
set hive.exec.max.dynamic.partitions.pernode=100000;

insert into dev_xfp.nz_user_gap_dist_1320_cate partition (dm = '""" + i[:7] + """')
select
    cate_name,
	floor(med_gap) med_gap,
	count(distinct user_log_acct) cn
from
	(
		select
		    cate_name,
			user_log_acct,
			percentile(datediff(next_ord_dt, sale_ord_dt), 0.5) med_gap
		from
			(
				select
				    cate_name,
					user_log_acct,
					sale_ord_dt,
					sum(1) over(partition by user_log_acct, cate_name) as ord_times,
					lead(sale_ord_dt) over(partition by user_log_acct, cate_name order by sale_ord_dt) as next_ord_dt
				from
					(
						select
							*
						from
							dev_xfp.nz_user_ord_1320_cate
						where
							sale_ord_dt >= date_sub('""" + i + """', 729)
							and sale_ord_dt <= '""" +  i + """'
					)
					a
			)
			a
		where
			ord_times >= 3
			and next_ord_dt is not null
		group by
		    cate_name,
			user_log_acct
	)
	a
group by
    cate_name,
	floor(med_gap);
	"""
	ht.exec_sql(schema_name='dev_xfp', sql=sql, merge_flag=False)
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict; 
set hive.exec.max.dynamic.partitions=100000;
set hive.exec.max.dynamic.partitions.pernode=100000;

drop table if exists dev_xfp.nz_user_gap_dist_1320;
create table dev_xfp.nz_user_gap_dist_1320
(
    med_gap bigint,
    cn bigint
)
partitioned by(dm string)
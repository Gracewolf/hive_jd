set hive.exec.parallel=true; 
set hive.exec.parallel.thread.number=16; 
--合并小文件
set hive.merge.mapfiles = true;  
set hive.merge.mapredfiles = true;  
set hive.merge.size.per.task=64000000;
set hive.merge.smallfiles.avgsize = 256000000; 
--Map阶段优化
set mapred.max.split.size=256000000; 
set mapred.min.split.size.per.node=256000000; 
set mapred.min.split.size.per.rack=256000000;  
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set hive.join.emit.interval = 2000;
set hive.mapjoin.size.key = 20000;
set hive.mapjoin.cache.numrows = 20000;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer=2000000000;
--数据倾斜
set hive.map.aggr=true;
set hive.groupby.mapaggr.checkinterval=100000;
set hive.auto.convert.join = true;
drop table if exists dev_xfp.nz_user_retained_peroid;
create table dev_xfp.nz_user_retained_peroid as
select
	cate_id,
	cate_name,
	floor(med_gap) med_gap,
	count(distinct user_log_acct) cn
from
	(
		select
		    cate_id,
			cate_name,
			user_log_acct,
			percentile(datediff(next_ord_dt, sale_ord_dt), 0.5) med_gap
		from
			(
				select
				    cate_id,
					cate_name,
					user_log_acct,
					sale_ord_dt,
					sum(1) over(partition by user_log_acct, cate_name, cate_id) as ord_times,
					lead(sale_ord_dt) over(partition by user_log_acct, cate_name, cate_id order by sale_ord_dt) as next_ord_dt
				from
					(
						select /*+mapjoin(a)*/
							cate_name,
							cate_id,
							b.user_log_acct,
							sale_ord_dt
						from
							(
								select
									item_sku_id,
									item_third_cate_name cate_name,
									item_third_cate_cd cate_id
								from
									gdm.gdm_m03_sold_item_sku_da
								where
									dt = sysdate( - 1)
									and data_type in('1', '3')
									and dept_id_1 = '33'
									and item_first_cate_cd = '1320'
									and item_third_cate_cd in('1602', '15051', '15052', '10975', '5023', '15055', '15053', '2679', '12201', '1601', '12200', '3986')
							)
							a
						join
							(
								select
									lower(trim(user_log_acct)) user_log_acct,
									item_sku_id,
									sale_ord_dt
								from
									app.v_app_cmo_cw_ord_det_sum_rb
								where
									dt >= sysdate( - 730)
									and dt <= sysdate( - 1)
									and sale_ord_dt >= sysdate( - 730)
									and sale_ord_dt <= sysdate( - 1)
									and valid_flag = '1'
									and cw_gmv > 0
									and item_third_cate_cd not in('6980') --剔除礼品卡
									and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
									and
									(
										substr(ord_flag, 31, 1) <> '2' --非行政内采
										or
										(
											substr(ord_flag, 31, 1) = '2'
											and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
										)
									)
									and substr(ord_flag, 40, 1) <> '1'
									and
									(
										substring(ord_flag, 46, 1) not in('1', '2', '3', '7')
										or substring(ord_flag, 60, 3) not in('013')
									)
									and sale_ord_type_cd <> '68' --剔除拍卖
									and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
							)
							b
						on
							a.item_sku_id = b.item_sku_id
						left join
							(
								select
									lower(trim(user_log_acct)) user_log_acct
								from
									gdm.gdm_m01_userinfo_enterprise_da
								where
									dt = sysdate( - 1)
								group by
									lower(trim(user_log_acct))
							)
							c
						on
							b.user_log_acct = c.user_log_acct
						where
							c.user_log_acct is null
							and b.user_log_acct not like"ept%"
							and b.user_log_acct not like"xtl%"
							and b.user_log_acct not like"*yhd%"
							and b.user_log_acct not like'*yx%'
						group by
							cate_name,
							cate_id,
							b.user_log_acct,
							sale_ord_dt
					)
					a
			)
			a
		where
			ord_times >= 3
			and next_ord_dt is not null
		group by
		    cate_id,
			cate_name,
			user_log_acct
	)
	ff
group by
	cate_id,
	cate_name,
	floor(med_gap)
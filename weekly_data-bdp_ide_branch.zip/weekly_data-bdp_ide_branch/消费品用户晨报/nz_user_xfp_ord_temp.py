#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import time
import datetime
import subprocess


sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day

sql_1 = """
--合并小文件
set hive.merge.mapfiles=true;
set hive.merge.mapredfiles = true;
set hive.merge.size.per.task = 256000000;
set hive.merge.smallfiles.avgsize = 256000000;
--存储压缩
set hive.default.fileformat=Orc;
--多线程并发
set hive.exec.parallel = true;
set hive.exec.parallel.thread.number = 8;
--列剪裁
set hive.optimize.cp = true;
set hive.optimize.pruner = true;
--map阶段优化
set mapred.max.split.size = 256000000;
set mapred.min.split.size.per.node = 256000000;
set mapred.min.split.size.per.rack = 256000000;
set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set hive.hadoop.supports.splittable.combineinputformat = true;
set mapreduce.input.fileinputformat.split.maxsize = 256000000;
set mapreduce.input.fileinputformat.split.minsize.per.node=256000000;
set mapreduce.input.fileinputformat.split.minsize.per.rack=256000000;

insert overwrite table dev_xfp.nz_user_xfp_temp
select /*+ MAPJOIN(a)*/
	user_log_acct,
	sale_ord_dt
from
	(
		select
			item_sku_id
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and dept_id_1 = '33'
	)
	a
join
	(
		select
			lower(trim(user_log_acct)) user_log_acct,
			item_sku_id,
			sale_ord_dt,
			parent_sale_ord_id,
			after_prefr_amount_1,
			check_account_tm,
			sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
		from
			app.v_gdm_m04_ord_det_sum_rb
		where
			dt >= date_sub(sysdate( - 367), day(sysdate( - 1)) - 1)
			and
			(
				(
					sale_ord_dt >= date_sub(sysdate( - 367), day(sysdate( - 1)) - 1)
					and sale_ord_dt <= sysdate( - 367)
				)
				or
				(
					sale_ord_dt >= date_sub(sysdate( - 1), day(sysdate( - 1)) - 1)
					and sale_ord_dt <= sysdate( - 1)
				)
			)
			and sale_ord_valid_flag = '1'
			and item_third_cate_cd not in('6980') --剔除礼品卡
			and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
			and
			(
				substr(ord_flag, 31, 1) <> '2' --非行政内采
				or
				(
					substr(ord_flag, 31, 1) = '2'
					and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
				)
			)
			and
			(
				substring(ord_flag, 46, 1) not in('1', '2', '3', '7')
				or substring(ord_flag, 60, 3) not in('013')
			)
			and sale_ord_type_cd <> '68' --剔除拍卖
			and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
			and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
			and user_log_acct not like 'ept%'
			and free_goods_flag = 0
	)
	b
on
	a.item_sku_id = b.item_sku_id
where
	b.ord_amount < 100000
	or
	(
		b.ord_amount >= 100000
		and coalesce(b.check_account_tm, '') <> ''
	)
group by
	user_log_acct,
	sale_ord_dt;
"""

ht.exec_sql(schema_name='dev_xfp', table_name='nz_user_xfp_temp', sql=sql_1, merge_flag=True)
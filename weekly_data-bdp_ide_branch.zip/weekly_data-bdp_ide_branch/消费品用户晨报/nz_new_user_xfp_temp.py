#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import os
import time
import datetime
import subprocess


sys.path.append(os.getenv('HIVE_TASK'))
from HiveTask import HiveTask
ht = HiveTask()
dt = ht.data_day

sql_1 = """
--合并小文件
set hive.merge.mapfiles=true;
set hive.merge.mapredfiles = true;
set hive.merge.size.per.task = 256000000;
set hive.merge.smallfiles.avgsize = 256000000;
--存储压缩
set hive.default.fileformat=Orc;
--多线程并发
set hive.exec.parallel = true;
set hive.exec.parallel.thread.number = 8;
--列剪裁
set hive.optimize.cp = true;
set hive.optimize.pruner = true;
--map阶段优化
set mapred.max.split.size = 256000000;
set mapred.min.split.size.per.node = 256000000;
set mapred.min.split.size.per.rack = 256000000;
set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set hive.hadoop.supports.splittable.combineinputformat = true;
set mapreduce.input.fileinputformat.split.maxsize = 256000000;
set mapreduce.input.fileinputformat.split.minsize.per.node=256000000;
set mapreduce.input.fileinputformat.split.minsize.per.rack=256000000;

insert overwrite table dev_xfp.nz_new_user_xfp_temp
select
	lower(trim(user_log_acct)) user_log_acct,
	max(case when ord_flag = 1 then 1 else 0 end) fst_all_yn,
	min(fst_ord_dt) fst_ord_dt
from
	udm.udm_m01_user_inner_new_or_old_user_flag
where
	dt = sysdate( - 1)
	and type = 'dept'
	and dept_id_1 = '33'
group by
	lower(trim(user_log_acct));
"""

ht.exec_sql(schema_name='dev_xfp', table_name='nz_new_user_xfp_temp', sql=sql_1, merge_flag=True)
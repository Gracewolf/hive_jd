set hive.exec.parallel = true;
create table dev_xfp.nz_niunai_chuda_pin_2 as
select
	user_log_acct
from
	(
		select
			b.user_log_acct,
			max(sale_ord_dt) last_sale_ord_dt
		from
			(
				select
					item_sku_id,
					item_third_cate_cd,
					item_third_cate_name
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and item_first_cate_cd = '1320'
					and item_third_cate_cd in('12201', '9434', '12215')
			)
			a
		join
			(
				select
					b.*
				from
					(
						select
							user_log_acct,
							item_sku_id,
							sale_ord_dt,
							parent_sale_ord_id,
							sale_ord_id,
							after_prefr_amount_1,
							rev_addr_city_id,
							check_account_tm,
							sale_qtty,
							sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
						from
							gdm.gdm_m04_ord_det_sum
						where
							dt >= '2018-01-01'
							and sale_ord_dt >= '2018-01-01'
							and sale_ord_dt <= sysdate( - 1)
							and sale_ord_valid_flag = '1'
							and item_third_cate_cd not in('6980') --剔除礼品卡
							and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
							and
							(
								substr(ord_flag, 31, 1) <> '2' --非行政内采
								or
								(
									substr(ord_flag, 31, 1) = '2'
									and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
								)
							)
							and
							(
								substring(ord_flag, 46, 1) not in('1', '2', '3', '7')
								or substring(ord_flag, 60, 3) not in('013')
							)
							and sale_ord_type_cd <> '68' --剔除拍卖
							and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
							and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
							and user_log_acct not like"ept%"
					)
					b
				where
					b.ord_amount < 100000
					or
					(
						b.ord_amount >= 100000
						and coalesce(b.check_account_tm, '') <> ''
					)
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		group by
			b.user_log_acct
	)
	ff
where
	last_sale_ord_dt < sysdate( - 88)
	and last_sale_ord_dt >= sysdate ( - 220);

set hive.exec.parallel = true;
create table dev_xfp.nz_niunai_chuda_pin_3 as
select
	user_log_acct
from
	(
		select
			user_log_acct,
			first_value(dim_jxkh_level) over(partition by user_log_acct order by ord_num desc) as max_city_level
		from
			(
				select /*+mapjoin(a)*/
					a.user_log_acct,
					c.dim_jxkh_level,
					count(distinct parent_sale_ord_id) ord_num
				from
					(
						select
							*
						from
							dev_xfp.nz_niunai_chuda_pin_2
					)
					a
				join
					(
						select
							user_log_acct,
							rev_addr_city_id,
							parent_sale_ord_id
						from
							gdm.gdm_m04_ord_det_sum
						where
							dt >= '2018-01-01'
							and sale_ord_valid_flag = '1'
						group by
							user_log_acct,
							rev_addr_city_id,
							parent_sale_ord_id
					)
					b
				on
					a.user_log_acct = b.user_log_acct
				join
					(
						select
							city_id,
							dim_jxkh_level
						from
							dim.dim_city_level
						where
							province_id not in('32', '42', '43')
					)
					c
				on
					b.rev_addr_city_id = c.city_id
				join
					(
						select /*+mapjoin(a)*/
							b.user_log_acct
						from
							(
								select
									item_sku_id,
									item_third_cate_cd,
									item_third_cate_name
								from
									gdm.gdm_m03_sold_item_sku_da
								where
									dt = sysdate( - 1)
									and data_type in('1', '3')
									and item_first_cate_cd = '1320'
									and item_third_cate_cd in('12201', '9434', '12215')
							)
							a
						join
							(
								select
									user_log_acct,
									item_sku_id
								from
									gdm.gdm_m13_sku_comment
								where
									dt >= '2018-01-01'
									and score <= 3
							)
							b
						on
							a.item_sku_id = b.item_sku_id
						group by
							b.user_log_acct
					)
					d
				on
					a.user_log_acct = d.user_log_acct
				group by
					a.user_log_acct,
					c.dim_jxkh_level
			)
			ff
	)
	ff
where
	ff.max_city_level in('一线', '二线', '三线')
group by
	user_log_acct;

drop table if exists dev_xfp.nz_niunai_pin_com_1;
set hive.exec.parallel = true;
create table dev_xfp.nz_niunai_pin_com_1 as
select
	user_log_acct,
	score
from
	(
		select
			user_log_acct,
			max(total_score) score
		from
			(
				select
					user_log_acct,
					lower(trim(user_log_acct)) pin
				from
					dev_xfp.nz_niunai_chuda_pin_3
			)
			a
		join
			(
				select
					jd_pin,
					total_score
				from
					app.app_cmo_dmt_jdmem_user_score_simple_da
				where
					dt = sysdate( - 2)
			)
			b
		on
			a.pin = b.jd_pin
		group by
			user_log_acct
	)
	ff
order by score desc
limit 6000;

set hive.exec.parallel = true;

drop table if exists dev_xfp.nz_niunaichuda_ord_list_2;
create table dev_xfp.nz_niunaichuda_ord_list_2 as
select /*+mapjoin(a)*/
    b.*,
    a.score,
    c.item_third_cate_cd,
    c.item_third_cate_name
from
	(
		select
			*
		from
			dev_xfp.nz_niunai_pin_com_1
	)
	a
join
	(
		select
			user_log_acct,
			item_sku_id,
			sale_ord_dt,
			parent_sale_ord_id,
			sale_ord_id,
			after_prefr_amount_1
		from
			(
				select
					user_log_acct,
					item_sku_id,
					sale_ord_dt,
					parent_sale_ord_id,
					sale_ord_id,
					after_prefr_amount_1,
					check_account_tm,
					sale_qtty,
					sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
				from
					gdm.gdm_m04_ord_det_sum
				where
					dt >= '2018-01-01'
					and sale_ord_valid_flag = '1'
					and item_third_cate_cd not in('6980') --剔除礼品卡
					and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
					and
					(
						substr(ord_flag, 31, 1) <> '2' --非行政内采
						or
						(
							substr(ord_flag, 31, 1) = '2'
							and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
						)
					)
					and
					(
						substring(ord_flag, 46, 1) not in('1', '2', '3', '7')
						or substring(ord_flag, 60, 3) not in('013')
					)
					and sale_ord_type_cd <> '68' --剔除拍卖
					and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
					and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
					and user_log_acct not like"ept%"
			)
			b
		where
			b.ord_amount < 100000
			or
			(
				b.ord_amount >= 100000
				and coalesce(b.check_account_tm, '') <> ''
			)
	)
	b
on
	a.user_log_acct = b.user_log_acct
left join
	(
		select
			item_sku_id,
			item_third_cate_cd,
			item_third_cate_name
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
	)
	c
on
	b.item_sku_id = c.item_sku_id;

drop table dev_xfp.nz_niunaichuda_user_list_cateinfo_1;
create table dev_xfp.nz_niunaichuda_user_list_cateinfo_1 as
select
	user_log_acct,
	first_niunai_cate,
	first_niunai_dt,
	last_third_niunai_cate,
	last_third_niunai_dt,
	last_second_niunai_cate,
	last_second_niunai_dt,
	last_niunai_cate,
	last_niunai_dt
from
	(
		select
			user_log_acct,
			first_value(item_third_cate_name) over(partition by user_log_acct order by sale_ord_dt) as first_niunai_cate,
			min(sale_ord_dt) over(partition by user_log_acct) first_niunai_dt,
			lag(item_third_cate_name, 2, '无') over(partition by user_log_acct order by sale_ord_dt) as last_third_niunai_cate,
			lag(sale_ord_dt, 2, '无') over(partition by user_log_acct order by sale_ord_dt) as last_third_niunai_dt,
			lag(item_third_cate_name, 1, '无') over(partition by user_log_acct order by sale_ord_dt) as last_second_niunai_cate,
			lag(sale_ord_dt, 1, '无') over(partition by user_log_acct order by sale_ord_dt) as last_second_niunai_dt,
			first_value(item_third_cate_name) over(partition by user_log_acct order by sale_ord_dt desc) as last_niunai_cate,
			max(sale_ord_dt) over(partition by user_log_acct) as last_niunai_dt,
			row_number() over(partition by user_log_acct order by sale_ord_dt desc) as ord_rank
		from
			dev_xfp.nz_niunaichuda_ord_list_2
		where
			item_third_cate_cd in('12201', '9434', '12215')
	)
	ff
where
	ord_rank = 1
group by
	user_log_acct,
	first_niunai_cate,
	first_niunai_dt,
	last_third_niunai_cate,
	last_third_niunai_dt,
	last_second_niunai_cate,
	last_second_niunai_dt,
	last_niunai_cate,
	last_niunai_dt;

drop table dev_xfp.nz_niunaichuda_user_list_cateinfo_2;	
create table dev_xfp.nz_niunaichuda_user_list_cateinfo_2 as
select
	user_log_acct,
	count(distinct parent_sale_ord_id) par_ord_num,
	sum(after_prefr_amount_1) ord_amount
from
	dev_xfp.nz_niunaichuda_ord_list_2
where
	item_third_cate_cd not in('12201', '9434', '12215')
	and sale_ord_dt >= sysdate( - 183)
	and sale_ord_dt <= sysdate( - 1)
group by
	user_log_acct;
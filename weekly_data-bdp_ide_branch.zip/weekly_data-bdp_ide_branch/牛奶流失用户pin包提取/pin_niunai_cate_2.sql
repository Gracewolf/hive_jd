drop table dev_xfp.nz_niunaichuda_user_list_cateinfo_1;
create table dev_xfp.nz_niunaichuda_user_list_cateinfo_1 as
select
	user_log_acct,
	first_niunai_cate,
	first_niunai_dt,
	last_third_niunai_cate,
	last_third_niunai_dt,
	last_second_niunai_cate,
	last_second_niunai_dt,
	last_niunai_cate,
	last_niunai_dt
from
	(
		select
			user_log_acct,
			first_value(item_third_cate_name) over(partition by user_log_acct order by sale_ord_dt) as first_niunai_cate,
			min(sale_ord_dt) over(partition by user_log_acct) first_niunai_dt,
			lag(item_third_cate_name, 2, '无') over(partition by user_log_acct order by sale_ord_dt) as last_third_niunai_cate,
			lag(sale_ord_dt, 2, '无') over(partition by user_log_acct order by sale_ord_dt) as last_third_niunai_dt,
			lag(item_third_cate_name, 1, '无') over(partition by user_log_acct order by sale_ord_dt) as last_second_niunai_cate,
			lag(sale_ord_dt, 1, '无') over(partition by user_log_acct order by sale_ord_dt) as last_second_niunai_dt,
			first_value(item_third_cate_name) over(partition by user_log_acct order by sale_ord_dt desc) as last_niunai_cate,
			max(sale_ord_dt) over(partition by user_log_acct) as last_niunai_dt,
			row_number() over(partition by user_log_acct order by sale_ord_dt desc) as ord_rank
		from
			dev_xfp.nz_niunaichuda_ord_list
		where
			item_third_cate_cd in('12201', '9434', '12215')
	)
	ff
where
	ord_rank = 1
group by
	user_log_acct,
	first_niunai_cate,
	first_niunai_dt,
	last_third_niunai_cate,
	last_third_niunai_dt,
	last_second_niunai_cate,
	last_second_niunai_dt,
	last_niunai_cate,
	last_niunai_dt;

drop table dev_xfp.nz_niunaichuda_user_list_cateinfo_2;	
create table dev_xfp.nz_niunaichuda_user_list_cateinfo_2 as
select
	user_log_acct,
	count(distinct parent_sale_ord_id) par_ord_num,
	sum(after_prefr_amount_1) ord_amount
from
	dev_xfp.nz_niunaichuda_ord_list
where
	item_third_cate_cd not in('12201', '9434', '12215')
	and sale_ord_dt >= sysdate( - 183)
	and sale_ord_dt <= sysdate( - 1)
group by
	user_log_acct

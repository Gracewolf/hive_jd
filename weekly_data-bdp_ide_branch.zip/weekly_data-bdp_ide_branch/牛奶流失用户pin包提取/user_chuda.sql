create table dev_xfp.niunai_chuda_pin as
select ----活跃用户
	user_log_acct
from
	(
		select
			user_log_acct,
			item_third_cate_cd,
			aera_flag,
			row_number() over(partition by item_third_cate_cd, aera_flag) as rank_flag
		from
			dev_xfp.nz_user_milk_pool
		where
			ord_num_cate >= 4
			and last_ord_dt_cate >= sysdate( - 22)
			and last_cart_dt >= sysdate( - 7)
	)
	t1
where
	(
		aera_flag = '一线'
		and rank_flag <= 1000
	)
	or
	(
		aera_flag <> '一线'
		and rank_flag <= 200
	);

insert into dev_xfp.niunai_chuda_pin
select ----准流失用户
	user_log_acct
from
	(
		select
			user_log_acct,
			item_third_cate_cd,
			aera_flag,
			row_number() over(partition by item_third_cate_cd, aera_flag) as rank_flag
		from
			dev_xfp.nz_user_milk_pool
		where
			ord_num_cate >= 1
			and ord_num_cate < 4
			and last_ord_dt_cate >= sysdate( - 66)
			and last_ord_dt_cate < sysdate( - 22)
			and last_cart_dt >= sysdate( - 7)
	)
	t1
where
	(
		aera_flag = '一线'
		and rank_flag <= 1000
	)
	or
	(
		aera_flag <> '一线'
		and rank_flag <= 200
	);

insert into dev_xfp.niunai_chuda_pin
select ----流失用户1
	user_log_acct
from
	(
		select
			user_log_acct,
			item_third_cate_cd,
			aera_flag,
			row_number() over(partition by item_third_cate_cd, aera_flag) as rank_flag
		from
			dev_xfp.nz_user_milk_pool
		where
			last_ord_dt_cate < sysdate( - 88)
			and last_ord_dt_cate >= sysdate( - 140)
			and last_ord_dt >= sysdate( - 180)
			and total_score >= 20000
			and last_cart_dt >= sysdate( - 15)
	)
	t1
where
	(
		aera_flag = '一线'
		and rank_flag <= 500
	)
	or
	(
		aera_flag <> '一线'
		and rank_flag <= 100
	);

insert into dev_xfp.niunai_chuda_pin
select ----流失用户2
	user_log_acct
from
	(
		select
			user_log_acct,
			item_third_cate_cd,
			aera_flag,
			row_number() over(partition by item_third_cate_cd, aera_flag) as rank_flag
		from
			dev_xfp.nz_user_milk_pool
		where
			last_ord_dt_cate < sysdate( - 140)
			and last_ord_dt >= sysdate( - 180)
			and total_score >= 20000
			and last_cart_dt >= sysdate( - 15)
	)
	t1
where
	(
		aera_flag = '一线'
		and rank_flag <= 500
	)
	or
	(
		aera_flag <> '一线'
		and rank_flag <= 100
	);
create table dev_xfp.nz_user_milk_pool as
select
	t1.user_log_acct,
	t1.pin,
	t1.item_third_cate_cd,
	t1.item_third_cate_name,
	t1.last_ord_dt,
	t1.last_ord_dt_cate,
	t1.ord_num_cate,
	coalesce(t2.last_cart_dt, '2010-01-01') last_cart_dt,
	t3.total_score,
	t4.aera_flag
from
	(
		select /*+mapjoin(a)*/
			b.user_log_acct,
			lower(trim(user_log_acct)) pin,
			a.item_third_cate_cd,
			a.item_third_cate_name,
			b.last_ord_dt,
			count(distinct case when b.sale_ord_dt >= sysdate( - 88) then b.parent_sale_ord_id end) ord_num_cate,
			max(sale_ord_dt) last_ord_dt_cate
		from
			(
				select
					item_sku_id,
					item_third_cate_cd,
					item_third_cate_name
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and item_first_cate_cd = '1320'
					and item_third_cate_cd in('12201', '9434', '12215')
			)
			a
		join
			(
				select
					user_log_acct,
					item_sku_id,
					parent_sale_ord_id,
					sale_ord_dt,
					min(sale_ord_dt) over(partition by user_log_acct) as last_ord_dt
				from
					gdm.gdm_m04_ord_det_sum
				where
					dt >= sysdate( - 180)
					and sale_ord_dt >= sysdate( - 180)
					and sale_ord_valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		group by
			b.user_log_acct,
			a.item_third_cate_cd,
			a.item_third_cate_name,
			b.last_ord_dt
	)
	t1
left join
	(
		select /*+mapjoin(a)*/
			lower(trim(user_log_acct)) pin,
			item_third_cate_cd,
			item_third_cate_name,
			max(dt) last_cart_dt
		from
			(
				select
					item_sku_id,
					item_third_cate_cd,
					item_third_cate_name
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and item_first_cate_cd = '1320'
					and item_third_cate_cd in('12201', '9434', '12215')
			)
			a
		join
			(
				select
					user_log_acct,
					sku_id,
					dt
				from
					app.v_adm_m14_online_log_cart_d_xfp
				where
					dt >= sysdate( - 15)
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			lower(trim(user_log_acct)),
			item_third_cate_cd,
			item_third_cate_name
	)
	t2
on
	t1.pin = t2.pin
	and t1.item_third_cate_cd = t2.item_third_cate_cd
join
	(
		select
			lower(trim(jd_pin)) pin,
			max(total_score) total_score
		from
			app.app_cmo_dmt_jdmem_user_score_simple_da
		where
			dt = sysdate( - 1)
		group by
			lower(trim(jd_pin))
	)
	t3
on
	t1.pin = t3.pin
join
	(
		select
			*
		from
			dev_xfp.nz_milk_user_city_flag
	)
	t4
on
	t1.user_log_acct = t4.user_log_acct
	and t1.item_third_cate_cd = t4.user_cate_cd
group by
	t1.user_log_acct,
	t1.pin,
	t1.item_third_cate_cd,
	t1.item_third_cate_name,
	t1.last_ord_dt,
	t1.last_ord_dt_cate,
	t1.ord_num_cate,
	coalesce(t2.last_cart_dt, '2010-01-01'),
	t3.total_score,
	t4.aera_flag
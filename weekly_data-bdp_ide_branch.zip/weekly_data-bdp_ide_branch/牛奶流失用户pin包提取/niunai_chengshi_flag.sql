create table dev_xfp.nz_milk_user_city_flag as
select
	ff.user_log_acct,
	ff.user_cate_cd,
	ff.user_cate_name,
	ff.aera_flag
from
	(
		select
			ff.*,
			row_number() over(partition by user_log_acct, user_cate_cd, user_cate_name order by ord_num) as rank_addr
		from
			(
				select
					b.user_log_acct,
					a.item_third_cate_cd user_cate_cd,
					a.item_third_cate_cd user_cate_name,
					c.aera_flag,
					count(distinct b.parent_sale_ord_id) ord_num
				from
					(
						select
							item_sku_id,
							item_third_cate_cd,
							item_third_cate_name
						from
							gdm.gdm_m03_sold_item_sku_da
						where
							dt = sysdate( - 1)
							and data_type in('1', '3')
							and item_first_cate_cd = '1320'
							and item_third_cate_cd in('12201', '9434', '12215')
					)
					a
				join
					(
						select
							item_sku_id,
							user_log_acct,
							rev_addr_city_id,
							parent_sale_ord_id
						from
							gdm.gdm_m04_ord_det_sum
						where
							dt >= '2018-01-01'
							and sale_ord_valid_flag = '1'
						group by
							item_sku_id,
							user_log_acct,
							rev_addr_city_id,
							parent_sale_ord_id
					)
					b
				on
					a.item_sku_id = b.item_sku_id
				join
					(
						select
							city_id,
							case
								when dim_jxkh_level = '一线' then '一线'
								when dim_jxkh_level <> '一线' and province_id in('3', '5', '6', '8', '9', '10', '11') then '华北'
								when dim_jxkh_level <> '一线' and province_id in('12', '13', '14', '15', '16', '21') then '华东'
								when dim_jxkh_level <> '一线' and province_id in('19', '20', '23') then '华南'
								when dim_jxkh_level <> '一线' and province_id in('7', '17', '18') then '华中'
								else '西部'
							end aera_flag
						from
							dim.dim_city_level
						where
							dim_jxkh_level in('一线', '二线', '三线')
							and province_id not in('32', '42', '43')
					)
					c
				on
					b.rev_addr_city_id = c.city_id
				group by
					b.user_log_acct,
					a.item_third_cate_cd,
					a.item_third_cate_cd,
					c.aera_flag
			)
			ff
	)
	ff
where
	rank_addr = 1
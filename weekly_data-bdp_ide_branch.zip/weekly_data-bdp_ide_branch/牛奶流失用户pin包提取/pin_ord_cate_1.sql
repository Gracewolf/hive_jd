create table dev_xfp.nz_niunaichuda_ord_list as
select /*+mapjoin(a)*/
    b.*,
    c.item_third_cate_cd,
    c.item_third_cate_name
from
	(
		select
			user_log_acct
		from
			dev_xfp.niunai_chuda_pin
		group by
			user_log_acct
	)
	a
join
	(
		select
			item_sku_id,
			user_log_acct,
			parent_sale_ord_id,
			sale_ord_id,
			sale_ord_dt,
			after_prefr_amount_1
		from
			gdm.gdm_m04_ord_det_sum
		where
			dt >= sysdate( - 1100)
			and sale_ord_dt >= sysdate( - 1100)
			and sale_ord_dt <= sysdate( - 1)
			and sale_ord_valid_flag = '1'
	)
	b
on
	a.user_log_acct = b.user_log_acct
left join
	(
		select
			item_sku_id,
			item_third_cate_cd,
			item_third_cate_name
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
	)
	c
on
	b.item_sku_id = c.item_sku_id
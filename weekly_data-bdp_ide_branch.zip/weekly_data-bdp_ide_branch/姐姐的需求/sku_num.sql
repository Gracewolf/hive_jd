select
    '去年' year_dt,
    count(distinct item_sku_id) sku_num
from
    (
        select
            item_sku_id
        from
            gdm.gdm_m03_mkt_item_sku_da_arc
        where
            dm = '2019-02'
            and start_date <= '2019-02-03'
            and end_date > '2019-02-03'
            and sku_status_cd = '3001'
    )
    a
left semi join
    (
        select
            item_sku_id
        from
            gdm.gdm_m03_mkt_item_sku_da
        where
            dt = sysdate( - 1)
            and tp = '1'
            and dept_id_3 = '985'
    )
    b
on
    a.item_sku_id = b.item_sku_id

union all

select
    '今年' year_dt,
    count(distinct item_sku_id) sku_num
from
    gdm.gdm_m03_mkt_item_sku_da
where
    dt = sysdate( - 1)
    and tp = '1'
    and dept_id_3 = '985'
    and sku_status_cd = '3001'
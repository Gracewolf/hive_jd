select
    year_dt,
    gmv / ord_num kedanjia
from
    (
        select
        	year_dt,
        	sum(cw_gmv) gmv,
        	count(distinct sale_ord_id) ord_num
        from
        	(
        		select
        			item_sku_id,
        			item_id
        		from
        			gdm.gdm_m03_sold_item_sku_da
        		where
        			dt = sysdate( - 1)
        			and data_type = '1'
        			and dept_id_2 = '47'
        			and dept_id_3 = '985'
        	)
        	a
        left join
        	(
        		select
        			item_id
        		from
        			gdm.gdm_m03_item_spec_attr_da
        		where
        			dt = sysdate( - 1)
        			and attr_name in('factoryShip')
        			and attr_val in('1')
        	)
        	c
        on
        	a.item_id = c.item_id
        join
        	(
        		select
        			item_sku_id,
        			case when dt >= sysdate( - 365) then 1 else 0 end year_dt,
        			sale_ord_id,
        			cw_gmv,
        			sale_qtty
        		from
        			app.v_app_cmo_cw_ord_det_sum_rb
        		where
        			dt >= sysdate( - 730)
        			and dt <= sysdate( - 1)
        			and valid_flag = '1'
        			and
        			(
        				(
        					tp = '1'
        					and substr(ord_flag, 40, 1) <> '1'
        				) ----自营剔分销
        				or
        				(
        					tp = '2'
        					and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
        				) ----POP剔赠品
        			)
        	)
        	b
        on
        	a.item_sku_id = b.item_sku_id
        where
        	c.item_id is null
        group by
        	year_dt
    )
    ff
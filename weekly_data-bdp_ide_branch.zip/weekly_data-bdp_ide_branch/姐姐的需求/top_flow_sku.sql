set hive.exec.parallel = true;
create table dev_xfp.nz_tea_top_flow_sku as
select /*+mapjoin(a)*/
    '去年' year_dt,
    item_sku_id sku_id,
    sku_name,
    sum(sku_pv) pv
from
    (
        select
            item_sku_id,
            regexp_replace(regexp_replace(trim(sku_name), ',', '，'), '"', '') sku_name
        from
            gdm.gdm_m03_sold_item_sku_da
        where
            dt = sysdate( - 1)
            and data_type = '1'
            and dept_id_3 = '985'
    )
    a
join
    (
		select
			sku_id,
			sku_pv
		from
			adm.adm_s14_online_log_smart_item_d
		where
		    dt >= sysdate( - 720)
		    and dt < sysdate( - 540)
    )
    b
on
    a.item_sku_id = b.sku_id
group by
    item_sku_id,
    sku_name

union all

select /*+mapjoin(a)*/
    '去年' year_dt,
    item_sku_id sku_id,
    sku_name,
    sum(sku_pv) pv
from
    (
        select
            item_sku_id,
            regexp_replace(regexp_replace(trim(sku_name), ',', '，'), '"', '') sku_name
        from
            gdm.gdm_m03_sold_item_sku_da
        where
            dt = sysdate( - 1)
            and data_type = '1'
            and dept_id_3 = '985'
    )
    a
join
    (
		select
			sku_id,
			sku_pv
		from
			adm.adm_s14_online_log_smart_item_d
		where
		    dt >= sysdate( - 540)
		    and dt < sysdate( - 360)
    )
    b
on
    a.item_sku_id = b.sku_id
group by
    item_sku_id,
    sku_name

union all

select /*+mapjoin(a)*/
    '今年' year_dt,
    item_sku_id sku_id,
    sku_name,
    sum(sku_pv) pv
from
    (
        select
            item_sku_id,
            regexp_replace(regexp_replace(trim(sku_name), ',', '，'), '"', '') sku_name
        from
            gdm.gdm_m03_sold_item_sku_da
        where
            dt = sysdate( - 1)
            and data_type = '1'
            and dept_id_3 = '985'
    )
    a
join
    (
		select
			sku_id,
			sku_pv
		from
			adm.adm_s14_online_log_smart_item_d
		where
		    dt >= sysdate( - 360)
		    and dt < sysdate( - 180)
    )
    b
on
    a.item_sku_id = b.sku_id
group by
    item_sku_id,
    sku_name

union all

select /*+mapjoin(a)*/
    '今年' year_dt,
    item_sku_id sku_id,
    sku_name,
    sum(sku_pv) pv
from
    (
        select
            item_sku_id,
            regexp_replace(regexp_replace(trim(sku_name), ',', '，'), '"', '') sku_name
        from
            gdm.gdm_m03_sold_item_sku_da
        where
            dt = sysdate( - 1)
            and data_type = '1'
            and dept_id_3 = '985'
    )
    a
join
    (
		select
			sku_id,
			sku_pv
		from
			adm.adm_s14_online_log_smart_item_d
		where
		    dt >= sysdate( - 180)
		    and dt <= sysdate( - 1)
    )
    b
on
    a.item_sku_id = b.sku_id
group by
    item_sku_id,
    sku_name;

select
    year_dt,
    sku_id,
    sku_name,
    rank_num
from
    (
        select
            year_dt,
            sku_id,
            sku_name,
            row_number() over(partition by year_dt order by pv desc) as rank_num
        from
            (
                select
                    year_dt,
                    sku_id,
                    sku_name,
                    sum(pv) pv
                from
                    dev_xfp.nz_tea_top_flow_sku
                group by
                    year_dt,
                    sku_id,
                    sku_name
            )
            a
    )
    a
where
    rank_num <= 30
set hive.exec.parallel = true;
select
	'亿滋' 备注,
	year(sale_ord_dt) 年份,
	coalesce(dim_jxkh_level, '未知') 城市线级,
	sum(after_prefr_amount_1) 有效金额
from
	(
		select * from dev_xfp.nz_yizi_ord_list
	)
	a
left join
	(
		select
			city_id,
			dim_province_name,
			dim_jxkh_level
		from
			dim.dim_city_level
		group by
			city_id,
			dim_province_name,
			dim_jxkh_level
	)
	d
on
	a.rev_addr_city_id = d.city_id
group by
	year(sale_ord_dt),
	coalesce(dim_jxkh_level, '未知')

union all

select
	barndname_full 备注,
	year(sale_ord_dt) 年份,
	coalesce(dim_jxkh_level, '未知') 城市线级,
	sum(after_prefr_amount_1) 有效金额
from
	(
		select * from dev_xfp.nz_yizi_ord_list
	)
	a
left join
	(
		select
			city_id,
			dim_province_name,
			dim_jxkh_level
		from
			dim.dim_city_level
		group by
			city_id,
			dim_province_name,
			dim_jxkh_level
	)
	d
on
	a.rev_addr_city_id = d.city_id
group by
	barndname_full,
	year(sale_ord_dt),
	coalesce(dim_jxkh_level, '未知')

union all

select
	'饼干蛋糕' 备注,
	year(sale_ord_dt) 年份,
	coalesce(dim_jxkh_level, '未知') 城市线级,
	sum(after_prefr_amount_1) 有效金额
from
	(
		select * from dev_xfp.nz_cookie_ord_list
	)
	a
left join
	(
		select
			city_id,
			dim_province_name,
			dim_jxkh_level
		from
			dim.dim_city_level
		group by
			city_id,
			dim_province_name,
			dim_jxkh_level
	)
	d
on
	a.rev_addr_city_id = d.city_id
group by
	year(sale_ord_dt),
	coalesce(dim_jxkh_level, '未知')

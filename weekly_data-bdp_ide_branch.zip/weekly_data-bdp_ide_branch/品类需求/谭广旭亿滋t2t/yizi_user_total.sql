select
	'亿滋' 品牌,
	month(sale_ord_dt) month_dt,
	count(distinct case when year(sale_ord_dt) = 2019 then a.user_log_acct end) 今年用户数,
	count(distinct case when year(sale_ord_dt) = 2019 and b.fst_all_yn = 1 then a.user_log_acct end) 今年站外新,
	count(distinct case when year(sale_ord_dt) = 2019 and b.fst_all_yn = 0 then a.user_log_acct end) 今年站内新,
	count(distinct case when year(sale_ord_dt) = 2018 then a.user_log_acct end) 去年用户数,
	count(distinct case when year(sale_ord_dt) = 2018 and b.fst_all_yn = 1 then a.user_log_acct end) 去年站外新,
	count(distinct case when year(sale_ord_dt) = 2018 and b.fst_all_yn = 0 then a.user_log_acct end) 去年站内新
from
	(
		select * from dev_xfp.nz_yizi_ord_list
	)
	a
left join
	(
		select
			x.user_log_acct,
			x.fst_all_yn,
			year(x.fst_ord_dt) year_dt,
			month(x.fst_ord_dt) month_dt
		from
			(
				select
					unif_user_log_acct user_log_acct,
					max(
						case
							when fst_all_yn = 1
							then 1
							else 0
						end) fst_all_yn,
					min(fst_ord_dt) fst_ord_dt
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 1)
					and tp = 'brand'
					and main_brand_cd in('3681', '44612', '14597', '16599', '18169', '8185', '11237', '17315', '21649', '20050', '197246', '22553', '145053')
				group by
					unif_user_log_acct
			)
			x
		where				
			(
				(
					fst_ord_dt >= '2018-01-01'
					and fst_ord_dt <= '2018-11-22'
				)
				or
				(
					fst_ord_dt >= '2019-01-01'
					and fst_ord_dt <= '2019-11-22'
				)
			)
	)
	b
on
	a.user_log_acct = b.user_log_acct
	and year(sale_ord_dt) = b.year_dt
	and month(sale_ord_dt) = b.month_dt
group by
	month(sale_ord_dt)
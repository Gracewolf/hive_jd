set hive.exec.parallel = true;
select
	coalesce(t1.model, t2.model) 模式,
	coalesce(t1.month_dt, t2.month_dt) 月份,
	sum(case when t1.year_dt = 2019 then t1.子单数 end) 今年子单数,
	sum(case when t1.year_dt = 2019 then t1.父单数 end) 今年父单数,
	sum(case when t1.year_dt = 2019 then t1.gmv end) 今年gmv,
	sum(case when t1.year_dt = 2019 then t2.pv end) 今年pv,
	sum(case when t1.year_dt = 2019 then t2.uv end) 今年uv,
	sum(case when t1.year_dt = 2018 then t1.子单数 end) 去年子单数,
	sum(case when t1.year_dt = 2018 then t1.父单数 end) 去年父单数,
	sum(case when t1.year_dt = 2018 then t1.gmv end) 去年gmv,
	sum(case when t1.year_dt = 2018 then t2.pv end) 去年pv,
	sum(case when t1.year_dt = 2018 then t2.uv end) 去年uv
from
	(
		select /*+ mapjoin(a)*/
			a.model,
			b.year_dt,
			b.month_dt,
			count(distinct b.sale_ord_id) 子单数,
			count(distinct b.parent_sale_ord_id) 父单数,
			sum(b.cw_gmv) gmv
		from
			(
				select
					item_sku_id,
					case data_type
						when '1' then '自营'
						when '3' then 'POP'
					end model
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and item_first_cate_cd = '1320'
					and dept_id_2 = '47'
					and brand_code in('3681', '44612', '14597', '16599', '18169', '8185', '11237', '17315', '21649', '20050', '197246', '22553', '145053')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					month(dt) month_dt,
					item_sku_id,
					sale_ord_id,
					parent_sale_ord_id,
					ord_flag,
					item_second_cate_cd,
					item_third_cate_cd,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2018-01-01'
							and dt <= '2018-04-30'
						)
						or
						(
							dt >= '2019-01-01'
							and dt <= '2019-04-30'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		group by
			a.model,
			b.year_dt,
			b.month_dt
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			a.model,
			b.year_dt,
			b.month_dt,
			sum(b.pv) pv,
			count(distinct b.browser_uniq_id) uv
		from
			(
				select
					item_sku_id,
					case data_type
						when '1' then '自营'
						when '3' then 'POP'
					end model
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and item_first_cate_cd = '1320'
					and dept_id_2 = '47'
					and brand_code in('3681', '44612', '14597', '16599', '18169', '8185', '11237', '17315', '21649', '20050', '197246', '22553', '145053')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					month(dt) month_dt,
					sku_id,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2018-01-01'
							and dt <= '2018-04-30'
						)
						or
						(
							dt >= '2019-01-01'
							and dt <= '2019-04-30'
						)
					)
				group by
					sku_id,
					year(dt),
					browser_uniq_id,
					month(dt)
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			a.model,
			b.year_dt,
			b.month_dt
	)
	t2
on
	t1.year_dt = t2.year_dt
	and t1.month_dt = t2.month_dt
	and t1.model = t2.model
group by
	coalesce(t1.model, t2.model),
	coalesce(t1.month_dt, t2.month_dt)

union all

select
	coalesce(t1.model, t2.model) 模式,
	coalesce(t1.month_dt, t2.month_dt) 月份,
	sum(case when t1.year_dt = 2019 then t1.子单数 end) 今年子单数,
	sum(case when t1.year_dt = 2019 then t1.父单数 end) 今年父单数,
	sum(case when t1.year_dt = 2019 then t1.gmv end) 今年gmv,
	sum(case when t1.year_dt = 2019 then t2.pv end) 今年pv,
	sum(case when t1.year_dt = 2019 then t2.uv end) 今年uv,
	sum(case when t1.year_dt = 2018 then t1.子单数 end) 去年子单数,
	sum(case when t1.year_dt = 2018 then t1.父单数 end) 去年父单数,
	sum(case when t1.year_dt = 2018 then t1.gmv end) 去年gmv,
	sum(case when t1.year_dt = 2018 then t2.pv end) 去年pv,
	sum(case when t1.year_dt = 2018 then t2.uv end) 去年uv
from
	(
		select /*+ mapjoin(a)*/
			a.model,
			b.year_dt,
			b.month_dt,
			count(distinct b.sale_ord_id) 子单数,
			count(distinct b.parent_sale_ord_id) 父单数,
			sum(b.cw_gmv) gmv
		from
			(
				select
					item_sku_id,
					case data_type
						when '1' then '自营'
						when '3' then 'POP'
					end model
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and item_first_cate_cd = '1320'
					and dept_id_2 = '47'
					and brand_code in('3681', '44612', '14597', '16599', '18169', '8185', '11237', '17315', '21649', '20050', '197246', '22553', '145053')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					month(dt) month_dt,
					item_sku_id,
					sale_ord_id,
					parent_sale_ord_id,
					ord_flag,
					item_second_cate_cd,
					item_third_cate_cd,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2018-05-01'
							and dt <= '2018-08-31'
						)
						or
						(
							dt >= '2019-05-01'
							and dt <= '2019-08-31'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		group by
			a.model,
			b.year_dt,
			b.month_dt
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			a.model,
			b.year_dt,
			b.month_dt,
			sum(b.pv) pv,
			count(distinct b.browser_uniq_id) uv
		from
			(
				select
					item_sku_id,
					case data_type
						when '1' then '自营'
						when '3' then 'POP'
					end model
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and item_first_cate_cd = '1320'
					and dept_id_2 = '47'
					and brand_code in('3681', '44612', '14597', '16599', '18169', '8185', '11237', '17315', '21649', '20050', '197246', '22553', '145053')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					month(dt) month_dt,
					sku_id,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2018-05-01'
							and dt <= '2018-08-31'
						)
						or
						(
							dt >= '2019-05-01'
							and dt <= '2019-08-31'
						)
					)
				group by
					sku_id,
					year(dt),
					browser_uniq_id,
					month(dt)
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			a.model,
			b.year_dt,
			b.month_dt
	)
	t2
on
	t1.year_dt = t2.year_dt
	and t1.month_dt = t2.month_dt
	and t1.model = t2.model
group by
	coalesce(t1.model, t2.model),
	coalesce(t1.month_dt, t2.month_dt)

union all

select
	coalesce(t1.model, t2.model) 模式,
	coalesce(t1.month_dt, t2.month_dt) 月份,
	sum(case when t1.year_dt = 2019 then t1.子单数 end) 今年子单数,
	sum(case when t1.year_dt = 2019 then t1.父单数 end) 今年父单数,
	sum(case when t1.year_dt = 2019 then t1.gmv end) 今年gmv,
	sum(case when t1.year_dt = 2019 then t2.pv end) 今年pv,
	sum(case when t1.year_dt = 2019 then t2.uv end) 今年uv,
	sum(case when t1.year_dt = 2018 then t1.子单数 end) 去年子单数,
	sum(case when t1.year_dt = 2018 then t1.父单数 end) 去年父单数,
	sum(case when t1.year_dt = 2018 then t1.gmv end) 去年gmv,
	sum(case when t1.year_dt = 2018 then t2.pv end) 去年pv,
	sum(case when t1.year_dt = 2018 then t2.uv end) 去年uv
from
	(
		select /*+ mapjoin(a)*/
			a.model,
			b.year_dt,
			b.month_dt,
			count(distinct b.sale_ord_id) 子单数,
			count(distinct b.parent_sale_ord_id) 父单数,
			sum(b.cw_gmv) gmv
		from
			(
				select
					item_sku_id,
					case data_type
						when '1' then '自营'
						when '3' then 'POP'
					end model
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and item_first_cate_cd = '1320'
					and dept_id_2 = '47'
					and brand_code in('3681', '44612', '14597', '16599', '18169', '8185', '11237', '17315', '21649', '20050', '197246', '22553', '145053')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					month(dt) month_dt,
					item_sku_id,
					sale_ord_id,
					parent_sale_ord_id,
					ord_flag,
					item_second_cate_cd,
					item_third_cate_cd,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2018-09-01'
							and dt <= '2018-11-22'
						)
						or
						(
							dt >= '2019-09-01'
							and dt <= '2019-11-22'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		group by
			a.model,
			b.year_dt,
			b.month_dt
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			a.model,
			b.year_dt,
			b.month_dt,
			sum(b.pv) pv,
			count(distinct b.browser_uniq_id) uv
		from
			(
				select
					item_sku_id,
					case data_type
						when '1' then '自营'
						when '3' then 'POP'
					end model
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and item_first_cate_cd = '1320'
					and dept_id_2 = '47'
					and brand_code in('3681', '44612', '14597', '16599', '18169', '8185', '11237', '17315', '21649', '20050', '197246', '22553', '145053')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					month(dt) month_dt,
					sku_id,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2018-09-01'
							and dt <= '2018-11-22'
						)
						or
						(
							dt >= '2019-09-01'
							and dt <= '2019-11-22'
						)
					)
				group by
					sku_id,
					year(dt),
					browser_uniq_id,
					month(dt)
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			a.model,
			b.year_dt,
			b.month_dt
	)
	t2
on
	t1.year_dt = t2.year_dt
	and t1.month_dt = t2.month_dt
	and t1.model = t2.model
group by
	coalesce(t1.model, t2.model),
	coalesce(t1.month_dt, t2.month_dt)
set hive.exec.parallel = true;
select
	coalesce(t1.yyyy_mm, t2.yyyy_mm) 日期,
	coalesce(t1.brand_code, t2.brand_code) 品牌id,
	coalesce(t1.barndname_full, t2.barndname_full) 品牌,
	子单数,
	gmv,
	pv,
	uv
from
	(
		select /*+ mapjoin(a)*/
			b.yyyy_mm,
			a.brand_code,
			a.barndname_full,
			count(distinct sale_ord_id) 子单数,
			sum(cw_gmv) gmv
		from
			(
				select
					item_sku_id,
					item_id,
					brand_code,
					barndname_full
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
					and brand_code in('17804', '151523', '7623', '37470', '7876', '17302', '5926', '5792', '28127', '7610', '18703', '14611', '32686', '20964', '11023', '17076', '12339', '206308', '20888', '17799', '5688', '8265', '11666', '20519', '22997', '28133', '11500', '78378', '7615', '13430', '8311', '8700', '27890', '109035', '6034', '26702', '21481', '14406', '7483', '16107', '16742', '50599', '27946', '27845', '130077', '272531', '153153', '22606', '153479', '185031', '28840', '20808', '102233', '15148', '9833', '17308', '32006', '50548', '11031')
			)
			a
		join
			(
				select
					substr(dt, 1, 7) yyyy_mm,
					item_sku_id,
					sale_ord_id,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2019-01-01'
							and dt <= '2019-04-23'
						)
						or
						(
							dt >= '2020-01-01'
							and dt <= '2020-04-23'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		group by
			b.yyyy_mm,
			a.brand_code,
			a.barndname_full
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			b.yyyy_mm,
			a.brand_code,
			a.barndname_full,
			sum(pv) pv,
			count(distinct browser_uniq_id) uv
		from
			(
				select
					item_sku_id,
					item_id,
					brand_code,
					barndname_full
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
					and brand_code in('17804', '151523', '7623', '37470', '7876', '17302', '5926', '5792', '28127', '7610', '18703', '14611', '32686', '20964', '11023', '17076', '12339', '206308', '20888', '17799', '5688', '8265', '11666', '20519', '22997', '28133', '11500', '78378', '7615', '13430', '8311', '8700', '27890', '109035', '6034', '26702', '21481', '14406', '7483', '16107', '16742', '50599', '27946', '27845', '130077', '272531', '153153', '22606', '153479', '185031', '28840', '20808', '102233', '15148', '9833', '17308', '32006', '50548', '11031')
			)
			a
		join
			(
				select
					substr(dt, 1, 7) yyyy_mm,
					sku_id,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2019-01-01'
							and dt <= '2019-04-23'
						)
						or
						(
							dt >= '2020-01-01'
							and dt <= '2020-04-23'
						)
					)
				group by
					sku_id,
					substr(dt, 1, 7),
					browser_uniq_id
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			b.yyyy_mm,
			a.brand_code,
			a.barndname_full
	)
	t2
on
	t1.yyyy_mm = t2.yyyy_mm
	and t1.brand_code = t2.brand_code
	and t1.barndname_full = t2.barndname_full
select
	cpp_base_ulevel 会员等级,
	count(distinct case when year_dt = 2019 then user_log_acct end) 今年用户数,
	count(distinct case when year_dt = 2018 then user_log_acct end) 去年用户数,
	count(distinct case when year_dt = 2019 and brand_code = '18703' then user_log_acct end) 今年杏花楼用户数,
	count(distinct case when year_dt = 2018 and brand_code = '18703' then user_log_acct end) 去年杏花楼用户数
from
	dev_xfp.nz_laozihao_user_pool
group by
	cpp_base_ulevel;
	
select
	cpp_base_sex 性别,
	count(distinct case when year_dt = 2019 then user_log_acct end) 今年用户数,
	count(distinct case when year_dt = 2018 then user_log_acct end) 去年用户数,
	count(distinct case when year_dt = 2019 and brand_code = '18703' then user_log_acct end) 今年杏花楼用户数,
	count(distinct case when year_dt = 2018 and brand_code = '18703' then user_log_acct end) 去年杏花楼用户数
from
	dev_xfp.nz_laozihao_user_pool
group by
	cpp_base_sex;
	
select
	cpp_base_age 年龄,
	count(distinct case when year_dt = 2019 then user_log_acct end) 今年用户数,
	count(distinct case when year_dt = 2018 then user_log_acct end) 去年用户数,
	count(distinct case when year_dt = 2019 and brand_code = '18703' then user_log_acct end) 今年杏花楼用户数,
	count(distinct case when year_dt = 2018 and brand_code = '18703' then user_log_acct end) 去年杏花楼用户数
from
	dev_xfp.nz_laozihao_user_pool
group by
	cpp_base_age;

select
	cpp_base_marriage 婚姻,
	count(distinct case when year_dt = 2019 then user_log_acct end) 今年用户数,
	count(distinct case when year_dt = 2018 then user_log_acct end) 去年用户数,
	count(distinct case when year_dt = 2019 and brand_code = '18703' then user_log_acct end) 今年杏花楼用户数,
	count(distinct case when year_dt = 2018 and brand_code = '18703' then user_log_acct end) 去年杏花楼用户数
from
	dev_xfp.nz_laozihao_user_pool
group by
	cpp_base_marriage;

select
    case cpp_base_education
		when 1 then '初中及以下'
		when 2 then '高中(中专)'
		when 3 then '大学(专科及本科)'
		when 4 then '研究生(硕士及以上)'
		else '未知'
	end 学历,
	count(distinct case when year_dt = 2019 then user_log_acct end) 今年用户数,
	count(distinct case when year_dt = 2018 then user_log_acct end) 去年用户数,
	count(distinct case when year_dt = 2019 and brand_code = '18703' then user_log_acct end) 今年杏花楼用户数,
	count(distinct case when year_dt = 2018 and brand_code = '18703' then user_log_acct end) 去年杏花楼用户数
from
	dev_xfp.nz_laozihao_user_pool
group by
    case cpp_base_education
		when 1 then '初中及以下'
		when 2 then '高中(中专)'
		when 3 then '大学(专科及本科)'
		when 4 then '研究生(硕士及以上)'
		else '未知'
	end;

select
	case cpp_base_profession
		when 'a' then '金融从业者'
		when 'b' then '医务人员'
		when 'c' then '公务员/事业单位'
		when 'd' then '白领/一般职员'
		when 'e' then '工人/服务业人员'
		when 'f' then '教师'
		when 'g' then '农民'
		when 'h' then '学生'
		else '未知'
	end 职业,
	count(distinct case when year_dt = 2019 then user_log_acct end) 今年用户数,
	count(distinct case when year_dt = 2018 then user_log_acct end) 去年用户数,
	count(distinct case when year_dt = 2019 and brand_code = '18703' then user_log_acct end) 今年杏花楼用户数,
	count(distinct case when year_dt = 2018 and brand_code = '18703' then user_log_acct end) 去年杏花楼用户数
from
	dev_xfp.nz_laozihao_user_pool
group by
	case cpp_base_profession
		when 'a' then '金融从业者'
		when 'b' then '医务人员'
		when 'c' then '公务员/事业单位'
		when 'd' then '白领/一般职员'
		when 'e' then '工人/服务业人员'
		when 'f' then '教师'
		when 'g' then '农民'
		when 'h' then '学生'
		else '未知'
	end;

select
	case
		when not (substr(cfv_sens_promotion, 1, 1) = 'L') then '未知'
		else substr(cfv_sens_promotion, 4, 1)
	end 促销敏感度,
	count(distinct case when year_dt = 2019 then user_log_acct end) 今年用户数,
	count(distinct case when year_dt = 2018 then user_log_acct end) 去年用户数,
	count(distinct case when year_dt = 2019 and brand_code = '18703' then user_log_acct end) 今年杏花楼用户数,
	count(distinct case when year_dt = 2018 and brand_code = '18703' then user_log_acct end) 去年杏花楼用户数
from
	dev_xfp.nz_laozihao_user_pool
group by
	case
		when not (substr(cfv_sens_promotion, 1, 1) = 'L') then '未知'
		else substr(cfv_sens_promotion, 4, 1)
	end;

select
	case
		when not (substr(cfv_sens_comment, 1, 1) = 'L') then '未知'
		else substr(cfv_sens_comment, 4, 1)
	end 评论敏感度,
	count(distinct case when year_dt = 2019 then user_log_acct end) 今年用户数,
	count(distinct case when year_dt = 2018 then user_log_acct end) 去年用户数,
	count(distinct case when year_dt = 2019 and brand_code = '18703' then user_log_acct end) 今年杏花楼用户数,
	count(distinct case when year_dt = 2018 and brand_code = '18703' then user_log_acct end) 去年杏花楼用户数
from
	dev_xfp.nz_laozihao_user_pool
group by
	case
		when not (substr(cfv_sens_comment, 1, 1) = 'L') then '未知'
		else substr(cfv_sens_comment, 4, 1)
	end;

select
	case cgp_cust_purchpower
		when '1' then '土豪'
		when '2' then '高级白领'
		when '3' then '小白领'
		when '4' then '蓝领'
		when '5' then '收入很少'
		else '未知'
	end 购买力,
	count(distinct case when year_dt = 2019 then user_log_acct end) 今年用户数,
	count(distinct case when year_dt = 2018 then user_log_acct end) 去年用户数,
	count(distinct case when year_dt = 2019 and brand_code = '18703' then user_log_acct end) 今年杏花楼用户数,
	count(distinct case when year_dt = 2018 and brand_code = '18703' then user_log_acct end) 去年杏花楼用户数
from
	dev_xfp.nz_laozihao_user_pool
group by
	case cgp_cust_purchpower
		when '1' then '土豪'
		when '2' then '高级白领'
		when '3' then '小白领'
		when '4' then '蓝领'
		when '5' then '收入很少'
		else '未知'
	end;
set hive.exec.parallel = true;
select
	a.yyyy_mm 日期,
	a.brand_code 品牌id,
	a.barndname_full 品牌,
	count(distinct a.user_log_acct) 整体用户数,
	sum(a.amount) 整体有效金额,
	count(distinct case when b.fst_all_yn = 1 then a.user_log_acct end) 站外新用户数,
	sum(case when b.fst_all_yn = 1 then a.amount else 0 end) 站外新有效金额,
	count(distinct case when b.fst_all_yn = 0 then a.user_log_acct end) 站内新用户数,
	sum(case when b.fst_all_yn = 0 then a.amount else 0 end) 站内新有效金额
from
	(
		select
			yyyy_mm,
			a.brand_code,
			a.barndname_full,
			coalesce(c.user_log_acct, b.user_log_acct) user_log_acct,
			sum(after_prefr_amount_1) amount
		from
			(
				select
					item_sku_id,
					brand_code,
					barndname_full
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
					and item_first_cate_cd = '1320'
					and brand_code in('17804', '151523', '7623', '37470', '7876', '17302', '5926', '5792', '28127', '7610', '18703', '14611', '32686', '20964', '11023', '17076', '12339', '206308', '20888', '17799', '5688', '8265', '11666', '20519', '22997', '28133', '11500', '78378', '7615', '13430', '8311', '8700', '27890', '109035', '6034', '26702', '21481', '14406', '7483', '16107', '16742', '50599', '27946', '27845', '130077', '272531', '153153', '22606', '153479', '185031', '28840', '20808', '102233', '15148', '9833', '17308', '32006', '50548', '11031')
			)
			a
		join
			(
		----有效订单模板
				select
					b.*
				from
					(
						select
							lower(trim(user_log_acct)) user_log_acct,
							item_sku_id,
							substr(sale_ord_dt, 1, 7) yyyy_mm,
							parent_sale_ord_id,
							sale_ord_id,
							case
								when after_prefr_amount_1 is not null and after_prefr_amount_1 <> '' then after_prefr_amount_1
								else after_prefr_amount
							end after_prefr_amount_1,
							check_account_tm,
							sale_qtty,
							sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
						from
							app.v_gdm_m04_ord_det_sum_rb
						where
							dt >= '2019-01-01'
							and
							(
								(
									sale_ord_dt >= '2019-01-01'
									and sale_ord_dt <= '2019-04-23'
								)
								or
								(
									sale_ord_dt >= '2020-01-01'
									and sale_ord_dt <= '2020-04-23'
								)
							)
							and sale_ord_valid_flag = '1'
							and item_third_cate_cd not in('6980') --剔除礼品卡
							and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
							and
							(
								substr(ord_flag, 31, 1) <> '2' --非行政内采
								or
								(
									substr(ord_flag, 31, 1) = '2'
									and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
								)
							)
							and
							(
								substr(ord_flag, 46, 1) not in('1', '2', '3', '7')
								or substr(ord_flag, 60, 3) not in('013')
							)
							and sale_ord_type_cd <> '68' --剔除拍卖
							and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
							and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
							and user_log_acct not like"ept%"
							and free_goods_flag = 0
					)
					b
				where
					b.ord_amount < 100000
					or
					(
						b.ord_amount >= 100000
						and coalesce(b.check_account_tm, '') <> ''
					)
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		left join
			(
				select
					lower(trim(unif_user_log_acct)) user_log_acct,
					lower(trim(user_acct_name)) pin
				from
					gdm.gdm_m01_userinfo_basic_da
				where
					dt = sysdate( - 1)
			) ----归一化用户pin
			c
		on
			b.user_log_acct = c.pin
		group by
			yyyy_mm,
			a.brand_code,
			a.barndname_full,
			coalesce(c.user_log_acct, b.user_log_acct)
	)
	a	
left join
	(
		select
			x.user_log_acct,
			x.fst_all_yn,
			substr(fst_ord_dt, 1, 7) yyyy_mm
		from
			(
				select
					lower(trim(unif_user_log_acct)) user_log_acct,
					max(
						case
							when fst_all_yn = 1
							then 1
							else 0
						end) fst_all_yn,
					min(fst_ord_dt) fst_ord_dt
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 1)
					and tp = 'cate'
					and item_first_cate_cd = '1320'
				group by
					lower(trim(unif_user_log_acct))
			)
			x
		where
			(
				(
					fst_ord_dt >= '2019-01-01'
					and fst_ord_dt <= '2019-04-23'
				)
				or
				(
					fst_ord_dt >= '2020-01-01'
					and fst_ord_dt <= '2020-04-23'
				)
			)
	)
	b
on
	a.user_log_acct = b.user_log_acct
	and a.yyyy_mm = b.yyyy_mm
left join
	(
		select
			lower(trim(unif_user_log_acct)) user_log_acct
		from
			app.v_adm_s01_user_new_or_old_flag_detail_xfp
		where
			dt = sysdate( - 1)
			and spite_user_flag = '1'
		group by
			lower(trim(unif_user_log_acct))
	)
	c
on
	a.user_log_acct = c.user_log_acct
where
	c.user_log_acct is null
group by
	a.yyyy_mm,
	a.brand_code,
	a.barndname_full
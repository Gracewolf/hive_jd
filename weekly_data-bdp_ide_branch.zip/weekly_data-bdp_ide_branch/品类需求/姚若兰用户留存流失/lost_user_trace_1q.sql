set hive.exec.parallel = true;
select
	t1.new_user_flag 新用户标记,
	t1.model 模式,
	t1.brand_code 品牌id,
	t1.brand_name 品牌,
	t1.season 季度,
	t1.lost_id 流失去向品牌id,
	t1.lost_name 流失去向品牌,
	t1.lost_cn 流失用户数
from
	(
		select
			*,
			row_number() over(partition by new_user_flag, model, brand_code, brand_name, season order by lost_cn desc) as row_rank
		from
			(
				select
					t1.new_user_flag,
					t1.model,
					t1.brand_code,
					t1.brand_name,
					t1.season,
					coalesce(t2.brand_code, '未购买') lost_id,
					coalesce(t2.brand_name, '未购买') lost_name,
					count(distinct t1.user_log_acct) lost_cn
				from
					(
						select
							a.model,
							a.brand_code,
							a.brand_name,
							a.season,
							a.season_comp,
							a.user_log_acct,
							a.new_user_flag
						from
							(
								select
									model,
									brand_code,
									brand_name,
									season,
									case season
										when 'Q1' then 1
										when 'Q2' then 2
										when 'Q3' then 3
									end season_comp,
									user_log_acct,
									new_user_flag
								from
									dev_xfp.nz_brand_user_pool_q
								where
									model = '自营'
									and season <> 'Q4'
							)
							a
						left join
							(
								select
									model,
									brand_code,
									brand_name,
									season,
									case season
										when 'Q2' then 1
										when 'Q3' then 2
										when 'Q4' then 3
									end season_comp,
									user_log_acct,
									new_user_flag
								from
									dev_xfp.nz_brand_user_pool_q
								where
									model = '自营'
									and season <> 'Q1'
							)
							b
						on
							a.model = b.model
							and a.brand_code = b.brand_code
							and a.brand_name = b.brand_name
							and a.season_comp = b.season_comp
							and a.user_log_acct = b.user_log_acct
						where
							b.user_log_acct is null
						group by
							a.model,
							a.brand_code,
							a.brand_name,
							a.season,
							a.season_comp,
							a.user_log_acct,
							a.new_user_flag
					)
					t1
				left join
					(
						select
							a.brand_code,
							a.brand_name,
							a.code_map,
							b.user_log_acct,
							b.season
						from
							(
								select
									item_sku_id,
									brand_code,
									case brand_code
										when '11187' then '乐事POP'
										when '7668' then '桂格POP'
										else barndname_full
									end brand_name,
									case
										when brand_code = '11187' then '11187'
										when brand_code = '7668' then '7668'
										when item_third_cate_cd = '1590' then '11187'
										when item_third_cate_cd = '1601' then '7668'
									end code_map
								from
									gdm.gdm_m03_sold_item_sku_da
								where
									dt = sysdate( - 1)
									and data_type in('1', '3')
									and dept_id_2 in('47', '1699')
									and
									(
										(
											item_first_cate_cd = '1320'
											and item_third_cate_cd in('1590', '1601')
											and brand_code not in('11187', '7668')
										)
										or
										(
											data_type = '3'
											and brand_code in('11187', '7668')
										)
									)
							)
							a
						join
							(
						----有效订单模板
								select
									b.*
								from
									(
										select
											lower(trim(user_log_acct)) user_log_acct,
											item_sku_id,
											case
												when sale_ord_dt <= '2019-06-30' then 1
												when sale_ord_dt <= '2019-09-30' then 2
												when sale_ord_dt <= '2019-12-26' then 3
											end season,
											parent_sale_ord_id,
											sale_ord_id,
											after_prefr_amount,
											check_account_tm,
											sale_qtty,
											sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
										from
											gdm.gdm_m04_ord_det_sum
										where
											dt >= '2019-04-01'
											and
											(
												(
													sale_ord_dt >= '2019-04-01'
													and sale_ord_dt <= '2019-12-26'
												)
											)
											and sale_ord_valid_flag = '1'
											and item_third_cate_cd not in('6980') --剔除礼品卡
											and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
											and
											(
												substr(ord_flag, 31, 1) <> '2' --非行政内采
												or
												(
													substr(ord_flag, 31, 1) = '2'
													and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
												)
											)
											and
											(
												substr(ord_flag, 46, 1) not in('1', '2', '3', '7')
												or substr(ord_flag, 60, 3) not in('013')
											)
											and sale_ord_type_cd <> '68' --剔除拍卖
											and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
											and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
											and user_log_acct not like"ept%"
									)
									b
								where
									b.ord_amount < 100000
									or
									(
										b.ord_amount >= 100000
										and coalesce(b.check_account_tm, '') <> ''
									)
							)
							b
						on
							a.item_sku_id = b.item_sku_id
						group by
							a.brand_code,
							a.brand_name,
							a.code_map,
							b.user_log_acct,
							b.season
					)
					t2
				on
					t1.brand_code = t2.code_map
					and t1.user_log_acct = t2.user_log_acct
					and t1.season_comp = t2.season
				group by
					t1.new_user_flag,
					t1.model,
					t1.brand_code,
					t1.brand_name,
					t1.season,
					coalesce(t2.brand_code, '未购买'),
					coalesce(t2.brand_name, '未购买')
			)
			t1
	)
	t1
where
	lost_id = '未购买'
	or row_rank <= 20
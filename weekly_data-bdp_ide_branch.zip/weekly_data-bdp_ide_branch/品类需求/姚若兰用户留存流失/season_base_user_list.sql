create table dev_xfp.nz_brand_user_pool_q as
select
	a.model,
	a.brand_code,
	a.brand_name,
	b.season,
	b.user_log_acct,
	case when d.user_log_acct is not null then 1 else 0 end new_user_flag
from
	(
		select
			item_sku_id,
			case data_type
				when '1' then '自营'
				when '3' then 'POP'
			end model,
			brand_code,
			barndname_full brand_name
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and dept_id_2 in('47', '1699')
			and brand_code in('11187', '7668')
	)
	a
left join
	(
		select * from dim.dim_item_brand
	)
	c
on
	a.brand_code = c.brand_code
join
	(
----有效订单模板
		select
			b.*
		from
			(
				select
					lower(trim(user_log_acct)) user_log_acct,
					item_sku_id,
					case
						when sale_ord_dt <= '2019-03-31' then 'Q1'
						when sale_ord_dt <= '2019-06-30' then 'Q2'
						when sale_ord_dt <= '2019-09-30' then 'Q3'
						when sale_ord_dt <= '2019-12-26' then 'Q4'
					end season,
					parent_sale_ord_id,
					sale_ord_id,
					after_prefr_amount,
					check_account_tm,
					sale_qtty,
					sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
				from
					gdm.gdm_m04_ord_det_sum
				where
					dt >= '2019-01-01'
					and
					(
						(
							sale_ord_dt >= '2019-01-01'
							and sale_ord_dt <= '2019-12-26'
						)
					)
					and sale_ord_valid_flag = '1'
					and item_third_cate_cd not in('6980') --剔除礼品卡
					and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
					and
					(
						substr(ord_flag, 31, 1) <> '2' --非行政内采
						or
						(
							substr(ord_flag, 31, 1) = '2'
							and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
						)
					)
					and
					(
						substr(ord_flag, 46, 1) not in('1', '2', '3', '7')
						or substr(ord_flag, 60, 3) not in('013')
					)
					and sale_ord_type_cd <> '68' --剔除拍卖
					and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
					and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
					and user_log_acct not like"ept%"
			)
			b
		where
			b.ord_amount < 100000
			or
			(
				b.ord_amount >= 100000
				and coalesce(b.check_account_tm, '') <> ''
			)
	)
	b
on
	a.item_sku_id = b.item_sku_id
left join
	(
		select
			main_brand_cd,
			x.user_log_acct,
			x.fst_all_yn,
			case
				when fst_ord_dt <= '2019-03-31' then 'Q1'
				when fst_ord_dt <= '2019-06-30' then 'Q2'
				when fst_ord_dt <= '2019-09-30' then 'Q3'
				when fst_ord_dt <= '2019-12-26' then 'Q4'
			end season
		from
			(
				select
					main_brand_cd,
					lower(trim(unif_user_log_acct)) user_log_acct,
					max(
						case
							when fst_all_yn = 1
							then 1
							else 0
						end) fst_all_yn,
					min(fst_ord_dt) fst_ord_dt
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 1)
					and tp = 'brand'
				group by
					main_brand_cd,
					lower(trim(unif_user_log_acct))
			)
			x
		where
			(
				(
					fst_ord_dt >= '2019-01-01'
					and fst_ord_dt <= '2019-12-26'
				)
			)
	)
	d
on
	b.user_log_acct = d.user_log_acct
	and b.season = d.season
	and c.main_brand_cd = d.main_brand_cd
group by
	a.model,
	a.brand_code,
	a.brand_name,
	b.season,
	b.user_log_acct,
	case when d.user_log_acct is not null then 1 else 0 end 

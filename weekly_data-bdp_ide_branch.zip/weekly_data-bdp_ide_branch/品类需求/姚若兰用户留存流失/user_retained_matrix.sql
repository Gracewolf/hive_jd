select
	t1.new_user_flag 新用户标记,
	t1.model 模式,
	t1.brand_code 品牌id,
	t1.brand_name 品牌,
	t1.season 季度,
	count(distinct t1.user_log_acct) 当期用户数,
	count(distinct case when t2.model = '自营' then t2.user_log_acct end) 第二期留存自营用户数,
	count(distinct case when t3.model = '自营' then t3.user_log_acct end) 第三期留存自营用户数,
	count(distinct case when t3.model = '自营' then t4.user_log_acct end) 第四期留存自营用户数,
	count(distinct case when t2.model = 'POP' then t2.user_log_acct end) 第二期留存POP用户数,
	count(distinct case when t3.model = 'POP' then t3.user_log_acct end) 第三期留存POP用户数,
	count(distinct case when t3.model = 'POP' then t4.user_log_acct end) 第四期留存POP用户数
from
	(
		select
			model,
			brand_code,
			brand_name,
			season,
			case season
				when 'Q1' then 1
				when 'Q2' then 2
				when 'Q3' then 3
				when 'Q4' then 4
			end season_comp,
			user_log_acct,
			new_user_flag
		from
			dev_xfp.nz_brand_user_pool_q
	)
	t1
left join
	(
		select
			model,
			brand_code,
			brand_name,
			case season
				when 'Q1' then 1
				when 'Q2' then 2
				when 'Q3' then 3
				when 'Q4' then 4
			end season_comp,
			user_log_acct
		from
			dev_xfp.nz_brand_user_pool_q
	)
	t2
on
	t1.brand_code = t2.brand_code
	and t1.brand_name = t2.brand_name
	and t1.season_comp + 1 = t2.season_comp
	and t1.user_log_acct = t2.user_log_acct
left join
	(
		select
			model,
			brand_code,
			brand_name,
			case season
				when 'Q1' then 1
				when 'Q2' then 2
				when 'Q3' then 3
				when 'Q4' then 4
			end season_comp,
			user_log_acct
		from
			dev_xfp.nz_brand_user_pool_q
	)
	t3
on
	t1.brand_code = t3.brand_code
	and t1.brand_name = t3.brand_name
	and t1.season_comp + 2 = t3.season_comp
	and t1.user_log_acct = t3.user_log_acct
left join
	(
		select
			model,
			brand_code,
			brand_name,
			case season
				when 'Q1' then 1
				when 'Q2' then 2
				when 'Q3' then 3
				when 'Q4' then 4
			end season_comp,
			user_log_acct
		from
			dev_xfp.nz_brand_user_pool_q
	)
	t4
on
	t1.brand_code = t4.brand_code
	and t1.brand_name = t4.brand_name
	and t1.season_comp + 3 = t4.season_comp
	and t1.user_log_acct = t4.user_log_acct
group by
	t1.new_user_flag,
	t1.model,
	t1.brand_code,
	t1.brand_name,
	t1.season
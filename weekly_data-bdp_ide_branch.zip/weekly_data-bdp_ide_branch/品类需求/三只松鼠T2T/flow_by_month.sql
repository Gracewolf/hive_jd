----周报分渠道流量模板
select
	case coalesce(t1.data_type, t2.data_type)
		when '1' then '自营'
		when '3' then 'POP'
	end 模式,
	coalesce(t1.month_dt, t2.month_dt) 月份,
	sum(case when t1.year_dt = 2019 then t1.子单数 end) 今年子单数,
	sum(case when t1.year_dt = 2019 then t1.gmv end) 今年gmv,
	sum(case when t1.year_dt = 2019 then t2.pv end) 今年pv,
	sum(case when t1.year_dt = 2019 then t2.uv end) 今年uv,
	sum(case when t1.year_dt = 2018 then t1.子单数 end) 去年子单数,
	sum(case when t1.year_dt = 2018 then t1.gmv end) 去年gmv,
	sum(case when t1.year_dt = 2018 then t2.pv end) 去年pv,
	sum(case when t1.year_dt = 2018 then t2.uv end) 去年uv
from
	(
		select /*+ mapjoin(a)*/
			b.year_dt,
			b.month_dt,
			a.data_type,
			count(distinct b.sale_ord_id) 子单数,
			sum(b.cw_gmv) gmv
		from
			(
				select
					item_sku_id,
					data_type
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and brand_code = '27776'
			)
			a
		join
			(
				select
					year(dt) year_dt,
					month(dt) month_dt,
					item_sku_id,
					sale_ord_id,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2018-01-01'
							and dt <= '2018-09-31'
						)
						or
						(
							dt >= '2019-01-01'
							and dt <= '2019-09-31'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		-- where
			-- (
				-- tp = '1'
				-- and substr(ord_flag, 40, 1) <> '1'
			-- ) ----自营剔分销
			-- or
			-- (
				-- tp = '2'
				-- and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
			-- ) ----POP剔赠品
		group by
			b.year_dt,
			b.month_dt,
			a.data_type
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			b.year_dt,
			b.month_dt,
			a.data_type,
			sum(b.pv) pv,
			count(distinct b.browser_uniq_id) uv
		from
			(
				select
					item_sku_id,
					data_type
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and brand_code = '27776'
			)
			a
		join
			(
				select
					year(dt) year_dt,
					month(dt) month_dt,
					sku_id,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2018-01-01'
							and dt <= '2018-09-31'
						)
						or
						(
							dt >= '2019-01-01'
							and dt <= '2019-09-31'
						)
					)
				group by
					sku_id,
					year(dt),
					month(dt),
					browser_uniq_id
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			b.year_dt,
			b.month_dt,
			a.data_type
	)
	t2
on
	t1.year_dt = t2.year_dt
	and t1.month_dt = t2.month_dt
	and t1.data_type = t2.data_type
group by
	case coalesce(t1.data_type, t2.data_type)
		when '1' then '自营'
		when '3' then 'POP'
	end,
	coalesce(t1.month_dt, t2.month_dt);

----分渠道流量按年汇总
----周报分渠道流量模板
select
	coalesce(t1.device, t2.device) 渠道,
	case coalesce(t1.data_type, t2.data_type)
		when '1' then '自营'
		when '3' then 'POP'
	end 模式,
	sum(case when t1.year_dt = 2019 then t1.子单数 end) 今年子单数,
	sum(case when t1.year_dt = 2019 then t1.gmv end) 今年gmv,
	sum(case when t1.year_dt = 2019 then t2.pv end) 今年pv,
	sum(case when t1.year_dt = 2019 then t2.uv end) 今年uv,
	sum(case when t1.year_dt = 2018 then t1.子单数 end) 去年子单数,
	sum(case when t1.year_dt = 2018 then t1.gmv end) 去年gmv,
	sum(case when t1.year_dt = 2018 then t2.pv end) 去年pv,
	sum(case when t1.year_dt = 2018 then t2.uv end) 去年uv
from
	(
		select /*+ mapjoin(a)*/
			b.year_dt,
			b.device,
			a.data_type,
			count(distinct b.sale_ord_id) 子单数,
			sum(b.cw_gmv) gmv
		from
			(
				select
					item_sku_id,
					data_type
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and brand_code = '27776'
			)
			a
		join
			(
				select
					year(dt) year_dt,
					item_sku_id,
					sale_ord_id,
					cw_gmv,
					case
						when terminal_flag in('12', '22', '42', '62') then 'APP'
						when terminal_flag in('13', '23', '43', '63') then 'M端'
						when terminal_flag in('11', '21', '41', '61') then 'PC'
						when terminal_flag in('33', '31', '30') then '微信'
						when terminal_flag in('32') then '手Q'
						else '未知'
					end device
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2018-01-01'
							and dt <= '2018-09-31'
						)
						or
						(
							dt >= '2019-01-01'
							and dt <= '2019-09-31'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		-- where
			-- (
				-- tp = '1'
				-- and substr(ord_flag, 40, 1) <> '1'
			-- ) ----自营剔分销
			-- or
			-- (
				-- tp = '2'
				-- and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
			-- ) ----POP剔赠品
		group by
			b.year_dt,
			b.device,
			a.data_type
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			b.year_dt,
			b.device,
			a.data_type,
			sum(b.pv) pv,
			count(distinct b.browser_uniq_id) uv
		from
			(
				select
					item_sku_id,
					data_type
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and brand_code = '27776'
			)
			a
		join
			(
				select
					year(dt) year_dt,
					sku_id,
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end device,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2018-01-01'
							and dt <= '2018-09-31'
						)
						or
						(
							dt >= '2019-01-01'
							and dt <= '2019-09-31'
						)
					)
				group by
					sku_id,
					year(dt),
					browser_uniq_id,
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			b.year_dt,
			b.device,
			a.data_type
	)
	t2
on
	t1.year_dt = t2.year_dt
	and t1.device = t2.device
	and t1.data_type = t2.data_type
group by
	coalesce(t1.device, t2.device),
	case coalesce(t1.data_type, t2.data_type)
		when '1' then '自营'
		when '3' then 'POP'
	end;

select
	coalesce(t1.device, t2.device) 渠道,
	coalesce(t1.dept_name_3, t2.dept_name_3) 三级部门,
	sum(case when t1.year_dt = 2019 then t1.子单数 end) 今年子单数,
	sum(case when t1.year_dt = 2019 then t1.gmv end) 今年gmv,
	sum(case when t1.year_dt = 2019 then t2.pv end) 今年pv,
	sum(case when t1.year_dt = 2019 then t2.uv end) 今年uv,
	sum(case when t1.year_dt = 2018 then t1.子单数 end) 去年子单数,
	sum(case when t1.year_dt = 2018 then t1.gmv end) 去年gmv,
	sum(case when t1.year_dt = 2018 then t2.pv end) 去年pv,
	sum(case when t1.year_dt = 2018 then t2.uv end) 去年uv
from
	(
		select /*+ mapjoin(a)*/
			b.year_dt,
			b.device,
			a.dept_name_3,
			count(distinct b.sale_ord_id) 子单数,
			sum(b.cw_gmv) gmv
		from
			(
				select
					item_sku_id,
					dept_name_3
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and dept_id_3 in('4159', '3840')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					item_sku_id,
					sale_ord_id,
					cw_gmv,
					case
						when terminal_flag in('12', '22', '42', '62') then 'APP'
						when terminal_flag in('13', '23', '43', '63') then 'M端'
						when terminal_flag in('11', '21', '41', '61') then 'PC'
						when terminal_flag in('33', '31', '30') then '微信'
						when terminal_flag in('32') then '手Q'
						else '未知'
					end device
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2018-01-01'
							and dt <= '2018-09-31'
						)
						or
						(
							dt >= '2019-01-01'
							and dt <= '2019-09-31'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		-- where
			-- (
				-- tp = '1'
				-- and substr(ord_flag, 40, 1) <> '1'
			-- ) ----自营剔分销
			-- or
			-- (
				-- tp = '2'
				-- and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
			-- ) ----POP剔赠品
		group by
			b.year_dt,
			b.device,
			a.dept_name_3
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			b.year_dt,
			b.device,
			a.dept_name_3,
			sum(b.pv) pv,
			count(distinct b.browser_uniq_id) uv
		from
			(
				select
					item_sku_id,
					dept_name_3
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and dept_id_3 in('4159', '3840')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					sku_id,
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end device,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2018-01-01'
							and dt <= '2018-09-31'
						)
						or
						(
							dt >= '2019-01-01'
							and dt <= '2019-09-31'
						)
					)
				group by
					sku_id,
					year(dt),
					browser_uniq_id,
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			b.year_dt,
			b.device,
			a.dept_name_3
	)
	t2
on
	t1.year_dt = t2.year_dt
	and t1.device = t2.device
	and t1.dept_name_3 = t2.dept_name_3
group by
	coalesce(t1.device, t2.device),
	coalesce(t1.dept_name_3, t2.dept_name_3)
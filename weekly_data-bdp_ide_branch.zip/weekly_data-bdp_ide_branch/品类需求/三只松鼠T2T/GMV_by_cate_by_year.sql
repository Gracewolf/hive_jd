select /*+ mapjoin(a)*/
	b.year_dt,
	a.data_type,
	a.item_second_cate_cd,
	a.item_second_cate_name,
	a.item_third_cate_cd,
	a.item_third_cate_name,
	sum(b.cw_gmv) gmv,
	sum(b.sale_qtty) sale_qtty
from
	(
		select
			item_sku_id,
			item_second_cate_cd,
			item_second_cate_name,
			item_third_cate_cd,
			item_third_cate_name,
			data_type
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and dept_id_2 = '47'
			and brand_code = '27776'
			and item_first_cate_cd = '1320'
			and item_second_cate_cd in('2641', '1583')
	)
	a
join
	(
		select
			year(dt) year_dt,
			item_sku_id,
			sale_qtty,
			cw_gmv
		from
			app.v_app_cmo_cw_ord_det_sum_rb
		where
			(
				(
					dt >= '2018-01-01'
					and dt <= '2018-09-31'
				)
				or
				(
					dt >= '2019-01-01'
					and dt <= '2019-09-31'
				)
			)
			and valid_flag = '1'
	)
	b
on
	a.item_sku_id = b.item_sku_id
group by
	b.year_dt,
	a.data_type,
	a.item_second_cate_cd,
	a.item_second_cate_name,
	a.item_third_cate_cd,
	a.item_third_cate_name;


----食品饮料类目
select /*+ mapjoin(a)*/
	b.year_dt,
	item_first_cate_name,
	item_second_cate_name,
	item_third_cate_name,
	sum(b.cw_gmv) gmv,
	sum(b.sale_qtty) sale_qtty
from
	(
		select
			item_sku_id,
        	item_first_cate_name,
        	item_second_cate_name,
        	item_third_cate_name
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and dept_id_2 = '47'
			and item_first_cate_cd = '1320'
			and item_second_cate_cd in('2641', '1583', '5019')
	)
	a
join
	(
		select
			year(dt) year_dt,
			item_sku_id,
			sale_qtty,
			cw_gmv
		from
			app.v_app_cmo_cw_ord_det_sum_rb
		where
			(
				(
					dt >= '2018-01-01'
					and dt <= '2018-09-31'
				)
				or
				(
					dt >= '2019-01-01'
					and dt <= '2019-09-31'
				)
			)
			and valid_flag = '1'
	)
	b
on
	a.item_sku_id = b.item_sku_id
group by
	b.year_dt,
	item_first_cate_name,
	item_second_cate_name,
	item_third_cate_name
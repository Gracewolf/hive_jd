----松鼠用户池构建
----松鼠用户池构建
drop table if exists dev_xfp.nz_user_pool_sq;
create table dev_xfp.nz_user_pool_sq as
select
	b.year_dt,
	a.model,
	b.user_log_acct,
	c.cpp_base_age,
	coalesce(dim_city_name, '未知') city_name,
	coalesce(dim_province_name, '未知') province_name,
	coalesce(dim_jxkh_level, '未知') city_level
from
	(
		select
			item_sku_id,
			case data_type
				when '1' then '自营'
				when '3' then 'POP'
			end model
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and dept_id_2 = '47'
			and brand_code = '27776'
	)
	a
join
	(
		select
			b.*
		from
			(
				select
					user_log_acct,
					item_sku_id,
					rev_addr_city_id,
					year(sale_ord_dt) year_dt,
					check_account_tm,
					sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
				from
					gdm.gdm_m04_ord_det_sum
				where
					dt >= '2018-01-01'
					and
					(
						(
							sale_ord_dt >= '2018-01-01'
							and sale_ord_dt <= '2018-09-30'
						)
						or
						(
							sale_ord_dt >= '2019-01-01'
							and sale_ord_dt <= '2019-09-30'
						)
					)
					and sale_ord_valid_flag = '1'
					and item_third_cate_cd not in('6980') --剔除礼品卡
					and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
					and
					(
						substr(ord_flag, 31, 1) <> '2' --非行政内采
						or
						(
							substr(ord_flag, 31, 1) = '2'
							and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
						)
					)
					and
					(
						substr(ord_flag, 46, 1) not in('1', '2', '3', '7')
						or substr(ord_flag, 60, 3) not in('013')
					)
					and sale_ord_type_cd <> '68' --剔除拍卖
					and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
					and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
					and user_log_acct not like"ept%"
			)
			b
		where
			b.ord_amount < 100000
			or
			(
				b.ord_amount >= 100000
				and coalesce(b.check_account_tm, '') <> ''
			)
	)
	b
on
	a.item_sku_id = b.item_sku_id
join
	(
		select
			user_log_acct,
			cpp_base_age
		from
			app.app_ba_userprofile_prop_nonpolar_view_ext
		where
			dt = '2019-10-15'
		group by
			user_log_acct,
			cpp_base_age
	)
	c
on
	b.user_log_acct = c.user_log_acct
left join
	(
		select
			city_id,
			dim_city_name,
			dim_province_name,
			dim_jxkh_level
		from
			dim.dim_city_level
		group by
			city_id,
			dim_city_name,
			dim_province_name,
			dim_jxkh_level
	)
	d
on
	b.rev_addr_city_id = d.city_id;

select
    year_dt,
    model,
    city_name,
    province_name,
    city_level,
    count(distinct user_log_acct) cn
from
    dev_xfp.nz_user_pool_sq
group by
    year_dt,
    model,
    city_name,
    province_name,
    city_level;

select
    year_dt,
    model,
    province_name,
    city_level,
    count(distinct user_log_acct) cn
from
    dev_xfp.nz_user_pool_sq
group by
    year_dt,
    model,
    province_name,
    city_level;


select
    year_dt,
    model,
    city_level,
    count(distinct user_log_acct) cn
from
    dev_xfp.nz_user_pool_sq
group by
    year_dt,
    model,
    city_level;

select
    year_dt,
    model,
    province_name,
    count(distinct user_log_acct) cn
from
    dev_xfp.nz_user_pool_sq
group by
    year_dt,
    model,
    province_name;

select
    year_dt,
    model,
    cpp_base_age,
    count(distinct user_log_acct) cn
from
    dev_xfp.nz_user_pool_sq
group by
    year_dt,
    model,
    cpp_base_age;

select
	year_dt,
	model,
	count(distinct user_log_acct) cn
from
	dev_xfp.nz_user_pool_sq
group by
	year_dt,
	model
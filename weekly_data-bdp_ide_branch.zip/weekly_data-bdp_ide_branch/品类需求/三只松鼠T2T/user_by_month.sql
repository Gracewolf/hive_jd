----松鼠分月用户

select
	month_dt,
	model,
	count(case when year_dt = 2019 then user_log_acct end) 今年总用户,
	count(case when new_user_flag = 1 and year_dt = 2019 then user_log_acct end) 今年站外新,
	count(case when new_user_flag = 0 and year_dt = 2019 then user_log_acct end) 今年站内新,
	count(case when year_dt = 2018 then user_log_acct end) 去年总用户,
	count(case when new_user_flag = 1 and year_dt = 2018 then user_log_acct end) 去年站外新,
	count(case when new_user_flag = 0 and year_dt = 2018 then user_log_acct end) 去年站内新
from
	(
		select
			year_dt,
			month_dt,
			model,
			user_log_acct,
			max(coalesce(fst_all_yn, -1)) new_user_flag
		from
			(
				select /*+ MAPJOIN(a)*/
					b.year_dt,
					b.month_dt,
					a.model,
					parent_sale_ord_id,
					sale_ord_id,
					b.user_log_acct
				from
					(
						select
							item_sku_id,
							case data_type
								when '1' then '自营'
								when '3' then 'POP'
							end model
						from
							gdm.gdm_m03_sold_item_sku_da
						where
							dt = sysdate( - 1)
							and data_type in('1', '3')
							and dept_id_2 = '47'
							and brand_code = '27776'
					)
					a
				join
					(
						select
							user_log_acct,
							item_sku_id,
							year(sale_ord_dt) year_dt,
							month(sale_ord_dt) month_dt,
							parent_sale_ord_id,
							sale_ord_id,
							after_prefr_amount_1,
							check_account_tm,
							sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
						from
							gdm.gdm_m04_ord_det_sum
						where
							dt >= '2018-01-01'
							and
							(
								(
									sale_ord_dt >= '2018-01-01'
									and sale_ord_dt <= '2018-09-30'
								)
								or
								(
									sale_ord_dt >= '2019-01-01'
									and sale_ord_dt <= '2019-09-30'
								)
							)
							and sale_ord_valid_flag = '1'
							and item_third_cate_cd not in('6980') --剔除礼品卡
							and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
							and
							(
								substr(ord_flag, 31, 1) <> '2' --非行政内采
								or
								(
									substr(ord_flag, 31, 1) = '2'
									and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
								)
							)
							and
							(
								substring(ord_flag, 46, 1) not in('1', '2', '3', '7')
								or substring(ord_flag, 60, 3) not in('013')
							)
							and sale_ord_type_cd <> '68' --剔除拍卖
							and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
							and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
							and user_log_acct not like"ept%"
					)
					b
				on
					a.item_sku_id = b.item_sku_id
				where
					b.ord_amount < 100000
					or
					(
						b.ord_amount >= 100000
						and coalesce(b.check_account_tm, '') <> ''
					)
			)
			x
		left join
			(
				select
					x.pin,
					x.main_brand_cd,
					fst_all_yn,
					parent_sale_ord_id,
					sale_ord_id
				from
					(
						select
							unif_user_log_acct pin,
							main_brand_cd,
							fst_ord_dt,
							fst_ord_tm,
							parent_sale_ord_id,
							sale_ord_id,
							max(case when fst_all_yn = '1' then 1 else 0 end) over(partition by unif_user_log_acct, main_brand_cd) as fst_all_yn,
							min(fst_ord_tm) over(partition by unif_user_log_acct, main_brand_cd) as min_fst_ord_tm
						from
							app.v_adm_s01_user_new_or_old_flag_detail_xfp
						where
							dt = sysdate( - 1)
							and tp = 'brand'
							and main_brand_cd = '27776'
					)
					x
				where
					fst_ord_tm = min_fst_ord_tm
					and
					(
						(
							fst_ord_dt >= '2018-01-01'
							and fst_ord_dt <= '2018-09-30'
						)
						or
						(
							fst_ord_dt >= '2019-01-01'
							and fst_ord_dt <= '2019-09-30'
						)
					)
				group by
					x.pin,
					x.main_brand_cd,
					fst_all_yn,
					parent_sale_ord_id,
					sale_ord_id
			)
			y
		on
			x.user_log_acct = y.pin
			and x.sale_ord_id = y.sale_ord_id
			and x.parent_sale_ord_id = y.parent_sale_ord_id
		group by
			year_dt,
			month_dt,
			model,
			user_log_acct
	)
	tt
group by
	month_dt,
	model
select
	cate_name 品牌,
	month_dt 月份,
	count(distinct case when c.year_dt = 2019 then c.user_log_acct end) 今年用户数,
	count(distinct case when c.year_dt = 2019 and b.fst_all_yn = 1 then c.user_log_acct end) 今年站外新,
	count(distinct case when c.year_dt = 2019 and b.fst_all_yn = 0 then c.user_log_acct end) 今年站内新,
	count(distinct case when c.year_dt = 2018 then c.user_log_acct end) 去年用户数,
	count(distinct case when c.year_dt = 2018 and b.fst_all_yn = 1 then c.user_log_acct end) 去年站外新,
	count(distinct case when c.year_dt = 2018 and b.fst_all_yn = 0 then c.user_log_acct end) 去年站内新
from
	(
		select
			case
				when dept_id_3 = '3814' then 'POP'
				when dept_id_3 in('141', '147') and item_second_cate_cd = '5019' then '进口'
				when dept_id_3 = '147' then '食用油'
				when item_third_cate_cd = '2675' then '米'
				when item_third_cate_cd = '13789' then '面'
				when item_third_cate_cd = '13790' then '杂粮'
				else '其它'
			end cate_name,
			dept_id_3,
			item_sku_id
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and dept_id_2 = '47'
			and dept_id_3 in('141', '147', '3814')
	)
	a
join
	(
----有效订单模板
		select
			b.*
		from
			(
				select
					user_log_acct,
					item_sku_id,
					year(sale_ord_dt) year_dt,
					month(sale_ord_dt) month_dt,
					parent_sale_ord_id,
					sale_ord_id,
					case
						when after_prefr_amount_1 is not null and after_prefr_amount_1 <> '' then after_prefr_amount_1
						else after_prefr_amount
					end after_prefr_amount_1,
					check_account_tm,
					sale_qtty,
					sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
				from
					gdm.gdm_m04_ord_det_sum
				where
					dt >= '2018-01-01'
					and
					(
						(
							sale_ord_dt >= '2018-01-01'
							and sale_ord_dt <= '2018-11-26'
						)
						or
						(
							sale_ord_dt >= '2019-01-01'
							and sale_ord_dt <= '2019-11-26'
						)
					)
					and sale_ord_valid_flag = '1'
					and item_third_cate_cd not in('6980') --剔除礼品卡
					and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
					and
					(
						substr(ord_flag, 31, 1) <> '2' --非行政内采
						or
						(
							substr(ord_flag, 31, 1) = '2'
							and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
						)
					)
					and
					(
						substr(ord_flag, 46, 1) not in('1', '2', '3', '7')
						or substr(ord_flag, 60, 3) not in('013')
					)
					and sale_ord_type_cd <> '68' --剔除拍卖
					and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
					and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
					and user_log_acct not like"ept%"
			)
			b
		where
			b.ord_amount < 100000
			or
			(
				b.ord_amount >= 100000
				and coalesce(b.check_account_tm, '') <> ''
			)
	)
	c
on
	a.item_sku_id = c.item_sku_id
left join
	(
		select
			dept_id_3,
			x.user_log_acct,
			x.fst_all_yn,
			year(x.fst_ord_dt) year_dt,
			month(x.fst_ord_dt) month_dt
		from
			(
				select
					dept_id_3,
					unif_user_log_acct user_log_acct,
					max(
						case
							when fst_all_yn = 1
							then 1
							else 0
						end) fst_all_yn,
					min(fst_ord_dt) fst_ord_dt
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 1)
					and tp = 'dept'
					and dept_id_2 = '47'
					and dept_id_3 in('141', '147', '3814')
				group by
					dept_id_3,
					unif_user_log_acct
			)
			x
		where
			(
				(
					fst_ord_dt >= '2018-01-01'
					and fst_ord_dt <= '2018-11-26'
				)
				or
				(
					fst_ord_dt >= '2019-01-01'
					and fst_ord_dt <= '2019-11-26'
				)
			)
	)
	b
on
	c.user_log_acct = b.user_log_acct
	and c.year_dt = b.year_dt
	and c.month_dt = b.month_dt
	and a.dept_id_3 = b.dept_id_3
group by
	a.cate_name,
	c.month_dt
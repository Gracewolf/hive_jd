select
	b.累计粉丝数,
	b.1月4日粉丝数,
	b.12月31日粉丝数,
	b.新粉丝数,
	a.*
from
	(
		select
			b.shop_id 店铺id,
			b.shop_name 店铺名,
			count(distinct a.user_log_acct) 有效用户数,
			count(distinct a.sale_ord_id) 有效子单数,
			sum(after_prefr_amount) 优惠后金额,
			count(distinct case when 
			c.start_date <= a.sale_ord_dt
			and c.end_date > a.sale_ord_dt then c.pin end) 粉丝用户数,
			count(distinct case when 
			c.start_date <= a.sale_ord_dt
			and c.end_date > a.sale_ord_dt then a.sale_ord_id end) 粉丝有效子单数,
			sum(case when 
			c.start_date <= a.sale_ord_dt
			and c.end_date > a.sale_ord_dt then a.after_prefr_amount end) 粉丝优惠后金额
		from
			(
				select
					x.user_log_acct,
					x.item_sku_id,
					x.sale_ord_id,
					x.after_prefr_amount_1 after_prefr_amount,
					sale_ord_dt
				from
					app.v_gdm_m04_ord_det_sum_rb x
				where
					dt >= '2020-01-01'
					and sale_ord_dt >= '2020-01-01'
					and sale_ord_dt <= '2020-01-04'
					and sale_ord_valid_flag = '1'
					and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
					and
					(
						substr(ord_flag, 31, 1) <> '2' --非行政内采
						or
						(
							substr(ord_flag, 31, 1) = '2'
							and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
						)
					)
					and
					(
						substring(ord_flag, 46, 1) not in('1', '2', '3', '7')
						or substring(ord_flag, 60, 3) not in('013')
					)
					and sale_ord_type_cd <> '68' --剔除拍卖
					and split_status_cd not in('1') --剔除订单状态为拆分后的父单
			)
			a
		join
			(
				select
					item_sku_id,
					shop_id,
					shop_name
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and shop_id in('1000008814') ----自营旗舰店
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		left join
			(
				select
					shop_id,
					pin,
					start_date,
					end_date
				from
					fdm.fdm_follow_vender_sns_follow_vender_chain ----粉丝拉链表
				where
					start_date <= '2020-01-04'
					and end_date > '2020-01-01'
					and shop_id in('1000008814') 
			)
			c
		on
			c.pin = a.user_log_acct
			and c.shop_id = b.shop_id
		group by
			b.shop_id,
			b.shop_name
	)
	a
join
	(
		select
			shop_id,
			count(distinct case when end_date > '2020-01-01' then pin end) 累计粉丝数, ----本周周期开始
			count(distinct case when end_date > '2020-01-04' then pin end) 1月4日粉丝数, ----本周周期结束
			count(distinct case when start_date <= '2019-12-31' then pin end) 12月31日粉丝数, ----本周周期开始前一天
			count(distinct case when start_date >= '2020-01-01' then pin end) 新粉丝数 ----本周周期开始
		from
			fdm.fdm_follow_vender_sns_follow_vender_chain ----粉丝拉链表
		where
			start_date <= '2020-01-04'
			and end_date > '2019-12-31'
			and shop_id in('1000008814')
		group by
			shop_id
	)
	b
on
	a.店铺id = b.shop_id
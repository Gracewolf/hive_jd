select
	case lvl
		when '42' then brand_code
		when '57' then item_third_cate_id
	end 品牌类目id,
	case lvl
		when '42' then brand_name
		when '57' then item_third_cate_name
	end 品牌类目名称,
	src_url_first_cate_name 一级来源,
	src_url_second_cate_name 二级来源,
	src_url_third_cate_name 三级来源,
	sum(case when year(dt) = 2020 then item_pv end) 今年PV,
	sum(case when year(dt) = 2020 then cart_num end) 今年加购,
	sum(case when year(dt) = 2020 then intr_valid_ord_num end) 今年引入订单数,
	sum(case when year(dt) = 2020 then intr_valid_aft_amount end) 今年优惠后订单金额,
	sum(case when year(dt) = 2019 then item_pv end) 去年PV,
	sum(case when year(dt) = 2019 then cart_num end) 去年加购,
	sum(case when year(dt) = 2019 then intr_valid_ord_num end) 去年引入订单数,
	sum(case when year(dt) = 2019 then intr_valid_aft_amount end) 去年优惠后订单金额
from
	adm.adm_s14_item_last_src_d
where
	(
		(
			dt >= '2019-01-01'
			and dt <= '2019-01-01'
		)
		or
		(
			dt >= '2020-01-01'
			and dt <= '2020-01-04'
		)
	)
	and
	(
		(
			lvl = '42'
			and item_first_cate_id = '1320'
			and brand_code = '55567'
		)
		or
		(
			lvl = '57'
			and dept_id_1 = '33'
			and item_first_cate_id = '1320'
			and item_third_cate_id in('1602', '10975')
		)
	)
	and bs = '311210'
group by
	case lvl
		when '42' then brand_code
		when '57' then item_third_cate_id
	end,
	case lvl
		when '42' then brand_name
		when '57' then item_third_cate_name
	end,
	src_url_first_cate_name,
	src_url_second_cate_name,
	src_url_third_cate_name
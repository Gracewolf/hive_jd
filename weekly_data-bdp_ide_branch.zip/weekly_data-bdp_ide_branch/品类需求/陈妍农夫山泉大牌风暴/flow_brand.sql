select
	coalesce(t1.dept_name_2, t2.dept_name_2) 二级部门,
	coalesce(t1.dept_name_3, t2.dept_name_3) 三级部门,
	coalesce(t1.item_first_cate_name, t2.item_first_cate_name) 一级类目,
	coalesce(t1.item_second_cate_name, t2.item_second_cate_name) 二级类目,
	coalesce(t1.item_third_cate_name, t2.item_third_cate_name) 三级类目,
	coalesce(t1.model, t2.model) 模式,
	coalesce(t1.year_dt, t2.year_dt) 年份,
	gmv,
	ord_num 子单数,
	pv,
	uv
from
	(
		select
			dept_name_2,
			dept_name_3,
			item_first_cate_name,
			item_second_cate_name,
			item_third_cate_name,
			model,
			year_dt,
			sum(cw_gmv) gmv,
			count(distinct sale_ord_id) ord_num
		from
			(
				select
					dept_name_2,
					dept_name_3,
					item_first_cate_name,
					item_second_cate_name,
					item_third_cate_name,
					case data_type
						when '1' then '自营'
						when '3' then 'POP'
					end model,
					item_sku_id
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
					and brand_code = '55567'
			)
			a
		join
			(
				select
					year(dt) year_dt,
					item_sku_id,
					sale_ord_id,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2019-01-01'
							and dt <= '2019-01-04'
						)
						or
						(
							dt >= '2020-01-01'
							and dt <= '2020-01-04'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		group by
			dept_name_2,
			dept_name_3,
			item_first_cate_name,
			item_second_cate_name,
			item_third_cate_name,
			model,
			year_dt
	)
	t1
full outer join
	(
		select
			dept_name_2,
			dept_name_3,
			item_first_cate_name,
			item_second_cate_name,
			item_third_cate_name,
			model,
			year_dt,
			sum(sku_pv) pv,
			count(distinct browser_uniq_id) uv
		from
			(
				select
					dept_name_2,
					dept_name_3,
					item_first_cate_name,
					item_second_cate_name,
					item_third_cate_name,
					case data_type
						when '1' then '自营'
						when '3' then 'POP'
					end model,
					item_sku_id
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 in('47', '1699')
					and brand_code = '55567'
			)
			a
		join
			(
				select
					year(dt) year_dt,
					sku_id,
					browser_uniq_id,
					sku_pv
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2019-01-01'
							and dt <= '2019-01-04'
						)
						or
						(
							dt >= '2020-01-01'
							and dt <= '2020-01-04'
						)
					)
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			dept_name_2,
			dept_name_3,
			item_first_cate_name,
			item_second_cate_name,
			item_third_cate_name,
			model,
			year_dt
	)
	t2
on
	t1.dept_name_2 = t2.dept_name_2
	and t1.dept_name_3 = t2.dept_name_3
	and t1.item_first_cate_name = t2.item_first_cate_name
	and t1.item_second_cate_name = t2.item_second_cate_name
	and t1.item_third_cate_name = t2.item_third_cate_name
	and t1.model = t2.model
	and t1.year_dt = t2.year_dt
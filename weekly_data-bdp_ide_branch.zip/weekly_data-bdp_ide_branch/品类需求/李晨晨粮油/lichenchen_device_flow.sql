----周报分渠道流量模板
select
	coalesce(t1.cate_name, t2.cate_name) 类目,
	coalesce(t1.device, t2.device) 渠道,
	sum(case when t1.year_dt = '2019' then t1.子单数 end) 今年子单数,
	sum(case when t1.year_dt = '2019' then t1.gmv end) 今年gmv,
	sum(case when t1.year_dt = '2019' then t2.pv end) 今年pv,
	sum(case when t1.year_dt = '2019' then t2.uv end) 今年uv,
	sum(case when t1.year_dt = '2018' then t1.子单数 end) 去年子单数,
	sum(case when t1.year_dt = '2018' then t1.gmv end) 去年gmv,
	sum(case when t1.year_dt = '2018' then t2.pv end) 去年pv,
	sum(case when t1.year_dt = '2018' then t2.uv end) 去年uv
from
	(
		select /*+ mapjoin(a)*/
			a.cate_name,
			b.year_dt,
			b.device,
			count(distinct b.sale_ord_id) 子单数,
			sum(b.cw_gmv) gmv
		from
			(
				select
					case
						when dept_id_3 = '3814' then 'POP'
						when dept_id_3 in('141', '147') and item_second_cate_cd = '5019' then '进口'
						when dept_id_3 = '147' then '食用油'
						when item_third_cate_cd = '2675' then '米'
						when item_third_cate_cd = '13789' then '面'
						when item_third_cate_cd = '13790' then '杂粮'
						else '其它'
					end cate_name,
					item_sku_id
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and dept_id_3 in('141', '147', '3814')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					item_sku_id,
					sale_ord_id,
					parent_sale_ord_id,
					lower(trim(user_log_acct)) pin,
					ord_flag,
					item_second_cate_cd,
					item_third_cate_cd,
					cw_gmv,
					case
						when terminal_flag in('12', '22', '42', '62') then 'APP'
						when terminal_flag in('13', '23', '43', '63') then 'M端'
						when terminal_flag in('11', '21', '41', '61') then 'PC'
						when terminal_flag in('33', '31', '30') then '微信'
						when terminal_flag in('32') then '手Q'
						else '未知'
					end device
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2018-10-01'
							and dt <= '2018-10-13'
						)
						or
						(
							dt >= '2019-10-01'
							and dt <= '2019-10-13'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		-- where
			-- (
				-- tp = '1'
				-- and substr(ord_flag, 40, 1) <> '1'
			-- ) ----自营剔分销
			-- or
			-- (
				-- tp = '2'
				-- and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
			-- ) ----POP剔赠品
		group by
			a.cate_name,
			b.year_dt,
			b.device
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			b.year_dt,
			a.cate_name,
			b.device,
			sum(b.pv) pv,
			count(distinct b.browser_uniq_id) uv
		from
			(
				select
					case
						when dept_id_3 = '3814' then 'POP'
						when dept_id_3 in('141', '147') and item_second_cate_cd = '5019' then '进口'
						when dept_id_3 = '147' then '食用油'
						when item_third_cate_cd = '2675' then '米'
						when item_third_cate_cd = '13789' then '面'
						when item_third_cate_cd = '13790' then '杂粮'
						else '其它'
					end cate_name,
					item_sku_id
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and dept_id_3 in('141', '147', '3814')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					sku_id,
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end device,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2018-10-01'
							and dt <= '2018-10-13'
						)
						or
						(
							dt >= '2019-10-01'
							and dt <= '2019-10-13'
						)
					)
				group by
					sku_id,
					year(dt),
					browser_uniq_id,
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			b.year_dt,
			a.cate_name,
			b.device
	)
	t2
on
	t1.year_dt = t2.year_dt
	and t1.cate_name = t2.cate_name
	and t1.device = t2.device
group by
	coalesce(t1.cate_name, t2.cate_name),
	coalesce(t1.device, t2.device)

union all

select
	'粮油组汇总' 类目,
	coalesce(t1.device, t2.device) 渠道,
	sum(case when t1.year_dt = '2019' then t1.子单数 end) 今年子单数,
	sum(case when t1.year_dt = '2019' then t1.gmv end) 今年gmv,
	sum(case when t1.year_dt = '2019' then t2.pv end) 今年pv,
	sum(case when t1.year_dt = '2019' then t2.uv end) 今年uv,
	sum(case when t1.year_dt = '2018' then t1.子单数 end) 去年子单数,
	sum(case when t1.year_dt = '2018' then t1.gmv end) 去年gmv,
	sum(case when t1.year_dt = '2018' then t2.pv end) 去年pv,
	sum(case when t1.year_dt = '2018' then t2.uv end) 去年uv
from
	(
		select /*+ mapjoin(a)*/
			b.year_dt,
			b.device,
			count(distinct b.sale_ord_id) 子单数,
			sum(b.cw_gmv) gmv
		from
			(
				select
					item_sku_id
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and dept_id_3 in('141', '147', '3814')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					item_sku_id,
					sale_ord_id,
					parent_sale_ord_id,
					lower(trim(user_log_acct)) pin,
					ord_flag,
					item_second_cate_cd,
					item_third_cate_cd,
					cw_gmv,
					case
						when terminal_flag in('12', '22', '42', '62') then 'APP'
						when terminal_flag in('13', '23', '43', '63') then 'M端'
						when terminal_flag in('11', '21', '41', '61') then 'PC'
						when terminal_flag in('33', '31', '30') then '微信'
						when terminal_flag in('32') then '手Q'
						else '未知'
					end device
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2018-10-01'
							and dt <= '2018-10-13'
						)
						or
						(
							dt >= '2019-10-01'
							and dt <= '2019-10-13'
						)
					)
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		-- where
			-- (
				-- tp = '1'
				-- and substr(ord_flag, 40, 1) <> '1'
			-- ) ----自营剔分销
			-- or
			-- (
				-- tp = '2'
				-- and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
			-- ) ----POP剔赠品
		group by
			b.year_dt,
			b.device
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			b.year_dt,
			b.device,
			sum(b.pv) pv,
			count(distinct b.browser_uniq_id) uv
		from
			(
				select
					item_sku_id
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and dept_id_2 = '47'
					and dept_id_3 in('141', '147', '3814')
			)
			a
		join
			(
				select
					year(dt) year_dt,
					sku_id,
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end device,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					(
						(
							dt >= '2018-10-01'
							and dt <= '2018-10-13'
						)
						or
						(
							dt >= '2019-10-01'
							and dt <= '2019-10-13'
						)
					)
				group by
					sku_id,
					year(dt),
					browser_uniq_id,
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			b.year_dt,
			b.device
	)
	t2
on
	t1.year_dt = t2.year_dt
	and t1.device = t2.device
group by
	coalesce(t1.device, t2.device)
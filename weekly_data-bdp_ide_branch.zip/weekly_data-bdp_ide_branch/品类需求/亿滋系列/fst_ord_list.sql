----新用户表
create table dev_xfp.nz_tanguangxu_fst_ord_list as
select
	pin,
	brand_name,
	fst_all_yn,
	parent_sale_ord_id,
	sale_ord_id
from
	(
		select
			pin,
			brand_name,
			sale_ord_id,
			parent_sale_ord_id,
			fst_ord_tm,
			max(case when fst_all_yn = '1' then 1 else 0 end) over(partition by pin, brand_name) as fst_all_yn,
			min(fst_ord_tm) over(partition by pin, brand_name) as min_fst_ord_tm
		from
			(
				select
					unif_user_log_acct pin,
					fst_ord_dt,
					fst_ord_tm,
					fst_all_yn,
					parent_sale_ord_id,
					sale_ord_id,
					case main_brand_cd
						when '154205' then '好丽友（orion）'
						when '10361' then '康师傅'
						when '63503' then '港荣'
						else '亿滋'
					end brand_name
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 1)
					and tp = 'brand'
					and main_brand_cd in('3681', '154205', '8185', '10361', '11237', '14597', '16599', '17315', '18169', '20050', '21649', '22553', '44612', '63503', '145053', '197246')
			)
			x
	)
	x
where
	fst_ord_tm = min_fst_ord_tm
group by
	pin,
	brand_name,
	fst_all_yn,
	parent_sale_ord_id,
	sale_ord_id
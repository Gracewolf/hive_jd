create table dev_xfp.nz_tanguangxu_sku_list as
select
	item_sku_id,
	case brand_code
		when '63503' then barndname_full
		when '10361' then barndname_full
		when '8055' then barndname_full
		else '亿滋'
	end brand_name,
	case data_type
		when '1' then '自营'
		when '3' then 'POP'
	end model		
from
	gdm.gdm_m03_sold_item_sku_da
where
	dt = sysdate( - 1)
	and data_type in('1', '3')
	and item_first_cate_cd = '1320'
	and dept_id_2 = '47'
	and item_second_cate_cd in('1583', '2641')
	and brand_code in('63503', '10361', '8055', '3681', '44612', '14597', '16599', '18169', '8185', '11237', '17315', '21649', '20050', '197246', '22553', '145053')
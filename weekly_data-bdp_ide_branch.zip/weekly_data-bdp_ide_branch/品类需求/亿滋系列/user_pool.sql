create table dev_xfp.nz_tanguangxu_user_pool as
select
	brand_name,
	model,
	substr(sale_ord_dt, 1, 7) yyyy_mm,
	user_log_acct,
	coalesce(b.dim_city_name, '未知') city_name,
	coalesce(b.dim_province_name, '未知') province_name,
	coalesce(b.dim_jxkh_level, '未知') city_level,
	coalesce(region_name, '未知') region
from
	(
		select
			*
		from
			dev_xfp.nz_tanguangxu_ord_list
	)
	a
left join
	(
		select
			city_id,
			dim_city_name,
			dim_province_name,
			dim_jxkh_level
		from
			dim.dim_city_level
	)
	b
on
	a.rev_addr_city_id = b.city_id
left join
	(
		select
			dim_province_name,
			region_name
		from
			dim.dim_province_subd_region
	)
	c
on
	b.dim_province_name = c.dim_province_name
group by
	brand_name,
	model,
	substr(sale_ord_dt, 1, 7),
	user_log_acct,
	coalesce(b.dim_city_name, '未知'),
	coalesce(b.dim_province_name, '未知'),
	coalesce(b.dim_jxkh_level, '未知'),
	coalesce(region_name, '未知');

select
    brand_name,
    model,
    yyyy_mm,
    region,
    count(distinct user_log_acct) cn
from
    dev_xfp.nz_tanguangxu_user_pool
group by
    brand_name,
    model,
    yyyy_mm,
    region
    
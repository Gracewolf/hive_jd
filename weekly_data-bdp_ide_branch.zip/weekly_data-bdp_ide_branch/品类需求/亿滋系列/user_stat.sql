select
	brand_name,
	yyyy_mm,
	sum(1) all_user_num,
	sum(case when fst_flag = 1 then 1 else 0 end) outer_new_num,
	sum(case when fst_flag = 0 then 1 else 0 end) inner_new_num,
	sum(case when fst_flag = -1 then 1 else 0 end) old_user_num,
	sum(case when ord_num >= 2 then 1 else 0 end) re_user_num
from
	(
		select
			a.brand_name,
			substr(a.sale_ord_dt, 1, 7) yyyy_mm,
			a.user_log_acct,
			count(distinct a.parent_sale_ord_id) ord_num,
			max(coalesce(b.fst_all_yn, -1)) fst_flag 
		from
			(
				select * from dev_xfp.nz_tanguangxu_ord_list
			)
			a
		left join
			(
				select * from dev_xfp.nz_tanguangxu_fst_ord_list
			)
			b
		on
			a.user_log_acct = b.pin
			and a.sale_ord_id = b.sale_ord_id
			and a.parent_sale_ord_id = b.parent_sale_ord_id
			and a.brand_name = b.brand_name
		group by
			a.brand_name,
			substr(a.sale_ord_dt, 1, 7),
			a.user_log_acct
	)
	t
group by
	brand_name,
	yyyy_mm
select
	coalesce(t1.device, t2.device) 渠道,
	coalesce(t1.yyyy_mm, t2.yyyy_mm) 日期, 
	coalesce(t1.brand_name, t2.brand_name) 品牌,
	sum(t1.子单数) 子单数,
	sum(t1.gmv) gmv,
	sum(t2.pv) pv,
	sum(t2.uv) uv
from
	(
		select /*+ mapjoin(a)*/
			a.brand_name,
			b.yyyy_mm,
			b.device,
			count(distinct b.sale_ord_id) 子单数,
			sum(b.cw_gmv) gmv
		from
			(
				select * from dev_xfp.nz_tanguangxu_sku_list
			)
			a
		join
			(
				select
					substr(dt, 1, 7) yyyy_mm,
					item_sku_id,
					sale_ord_id,
					cw_gmv,
					case
						when terminal_flag in('12', '22', '42', '62') then 'APP'
						when terminal_flag in('13', '23', '43', '63') then 'M端'
						when terminal_flag in('11', '21', '41', '61') then 'PC'
						when terminal_flag in('33', '31', '30') then '微信'
						when terminal_flag in('32') then '手Q'
						else '未知'
					end device
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					dt >= '2017-01-01'
					and dt <= '2017-12-31'
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		-- where
			-- (
				-- tp = '1'
				-- and substr(ord_flag, 40, 1) <> '1'
			-- ) ----自营剔分销
			-- or
			-- (
				-- tp = '2'
				-- and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
			-- ) ----POP剔赠品
		group by
			b.yyyy_mm,
			b.device,
			a.brand_name
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			b.yyyy_mm,
			b.device,
			a.brand_name,
			sum(b.pv) pv,
			count(distinct b.browser_uniq_id) uv
		from
			(
				select * from dev_xfp.nz_tanguangxu_sku_list
			)
			a
		join
			(
				select
					substr(dt, 1, 7) yyyy_mm,
					sku_id,
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end device,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					dt >= '2017-01-01'
					and dt <= '2017-12-31'
				group by
					sku_id,
					substr(dt, 1, 7),
					browser_uniq_id,
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			b.yyyy_mm,
			b.device,
			a.brand_name
	)
	t2
on
	t1.yyyy_mm = t2.yyyy_mm
	and t1.device = t2.device
	and t1.brand_name = t2.brand_name
group by
	coalesce(t1.device, t2.device),
	coalesce(t1.yyyy_mm, t2.yyyy_mm), 
	coalesce(t1.brand_name, t2.brand_name);

select
	coalesce(t1.device, t2.device) 渠道,
	coalesce(t1.yyyy_mm, t2.yyyy_mm) 日期, 
	coalesce(t1.brand_name, t2.brand_name) 品牌,
	sum(t1.子单数) 子单数,
	sum(t1.gmv) gmv,
	sum(t2.pv) pv,
	sum(t2.uv) uv
from
	(
		select /*+ mapjoin(a)*/
			a.brand_name,
			b.yyyy_mm,
			b.device,
			count(distinct b.sale_ord_id) 子单数,
			sum(b.cw_gmv) gmv
		from
			(
				select * from dev_xfp.nz_tanguangxu_sku_list
			)
			a
		join
			(
				select
					substr(dt, 1, 7) yyyy_mm,
					item_sku_id,
					sale_ord_id,
					cw_gmv,
					case
						when terminal_flag in('12', '22', '42', '62') then 'APP'
						when terminal_flag in('13', '23', '43', '63') then 'M端'
						when terminal_flag in('11', '21', '41', '61') then 'PC'
						when terminal_flag in('33', '31', '30') then '微信'
						when terminal_flag in('32') then '手Q'
						else '未知'
					end device
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					dt >= '2018-01-01'
					and dt <= '2018-06-30'
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		-- where
			-- (
				-- tp = '1'
				-- and substr(ord_flag, 40, 1) <> '1'
			-- ) ----自营剔分销
			-- or
			-- (
				-- tp = '2'
				-- and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
			-- ) ----POP剔赠品
		group by
			b.yyyy_mm,
			b.device,
			a.brand_name
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			b.yyyy_mm,
			b.device,
			a.brand_name,
			sum(b.pv) pv,
			count(distinct b.browser_uniq_id) uv
		from
			(
				select * from dev_xfp.nz_tanguangxu_sku_list
			)
			a
		join
			(
				select
					substr(dt, 1, 7) yyyy_mm,
					sku_id,
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end device,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					dt >= '2018-01-01'
					and dt <= '2018-06-30'
				group by
					sku_id,
					substr(dt, 1, 7),
					browser_uniq_id,
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			b.yyyy_mm,
			b.device,
			a.brand_name
	)
	t2
on
	t1.yyyy_mm = t2.yyyy_mm
	and t1.device = t2.device
	and t1.brand_name = t2.brand_name
group by
	coalesce(t1.device, t2.device),
	coalesce(t1.yyyy_mm, t2.yyyy_mm), 
	coalesce(t1.brand_name, t2.brand_name);

select
	coalesce(t1.device, t2.device) 渠道,
	coalesce(t1.yyyy_mm, t2.yyyy_mm) 日期, 
	coalesce(t1.brand_name, t2.brand_name) 品牌,
	sum(t1.子单数) 子单数,
	sum(t1.gmv) gmv,
	sum(t2.pv) pv,
	sum(t2.uv) uv
from
	(
		select /*+ mapjoin(a)*/
			a.brand_name,
			b.yyyy_mm,
			b.device,
			count(distinct b.sale_ord_id) 子单数,
			sum(b.cw_gmv) gmv
		from
			(
				select * from dev_xfp.nz_tanguangxu_sku_list
			)
			a
		join
			(
				select
					substr(dt, 1, 7) yyyy_mm,
					item_sku_id,
					sale_ord_id,
					cw_gmv,
					case
						when terminal_flag in('12', '22', '42', '62') then 'APP'
						when terminal_flag in('13', '23', '43', '63') then 'M端'
						when terminal_flag in('11', '21', '41', '61') then 'PC'
						when terminal_flag in('33', '31', '30') then '微信'
						when terminal_flag in('32') then '手Q'
						else '未知'
					end device
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					dt >= '2018-07-01'
					and dt <= '2018-12-31'
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		-- where
			-- (
				-- tp = '1'
				-- and substr(ord_flag, 40, 1) <> '1'
			-- ) ----自营剔分销
			-- or
			-- (
				-- tp = '2'
				-- and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
			-- ) ----POP剔赠品
		group by
			b.yyyy_mm,
			b.device,
			a.brand_name
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			b.yyyy_mm,
			b.device,
			a.brand_name,
			sum(b.pv) pv,
			count(distinct b.browser_uniq_id) uv
		from
			(
				select * from dev_xfp.nz_tanguangxu_sku_list
			)
			a
		join
			(
				select
					substr(dt, 1, 7) yyyy_mm,
					sku_id,
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end device,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					dt >= '2018-07-01'
					and dt <= '2018-12-31'
				group by
					sku_id,
					substr(dt, 1, 7),
					browser_uniq_id,
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			b.yyyy_mm,
			b.device,
			a.brand_name
	)
	t2
on
	t1.yyyy_mm = t2.yyyy_mm
	and t1.device = t2.device
	and t1.brand_name = t2.brand_name
group by
	coalesce(t1.device, t2.device),
	coalesce(t1.yyyy_mm, t2.yyyy_mm), 
	coalesce(t1.brand_name, t2.brand_name);

select
	coalesce(t1.device, t2.device) 渠道,
	coalesce(t1.yyyy_mm, t2.yyyy_mm) 日期, 
	coalesce(t1.brand_name, t2.brand_name) 品牌,
	sum(t1.子单数) 子单数,
	sum(t1.gmv) gmv,
	sum(t2.pv) pv,
	sum(t2.uv) uv
from
	(
		select /*+ mapjoin(a)*/
			a.brand_name,
			b.yyyy_mm,
			b.device,
			count(distinct b.sale_ord_id) 子单数,
			sum(b.cw_gmv) gmv
		from
			(
				select * from dev_xfp.nz_tanguangxu_sku_list
			)
			a
		join
			(
				select
					substr(dt, 1, 7) yyyy_mm,
					item_sku_id,
					sale_ord_id,
					cw_gmv,
					case
						when terminal_flag in('12', '22', '42', '62') then 'APP'
						when terminal_flag in('13', '23', '43', '63') then 'M端'
						when terminal_flag in('11', '21', '41', '61') then 'PC'
						when terminal_flag in('33', '31', '30') then '微信'
						when terminal_flag in('32') then '手Q'
						else '未知'
					end device
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					dt >= '2019-01-01'
					and dt <= '2019-09-30'
					and valid_flag = '1'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		-- where
			-- (
				-- tp = '1'
				-- and substr(ord_flag, 40, 1) <> '1'
			-- ) ----自营剔分销
			-- or
			-- (
				-- tp = '2'
				-- and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
			-- ) ----POP剔赠品
		group by
			b.yyyy_mm,
			b.device,
			a.brand_name
	)
	t1
full outer join
	(
		select
			/*+ mapjoin(a)*/
			b.yyyy_mm,
			b.device,
			a.brand_name,
			sum(b.pv) pv,
			count(distinct b.browser_uniq_id) uv
		from
			(
				select * from dev_xfp.nz_tanguangxu_sku_list
			)
			a
		join
			(
				select
					substr(dt, 1, 7) yyyy_mm,
					sku_id,
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end device,
					sum(sku_pv) pv,
					browser_uniq_id
				from
					adm.adm_s14_online_log_smart_item_d
				where
					dt >= '2019-01-01'
					and dt <= '2019-09-30'
				group by
					sku_id,
					substr(dt, 1, 7),
					browser_uniq_id,
					case platform
						when 'PC'
						then 'PC'
						when 'APP'
						then 'APP'
						when 'M'
						then 'M端'
						when 'WX'
						then '微信'
						when 'SQ'
						then '手Q'
						else '未知'
					end
			)
			b
		on
			a.item_sku_id = b.sku_id
		group by
			b.yyyy_mm,
			b.device,
			a.brand_name
	)
	t2
on
	t1.yyyy_mm = t2.yyyy_mm
	and t1.device = t2.device
	and t1.brand_name = t2.brand_name
group by
	coalesce(t1.device, t2.device),
	coalesce(t1.yyyy_mm, t2.yyyy_mm), 
	coalesce(t1.brand_name, t2.brand_name);
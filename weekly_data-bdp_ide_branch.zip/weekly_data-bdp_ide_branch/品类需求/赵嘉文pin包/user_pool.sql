set hive.exec.parallel = true;
create table dev_xfp.nz_zhaojiawen_pin as
select
    coalesce(d.unif_user_log_acct, b.user_log_acct) userpin,
    min(total_score) score
from
    (
        select
            item_sku_id
        from
            gdm.gdm_m03_sold_item_sku_da
        where
            dt = sysdate( - 1)
            and data_type in('1', '3')
            and brand_code in('10373', '99730', '17759', '145403')
    )
    a
join
    (
		select
			b.*
		from
			(
				select
					user_log_acct,
					lower(trim(user_log_acct)) pin,
					item_sku_id,
					check_account_tm,
					sum(after_prefr_amount) over(partition by parent_sale_ord_id) as ord_amount
				from
					gdm.gdm_m04_ord_det_sum
				where
					dt >= sysdate( - 365)
					and sale_ord_dt >= sysdate( - 365)
					and sale_ord_dt <= sysdate( - 1)
					and sale_ord_valid_flag = '1'
					and item_third_cate_cd not in('6980') --剔除礼品卡
					and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
					and
					(
						substr(ord_flag, 31, 1) <> '2' --非行政内采
						or
						(
							substr(ord_flag, 31, 1) = '2'
							and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
						)
					)
					and
					(
						substr(ord_flag, 46, 1) not in('1', '2', '3', '7')
						or substr(ord_flag, 60, 3) not in('013')
					)
					and sale_ord_type_cd <> '68' --剔除拍卖
					and substr(ord_flag, 154, 3) not in('136') --剔除拼团抽奖订单
					and split_status_cd not in('1')  --剔除订单状态为拆分后的父单
					and user_log_acct not like"ept%"
					and user_log_acct not like'*yhd%'
					and user_log_acct not like '%xtl'
			)
			b
		where
			b.ord_amount < 100000
			or
			(
				b.ord_amount >= 100000
				and coalesce(b.check_account_tm, '') <> ''
			)
    )
    b
on
    a.item_sku_id = b.item_sku_id
left join
    (
        select * from dev_xfp.nz_risk_user_pin
    )
    c
on
    b.pin = c.pin
left join
	(
		select
			unif_user_log_acct,
			user_acct_name user_log_acct
		from
			gdm.gdm_m01_userinfo_basic_da
		where
			dt = sysdate( - 1)
	) ----归一化用户pin
	d
on
	b.user_log_acct = d.user_log_acct
left join
    (
        select
            lower(trim(jd_pin)) pin,
            total_score
        from
            app.app_cmo_dmt_jdmem_user_score_simple_da
        where
            dt = sysdate( - 1)
    )
    e
on
    b.pin = e.pin
where
    c.pin is null
group by
    coalesce(d.unif_user_log_acct, b.user_log_acct);

select
    case
        when score >= 20000 then '20000'
        when score >= 10000 then '10000'
        when score >= 5000 then '5000'
        when score > 0 then '0'
        when score = 0 then '00'
        else 'none'
    end lv,
    sum(1)
from
    dev_xfp.nz_zhaojiawen_pin
group by
    case
        when score >= 20000 then '20000'
        when score >= 10000 then '10000'
        when score >= 5000 then '5000'
        when score > 0 then '0'
        when score = 0 then '00'
        else 'none'
    end
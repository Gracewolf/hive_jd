select
    cate_name,
	floor(med_gap) med_gap,
	count(distinct user_log_acct) cn
from
	(
		select
		    cate_name,
			user_log_acct,
			percentile(datediff(next_ord_dt, sale_ord_dt), 0.5) med_gap
		from
			(
				select
				    cate_name,
					user_log_acct,
					sale_ord_dt,
					sum(1) over(partition by user_log_acct, cate_name) as ord_times,
					lead(sale_ord_dt) over(partition by user_log_acct, cate_name order by sale_ord_dt) as next_ord_dt
				from
					(
						select
							*
						from
							dev_xfp.nz_user_ord_coffey_cate
						where
							sale_ord_dt <= '2020-03-25'
					)
					a
			)
			a
		where
			ord_times >= 3
			and next_ord_dt is not null
		group by
		    cate_name,
			user_log_acct
	)
	a
group by
    cate_name,
	floor(med_gap);
create table dev_xfp.nz_lifecycle_coffey as
-- 成熟用户购买次数 7
-- 流失用户天数 398
select
	sysdate( - 1) dt,
	t1.user_log_acct,
	t1.ghsp_days221_ord_cnt,
	round(t1.ghsp_days221_gmv, 2) ghsp_days221_gmv,
	t1.ghsp_days_all_ord_cnt,
	round(t1.ghsp_days_all_gmv, 2) ghsp_days_all_gmv,
	t1.ghsp_first_ord_days,
	t1.ghsp_last_ord_days,
	t1.ghsp_pre_days221_ord_cnt,
	t1.days_all_ord_cnt,
	round(t1.days_all_gmv, 2) days_all_gmv,
	(
		case
			when t1.ghsp_days_all_ord_cnt > 0
				and t1.ghsp_first_ord_days < 399
				and t1.ghsp_days221_ord_cnt = 1
			then 1 --引入期
			when t1.ghsp_days_all_ord_cnt > 0
				and t1.ghsp_days221_ord_cnt < 7
				and t1.ghsp_days221_ord_cnt > 0
				and t1.ghsp_days221_ord_cnt >= t1.ghsp_pre_days221_ord_cnt
			then 2 --成长期
			when t1.ghsp_days_all_ord_cnt > 0
				and t1.ghsp_days221_ord_cnt >= 7
			then 3 --成熟期
			when t1.ghsp_days_all_ord_cnt > 0
				and t1.ghsp_days221_ord_cnt < 7
				and t1.ghsp_days221_ord_cnt > 0
				and t1.ghsp_days221_ord_cnt < t1.ghsp_pre_days221_ord_cnt
			then 4 --衰退期
			when t1.ghsp_days_all_ord_cnt > 0
				and t1.ghsp_last_ord_days >= 399
			then 5 --流失期
			when t1.ghsp_days_all_ord_cnt = 0
				and t1.days_all_ord_cnt = 1
			then 6 --低潜力
			when t1.ghsp_days_all_ord_cnt = 0
				and t1.days_all_ord_cnt > 1
			then 7 --高潜力
		end) as life_cycle
from
	(
		select
			user_log_acct,
			count(distinct case when b.item_third_cate_cd in('15053', '3986')
							and sale_ord_dt > sysdate( - 399)
						then parent_sale_ord_id
					end) as ghsp_days221_ord_cnt, ----最近一个周期的下单数
			sum(
				case
					when b.item_third_cate_cd in('15053', '3986')
						and sale_ord_dt > sysdate( - 399)
					then cw_gmv
					else 0.0
				end) as ghsp_days221_gmv, ----最近一个周期的gmv
			count(distinct
			case
				when b.item_third_cate_cd in('15053', '3986')
				then parent_sale_ord_id
			end) as ghsp_days_all_ord_cnt, ----部门内订单数
			sum(
				case
					when b.item_third_cate_cd in('15053', '3986')
					then cw_gmv
					else 0.0
				end) as ghsp_days_all_gmv, ----部门内gmv
			count(distinct
			case
				when b.item_third_cate_cd in('15053', '3986')
					and sale_ord_dt >= sysdate( - 796)
					and sale_ord_dt <= sysdate( - 399)
				then parent_sale_ord_id
			end) as ghsp_pre_days221_ord_cnt, ----上一个周期下单数
			count(distinct parent_sale_ord_id) as days_all_ord_cnt, ----全站累计订单数
			sum(cw_gmv) as days_all_gmv, ----全站gmv
			(
				case
					when min(
							case
								when b.item_third_cate_cd in('15053', '3986')
								then sale_ord_dt
							end) is not null
					then datediff(sysdate(0), min(
							case
								when b.item_third_cate_cd in('15053', '3986')
								then sale_ord_dt
							end))
					else null
				end) as ghsp_first_ord_days, ----干货食品首单距今天数
			(
				case
					when max(
							case
								when b.item_third_cate_cd in('15053', '3986')
								then sale_ord_dt
							end) is not null
					then datediff(sysdate(0), max(
							case
								when b.item_third_cate_cd in('15053', '3986')
								then sale_ord_dt
							end))
					else null
				end) as ghsp_last_ord_days ----干货食品最近订单距今天数
		from
			(
				select
					*
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					dt >= '2017-01-01'
					and dt <= sysdate( - 1)
					and sale_ord_dt >= '2017-01-01'
					and sale_ord_dt <= sysdate( - 1)
					and valid_flag = '1'
			)
			a
		join
			(
				select
					*
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and dept_id_1 = '33'
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		group by
			user_log_acct
	)
	t1;

select
	life_cycle,
	case
		when life_cycle = 1
		then '引入期'
		when life_cycle = 2
		then '成长期'
		when life_cycle = 3
		then '成熟期'
		when life_cycle = 4
		then '衰退期'
		when life_cycle = 5
		then '流失期'
		when life_cycle = 6
		then '低潜力'
		when life_cycle = 7
		then '高潜力'
	end as dist,
	count( *) cn
from
	dev_xfp.nz_lifecycle_coffey
group by
	life_cycle,
	case
		when life_cycle = 1
		then '引入期'
		when life_cycle = 2
		then '成长期'
		when life_cycle = 3
		then '成熟期'
		when life_cycle = 4
		then '衰退期'
		when life_cycle = 5
		then '流失期'
		when life_cycle = 6
		then '低潜力'
		when life_cycle = 7
		then '高潜力'
	end;
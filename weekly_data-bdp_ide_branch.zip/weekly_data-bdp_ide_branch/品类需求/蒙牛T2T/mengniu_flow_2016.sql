----蒙牛流量
create table dev_xfp.nz_mn_flow_2016 as
----16年流量
select /*+mapjoin(a)*/
    yyyy_mm,
    model,
    item_second_cate_name,
    item_third_cate_name,
	sum(pv) pv,
	count(distinct browser_uniq_id) uv
from
	(
		select
			item_sku_id,
			item_second_cate_name,
			item_third_cate_name,
			case data_type
				when '1' then '自营'
				when '3' then 'POP'
			end model
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and item_first_cate_cd = '1320'
			and brand_code = '12690'
	)
	a
join
	(
		select
		    substr(dt, 1, 7) yyyy_mm,
			sku_id,
			browser_uniq_id,
			sum(sku_pv) pv
		from
			adm.adm_s14_online_log_smart_item_d
		where
			dt >= '2016-01-01'
			and dt < '2017-01-01'
			and brand_code = '19306'
			and item_third_cate_id in('9434', '12201')
		group by
		    substr(dt, 1, 7),
			sku_id,
			browser_uniq_id
	)
	b
on
	a.item_sku_id = b.sku_id
group by
    yyyy_mm,
    model,
    item_second_cate_name,
    item_third_cate_name;
	
insert into dev_xfp.nz_mn_flow_2016
select /*+mapjoin(a)*/
    yyyy_mm,
    model,
    item_second_cate_name,
    item_third_cate_name,
	sum(pv) pv,
	count(distinct browser_uniq_id) uv
from
	(
		select
			item_sku_id,
			item_second_cate_name,
			item_third_cate_name,
			case data_type
				when '1' then '自营'
				when '3' then 'POP'
			end model
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and item_first_cate_cd = '1320'
			and brand_code = '12690'
	)
	a
join
	(
		select
		    substr(dt, 1, 7) yyyy_mm,
			sku_id,
			browser_uniq_id,
			sum(sku_pv) pv
		from
			adm.adm_s14_online_log_smart_item_d
		where
			dt >= '2017-01-01'
			and dt < '2017-07-01'
			and brand_code = '19306'
			and item_third_cate_id in('9434', '12201')
		group by
		    substr(dt, 1, 7),
			sku_id,
			browser_uniq_id
	)
	b
on
	a.item_sku_id = b.sku_id
group by
    yyyy_mm,
    model,
    item_second_cate_name,
    item_third_cate_name;

insert into dev_xfp.nz_mn_flow_2016
select /*+mapjoin(a)*/
    yyyy_mm,
    model,
    item_second_cate_name,
    item_third_cate_name,
	sum(pv) pv,
	count(distinct browser_uniq_id) uv
from
	(
		select
			item_sku_id,
			item_second_cate_name,
			item_third_cate_name,
			case data_type
				when '1' then '自营'
				when '3' then 'POP'
			end model
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and item_first_cate_cd = '1320'
			and brand_code = '12690'
	)
	a
join
	(
		select
		    substr(dt, 1, 7) yyyy_mm,
			sku_id,
			browser_uniq_id,
			sum(sku_pv) pv
		from
			adm.adm_s14_online_log_smart_item_d
		where
			dt >= '2017-07-01'
			and dt < '2018-01-01'
			and brand_code = '19306'
			and item_third_cate_id in('9434', '12201')
		group by
		    substr(dt, 1, 7),
			sku_id,
			browser_uniq_id
	)
	b
on
	a.item_sku_id = b.sku_id
group by
    yyyy_mm,
    model,
    item_second_cate_name,
    item_third_cate_name;

insert into dev_xfp.nz_mn_flow_2016
select /*+mapjoin(a)*/
    yyyy_mm,
    model,
    item_second_cate_name,
    item_third_cate_name,
	sum(pv) pv,
	count(distinct browser_uniq_id) uv
from
	(
		select
			item_sku_id,
			item_second_cate_name,
			item_third_cate_name,
			case data_type
				when '1' then '自营'
				when '3' then 'POP'
			end model
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and item_first_cate_cd = '1320'
			and brand_code = '12690'
	)
	a
join
	(
		select
		    substr(dt, 1, 7) yyyy_mm,
			sku_id,
			browser_uniq_id,
			sum(sku_pv) pv
		from
			adm.adm_s14_online_log_smart_item_d
		where
			dt >= '2018-01-01'
			and dt < '2018-05-01'
			and brand_code = '19306'
			and item_third_cate_id in('9434', '12201')
		group by
		    substr(dt, 1, 7),
			sku_id,
			browser_uniq_id
	)
	b
on
	a.item_sku_id = b.sku_id
group by
    yyyy_mm,
    model,
    item_second_cate_name,
    item_third_cate_name;

insert into dev_xfp.nz_mn_flow_2016
select /*+mapjoin(a)*/
    yyyy_mm,
    model,
    item_second_cate_name,
    item_third_cate_name,
	sum(pv) pv,
	count(distinct browser_uniq_id) uv
from
	(
		select
			item_sku_id,
			item_second_cate_name,
			item_third_cate_name,
			case data_type
				when '1' then '自营'
				when '3' then 'POP'
			end model
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and item_first_cate_cd = '1320'
			and brand_code = '12690'
	)
	a
join
	(
		select
		    substr(dt, 1, 7) yyyy_mm,
			sku_id,
			browser_uniq_id,
			sum(sku_pv) pv
		from
			adm.adm_s14_online_log_smart_item_d
		where
			dt >= '2018-05-01'
			and dt < '2018-09-01'
			and brand_code = '19306'
			and item_third_cate_id in('9434', '12201')
		group by
		    substr(dt, 1, 7),
			sku_id,
			browser_uniq_id
	)
	b
on
	a.item_sku_id = b.sku_id
group by
    yyyy_mm,
    model,
    item_second_cate_name,
    item_third_cate_name;

insert into dev_xfp.nz_mn_flow_2016
select /*+mapjoin(a)*/
    yyyy_mm,
    model,
    item_second_cate_name,
    item_third_cate_name,
	sum(pv) pv,
	count(distinct browser_uniq_id) uv
from
	(
		select
			item_sku_id,
			item_second_cate_name,
			item_third_cate_name,
			case data_type
				when '1' then '自营'
				when '3' then 'POP'
			end model
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and item_first_cate_cd = '1320'
			and brand_code = '12690'
	)
	a
join
	(
		select
		    substr(dt, 1, 7) yyyy_mm,
			sku_id,
			browser_uniq_id,
			sum(sku_pv) pv
		from
			adm.adm_s14_online_log_smart_item_d
		where
			dt >= '2018-09-01'
			and dt < '2019-01-01'
			and brand_code = '19306'
			and item_third_cate_id in('9434', '12201')
		group by
		    substr(dt, 1, 7),
			sku_id,
			browser_uniq_id
	)
	b
on
	a.item_sku_id = b.sku_id
group by
    yyyy_mm,
    model,
    item_second_cate_name,
    item_third_cate_name;

insert into dev_xfp.nz_mn_flow_2016
select /*+mapjoin(a)*/
    yyyy_mm,
    model,
    item_second_cate_name,
    item_third_cate_name,
	sum(pv) pv,
	count(distinct browser_uniq_id) uv
from
	(
		select
			item_sku_id,
			item_second_cate_name,
			item_third_cate_name,
			case data_type
				when '1' then '自营'
				when '3' then 'POP'
			end model
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and item_first_cate_cd = '1320'
			and brand_code = '12690'
	)
	a
join
	(
		select
		    substr(dt, 1, 7) yyyy_mm,
			sku_id,
			browser_uniq_id,
			sum(sku_pv) pv
		from
			adm.adm_s14_online_log_smart_item_d
		where
			dt >= '2019-01-01'
			and dt < '2019-04-01'
			and brand_code = '19306'
			and item_third_cate_id in('9434', '12201')
		group by
		    substr(dt, 1, 7),
			sku_id,
			browser_uniq_id
	)
	b
on
	a.item_sku_id = b.sku_id
group by
    yyyy_mm,
    model,
    item_second_cate_name,
    item_third_cate_name;


insert into dev_xfp.nz_mn_flow_2016
select /*+mapjoin(a)*/
    yyyy_mm,
    model,
    item_second_cate_name,
    item_third_cate_name,
	sum(pv) pv,
	count(distinct browser_uniq_id) uv
from
	(
		select
			item_sku_id,
			item_second_cate_name,
			item_third_cate_name,
			case data_type
				when '1' then '自营'
				when '3' then 'POP'
			end model
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and item_first_cate_cd = '1320'
			and brand_code = '12690'
	)
	a
join
	(
		select
		    substr(dt, 1, 7) yyyy_mm,
			sku_id,
			browser_uniq_id,
			sum(sku_pv) pv
		from
			adm.adm_s14_online_log_smart_item_d
		where
			dt >= '2019-04-01'
			and dt < '2019-07-01'
			and brand_code = '19306'
			and item_third_cate_id in('9434', '12201')
		group by
		    substr(dt, 1, 7),
			sku_id,
			browser_uniq_id
	)
	b
on
	a.item_sku_id = b.sku_id
group by
    yyyy_mm,
    model,
    item_second_cate_name,
    item_third_cate_name;


insert into dev_xfp.nz_mn_flow_2016
select /*+mapjoin(a)*/
    yyyy_mm,
    model,
    item_second_cate_name,
    item_third_cate_name,
	sum(pv) pv,
	count(distinct browser_uniq_id) uv
from
	(
		select
			item_sku_id,
			item_second_cate_name,
			item_third_cate_name,
			case data_type
				when '1' then '自营'
				when '3' then 'POP'
			end model
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and item_first_cate_cd = '1320'
			and brand_code = '12690'
	)
	a
join
	(
		select
		    substr(dt, 1, 7) yyyy_mm,
			sku_id,
			browser_uniq_id,
			sum(sku_pv) pv
		from
			adm.adm_s14_online_log_smart_item_d
		where
			dt >= '2019-07-01'
			and dt <= sysdate( - 1)
			and brand_code = '19306'
			and item_third_cate_id in('9434', '12201')
		group by
		    substr(dt, 1, 7),
			sku_id,
			browser_uniq_id
	)
	b
on
	a.item_sku_id = b.sku_id
group by
    yyyy_mm,
    model,
    item_second_cate_name,
    item_third_cate_name;
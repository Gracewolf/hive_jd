select
	b.year_dt,
	count(distinct b.user_log_acct) 整体用户数,
	count(distinct case when fst_all_yn = 1 then b.user_log_acct end) 站内新用户数,
	count(distinct case when fst_all_yn = 0 then b.user_log_acct end) 站外新用户数
from
	(
		select
			user_log_acct,
			year(sale_ord_dt) year_dt
		from
			dev_xfp.nz_mn_valid_ord_pool
	)
	b
left join
	(
		select
			x.user_log_acct,
			x.fst_all_yn,
			year(x.fst_ord_dt) year_dt
		from
			(
				select
					unif_user_log_acct user_log_acct,
					max(
						case
							when fst_all_yn = 1
							then 1
							else 0
						end) fst_all_yn,
					min(fst_ord_dt) fst_ord_dt
				from
					app.v_adm_s01_user_new_or_old_flag_detail_xfp
				where
					dt = sysdate( - 1)
					and tp = 'brand'
					and item_first_cate_cd = '1320'
					and main_brand_cd = '131496'
				group by
					unif_user_log_acct
			)
			x
		where
			fst_ord_dt >= '2014-01-01'
	)
	c
on
	b.user_log_acct = c.user_log_acct
	and b.year_dt = c.year_dt
group by
	b.year_dt
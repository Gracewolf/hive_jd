--蒙牛销售
select
	year_dt,
	model,
	item_second_cate_name,
	item_third_cate_name,
	sum(gmv) GMV,
	count(distinct sale_ord_id) ord_num
from
	(
		select
			item_sku_id,
			item_second_cate_name,
			item_third_cate_name,
			case data_type
				when '1' then '自营'
				when '3' then 'POP'
			end model
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and item_first_cate_cd = '1320'
			and brand_code = '12690'
	)
	a
join
	(
		select
			item_sku_id,
		    sale_ord_id,
			year(dt) year_dt,
			sum(cw_gmv) gmv
		from
			app.v_app_cmo_cw_ord_det_sum_rb
		where
			dt >= '2014-01-01'
			and dt <= '2019-09-30'
			and valid_flag = '1'
		group by
			item_sku_id,
		    sale_ord_id,
			year(dt)
	)
	b
on
	a.item_sku_id = b.item_sku_id
group by
	year_dt,
	model,
	item_second_cate_name,
	item_third_cate_name
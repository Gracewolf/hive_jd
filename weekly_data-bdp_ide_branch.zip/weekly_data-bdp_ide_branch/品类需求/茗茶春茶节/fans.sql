set hive.exec.parallel = true;
select
	累计粉丝数,
	本周末粉丝数,
	上周末粉丝数,
	新增粉丝数,
	t2.*
from
	(
		select
			shop_id 店铺id,
			count(distinct case when end_date > '2019-03-28' then pin end) 累计粉丝数, ----本周周期开始
			count(distinct case when end_date > '2019-04-30' then pin end) 本周末粉丝数, ----本周周期结束
			count(distinct case when start_date <= '2019-03-27' then pin end) 上周末粉丝数, ----本周周期开始前一天
			count(distinct case when start_date >= '2019-03-28' then pin end) 新增粉丝数 ----本周周期开始
		from
			fdm.fdm_follow_vender_sns_follow_vender_chain ----粉丝拉链表
		where
			start_date <= '2019-04-30'
			and end_date > '2019-03-27'
			and shop_id in('1000011883', '12697', '1000225164', '691148', '1000093452', '11566', '1000015041', '10377', '1000011484', '620056', '1000072243', '16798', '1000083269', '34836', '1000083641', '179151', '1000092862', '57552', '27768')
		group by
			shop_id
	)
	t1
join
	(
		select
			b.shop_id 店铺id,
			b.shop_name 店铺名,
			count(distinct a.user_log_acct) 有效用户数,
			count(distinct a.sale_ord_id) 有效子单数,
			sum(after_prefr_amount) 优惠后金额,
			count(distinct case when 
			c.start_date <= a.sale_ord_dt
			and c.end_date > a.sale_ord_dt then c.pin end) 粉丝用户数,
			count(distinct case when 
			c.start_date <= a.sale_ord_dt
			and c.end_date > a.sale_ord_dt then a.sale_ord_id end) 粉丝有效子单数,
			sum(case when 
			c.start_date <= a.sale_ord_dt
			and c.end_date > a.sale_ord_dt then a.after_prefr_amount end) 粉丝优惠后金额
		from
			(
				select
					x.user_log_acct,
					x.item_sku_id,
					x.sale_ord_id,
					x.after_prefr_amount_1 after_prefr_amount,
					sale_ord_dt
				from
					gdm.gdm_m04_ord_det_sum x
				where
					dt >= '2019-03-28'
					and sale_ord_dt >= '2019-03-28'
					and sale_ord_dt <= '2019-04-30'
					and sale_ord_valid_flag = '1'
					and substr(ord_flag, 18, 1) not in('1', '2') --剔除售后
					and
					(
						substr(ord_flag, 31, 1) <> '2' --非行政内采
						or
						(
							substr(ord_flag, 31, 1) = '2'
							and user_log_acct in('网银在线专号', '网银在线专号1', '网银在线专号2', '网银在线专号3', 'jd-finance-xzcg', 'jd-finance')
						)
					)
					and
					(
						substring(ord_flag, 46, 1) not in('1', '2', '3', '7')
						or substring(ord_flag, 60, 3) not in('013')
					)
					and sale_ord_type_cd <> '68' --剔除拍卖
					and split_status_cd not in('1') --剔除订单状态为拆分后的父单
			)
			a
		join
			(
				select
					item_sku_id,
					shop_id,
					shop_name
				from
					gdm.gdm_m03_sold_item_sku_da
				where
					dt = sysdate( - 1)
					and data_type in('1', '3')
					and shop_id in('1000011883', '12697', '1000225164', '691148', '1000093452', '11566', '1000015041', '10377', '1000011484', '620056', '1000072243', '16798', '1000083269', '34836', '1000083641', '179151', '1000092862', '57552', '27768') ----自营旗舰店
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		left join
			(
				select
					shop_id,
					pin,
					start_date,
					end_date
				from
					fdm.fdm_follow_vender_sns_follow_vender_chain ----粉丝拉链表
				where
					start_date <= '2019-04-30'
					and end_date > '2019-03-27'
					and shop_id in('1000011883', '12697', '1000225164', '691148', '1000093452', '11566', '1000015041', '10377', '1000011484', '620056', '1000072243', '16798', '1000083269', '34836', '1000083641', '179151', '1000092862', '57552', '27768') 
			)
			c
		on
			c.pin = a.user_log_acct
			and c.shop_id = b.shop_id
		group by
			b.shop_id,
			b.shop_name
	)
	t2
on
	t1.店铺id = t2.店铺id
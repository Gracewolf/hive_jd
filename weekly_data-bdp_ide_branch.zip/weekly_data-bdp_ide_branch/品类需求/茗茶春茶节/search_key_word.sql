select
	*
from
	(
		select
			m.*,
			row_number() over(partition by 一级类目id, 一级类目, 二级类目id, 二级类目 order by 搜索次数 desc) as 排名
		from
			(
				select
					一级类目id,
					一级类目,
					二级类目id,
					二级类目,
					regexp_replace(regexp_replace(trim(key_word), '"', ''), ',', '，') 关键词,
					sum(搜索次数) 搜索次数,
					sum(搜索结果页点击量) 搜索结果页点击量,
					sum(访客数) 访客数,
					sum(搜索结果页商品点击量) 搜索结果页商品点击量,
					sum(引入订单用户数) 引入订单用户数,
					sum(有效引入订单用户数) 有效引入订单用户数,
					sum(父单量) 父单量,
					sum(有效子单量) 有效子单量,
					sum(优惠后金额) 优惠后金额
				from
					(
						select
							dt,
							dim_item_gen_first_cate_id 一级类目id,
							dim_item_gen_first_cate_name 一级类目,
							dim_item_gen_second_cate_id 二级类目id,
							dim_item_gen_second_cate_name 二级类目,
							key_word,
							search_times 搜索次数,
							click_num 搜索结果页点击量,
							uv 访客数,
							click_num_sku 搜索结果页商品点击量,
							user_num_cate 引入订单用户数,
							valid_user_num_cate 有效引入订单用户数,
							par_ord_num_cate 父单量,
							ord_num_cate 子单量,
							valid_ord_num_cate 有效子单量,
							gmv_cate 优惠后金额
						from
							(
								select
									*
								from
									app.v_adm_m14_key_word_sum_d LATERAL VIEW explode(split(high_value, ',')) adTable as high_value_third_cate
								where
								    dt >= '2019-03-04'
								    and dt <= '2019-03-10'
							)
							a
						join
							(
								select
									dim_item_gen_first_cate_name,
									dim_item_gen_first_cate_id,
									dim_item_gen_second_cate_id,
									dim_item_gen_second_cate_name,
									dim_item_gen_third_cate_id,
									dim_item_gen_third_cate_name
									
								from
									dim.dim_item_gen_third_cate_orc
								where
									valid_flag = '1'
									and dim_item_gen_first_cate_id in('1320')
									and dim_item_gen_second_cate_id in('12202')
							)
							b
						on
							a.high_value_third_cate = b.dim_item_gen_third_cate_id
						group by
							dt,
							dim_item_gen_first_cate_id,
							dim_item_gen_first_cate_name,
							dim_item_gen_second_cate_id,
							dim_item_gen_second_cate_name,
							key_word,
							search_times,
							click_num,
							uv,
							click_num_sku,
							user_num_cate,
							valid_user_num_cate,
							par_ord_num_cate,
							ord_num_cate,
							valid_ord_num_cate,
							gmv_cate
					)
					c
				group by
					一级类目id,
					一级类目,
					二级类目id,
					二级类目,
					regexp_replace(regexp_replace(trim(key_word), '"', ''), ',', '，')
			)
			m
	)
	tt
where
	排名 <= 200
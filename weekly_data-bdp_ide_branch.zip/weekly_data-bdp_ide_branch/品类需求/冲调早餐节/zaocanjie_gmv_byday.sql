select
	dt 日期,
	item_second_cate_name 二级类目,
	item_third_cate_name 三级类目,
	count(distinct parent_sale_ord_id) 父单数,
	count(distinct sale_ord_id) 子单数,
	sum(cw_gmv) gmv,
	count(distinct case when z.pin is not null then parent_sale_ord_id end) 家庭号父单数,
	count(distinct case when z.pin is not null then sale_ord_id end) 家庭号子单数,
	sum(case when z.pin is not null then cw_gmv end) 家庭号gmv
from
	(
		select
			item_sku_id,
			item_second_cate_name,
			item_third_cate_name
		from
			gdm.gdm_m03_sold_item_sku_da
		where
			dt = sysdate( - 1)
			and data_type in('1', '3')
			and dept_id_2 in('47', '1699')
			and item_first_cate_cd = '1320'
			and item_third_cate_cd in('1601', '3986', '5023', '15053')
	)
	a
join
	(
		select
			item_sku_id,
			cw_gmv,
			parent_sale_ord_id,
			sale_ord_id,
			lower(trim(user_log_acct)) pin,
			dt
		from
			app.v_app_cmo_cw_ord_det_sum_rb
		where
			dt >= '2020-03-01'
			and dt <= '2020-03-24'
			and valid_flag = '1'
	)
	b
on
	a.item_sku_id = b.item_sku_id
left join
	(
		select
			lower(trim(user_log_acct)) pin
		from
			gdm.gdm_m01_userinfo_basic_sum
		where
		    dt = sysdate( - 1)
			and substr(seco_school, 66, 1) = 1
	)
	z
on
	b.pin = z.pin
group by
	dt,
	item_second_cate_name,
	item_third_cate_name
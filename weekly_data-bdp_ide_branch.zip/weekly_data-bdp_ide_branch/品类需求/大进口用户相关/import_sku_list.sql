set hive.exec.parallel = true;
drop table if exists dev_xfp.nz_import_sku_list;
create table dev_xfp.nz_import_sku_list as
select
	item_sku_id,
	item_first_cate_name,
	item_second_cate_name,
	item_third_cate_name,
	brand_code,
	barndname_full
from
	app.app_cmo_sku_global_da
where
	dt = sysdate( - 1)
	and item_first_cate_cd = '1320'
	and item_second_cate_cd <> '5019'
	and dept_id_2 in('47', '1699')

union all

select
	item_sku_id,
	item_first_cate_name,
	item_second_cate_name,
	item_third_cate_name,
	brand_code,
	barndname_full
from
	gdm.gdm_m03_sold_item_sku_da
where
	dt = sysdate( - 1)
	and data_type in('1', '3')
	and item_first_cate_cd = '1320'
	and item_second_cate_cd = '5019'
	and dept_id_2 in('47', '1699')
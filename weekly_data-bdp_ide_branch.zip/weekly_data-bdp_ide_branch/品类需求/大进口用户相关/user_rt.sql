set hive.exec.parallel=true; 
set hive.exec.parallel.thread.number=16; 
--合并小文件
set hive.merge.mapfiles = true;  
set hive.merge.mapredfiles = true;  
set hive.merge.size.per.task=64000000;
set hive.merge.smallfiles.avgsize = 256000000; 
--Map阶段优化
set mapred.max.split.size=256000000; 
set mapred.min.split.size.per.node=256000000; 
set mapred.min.split.size.per.rack=256000000;  
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set hive.join.emit.interval = 2000;
set hive.mapjoin.size.key = 20000;
set hive.mapjoin.cache.numrows = 20000;
--Reduce阶段优化
set hive.exec.reducers.bytes.per.reducer=2000000000;
set hive.exec.reducers.max=999;
--数据倾斜
set hive.map.aggr=true;
set hive.groupby.mapaggr.checkinterval=100000;
set hive.auto.convert.join = true;
select
    b.year_dt,
    count(distinct user_log_acct) cn,
    sum(rt) rt
from
    (
        select
            sku_id,
            case dt
                when '2017-07' then 2017
                when '2018-07' then 2018
                when '2019-07' then 2019
            end year_dt,
            user_log_acct,
            sum(sku_rt) rt
        from
            adm.adm_s14_online_log_smart_item_m
        where
            dt = '2017-07'
            or dt = '2018-07'
            or dt = '2019-07'
        group by
            sku_id,
            case dt
                when '2017-07' then 2017
                when '2018-07' then 2018
                when '2019-07' then 2019
            end,
            user_log_acct
    )
    b
left semi join
    (
        select * from dev_xfp.nz_import_sku_list
    )
    a
on
    a.item_sku_id = b.sku_id
left semi join
    (
        select
            user_log_acct,
            year_dt
        from
            dev_xfp.nz_import_user_pool
        group by
            user_log_acct,
            year_dt
    )
    c
on
    b.user_log_acct = c.user_log_acct
    and b.year_dt = c.year_dt
group by
    b.year_dt
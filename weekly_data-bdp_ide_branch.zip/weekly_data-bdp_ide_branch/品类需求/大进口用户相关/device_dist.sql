select
	b.year_dt,
	device,
	sum(cw_gmv) GMV,
	count(distinct b.user_log_acct) cn
from
	(
        select * from dev_xfp.nz_import_sku_list
	)
	a
join
	(
		select
			year(dt) year_dt,
			item_sku_id,
			user_log_acct,
			case
				when terminal_flag in('12', '22', '42', '62') then 'APP'
				when terminal_flag in('13', '23', '43', '63') then 'M端'
				when terminal_flag in('11', '21', '41', '61') then 'PC'
				when terminal_flag in('33', '31', '30', '32') then '微信手Q'
				else '未知'
			end device,
			cw_gmv
		from
			app.v_app_cmo_cw_ord_det_sum_rb
		where
			(
				(
					dt >= '2017-01-01'
					and dt <= '2017-09-30'
				)
				or
				(
					dt >= '2018-01-01'
					and dt <= '2018-09-30'
				)
				or
				(
					dt >= '2019-01-01'
					and dt <= '2019-09-30'
				)
			)
			and valid_flag = '1'
			and
			(
				(
					tp = '1'
					and substr(ord_flag, 40, 1) <> '1'
				) ----自营剔分销
				or
				(
					tp = '2'
					and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
				) ----POP剔赠品
			)
	)
	b
on
    a.item_sku_id = b.item_sku_id
join
    (
        select
            user_log_acct,
            year_dt
        from
            dev_xfp.nz_import_user_pool
        group by
            user_log_acct,
            year_dt
    )
    c
on
    b.user_log_acct = c.user_log_acct
    and b.year_dt = c.year_dt
group by
	b.year_dt,
	device
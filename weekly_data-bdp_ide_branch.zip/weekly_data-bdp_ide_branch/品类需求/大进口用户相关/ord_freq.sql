select
	year_dt,
	GMV,
	cn,
	ord_num / cn ord_freq
from
	(
		select
			b.year_dt,
			sum(cw_gmv) GMV,
			count(distinct parent_sale_ord_id) ord_num,
			count(distinct b.user_log_acct) cn
		from
			(
				select * from dev_xfp.nz_import_sku_list
			)
			a
		join
			(
				select
					year(dt) year_dt,
					user_log_acct,
					item_sku_id,
					parent_sale_ord_id,
					cw_gmv
				from
					app.app_cmo_cw_ord_det_sum
				where
					(
						(
							dt >= '2017-01-01'
							and dt <= '2017-09-30'
						)
						or
						(
							dt >= '2018-01-01'
							and dt <= '2018-09-30'
						)
						or
						(
							dt >= '2019-01-01'
							and dt <= '2019-09-30'
						)
					)
					and valid_flag = '1'
					and
					(
						(
							tp = '1'
							and substr(ord_flag, 40, 1) <> '1'
						) ----自营剔分销
						or
						(
							tp = '2'
							and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
						) ----POP剔赠品
					)
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		join
			(
				select
					user_log_acct,
					year_dt
				from
					dev_xfp.nz_import_user_pool
				group by
					user_log_acct,
					year_dt
			)
			c
		on
			b.user_log_acct = c.user_log_acct
			and b.year_dt = c.year_dt
		group by
			b.year_dt
	)
	tt

select
	year_dt,
	city_level,
	GMV,
	cn,
	ord_num / cn ord_freq
from
	(
		select
			b.year_dt,
			city_level,
			sum(cw_gmv) GMV,
			count(distinct parent_sale_ord_id) ord_num,
			count(distinct b.user_log_acct) cn
		from
			(
				select * from dev_xfp.nz_import_sku_list
			)
			a
		join
			(
				select
					year(dt) year_dt,
					user_log_acct,
					item_sku_id,
					parent_sale_ord_id,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2017-01-01'
							and dt <= '2017-09-30'
						)
						or
						(
							dt >= '2018-01-01'
							and dt <= '2018-09-30'
						)
						or
						(
							dt >= '2019-01-01'
							and dt <= '2019-09-30'
						)
					)
					and valid_flag = '1'
					and
					(
						(
							tp = '1'
							and substr(ord_flag, 40, 1) <> '1'
						) ----自营剔分销
						or
						(
							tp = '2'
							and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
						) ----POP剔赠品
					)
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		join
			(
				select
					user_log_acct,
					city_level,
					year_dt
				from
					dev_xfp.nz_import_user_pool
				group by
					user_log_acct,
					city_level,
					year_dt
			)
			c
		on
			b.user_log_acct = c.user_log_acct
			and b.year_dt = c.year_dt
		group by
			b.year_dt,
			city_level
	)
	tt;

select
	year_dt,
	province_name,
	GMV,
	cn,
	ord_num / cn ord_freq
from
	(
		select
			b.year_dt,
			province_name,
			sum(cw_gmv) GMV,
			count(distinct parent_sale_ord_id) ord_num,
			count(distinct b.user_log_acct) cn
		from
			(
				select * from dev_xfp.nz_import_sku_list
			)
			a
		join
			(
				select
					year(dt) year_dt,
					user_log_acct,
					item_sku_id,
					parent_sale_ord_id,
					cw_gmv
				from
					app.v_app_cmo_cw_ord_det_sum_rb
				where
					(
						(
							dt >= '2017-01-01'
							and dt <= '2017-09-30'
						)
						or
						(
							dt >= '2018-01-01'
							and dt <= '2018-09-30'
						)
						or
						(
							dt >= '2019-01-01'
							and dt <= '2019-09-30'
						)
					)
					and valid_flag = '1'
					and
					(
						(
							tp = '1'
							and substr(ord_flag, 40, 1) <> '1'
						) ----自营剔分销
						or
						(
							tp = '2'
							and (item_second_cate_cd <> '4980' or item_third_cate_cd <> '4992')
						) ----POP剔赠品
					)
			)
			b
		on
			a.item_sku_id = b.item_sku_id
		join
			(
				select
					user_log_acct,
					province_name,
					year_dt
				from
					dev_xfp.nz_import_user_pool
				group by
					user_log_acct,
					province_name,
					year_dt
			)
			c
		on
			b.user_log_acct = c.user_log_acct
			and b.year_dt = c.year_dt
		group by
			b.year_dt,
			province_name
	)
	tt